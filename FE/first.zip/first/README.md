# ncp-client-firstapperal

## Quickstart

``` sh
npm install

npm run serve
```

build alpha env:
``` sh
npm run build:alpha
```

build production env:
``` sh
npm run build
```

## Docs
* Vue.js Guide: https://vuejs.org/v2/guide/
* Vue.js API: https://vuejs.org/v2/api/
* vue-cli: https://github.com/vuejs/vue-cli/blob/dev/docs/README.md
* vue-router: https://router.vuejs.org/en/
* vuex: https://vuex.vuejs.org/en/
* vuex-rest-api: https://github.com/christianmalek/vuex-rest-api/blob/v2/README.md
