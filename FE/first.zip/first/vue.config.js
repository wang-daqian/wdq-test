module.exports = {
  devServer: {
    port: 80,
    disableHostCheck: true
  },
  configureWebpack: config => {
    if (process.env.NODE_ENV === 'production') {
      config.devtool = false
    }
  }
}
