const utils = {
  chkIsInput: function (input) {
    return input && input.length > 0
  },
  chkName: function (input) {
    let reg = new RegExp(/^[a-zA-Zㄱ-ㅎㅏ-ㅣ가-힣]+$/)
    if (reg.test(input)) {
      return true
    } else {
      return false
    }
  },
  chkPhone: function (input) {
    // let reg = new RegExp(/^\d{10,20}$/)
    let reg = new RegExp(/^\d{11}$/)
    if (reg.test(input)) {
      return true
    } else {
      return false
    }
  },
  chkPassword: function (input) {
    let reg = new RegExp(/^(?=.*[0-9])(?=.*[a-zA-Z])(?=.*[!@#$%^&+=_.()-])[A-Za-z0-9!@#$%^&+=_.()-]{8,20}$/)
    if (reg.test(input)) {
      return true
    } else {
      return false
    }
  },
  chkZipCode: function (input) {
    if (input.length === 5) {
      return true
    }
    return false
  }
}

export default utils
