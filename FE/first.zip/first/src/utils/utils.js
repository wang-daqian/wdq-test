import cookies from 'js-cookie'
import { getToday } from '@/utils/dateUtils'
import { deleteOrderInfoInStorage } from '@/utils/orderUtils'

export function setRecentWords (keywords) {
  let recentWords = JSON.parse(window.localStorage.recentWords || '[]')
  if (recentWords.length) {
    recentWords = recentWords.filter(item => item.word !== keywords)
  }
  recentWords.unshift({
    word: keywords,
    datetime: getToday()
  })
  if (recentWords.length > 10) {
    recentWords = recentWords.filter((item, index) => index < 10)
  }
  window.localStorage.recentWords = JSON.stringify(recentWords)
}

export function delRecentWords (keywords) {
  if (keywords) {
    let recentWords = JSON.parse(window.localStorage.recentWords || '[]')
    recentWords = recentWords.filter(item => item.word !== keywords)
    window.localStorage.recentWords = JSON.stringify(recentWords)
  } else {
    window.localStorage.recentWords = JSON.stringify([])
  }
}

export function logoutRemoveCookie () {
  cookies.remove('ncpMemberId')
  cookies.remove('ncpOauthIdNo')
  cookies.remove('memberStatus')
  cookies.remove('ncpCertificated')
  cookies.remove('memberName')
  cookies.remove('1ST_APPERAL_TOKEN')
  cookies.remove('FstAppShowMemberID')
  cookies.remove('1ST_APPERAL_dormantMember')
  deleteOrderInfoInStorage()
}

export function formatCurrency (num, positive) {
  if (!positive) {
    positive = ''
  }
  if (num) {
    let number = num.toString()

    if (number === '' || isNaN(number)) {
      return num
    }

    if (number.indexOf('-') > 0) {
      return num
    }

    let sign = number.indexOf('-') === 0 ? '-' : positive
    if (sign === '-') {
      number = number.substr(1)
    }

    let cents = number.indexOf('.') > 0 ? number.substr(number.indexOf('.')) : ''
    cents = cents.length > 1 ? cents : ''

    number = number.indexOf('.') > 0 ? number.substring(0, (number.indexOf('.'))) : number

    if (cents === '') {
      if (number.length > 1 && number.substr(0, 1) === '0') {
        return num
      }
    } else {
      if (number.length > 1 && number.substr(0, 1) === '0') {
        return num
      }
    }

    let tempNum = ''
    while (number.length > 3) {
      tempNum = ',' + number.slice(-3) + tempNum
      number = number.slice(0, number.length - 3)
    }
    if (number) {
      tempNum = number + tempNum
    }

    return (sign + tempNum + cents)
  } else {
    return num
  }
}

export function hasClass (elem, cls) {
  cls = cls || ''
  if (cls.replace(/\s/g, '').length === 0) return false
  return new RegExp(' ' + cls + ' ').test(' ' + elem.className + ' ')
}

export function addClass (elem, cls) {
  if (!hasClass(elem, cls)) {
    elem.className = elem.className === '' ? cls : elem.className + ' ' + cls
  }
}

export function removeClass (elem, cls) {
  if (hasClass(elem, cls)) {
    let newClass = ' ' + elem.className.replace(/[\t\r\n]/g, '') + ' '
    while (newClass.indexOf(' ' + cls + ' ') >= 0) {
      newClass = newClass.replace(' ' + cls + ' ', ' ')
    }
    elem.className = newClass.replace(/^\s+|\s+$/g, '')
  }
}

export function scriptLoader (url) {
  return new Promise((resolve, reject) => {
    const script = document.createElement('script')
    script.type = 'text/javascript'
    script.src = url
    script.async = true
    script.addEventListener('load', resolve)
    script.addEventListener('error', reject)
    document.body.appendChild(script)
  })
}

export function platform () {
  const u = navigator.userAgent
  const isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/)
  return isiOS ? 'IOS' : 'AOS'
}

export function loadSearchLogScript () {
  if (window.SearchLog) {
    return Promise.resolve()
  } else {
    return scriptLoader(process.env.VUE_APP_SEARCH_LOG)
  }
}

export function logoutProcess () {
  cookies.remove('1ST_APPERAL_TOKEN')
  cookies.remove('FstAppShowMemberID')
  location.href = '/'
}

export function isLogin () {
  if (!cookies.get('1ST_APPERAL_TOKEN') || cookies.get('1ST_APPERAL_TOKEN').length === 0) {
    return false
  } else {
    return true
  }
}

export function getUrlParam (name) {
  var reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)')
  var r = window.location.search.substr(1).match(reg)
  if (r != null) return decodeURIComponent(r[2]); return null
}

export function getUrlParams (url) {
  url = url.replace(/#.*$/, '')
  var queryArray = url.split(/[?&]/).slice(1)
  var i
  let args = {}
  for (i = 0; i < queryArray.length; i++) {
    var match = queryArray[i].match(/([^=]+)=([^=]+)/)
    if (match !== null) {
      args[match[1]] = decodeURIComponent(match[2])
    }
  }
  return args
}

export function range (start, edge, step) {
  if (arguments.length === 1) {
    edge = start
    start = 0
  }

  edge = edge || 0
  step = step || 1

  for (var ret = []; (edge - start) * step > 0; start += step) {
    ret.push(start)
  }
  return ret
}

export function loginAndBack (router, route) {
  if (!isLogin()) {
    router.push({
      path: '/member/login',
      query: {
        redirect: encodeURIComponent(`${location.protocol}//${location.host}${route.fullPath}`)
      }
    })
    return false
  }
  return true
}

export function shareAndLoadScript (shareObj) {
  if ((shareObj.shareType === 'KT' || shareObj.shareType === 'KS') && !window.Kakao) {
    scriptLoader('https://developers.kakao.com/sdk/js/kakao.min.js').then(() => {
      share(shareObj)
    })
  } else {
    share(shareObj)
  }
}

/* global Kakao */
export function share ({ shareType, targetLink, title, msg, link, linkText, imageLink, imgW, imgH }) {
  const kakaoKey = 'ac745d2fdf6d235a44b5603145148464'
  if (shareType === 'KT') {
    const obj = {}
    if (imageLink !== '') {
      obj.image = { src: imageLink, width: imgW, height: imgH }
    }
    obj.label = msg
    obj.webButton = { url: link, text: '' }
    Kakao.cleanup()
    Kakao.init(kakaoKey)
    Kakao.Link.sendTalkLink(obj)
  } else if (shareType === 'FB') {
    window.open(targetLink, '_blank', 'width=750,height=300,top=100px,left=100px')
  } else if (shareType === 'TW') {
    window.open(targetLink, '_blank', 'width=500,height=250,top=100px,left=100px')
  } else if (shareType === 'PT') {
    window.open(targetLink, '_blank', 'width=750,height=570,top=100px,left=100px')
  } else if (shareType === 'SMS') {
    if (platform.os.family === 'iOS') {
      location.href = `sms:&body=${msg}${link}`
    } else {
      location.href = `sms:?body=${msg}${link}`
    }
  } else if (shareType === 'KS') {
    Kakao.init('')
    // Kakao.Story.cleanup()
    // Kakao.Story.open({
    //   url: link,
    //   text: msg
    // })
    Kakao.Story.share({
      text: '',
      url: link
    })
  }
}

export function isPC () {
  if (/(iPhone|iPad|iPod|iOS|Android)/i.test(navigator.userAgent)) {
    return false
  } else {
    return true
  }
}

export function startWith (src, str) {
  const reg = new RegExp('^' + str)
  return reg.test(src)
}

export function getPathName (src) {
  let pathName = 'main'
  if (src === 'FRENCH CAT') {
    pathName = 'frenchcat'
  } else if (src === 'TIFFANY') {
    pathName = 'tiffany'
  } else if (src === 'ELECONE') {
    pathName = 'elecone'
  } else if (src === 'GUESS KIDS') {
    pathName = 'guesskids'
  } else if (src === 'NUBABY') {
    pathName = 'nubaby'
  }

  return pathName
}

export function haveProductList (data) {
  if (data && data.products && data.products.length) {
    return true
  } else {
    return false
  }
}

export function getDeviceType () {
  if (isPC()) {
    return 'web'
  } else {
    return 'mobile'
  }
}

export function loadWpAstgScripts (type, dispItems) {
  /* eslint-disable */
  window.wptg_tagscript_vars = window.wptg_tagscript_vars || []
  window.wptg_tagscript_vars.push(
    function () {
      return {
        wp_hcuid: cookies.get('FstAppShowMemberID') || '', /* 고객넘버 등 Unique ID (ex. 로그인  ID, 고객넘버 등 )를 암호화하여 대입. 주의 : 로그인 하지 않은 사용자는 어떠한 값도 대입하지 않습니다. */
        ti: '25725',
        ty: type,
        device: getDeviceType(),
        items: dispItems /* i:<?상품 식별번호  (Feed로 제공되는 식별번호와 일치하여야 합니다 .) t:상품명  */
      }
    })
    // console.log(window.wptg_tagscript_vars)
  scriptLoader('//cdn-aitg.widerplanet.com/js/wp_astg_4.0.js').then(() => {
    if (window.wptg_tagscript_history) {
      window.wptg_tagscript_history.history_peak = {}
      window.wptg_tagscript_history.history_ty = {}
    }
    if (window.wptg_tagscript) {
      window.wptg_tagscript.exec()
    }
  })
  
  /* eslint-enable */
}

export function loadAnalysisScript (type, value) {
  return new Promise((resolve, reject) => {
    scriptLoader('https://wcs.naver.net/wcslog.js')

    const script = document.createElement('script')
    script.type = 'text/javascript'
    var _nasa = {}
    /* eslint-disable */
    _nasa['cnv'] = wcs.cnv(type, value)
    wcs_do(_nasa)
    /* eslint-enable */
    script.addEventListener('load', resolve)
    script.addEventListener('error', reject)
    document.body.appendChild(script)
  })
}

export function isIE () {
  if (!!window.ActiveXObject || 'ActiveXObject' in window) {
    return true
  } else {
    return false
  }
}
