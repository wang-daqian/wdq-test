<template>
  <div class="location_wrap location_sp">
    <div class="location_cont">
      <em>
        <a href="javascript:" @click.prevent="clickBrand(brandInfo.label)" class="local_home">{{brandInfo.label}}</a>
        &nbsp;
      </em>
      <template v-for="(menu, index) in listMenu">
        <span :key="`span${index}`"> &gt; </span>
        <location-select :menu="menu" :key="`menu${index}`" />
      </template>
    </div>
  </div>
</template>

<script>
import LocationSelect from '@/components/common/LocationSelect'

export default {
  props: ['brandInfo', 'listMenu'],
  components: {
    LocationSelect
  },
  methods: {
    clickBrand (label) {
      if (label === 'FRENCH CAT') {
        this.$router.push('/frenchcat')
      } else if (label === 'TIFFANY') {
        this.$router.push('/tiffany')
      } else if (label === 'ELECONE') {
        this.$router.push('/elecone')
      } else if (label === 'GUESS KIDS') {
        this.$router.push('/guesskids')
      } else if (label === 'NUBABY') {
        this.$router.push('/nubaby')
      } else {
        this.$router.push('/')
      }
    }
  }
}
</script>

<style>
</style>
