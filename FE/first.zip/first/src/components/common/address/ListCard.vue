<template>
  <div id="road-address-list" style="display:block;">
    <div id="explain_search_count_area" class="explain bg28">
      <div v-if="addresses && addresses.totalCount > 100">
        <u>총
          <span id="explain_search_count">{{addresses.totalCount | formatNumber}}</span>건 중 100건만 보여집니다.</u>
      </div>
      <div>정확한 검색을 위해 지번 또는 건물번호 또는 건물명을 함께 검색해 주세요.</div>
    </div>
    <div class="explain bg28">
      <div>※ 도로명 주소를 모르실 경우
        <a href="http://www.juso.go.kr" target="_blank">www.juso.go.kr</a> 에서 확인 가능합니다.</div>
      <br>아래 주소중에서 해당되는 주소를
      <strong>선택</strong>해 주세요.
      <a href="javascript:" class="explain_reSearch move-back" @click.prevent="goBack">[재검색하기]</a>
    </div>

    <div id="road-address-search-data" v-show="!pending.addresses && !emptyAddresses">
      <table class="address-table">
        <tbody>
          <tr class="address-search-row" v-for="(address, index) in addresses && addresses.items" :key="index">
            <td class="zipcode">{{address.zipCode}}
            </td>
            <td class="address">
              <div class="road">{{address.address}}{{address.detailAddress}}</div>
              <div class="zipcode">{{address.jibunAddress}}{{address.detailAddress}}</div>
            </td>
            <td class="action">
              <a href="javascript:" class="select button-gray" @click.prevent="selectAddress(address)">선택</a>
            </td>
          </tr>
        </tbody>
      </table>
      <br />
      <br />
      <pagination :page="nowPage" :total_count="totalCnt" :page_size="5" :page_term="5" @onPageChange="pageChange" ref="pagination" />
    </div>
    <div v-if="!pending.addresses && emptyAddresses" class="bx_no_result">
      <p>검색어에 대한 결과가 없습니다. <br>지번 또는 도로명을 다시 입력해 주세요.</p>
    </div>
    <div class="action">
      <a class="button-gray move-back" href="javascript:" @click.prevent="goBack">뒤로</a>
    </div>
  </div>
</template>

<script>
import Pagination from '@/components/common/Pagination'
import { mapState } from 'vuex'

export default {
  props: ['nowPage'],
  computed: {
    ...mapState('common', ['addresses', 'pending']),
    emptyAddresses () {
      return this.addresses && this.addresses.items.length === 0
    },
    totalCnt () {
      if (this.addresses && this.addresses.totalCount) {
        return this.addresses.totalCount > 100 ? 100 : this.addresses.totalCount
      } else {
        return 0
      }
    }
  },
  methods: {
    goBack () {
      this.$emit('toSearch')
    },
    selectAddress (address) {
      this.$emit('selectAddress', address)
    },
    pageChange (page) {
      this.$emit('pageChange', page)
    }
  },
  components: {
    Pagination
  }
}
</script>
