<template>
  <div id="address_layerPopup">
    <div class="responsive">
      <h1 class="hide-text">주소찾기</h1>
      <a id="close" class="hide-text" href="javascript:" @click.prevent="closePop(false)">닫기</a>

      <div id="main-content">
        <div id="road-address-content" class="address-content active search">
          <search-card :beSearchKey="searchKey" @search="search" v-if="showCard === 'search'" />
          <list-card :nowPage="nowPage" @toSearch="toSearch" @selectAddress="selectAddress" @pageChange="pageChange" v-if="showCard === 'list'" />
          <sub-card :address="selectedAddress" @toList="toList" @returnAddress="returnAddress" v-if="showCard === 'sub'" />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import SearchCard from '@/components/common/address/SearchCard'
import ListCard from '@/components/common/address/ListCard'
import SubCard from '@/components/common/address/SubCard'

export default {
  data () {
    return {
      showCard: 'search',
      searchKey: '',
      nowPage: 1,
      selectedAddress: {}
    }
  },
  methods: {
    closePop (selected, address) {
      this.$emit('closePop', selected, address)
    },
    search (searchKey) {
      if (!searchKey || !searchKey.trim()) {
        alert('검색어를 입력해주세요.')
        return
      }
      this.showCard = 'list'
      this.searchKey = searchKey

      this.pageChange(1)
    },
    toSearch () {
      this.showCard = 'search'
    },
    selectAddress (address) {
      this.selectedAddress = address
      this.showCard = 'sub'
    },
    pageChange (page) {
      this.nowPage = page
      const params = {
        keyword: this.searchKey,
        pageNumber: page
      }
      this.$store.dispatch('common/fetchAddresses', params)
    },
    toList () {
      this.showCard = 'list'
    },
    returnAddress (res) {
      this.closePop(true, res)
    }
  },
  components: {
    SearchCard,
    ListCard,
    SubCard
  }
}
</script>
<style>
#address_layerPopup {
  width: 100%;
  height: 100%;
  position: fixed;
  left: 0;
  top: 0;
  z-index: 999999;
}
</style>
