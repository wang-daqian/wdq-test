<template>
  <form id="road-address-confirm" name="form-confirm-road" style="display:block;">
    <div class="zipcode">
      <input class="zonecode" type="text" readonly="readonly" disabled="disabled" style="background-color: rgb(255, 255, 255); color: rgb(0, 0, 0); " :value="address.zipCode">
    </div>
    <div class="address">
      <input class="address" type="text" readonly="readonly" disabled="disabled" style="background-color: rgb(255, 255, 255); color: rgb(0, 0, 0);" :value="address.jibunAddress">
      <div class="road-address-confirm-display">
        도로명주소 :{{address.address}}
        <span id="road-address-confirm-value"></span>
      </div>
    </div>
    <div class="address2-description">나머지 주소를 입력하신 후 '주소입력' 버튼을 눌러주세요.</div>
    <div class="address-sub">
      <input id="address_sub" name="address_sub" class="address-sub" type="text" v-model="addressSub">
      <input id="hiddenText" type="text" style="display:none" />
    </div>
    <div class="action">
      <a class="button-gray move-back" href="javascript:" @click.prevent="goBack">뒤로</a>
      <a class="button-blue" href="javascript:" @click.prevent="onEnterAddress">주소입력</a>
    </div>
  </form>
</template>

<script>
export default {
  props: ['address'],
  data () {
    return {
      addressSub: ''
    }
  },
  methods: {
    goBack () {
      this.addressSub = ''
      this.$emit('toList')
    },
    onEnterAddress () {
      this.$emit('returnAddress', {
        zipCd: this.address.zipCode,
        address: this.address.address,
        addressSub: this.addressSub,
        receiverJibunAddress: this.address.jibunAddress
      })
    }
  },
  mounted () {
    document.getElementById('address_sub').addEventListener('focusout', function () {
      setTimeout(function () {
        window.scrollTo(0, 0)
      }, 100)
    })
  }
}
</script>
