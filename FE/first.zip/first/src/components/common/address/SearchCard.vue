<template>
  <div id="road-address-search" style="display:block;">
    <div class="description">
      <ul>
        <li>지번 또는 도로명 주소로 검색이 가능합니다.</li>
        <li>도로명 주소를 모르실 경우
          <a href="http://www.juso.go.kr" target="_blank">www.juso.go.kr</a> 에서 확인 가능합니다.</li>
        <li>'시/도'와 '시/군/구' 선택 후, 주소명을 입력해 주세요.</li>
        <li>주소명의 키워드는 공백으로 구분되어야 검색이 가능합니다.</li>
      </ul>
    </div>
    <div class="keyword_description">키워드 : 동(읍/면)명, 지번, 도로명, 건물번호, 건물명</div>
    <form id="road-address-search-form">
      <div class="group address_search_name">
        <div class="field">
          <label for="address_search_name">주소명</label>
          <div class="input-wrapper">
            <input id="address_search_name" name="address_search_name" type="text" placeholder="(예: 영동대로 513, 삼성동 159, 코엑스)" v-model="searchKey" @keypress.enter="search">
            <input id="hiddenText" type="text" style="display:none" />
          </div>
          <a class="button-blue" href="javascript:" @click.prevent="search">검색</a>
        </div>
      </div>
    </form>
  </div>
</template>

<script>
export default {
  props: ['beSearchKey'],
  data () {
    return {
      searchKey: ''
    }
  },
  methods: {
    search () {
      this.$emit('search', this.searchKey)
    }
  },
  mounted () {
    this.searchKey = this.beSearchKey
    document.getElementById('address_search_name').addEventListener('focusout', function () {
      setTimeout(function () {
        window.scrollTo(0, 0)
      }, 100)
    })
  }
}
</script>
