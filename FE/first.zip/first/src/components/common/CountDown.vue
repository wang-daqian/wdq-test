<template>
  <p class="cd">유효시간
    <span>{{rocallTime}}</span>
  </p>
</template>
<script>
export default {
  props: ['countTime'],
  data () {
    return {
      rocallTime: this.countTime,
      countDownTime: this.countTime,
      intervalID: 0
    }
  },
  methods: {
    formatCountDownTime (countTime) {
      if (countTime > 0) {
        countTime > 60000
          ? (this.rocallTime =
            (new Date(countTime).getMinutes() < 10
              ? '0' + new Date(countTime).getMinutes()
              : new Date(countTime).getMinutes()) +
            ':' +
            (new Date(countTime).getSeconds() < 10
              ? '0' + new Date(countTime).getSeconds()
              : new Date(countTime).getSeconds()))
          : (this.rocallTime =
            '00:' +
            (new Date(countTime).getSeconds() < 10
              ? (new Date(countTime).getSeconds() === 0 ? '60' : '0' + new Date(countTime).getSeconds())
              : new Date(countTime).getSeconds()))
      } else {
        this.rocallTime = '00:00'
      }
    },
    runBack () {
      this.countDownTime = this.countDownTime - 1000

      if (this.countDownTime > 0) {
        this.formatCountDownTime(this.countDownTime)
      } else {
        this.rocallTime = '00:00'
        this.changeState()
      }
    },
    changeState () {
      this.$emit('verifyPCodeCallBack')
    },
    reStartCountTime (time) {
      this.rocallTime = time
      this.countDownTime = time
      this.countTime = time
      this.formatCountDownTime(this.countTime)
      this.intervalID = self.setInterval(this.runBack, 1000)
    },
    stopCountTime () {
      window.clearInterval(this.intervalID)
    }
  },
  mounted () {
    this.formatCountDownTime(this.countTime)
    this.intervalID = self.setInterval(this.runBack, 1000)
  }
}
</script>
