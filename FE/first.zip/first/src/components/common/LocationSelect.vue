<template>
  <div class="location_select" @mouseover="showFlg = true" @mouseout="showFlg = false">
    <div class="location_tit">
      <a href="javascript:">
        <span>{{menu.selectItem.label}}</span>
      </a>
    </div>
    <ul :style="showFlg ? 'display: block;' : 'display: none;'">
      <li v-for="(item, i) in menu.items" :key="i">
        <router-link :to="item.link_to">
          <span>{{item.label}}</span>
        </router-link>
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  props: ['menu'],
  data () {
    return {
      showFlg: false
    }
  }
}
</script>

<style>
</style>
