<template>
  <div :class="['layer_wrap', {'zoom_layer' : isPC}, {'ss_layer' : !isPC}]" v-if="openLayer">
    <div id="ly_zoom_wrap" class="layer_wrap_cont" :style="ly_style" v-if="isPC">
      <div class="ly_tit">
        <h4>
          상품후기 이미지
          <span>{{productName}} {{managementCd | dispManageCode}}</span>
        </h4>
      </div>
      <div class="ly_cont">
        <div class="item_photo_view_box">
          <div class="item_photo_view">
            <div class="item_photo_big" id="magnifyImage">
              <span class="img_photo_big">
                <img :src="mainImage" width="500" class="middle">
              </span>
            </div>
            <!-- //item_photo_big -->
            <div class="item_photo_slide">
              <button type="button" class="slick_goods_prev arrows_btn" @click.prevent="slickPrev">
                <img src="../../assets/img/common/btn/btn_vertical_prev.png" alt="이전 상품 이미지">
              </button>
              <ul class="slider_wrap ly_slider_goods_nav">
                <slick ref="slick" :options="slickOptions">
                  <li v-for="(item, index) in imgUrls" :key="index">
                    <a href="javascript:" @click.prevent="gdChangeImage(index)">
                      <img :src="item" width="68" class="middle">
                    </a>
                  </li>
                </slick>
              </ul>
              <button type="button" class="slick_goods_next arrows_btn" @click.prevent="slickNext">
                <img src="../../assets/img/common/btn/btn_vertical_next.png" alt="다음 상품 이미지">
              </button>
            </div>
          </div>
        </div>
      </div>
      <!-- //ly_cont -->
      <a href="javascript:" class="ly_close layer_close" @click.prevent="closeLayer">
        <img src="../../assets/img/common/layer/btn_layer_close.png" alt="닫기">
      </a>
    </div>
    <div id="sslyZoom_wrap" class="layer_wrap_cont" :style="ly_style" v-else>
      <div class="layer_ss_list">
        <div class="item_slide_horizontal">
          <ul class="slide_horizontal goods_sp">
            <slick ref="slick" :options="spSlickOptions">
              <li v-for="(item, index) in imgUrls" :key="index">
                <div class="ss_img">
                  <img :src="item" class="middle">
                </div>
              </li>
            </slick>
          </ul>
        </div>
      </div>

      <a href="#close" class="ly_close layer_close" @click.prevent="closeLayer">
        <img src="../../assets/img/common/layer/btn_layer_close.png" alt="닫기">
      </a>
    </div>
  </div>
</template>

<script>
import Slick from 'vue-slick'
import $ from 'jquery'
import { isPC } from '@/utils/utils'

export default {
  props: ['imgUrls', 'clickInx', 'productName', 'managementCd', 'openLayer'],
  data () {
    return {
      mainImageIndex: 0,
      ly_style: '',
      slickOptions: {
        vertical: true,
        arrows: false,
        draggable: false,
        autoplay: false,
        infinite: false,
        slidesToShow: 5,
        slidesToScroll: 1
      },
      spSlickOptions: {
        initialSlide: 0,
        draggable: false,
        autoplay: false,
        infinite: false,
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }
  },
  computed: {
    mainImage () {
      return this.imgUrls[this.mainImageIndex]
    },
    isPC () {
      return isPC()
    }
  },
  components: {
    Slick
  },
  methods: {
    gdChangeImage (index) {
      this.mainImageIndex = index
    },
    closeLayer () {
      this.$emit('close')
    },
    slickPrev () {
      this.mainImageIndex--
      this.mainImageIndex = this.mainImageIndex < 0 ? 0 : this.mainImageIndex
      this.$refs.slick.prev()
    },
    slickNext () {
      this.mainImageIndex++
      this.mainImageIndex = this.mainImageIndex >= this.imgUrls.length ? this.imgUrls.length - 1 : this.mainImageIndex
      this.$refs.slick.next()
    },
    showInit () {
      this.$nextTick(() => {
        const outerHeight = isPC() ? $('#ly_zoom_wrap').outerHeight() : $('#sslyZoom_wrap').outerHeight()
        const outerWidth = isPC() ? $('#ly_zoom_wrap').outerWidth() : $('#sslyZoom_wrap').outerWidth()
        const top = ($(window).height() - outerHeight) / 2
        const left = ($(window).width() - outerWidth) / 2
        this.ly_style = `position: absolute; margin: 0px; top: ${top > 0 ? top : 0}px; left: ${left > 0 ? left : 0}px;`
      })
      if (this.openLayer) {
        this.mainImageIndex = this.clickInx
        this.spSlickOptions.initialSlide = this.clickInx
      }
    }
  },
  watch: {
    'openLayer': 'showInit'
  }
}
</script>

<style>
</style>
