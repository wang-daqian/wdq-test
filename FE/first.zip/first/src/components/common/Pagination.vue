<template>
  <div class="pagination">
    <a href="#" class="prev" @click.prevent="prev">이전으로</a>
    <a href="#" :class="{ now : n === current_page}" v-for="(n, index) in range(startIdx, endIdx)" :key="index" @click.prevent="pageChange(n)">{{ n }}</a>
    <a href="#" class="next" @click.prevent="next">다음으로</a>
  </div>
</template>
<script>
import { range } from '@/utils/utils'

function getStartIdx (currentPage, pageTerm) {
  return Math.floor(currentPage / pageTerm) * pageTerm + (currentPage % pageTerm !== 0 ? 1 : (1 - pageTerm))
}
export default {
  data () {
    return {
      current_page: this.page
    }
  },
  props: {
    page: {
      type: Number,
      required: false,
      default: 1
    },
    total_count: {
      type: Number,
      required: true
    },
    page_size: {
      type: Number,
      required: false,
      default: 10
    },
    page_term: {
      type: Number,
      required: false,
      default: 5
    }
  },
  computed: {
    pageCount () {
      return Math.ceil(this.total_count / this.page_size)
    },
    startIdx () {
      return getStartIdx(this.current_page, this.page_term)
    },
    endIdx () {
      return Math.min(this.startIdx + this.page_term, this.pageCount + 1)
    }
  },
  methods: {
    prev () {
      // if (this.current_page - this.page_term > 0) {
      //   this.pageChange(getStartIdx(this.current_page - this.page_term, this.page_term) + this.page_term - 1)
      // }
      if (this.current_page > 1) {
        this.pageChange(getStartIdx(this.current_page - 1, 1))
      }
    },
    next () {
      // let nextPage = getStartIdx(this.current_page + this.page_term, this.page_term)
      let nextPage = getStartIdx(this.current_page + 1, 1)
      if (nextPage <= this.pageCount) {
        this.pageChange(nextPage)
      }
    },
    pageChange (_page) {
      if (this.current_page !== _page) {
        this.current_page = _page
        this.$emit('onPageChange', _page)
      }
    },
    reset () {
      this.current_page = 1
    },
    range (start, end) {
      return range(start, end)
    }
  },
  watch: {
    page (a) {
      this.pageChange(a)
    }
  }
}
</script>
<style>
/* pagination */
.pagination {
  width: 100%;
  font-size: 0;
  text-align: center;
}
.pagination a {
  display: inline-block;
  position: relative;
  height: 30px;
  padding: 0 10px;
  border: 1px solid #dedede;
  border-radius: 15px;
  box-sizing: border-box;
  background-color: transparent;
  font-family: 'mtsr', sans-serif;
  font-size: 14px;
  color: #9b9b9b;
  line-height: 30px;
  text-align: center;
}
.pagination a + a {
  margin-left: 20px;
}
.pagination a:nth-child(2) {
  margin-left: 15px;
}
.pagination .now {
  border-color: #9b9b9b;
  background-color: #9b9b9b;
  font-weight: 500;
  color: #fff;
}
.pagination .prev,
.pagination .next {
  border-color: transparent;
  font-size: 0;
  vertical-align: top;
}
.pagination .prev:before,
.pagination .next:before {
  position: absolute;
  top: 50%;
  left: 50%;
  width: 9px;
  height: 9px;
  margin: -5px 0 0 -5px;
  border: 1px solid #9b9b9b;
  border-top: 0;
  border-left: 0;
  transform: rotate(135deg);
  content: '';
}
.pagination .next {
  margin-left: 15px;
}
.pagination .next:before {
  transform: rotate(315deg);
}
</style>
