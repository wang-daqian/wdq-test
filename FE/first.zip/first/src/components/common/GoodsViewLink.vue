<template>
  <router-link :to="viewUrl" @click.native="clickLink">
    <slot></slot>
  </router-link>
</template>

<script>
export default {
  props: ['product'],
  computed: {
    viewUrl () {
      if (this.product.brandNameEn) {
        return `/${this.product.brandNameEn}/goods/view/${this.product.productNo}`
      } else {
        return `/goods/view/${this.product.productNo}`
      }
    }
  },
  methods: {
    clickLink () {
      this.$emit('clickLink')
    }
  }
}
</script>
