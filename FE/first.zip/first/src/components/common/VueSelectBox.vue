<template>
  <div :class="['chosen-container chosen-container-single chosen-container-single-nosearch', {'chosen-with-drop chosen-container-active' : showItem}]" v-click-outside="closeItem" :style="{width:this.width,'margin-left':noLeftMargin?'':'5px'}">
    <a class="chosen-single" @click.prevent="showItem = !showItem">
      <span v-for="(item, index) in items" :key="index" v-if="item.value == showValue">{{item.label}}</span>
      <div>
        <b></b>
      </div>
    </a>
    <div class="chosen-drop">
      <ul class="chosen-results">
        <li class="active-result" v-for="(item, index) in items" :key="index" @click.prevent="selected(item.label, item.value)">{{item.label}}</li>
      </ul>
    </div>
  </div>
</template>

<script>
import ClickOutside from 'vue-click-outside'

export default {
  props: ['showValue', 'items', 'width', 'noLeftMargin'],
  directives: {
    ClickOutside
  },
  data () {
    return {
      showItem: false
    }
  },
  methods: {
    closeItem () {
      this.showItem = false
    },
    selected (label, value) {
      this.showItem = false
      this.$emit('selected', value)
    }
  }
}
</script>

<style>
</style>
