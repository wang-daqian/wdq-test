<template>
  <div id="joinPop" class="layer_wrap dn" style="display: block !important;">
    <div class="layer_wrap_cont">
      <div class="ly_cont">
        <div class="scroll_box">
          <pre>
          {{textMsg}}
         </pre>
        </div>
        <!-- // -->
        <div class="btn_center_box">
          <button type="button" class="btn_ly_password js_submit" @click.prevent="onConfirm">
            <strong>확인</strong>
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: ['textMsg'],
  methods: {
    onConfirm () {
      this.$emit('confirmCallback')
    }
  }
}
</script>
