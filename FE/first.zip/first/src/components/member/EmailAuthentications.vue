<template>
  <tr>
    <th>
      <span class="important">이메일</span>
    </th>
    <td class="member_email">
      <div class="member_warning">
        <input type="text" ref="emailName" id="emailName" autocomplete="off" v-model="prefixEmailName" placeholder="이메일" class="exsmall" @blur="emailCheck(false)">
        <span class="email_icon">@</span>
        <input type="text" ref="emailDomain" autocomplete="off" id="emailDomain" v-model="myInput.emailDomain" class="small" @blur="emailCheck(false)">
        <vue-select-box :showValue="selectValue" :items="selectDomainItems" @selected="setDomain" :width="seletBoxWidth" />
      </div>
      <div v-if="!emailPassed" class="warning_1">{{emailPassedTxt}}</div>
    </td>
  </tr>
</template>

<script>
import { mapState, mapActions } from 'vuex'
import VueSelectBox from '@/components/common/VueSelectBox'
import { hasUpperCode } from '@/utils/stringUtils'

export default {
  data () {
    return {
      selectValue: '',
      selectDomainItems: [
        {
          label: '직접입력',
          value: ''
        },
        {
          label: 'naver.com',
          value: 'naver.com'
        },
        {
          label: 'hanmail.net',
          value: 'hanmail.net'
        },
        {
          label: 'daum.net',
          value: 'daum.net'
        },
        {
          label: 'gmail.com',
          value: 'gmail.com'
        },
        {
          label: 'hotmail.com',
          value: 'hotmail.com'
        },
        {
          label: 'nate.com',
          value: 'nate.com'
        },
        {
          label: 'yahoo.co.kr',
          value: 'yahoo.co.kr'
        },
        {
          label: 'yahoo.com',
          value: 'yahoo.com'
        }
      ],
      myInput: {
        emailName: '',
        emailDomain: '',
        prefixEmailName: '',
        certificatedNumber: ''
      },
      seletBoxWidth: '120px',
      emailPassed: true,
      emailPassedTxt: '',
      emailAuthPassed: false,
      emailValidate: true
    }
  },

  props: ['prefixName', 'domain'],

  components: {
    VueSelectBox
  },

  watch: {
    prefixName () {
      if (this.prefixName && this.prefixName !== '') {
        this.myInput.prefixEmailName = this.prefixName
        this.emailPCodeVerifiedOK = true
      }
    },
    domain () {
      if (this.domain && this.domain !== '') {
        this.myInput.emailDomain = this.domain
      }
    }
  },

  computed: {
    ...mapState('authentication', ['authenticationRes']),

    showSelectValue () {
      if (this.selectValue === '') {
        return '직접입력'
      } else {
        return this.selectValue
      }
    },
    prefixEmailName: {
      get () {
        return this.myInput.prefixEmailName
      },
      set (value) {
        this.myInput.prefixEmailName = value
      }
    },
    getEmail () {
      if (this.myInput.prefixEmailName && this.myInput.prefixEmailName !== '') {
        return this.myInput.prefixEmailName + '@' + this.myInput.emailDomain
      } else if (this.myInput.prefixEmailName === '' && this.myInput.emailDomain === '') {
        return ''
      }
    }
  },
  methods: {
    ...mapActions('authentication', ['authentications', 'certiAuthentications']),

    emailCheck (isCheckBtnClicked) {
      let isValigate = true
      this.emailValidate = true
      this.emailPassedTxt = ''

      if (this.myInput.prefixEmailName === this.prefixName && this.myInput.emailDomain === this.domain) {
        return true
      }

      if (this.myInput.prefixEmailName !== '' || this.myInput.emailDomain !== '') {
        if (hasUpperCode(this.myInput.prefixEmailName)) {
          this.emailPassedTxt = '이메일 주소가 유효하지 않습니다.'
          this.emailPassed = false
          this.emailValidate = false
          return false
        }
        let reg1 = /^([A-Za-z0-9_\-.])+$/
        if (!reg1.test(this.myInput.prefixEmailName)) {
          // this.$refs.emailName.focus()
          this.emailPassedTxt = '이메일 주소가 유효하지 않습니다.'
          isValigate = false
        }

        let reg2 = /^([A-Za-z0-9-._])+\.([A-Za-z]{2,4})$/
        if (!reg2.test(this.myInput.emailDomain)) {
          // this.$refs.emailDomain.focus()
          this.emailPassedTxt = '이메일 주소가 유효하지 않습니다.'
          isValigate = false
        }

        if (isValigate) {
          this.emailPassed = true
        } else {
          this.emailPassed = false
        }
      } else {
        this.emailPassedTxt = '이메일을 입력해 주세요.'
        isValigate = false
        this.emailPassed = false
      }

      return isValigate
    },

    regCheckEmail () {
      let isValigate = true
      this.emailValidate = true

      if (this.myInput.prefixEmailName === this.prefixName && this.myInput.emailDomain === this.domain) {
        return true
      } else if (this.myInput.prefixEmailName !== '' && this.myInput.emailDomain !== '') {
        if (hasUpperCode(this.myInput.prefixEmailName)) {
          this.emailPassedTxt = '이메일 주소가 유효하지 않습니다.'
          this.emailPassed = false
          this.emailValidate = false
          return false
        }

        let reg1 = /^([A-Za-z0-9_\-.])+$/
        if (!reg1.test(this.myInput.prefixEmailName)) {
          this.emailPassedTxt = '이메일 주소가 유효하지 않습니다.'
          isValigate = false
        }

        let reg2 = /^([A-Za-z0-9-._])+\.([A-Za-z]{2,4})$/
        if (!reg2.test(this.myInput.emailDomain)) {
          this.emailPassedTxt = '이메일 주소가 유효하지 않습니다.'
          isValigate = false
        }
      } else {
        this.emailPassedTxt = '이메일을 입력해 주세요.'
        isValigate = false
        this.emailPassed = false
      }

      return isValigate
    },
    resetEmailInput () {
      this.emailPCodeVerifiedOK = false
      this.emailAuthPassed = false
      this.emailPassed = true
      this.myInput.certificatedNumber = ''
    },
    setDomain (domain) {
      this.selectValue = domain
      this.myInput.emailDomain = domain
      this.mEmail = this.myInput.prefixEmailName + '@' + this.myInput.emailDomain

      this.emailCheck(false)
    },
    focusEmailName () {
      this.$refs.emailName.focus()
    }
  }
}
</script>
