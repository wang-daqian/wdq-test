<template>
  <tr>
    <th>
      <span class="important">휴대전화</span>
    </th>
    <td class="member_add_tel">
      <div v-if="!mobilePCodeVerifiedOK" class="member_warning">
        <vue-select-box :showValue="selectMobileValue" :items="selectMobileItems" @selected="setMobliePrefix" :width="seletBoxWidth" :noLeftMargin="true" />
        <div :class="myInput.mbPriorWrong?'member_warning prior_wrong':'member_warning'">
          <input class="cellphone" type="text" ref="mobilePhone" maxlength="8" placeholder="-  없이 숫자만 입력하세요." v-model="myInput.mobile" @keydown="gdNum" @input="gdNum" @blur="mobileCheck(false)" :style="{'margin-left':'5px'}">
        </div>
        <button type="button" ref="btnMobilePostCode" class="btn_sec btn_war_2" @click.prevent="mobileAuthen">인증번호 발송</button>
      </div>
      <div v-else class="member_warning">
        <div class="chosen-container chosen-container-single chosen-container-single-nosearch" style="width: 120px;">
          <a class="chosen-single disabled">
            <span>{{selectMobileValue}}</span>
            <div>
              <b></b>
            </div>
          </a>
        </div>
        <input class="cellphone disabled" type="text" ref="mobilePhone" maxlength="8" v-model="myInput.mobile" :style="{'margin-left':'5px'}" disabled>
        <button type="button" class="btn_sec btn_war_2" @click.prevent="btnMobileReset">재인증</button>
      </div>
      <div v-if="!mobilePassed" class="warning_1">{{mobilePassedTxt}}</div>
      <div class="member_warning js_email"></div>
      <div v-if="mobileAuthPassed && !mobilePCodeVerifiedOK" class="addLine">
        <div class="member_warning">
          <input type="text" id="memIdcode" class="input_code" v-model="myInput.mbCertiNumber" placeholder="인증번호를 입력하세요.">
          <count-down ref="mbCountDown" @verifyPCodeCallBack="mbPCodeCallBack" :countTime="mobilePostCodeTime"></count-down>
          <button type="button" class="btn_sec" @click="verifyMbPostCode">확인</button>
          <p v-if="mobilePCodeVerified" class="warning_1">{{mobileVerifyTxt}}</p>
        </div>
      </div>
    </td>
  </tr>
</template>

<script>
import { mapState, mapActions } from 'vuex'
import VueSelectBox from '@/components/common/VueSelectBox'
import CountDown from '@/components/common/CountDown'
import { replacePattern } from '@/utils/validateUtils'

export default {
  data () {
    return {
      seletBoxWidth: '120px',
      mobileAuthPassed: false,
      mobilePostCodeTime: 5 * 60 * 1000,
      mobilePCodeTimeOut: false,
      mobilePCodeVerified: false,
      mobilePCodeVerifiedOK: false,
      mobileVerifyTxt: '',
      selectMobileValue: '010',
      selectMobileItems: [
        {
          label: '010',
          value: '010'
        },
        {
          label: '011',
          value: '011'
        },
        {
          label: '016',
          value: '016'
        },
        {
          label: '017',
          value: '017'
        },
        {
          label: '018',
          value: '018'
        },
        {
          label: '019',
          value: '019'
        }
      ],
      myInput: {
        mobile: '',
        mbPriorWrong: false,
        prefixMobile: '010',
        mbCertiNumber: ''
      },
      mobilePassed: true,
      mobilePassedTxt: ''
    }
  },
  props: ['prefixMobileNo', 'mobileNo', 'from'],
  watch: {
    prefixMobileNo () {
      if (this.prefixMobileNo && this.prefixMobileNo !== '') {
        this.selectMobileValue = this.prefixMobileNo
        this.myInput.prefixMobile = this.prefixMobileNo
        this.mobilePCodeVerifiedOK = true
      }
    },
    mobileNo () {
      if (this.mobileNo && this.mobileNo !== '') {
        this.myInput.mobile = this.mobileNo
      }
    }
  },
  components: {
    VueSelectBox,
    CountDown
  },
  computed: {
    ...mapState('member', ['idCheckRes']),
    ...mapState('authentication', ['authenticationRes']),

    getMobileNum () {
      return this.myInput.prefixMobile + this.myInput.mobile
    },
    getSmsAuthKey () {
      return this.myInput.mbCertiNumber
    }
  },
  methods: {
    ...mapActions('authentication', ['authentications', 'certiAuthentications']),

    mobileCheck (isCheckBtnClicked, isRegCheck) {
      let isValigate = true

      if (this.myInput.prefixMobile === this.prefixMobileNo && this.myInput.mobile === this.mobileNo) {
        return true
      }

      if (this.myInput.mobile === '' || this.myInput.mobile.length < 7 || this.myInput.mobile.length > 8) {
        if (isRegCheck) {
        } else {
          // this.$refs.mobilePhone.focus()
        }
        this.mobilePassedTxt = '정확한 휴대폰 번호를 입력해 주세요. '
        this.mobilePassed = false
        isValigate = false
      } else {
        let reg = /^\d*$/
        if (!reg.test(this.myInput.mobile)) {
          if (isRegCheck) {
          } else {
            // this.$refs.mobilePhone.focus()
          }
          this.mobilePassedTxt = '정확한 휴대폰 번호를 입력해 주세요. '
          isValigate = false
          this.mobilePassed = false
        } else {
          isValigate = true
        }
      }

      if (isValigate) {
        this.myInput.mbPriorWrong = false
        if (isCheckBtnClicked) {
          this.mobilePassed = true
        } else {
          this.mobilePassed = false
          this.mobilePassedTxt = '휴대폰 번호인증을 진행해 주세요.'
        }
        if (isRegCheck) {
          if (this.mobilePCodeVerifiedOK) {
            this.mobilePassed = true
            return true
          } else {
            return false
          }
        } else {
          //  this.$refs.btnMobilePostCode.focus()
        }
      } else {
        this.myInput.mbPriorWrong = true
      }
      return isValigate
    },

    async mobileAuthen () {
      if (this.$refs.mbCountDown) {
        this.$refs.mbCountDown.stopCountTime()
        this.mobilePostCodeTime = 5 * 60 * 1000

        this.mobilePassed = true
        this.mobilePCodeTimeOut = false
        this.mobilePCodeVerified = false
      }

      if (this.mobileCheck(true)) {
        const mobileData = {
          notiAccount: this.getMobileNum,
          type: 'SMS',
          usage: this.from
        }
        await this.authentications(mobileData).then(() => {
          this.$emit('showSmsAuthenPop')
        }).catch((e) => {
          this.mobilePassedTxt = '재인증 클릭 . '
          this.mobilePassed = false
        })
      }
    },
    reStartCountTime () {
      this.mobileAuthPassed = true
      if (this.$refs.mbCountDown) {
        this.$refs.mbCountDown.reStartCountTime(this.mobilePostCodeTime)
      }
    },
    mbPCodeCallBack () {
      this.mobilePCodeTimeOut = true
      this.mobilePCodeVerified = true
      this.mobileVerifyTxt = '유효시간 경과되었습니다. 다시 [인증번호 발송] 클릭하여 발급된 인증번호를 입력해 주세요.'
    },
    async verifyMbPostCode () {
      const mobileData = {
        notiAccount: this.getMobileNum,
        certificatedNumber: this.myInput.mbCertiNumber,
        usage: this.from,
        type: 'SMS'
      }
      if (this.myInput.mbCertiNumber !== '' && this.mobilePCodeTimeOut === false) {
        await this.certiAuthentications(mobileData).then(() => {
          if (this.authenticationRes && this.authenticationRes.remainTime > 0) {
            this.mobilePCodeVerifiedOK = true
          }
        }).catch((e) => {
          this.mobilePCodeVerified = true
          this.mobileVerifyTxt = '올바른 인증번호가 아닙니다.'
        })
      }
    },
    btnMobileReset () {
      this.mobilePCodeVerifiedOK = false
      this.mobileAuthPassed = false
      this.mobilePassed = true
      this.myInput.mbCertiNumber = ''
    },
    gdNum: function () {
      if (this.myInput.mobile !== '') {
        this.myInput.mobile = replacePattern(this.myInput.mobile, /[^\d]/g, '')
      }
    },
    setMobliePrefix (value) {
      this.selectMobileValue = value
      this.myInput.prefixMobile = value
    },
    focusMobile () {
      this.$refs.mobilePhone.focus()
    }
  }
}
</script>
