<template>
  <tr>
    <th>
      <span class="important">이메일</span>
    </th>
    <td class="member_email">
      <div v-if="!emailPCodeVerifiedOK" class="member_warning">
        <input type="text" ref="emailName" id="emailName" autocomplete="off" v-model="prefixEmailName" placeholder="이메일" class="exsmall" @blur="emailCheck(false)" @focus="onFoucsPreName">
        <span class="email_icon">@</span>
        <input type="text" ref="emailDomain" autocomplete="off" id="emailDomain" v-model="myInput.emailDomain" class="small" @blur="emailCheck(false)" @focus="onFoucsDomain">
        <vue-select-box :showValue="selectValue" :items="selectDomainItems" @selected="setDomain" :width="seletBoxWidth" />
        <button type="button" ref="btnEmailPostCode" class="btn_sec btn_war_1" @click.prevent="emailAuthen" :disabled="!emailValidate">이메일 인증</button>
      </div>
      <div v-else class="member_warning">
        <input type="text" ref="emailName" v-model="prefixEmailName" readonly="readonly" class="exsmall disabled">
        <span class="email_icon">@</span>
        <input type="text" id="emailDomain" ref="emailDomain" v-model="myInput.emailDomain" readonly="readonly" class="small disabled">
        <div class="chosen-container chosen-container-single chosen-container-single-nosearch" style="width: 120px;" :style="{'margin-left':'5px'}">
          <a class="chosen-single disabled">
            <span>{{showSelectValue}}</span>
            <div>
              <b></b>
            </div>
          </a>
        </div>
        <button type="button" ref="btnEmailPostCode" class="btn_sec btn_war_1" @click.prevent="resetEmailInput">이메일 재인증</button>
      </div>
      <div v-if="!emailPassed && !emailPCodeVerifiedOK" class="warning_1">{{emailPassedTxt}}</div>
      <div class="member_warning js_email"></div>
      <div v-if="emailAuthPassed && !emailPCodeVerifiedOK" class="addLine">
        <div class="member_warning">
          <input type="text" id="memIdcode" class="input_code" v-model="myInput.certificatedNumber" placeholder="인증번호를 입력하세요.">
          <count-down ref="emailCountDown" @verifyPCodeCallBack="emailPCodeCallBack" :countTime="emailPostCodeTime"></count-down>
          <button type="button" class="btn_sec" @click="verifyEmailPostCode">확인</button>
        </div>
        <div v-if="emailPCodeVerified" class="warning_1">{{emailVerifyTxt}}</div>
      </div>
    </td>
  </tr>
</template>

<script>
import { mapState, mapActions } from 'vuex'
import VueSelectBox from '@/components/common/VueSelectBox'
import CountDown from '@/components/common/CountDown'
import { hasUpperCode } from '@/utils/stringUtils'

export default {
  data () {
    return {
      selectValue: '',
      selectDomainItems: [
        {
          label: '직접입력',
          value: ''
        },
        {
          label: 'naver.com',
          value: 'naver.com'
        },
        {
          label: 'hanmail.net',
          value: 'hanmail.net'
        },
        {
          label: 'daum.net',
          value: 'daum.net'
        },
        {
          label: 'gmail.com',
          value: 'gmail.com'
        },
        {
          label: 'hotmail.com',
          value: 'hotmail.com'
        },
        {
          label: 'nate.com',
          value: 'nate.com'
        },
        {
          label: 'yahoo.co.kr',
          value: 'yahoo.co.kr'
        },
        {
          label: 'yahoo.com',
          value: 'yahoo.com'
        }
      ],
      myInput: {
        emailName: '',
        emailDomain: '',
        prefixEmailName: '',
        certificatedNumber: ''
      },
      seletBoxWidth: '120px',
      emailPassed: true,
      emailPassedTxt: '',
      emailAuthPassed: false,
      emailPostCodeTime: 10 * 60 * 1000,
      emailPCodeTimeOut: false,
      emailPCodeVerified: false,
      emailPCodeVerifiedOK: false,
      emailVerifyTxt: '',
      emailValidate: true
    }
  },

  props: ['prefixName', 'domain'],

  components: {
    VueSelectBox,
    CountDown
  },

  watch: {
    prefixName () {
      if (this.prefixName && this.prefixName !== '') {
        this.myInput.prefixEmailName = this.prefixName
        this.emailPCodeVerifiedOK = true
      }
    },
    domain () {
      if (this.domain && this.domain !== '') {
        this.myInput.emailDomain = this.domain
      }
    }
  },

  computed: {
    ...mapState('authentication', ['authenticationRes']),

    showSelectValue () {
      if (this.selectValue === '') {
        return '직접입력'
      } else {
        return this.selectValue
      }
    },
    prefixEmailName: {
      get () {
        return this.myInput.prefixEmailName
      },
      set (value) {
        this.myInput.prefixEmailName = value
      }
    },
    getEmail () {
      if (this.myInput.prefixEmailName && this.myInput.prefixEmailName !== '') {
        return this.myInput.prefixEmailName + '@' + this.myInput.emailDomain
      } else if (this.myInput.prefixEmailName === '' && this.myInput.emailDomain === '') {
        return ''
      }
    }
  },
  methods: {
    ...mapActions('authentication', ['authentications', 'certiAuthentications']),

    onFoucsPreName () {

    },
    onFoucsDomain () {

    },
    emailCheck (isCheckBtnClicked) {
      let isValigate = true
      this.emailValidate = true
      this.emailPassedTxt = ''

      if (this.myInput.prefixEmailName === this.prefixName && this.myInput.emailDomain === this.domain) {
        return true
      }

      if (this.myInput.prefixEmailName !== '' || this.myInput.emailDomain !== '') {
        if (hasUpperCode(this.myInput.prefixEmailName)) {
          this.emailPassedTxt = '이메일 주소가 유효하지 않습니다.'
          this.emailPassed = false
          this.emailValidate = false
          return false
        }
        let reg1 = /^([A-Za-z0-9_\-.])*$/
        if (!reg1.test(this.myInput.prefixEmailName)) {
          // this.$refs.emailName.focus()
          this.emailPassedTxt = '이메일 주소가 유효하지 않습니다.'
          isValigate = false
        }

        let reg2 = /^([A-Za-z0-9-._])+\.([A-Za-z]{2,4})$/
        if (!reg2.test(this.myInput.emailDomain)) {
          // this.$refs.emailDomain.focus()
          this.emailPassedTxt = '이메일 주소가 유효하지 않습니다.'
          isValigate = false
        }

        if (isValigate) {
          if (isCheckBtnClicked) {
            this.emailPassed = true
          } else {
            this.emailPassed = false
            this.emailPassedTxt = '이메일 인증을 진행해 주세요.'
          }
          this.$refs.btnEmailPostCode.focus()
        } else {
          if (isCheckBtnClicked) {
            this.emailPassed = false
          }
        }
      } else {
        this.emailPassedTxt = '이메일을 입력해 주세요.'
        isValigate = false
        this.emailPassed = false
      }

      return isValigate
    },

    regCheckEmail () {
      let isValigate = true
      this.emailValidate = true

      if (this.myInput.prefixEmailName === this.prefixName && this.myInput.emailDomain === this.domain) {
        return true
      } else if (this.myInput.prefixEmailName !== '' && this.myInput.emailDomain !== '') {
        if (hasUpperCode(this.myInput.prefixEmailName)) {
          this.emailPassedTxt = '이메일 주소가 유효하지 않습니다.'
          this.emailPassed = false
          this.emailValidate = false
          return false
        }

        let reg1 = /^([A-Za-z0-9_\-.])*$/
        if (!reg1.test(this.myInput.prefixEmailName)) {
          this.emailPassedTxt = '이메일 주소가 유효하지 않습니다.'
          isValigate = false
        }

        let reg2 = /^([A-Za-z0-9-._])+\.([A-Za-z]{2,4})$/
        if (!reg2.test(this.myInput.emailDomain)) {
          this.emailPassedTxt = '이메일 주소가 유효하지 않습니다.'
          isValigate = false
        }

        if (isValigate) {
          if (this.emailPCodeVerifiedOK) {
            return true
          } else {
            this.emailPassedTxt = '이메일을 입력해 주세요.'
            isValigate = false
            this.emailPassed = false
          }
        }
      } else {
        this.emailPassedTxt = '이메일을 입력해 주세요.'
        isValigate = false
        this.emailPassed = false
      }

      return isValigate
    },
    async emailAuthen () {
      if (this.$refs.emailCountDown) {
        this.$refs.emailCountDown.stopCountTime()
        this.emailPostCodeTime = 10 * 60 * 1000
        this.emailPassed = true
        this.emailPCodeTimeOut = false
        this.emailPCodeVerified = false
      }
      if (this.myInput.prefixEmailName === '' || this.myInput.emailDomain === '') {
        // this.$refs.emailName.focus()
        this.emailPassed = false
        this.emailPassedTxt = '이메일 주소가 유효하지 않습니다.'
      } else if (this.emailCheck(true)) {
        const emailData = {
          notiAccount: this.getEmail,
          type: 'EMAIL',
          usage: 'JOIN'
        }

        await this.authentications(emailData).then(() => {
          this.$emit('showEmailAuthenPop')
        })
      }
    },
    reStartCountTime () {
      this.emailAuthPassed = true
      if (this.$refs.emailCountDown) {
        this.$refs.emailCountDown.reStartCountTime(this.emailPostCodeTime)
      }
    },
    countDownTime () {
      if (this.emailPostCodeTime > 0) {
        this.emailPostCodeTime = this.emailPostCodeTime - 1000
      } else {
        this.emailPostCodeTime = 0
      }
    },
    emailPCodeCallBack () {
      this.emailPCodeTimeOut = true
      this.emailPCodeVerified = true
      this.emailVerifyTxt = '유효시간 경과되었습니다. 다시 [이메일 인증] 클릭하여 발급된 인증번호를 입력해 주세요.'
    },
    async verifyEmailPostCode () {
      const emailData = {
        notiAccount: this.getEmail,
        certificatedNumber: this.myInput.certificatedNumber,
        usage: 'JOIN',
        type: 'EMAIL'
      }
      if (this.myInput.certificatedNumber !== '' && this.emailPCodeTimeOut === false) {
        await this.certiAuthentications(emailData).then(() => {
          if (this.authenticationRes.remainTime > 0) {
            this.emailPCodeVerifiedOK = true
          }
        }).catch((e) => {
          this.emailPCodeVerified = true
          this.emailVerifyTxt = '올바른 인증번호가 아닙니다.'
        })
      }
    },
    resetEmailInput () {
      this.emailPCodeVerifiedOK = false
      this.emailAuthPassed = false
      this.emailPassed = true
      this.myInput.certificatedNumber = ''
    },
    setDomain (domain) {
      if (this.emailValidate) {
        this.emailPassedTxt = '이메일 인증을 진행해 주세요.'
      }

      this.selectValue = domain
      this.myInput.emailDomain = domain
      this.mEmail = this.myInput.prefixEmailName + '@' + this.myInput.emailDomain
    },
    focusEmailName () {
      this.$refs.emailName.focus()
    }
  }
}
</script>
