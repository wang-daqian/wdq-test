<template>
  <li @mouseover="showPcPop" @mouseout="closePcPop">
    <a href="javascript:" @click.prevent="cilckCate" :class="['gnb_menu_cate_name', {'on' : showNext}, {'active' : showPcTab}]">{{category.label}}</a>
    <ul :class="'depth' + depth" :style="(showNext && displayMode === 'MO') || showPcTab ? 'display: block;' : 'display: none;'" v-if="haveNext">
      <li class="js-mobile-menu-content">
        <router-link :to="`${parentHref}/${category.categoryNo}`">전체보기</router-link>
      </li>
      <category-depth v-for="item in category.children" :key="item.categoryNo" :displayMode="displayMode" :depth="depth + 1" :parentHref="`${parentHref}/${category.categoryNo}`" :category="item" />
    </ul>
  </li>
</template>

<script>
import CategoryDepth from '@/components/layout/CategoryDepth'

export default {
  name: 'CategoryDepth',
  props: ['displayMode', 'depth', 'parentHref', 'category'],
  data () {
    return {
      showNext: false,
      showPcTab: false
    }
  },
  components: {
    CategoryDepth
  },
  computed: {
    haveNext () {
      return this.depth <= 3 && this.category.children && this.category.children.length
    }
  },
  methods: {
    showPcPop () {
      if (this.displayMode === 'PC') {
        this.showPcTab = true
        this.$emit('closeCategoryMenu')
      }
    },
    closePcPop () {
      this.showPcTab = false
    },
    cilckCate () {
      if (this.displayMode === 'MO' && this.haveNext) {
        this.showNext = !this.showNext
      } else {
        this.$router.push(`${this.parentHref}/${this.category.categoryNo}`)
      }
    }
  }
}
</script>

<style>
</style>
