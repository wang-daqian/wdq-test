<template>
  <div @mousemove="imageMouseover" @mouseout="imageMouseout" class="header_banner" v-if="showFlg" :style="{ background: `linear-gradient(to right, ${band.leftSpaceColor} 0%, ${band.leftSpaceColor} 50%, ${band.rightSpaceColor} 50%, ${band.rightSpaceColor} 50%, ${band.rightSpaceColor} 100%)`}">
    <span v-if="band.landingUrlType === 'IMAGEMAP'">
      <slot name="top"></slot>
      <map name="topBannerMap" v-html="band.landingUrl"></map>
      <img usemap="#topBannerMap" :src="showImageUrl" alt="">
      <slot name="bottom"></slot>
    </span>
    <a v-else :href="landingUrl" :target="band.browerTargetType === 'NEW' ? '_blank' : false">
      <img :src="showImageUrl" alt="">
    </a>
  </div>
</template>

<script>
export default {
  props: ['banner'],
  data () {
    return {
      showImageUrl: null
    }
  },
  watch: {
    banner () {
      if (this.banner && this.banner.length && this.banner[0].accounts[0].banners[0]) {
        this.showImageUrl = this.banner[0].accounts[0].banners[0].imageUrl
      }
    }
  },
  computed: {
    band () {
      if (this.banner && this.banner.length) {
        return this.banner[0].accounts[0].banners[0] ? this.banner[0].accounts[0].banners[0] : null
      }
      return null
    },
    landingUrl () {
      return this.band && ((this.band.landingUrlType === 'EVENT' && '/event/' + this.band.landingUrl) || this.band.landingUrl)
    },
    showFlg () {
      if (this.banner && this.banner.length && this.banner[0].accounts[0].banners[0] && this.banner[0].accounts[0].banners[0].imageUrl) {
        return true
      }
      return false
    }
  },
  methods: {
    imageMouseover () {
      if (this.band.mouseOverImageUrl != null) {
        this.showImageUrl = this.band.mouseOverImageUrl
      }
    },
    imageMouseout () {
      this.showImageUrl = this.band.imageUrl
    }
  }
}
</script>

<style>
</style>
