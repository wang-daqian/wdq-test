<template>
  <div>
    <div class="gnb_all">
      <strong>ALL CATEGORY</strong>
      <a href="javascript:" class="btn_all_menu_open" @click.prevent="showLayer = true">
        <img src="../../assets/img/common/btn/btn_allmenu_open.png" alt="전체메뉴보기">
      </a>
      <a href="javascript:" class="btn_side_menu_open" @click.prevent="showMenuMO"></a>
    </div>

    <category-menu-layer v-if="showLayer && category" @close="closeLayer" v-click-outside="closeLayer" :category="category" />

    <div class="gnb_menu_box" :style="wrapStyle === '' ? '' : 'display: block;'">
      <div class="gnb_menu_box_wrap_bg"></div>
      <div class="gnb_menu_box_wrap" :style="displayMode === 'MO' ? wrapStyle : ''">
        <div class="js-mobile-menu-content">
          <span class="btn_mobile_side_close" @click.prevent="closeMenuMO">전체메뉴닫기</span>
          <!-- //nav_language -->
          <div class="nav_banner">
            <div class="nav_login">
              <ul>
                <li>
                  <template v-if="!logined">
                    <router-link to="/member/login">LOGIN</router-link>
                  </template>
                  <template v-else>
                    <a href="#" @click.prevent="logout">LOGOUT</a>
                  </template>
                </li>
                <li>
                  <template v-if="!logined">
                    <router-link to="/member/joinagreement">JOIN</router-link>
                  </template>
                  <template v-else>
                    <router-link to="/mypage">MYPAGE</router-link>
                  </template>
                </li>
              </ul>
            </div>
          </div>
          <!-- //nav_banner -->
          <div class="nav_link">
            <ul>
              <li>
                <router-link to="/" @click.native="closeMenuMO">홈</router-link>
              </li>
              <li>
                <router-link to="/order/cart" @click.native="closeMenuMO">장바구니</router-link>
              </li>
              <li>
                <router-link to="/mypage" @click.native="closeMenuMO">마이페이지</router-link>
              </li>
              <li>
                <router-link to="/mypage/profile/signininquiry" @click.native="closeMenuMO">Q&A</router-link>
              </li>
            </ul>
          </div>

          <div class="nav_search">
            <header-search v-if="showMenuBox" />
          </div>

          <ul class="nav_tabmenu">
            <li :class="{'on' : showCateTab}" @click.prevent="showCateTab = true">
              <span>CATEGORY</span>
            </li>
            <li :class="{'on' : !showCateTab}" @click.prevent="showCateTab = false">
              <span>고객센터</span>
            </li>
          </ul>

          <ul class="depth0 gnb_menu0 tab_menu1" style="overflow: visible; height: 100%;" v-if="!showCateTab">
            <li>
              <router-link to='/etc/center/notice'>-NOTICE</router-link>
            </li>
            <li>
              <router-link to='/etc/center/faq'>-FAQ</router-link>
            </li>
            <li>
              <router-link to='/etc/center/store'>-매장정보</router-link>
            </li>
          </ul>
        </div>

        <ul class="depth0 gnb_menu0 tab_menu0" style="overflow: visible; height: 100%;" v-if="showCateTab">
          <category-depth @closeCategoryMenu="closeLayer" v-for="item in category.children" :key="item.categoryNo" :displayMode="displayMode" :depth="1" :parentHref="`/${pathName(category.label)}/categorylist/${category.categoryNo}`" :category="item" />
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
import $ from 'jquery'
import ClickOutside from 'vue-click-outside'
import CategoryMenuLayer from '@/components/layout/CategoryMenuLayer'
import HeaderSearch from '@/components/layout/HeaderSearch'
import CategoryDepth from '@/components/layout/CategoryDepth'
import { isLogin, logoutProcess, getPathName } from '@/utils/utils'

export default {
  props: ['displayMode', 'category'],
  components: {
    CategoryMenuLayer,
    HeaderSearch,
    CategoryDepth
  },
  directives: {
    ClickOutside
  },
  data () {
    return {
      logined: isLogin(),
      showLayer: false,
      wrapStyle: '',
      showCateTab: true,
      showMenuBox: false
    }
  },
  methods: {
    closeLayer () {
      this.showLayer = false
    },
    showMenuMO () {
      this.showMenuBox = true
      this.$nextTick(() => {
        this.wrapStyle = `height: ${$(window).height() - 20}px`
      })
    },
    closeMenuMO () {
      this.wrapStyle = ''
      this.showMenuBox = false
    },
    logout () {
      logoutProcess()
    },
    pathName (label) {
      return getPathName(label)
    }
  },
  watch: {
    '$route': 'closeMenuMO'
  }
}
</script>

<style>
</style>
