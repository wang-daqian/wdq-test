<template>
  <div :class="logoInfo.logoClass">
    <div class="logo_main">
      <router-link :to="logoInfo.linkUrl">
        <img :src="logoInfo.imgUrl" alt="" title="">
      </router-link>
    </div>
  </div>
</template>

<script>
export default {
  props: ['brandInfo'],
  computed: {
    logoInfo () {
      if (this.brandInfo.label === 'HOME') {
        return {
          logoClass: 'h1_logo',
          imgUrl: require('../../assets/img/common/logo/logo_home.png'),
          linkUrl: '/'
        }
      } else if (this.brandInfo.label === 'FRENCH CAT') {
        return {
          logoClass: 'h1_logo logo1',
          imgUrl: require('../../assets/img/common/logo/ico_french_cat.png'),
          linkUrl: '/frenchcat'
        }
      } else if (this.brandInfo.label === 'TIFFANY') {
        return {
          logoClass: 'h1_logo logo2',
          imgUrl: require('../../assets/img/common/logo/logo_tiffany.png'),
          linkUrl: '/tiffany'
        }
      } else if (this.brandInfo.label === 'ELECONE') {
        return {
          logoClass: 'h1_logo logo4',
          imgUrl: require('../../assets/img/common/logo/logo_elecone.png'),
          linkUrl: '/elecone'
        }
      } else if (this.brandInfo.label === 'GUESS KIDS') {
        return {
          logoClass: 'h1_logo logo3',
          imgUrl: require('../../assets/img/common/logo/logo_guess.png'),
          linkUrl: '/guesskids'
        }
      } else if (this.brandInfo.label === 'NUBABY') {
        return {
          logoClass: 'h1_logo logo5',
          imgUrl: require('../../assets/img/common/logo/ico_nubaby.png'),
          linkUrl: '/nubaby'
        }
      } else {
        return {
          logoClass: 'h1_logo',
          imgUrl: require('../../assets/img/common/logo/logo_home.png'),
          linkUrl: '/'
        }
      }
    }
  }
}
</script>

<style>
</style>
