<template>
  <div class="header_gnb" :style="`margin-top: ${gnbMargin}px;`">
    <header-logo :brandInfo="brandInfo" v-if="brandInfo" />
    <div class="gnb">

      <category-menu v-if="brandInfo" :displayMode="displayMode" :category="brandInfo" />

      <header-search />

      <ul class="cart">
        <li>
          <router-link to="/order/cart">
            <img src="../../assets/img/common/btn/ico_purchase.png" alt="">
          </router-link>
        </li>
        <li>
          <router-link to="/mypage">
            <img src="../../assets/img/common/btn/ico_user_out.png" alt="">
          </router-link>
        </li>
      </ul>

      <div class="allmenu_sp" v-if="brandInfo">
        <ul>
          <li v-for="item in brandInfo.children" :key="item.categoryNo">
            <router-link :to="`/${pathName(brandInfo.label)}/categorylist/${brandInfo.categoryNo}/${item.categoryNo}`">{{item.label}}</router-link>
          </li>
        </ul>
      </div>

    </div>
  </div>
</template>

<script>
import { getPathName } from '@/utils/utils'
import ClickOutside from 'vue-click-outside'
import HeaderLogo from '@/components/layout/HeaderLogo'
import CategoryMenu from '@/components/layout/CategoryMenu'
import HeaderSearch from '@/components/layout/HeaderSearch'

export default {
  props: ['displayMode', 'brandInfo', 'gnbMargin'],
  components: {
    HeaderLogo,
    CategoryMenu,
    HeaderSearch
  },
  directives: {
    ClickOutside
  },
  methods: {
    pathName (label) {
      return getPathName(label)
    }
  }
}
</script>

<style>
</style>
