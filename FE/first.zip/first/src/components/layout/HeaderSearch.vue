<template>
  <div class="header_search">
    <div class="header_search_cont">
      <div class="top_search">
        <fieldset>
          <legend>검색폼</legend>
          <div class="top_search_cont" v-click-outside="closeRecent">
            <div class="top_text_cont">
              <input type="text" class="top_srarch_text" v-model="words" @click="showRecent = true" @keypress.enter="search">
              <input type="image" :src="searchImg" id="btnSearchTop" class="btn_top_srarch" title="검색" value="검색" alt="검색" @click.prevent="search">
            </div>
            <div class="search_cont" :style="showRecent ? 'display: block;' : 'display: none;'">
              <div class="recent_box">
                <dl class="js_recent_area">
                  <dt>최근검색어</dt>
                  <template v-if="oldWords.length">
                    <dd>
                      <ul class="js_recent_list" style="border: none;">
                        <li v-for="(item, index) in oldWords" :key="index">
                          <a href="javascript:" @click.prevent="setkey(item.word)">{{item.word}}</a>
                          <span>{{item.datetime}}
                            <button type="button" class="btn_top_search_del" @click.prevent="delkey(item.word)">
                              <img :src="delImg" alt="삭제">
                            </button>
                          </span>
                        </li>
                      </ul>
                    </dd>
                  </template>
                  <template v-else>
                    <dd>최근 검색어가 없습니다.</dd>
                  </template>
                </dl>
              </div>
              <div class="seach_top_all">
                <button type="button" class="btn_top_search_all_del" v-if="oldWords.length" @click.prevent="delAll">
                  <strong>전체삭제</strong>
                </button>
                <button type="button" class="btn_top_search_close" @click.prevent="closeRecent">
                  <strong>닫기</strong>
                </button>
              </div>
            </div>
          </div>
        </fieldset>
      </div>
    </div>
  </div>
</template>

<script>
/* global fbq */
import { setRecentWords, delRecentWords } from '@/utils/utils'
import ClickOutside from 'vue-click-outside'
import { gaEventSearch } from '@/utils/gaEventUtils'

export default {
  directives: {
    ClickOutside
  },
  data () {
    return {
      words: '',
      oldWords: JSON.parse(window.localStorage.recentWords || '[]'),
      searchImg: require('../../assets/img/common/btn/btn_top_search.png'),
      delImg: require('../../assets/img/common/btn/btn_top_search_del.png'),
      showRecent: false
    }
  },
  methods: {
    initData () {
      this.words = ''
      this.oldWords = JSON.parse(window.localStorage.recentWords || '[]')
      this.showRecent = false
    },
    closeRecent () {
      this.showRecent = false
    },
    search () {
      if (this.words.trim()) {
        this.words = this.words.trim()
        setRecentWords(this.words)
        /** gtag.js */
        gaEventSearch(this.words)
        this.$router.push(`/searchlist?q=${this.words}`)
      } else {
        alert('검색어를 입력해 주세요.')
      }
      fbq('track', 'Search')
    },
    setkey (wordkey) {
      this.words = wordkey
      this.search()
    },
    delkey (wordkey) {
      delRecentWords(wordkey)
      this.oldWords = JSON.parse(window.localStorage.recentWords || '[]')
    },
    delAll () {
      delRecentWords()
      this.oldWords = []
    }
  },
  watch: {
    '$route': 'initData'
  }
}
</script>

<style>
</style>
