<template>
  <div class="header_nav">
    <div class="con">
      <div class="logo">
        <ul>
          <li v-for="item in brands" :key="item.categoryNo">
            <a href="javascript:" @click.prevent="clickLogo(item.label)">
              <img :src="item.icon" alt="">
            </a>
          </li>
        </ul>
      </div>
      <div class="login">
        <ul>
          <template v-if="!logined">
            <li>
              <router-link to="/member/login">로그인</router-link>
            </li>
            <li>
              <router-link to="/member/joinagreement">회원가입</router-link>
            </li>
          </template>
          <li v-else>
            <a href="javascript:" @click.prevent="logout">로그아웃</a>
          </li>
          <li>
            <router-link to="/mypage">마이페이지</router-link>
          </li>
          <li>
            <a href="javascript:" @click.prevent="clickRecent">최근본상품</a>
            <recent-items v-if="showRecent" :products="products" @close="closePop" v-click-outside="closePop" />
          </li>
        </ul>
      </div>
      <div class="user">
        <ul>
          <li>
            <router-link to="/mypage/wishlist">
              <img src="../../assets/img/common/btn/ico_follow.png" alt="">
            </router-link>
            <span>({{wishCnt}})</span>
          </li>
          <li>
            <router-link to="/order/cart">
              <img src="../../assets/img/common/btn/ico_purchase.png" alt="">
            </router-link>
            <span>({{cartCnt}})</span>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
import RecentItems from '@/components/layout/RecentItems'
import ClickOutside from 'vue-click-outside'
import { isLogin, logoutProcess } from '@/utils/utils'

export default {
  props: ['brands', 'cartCnt', 'wishCnt', 'products'],
  data () {
    return {
      logined: isLogin(),
      showRecent: false
    }
  },
  components: {
    RecentItems
  },
  directives: {
    ClickOutside
  },
  methods: {
    closePop () {
      this.showRecent = false
    },
    logout () {
      logoutProcess()
    },
    clickRecent () {
      if (isLogin()) {
        this.showRecent = true
      } else {
        this.$router.push('/member/login')
      }
    },
    clickLogo (label) {
      if (label === 'FRENCH CAT') {
        this.$router.push('/frenchcat')
      } else if (label === 'TIFFANY') {
        this.$router.push('/tiffany')
      } else if (label === 'ELECONE') {
        this.$router.push('/elecone')
      } else if (label === 'GUESS KIDS') {
        this.$router.push('/guesskids')
      } else if (label === 'NUBABY') {
        this.$router.push('/nubaby')
      } else {
        this.$router.push('/')
      }
    }
  }
}
</script>

<style scoped>
#header .header_nav .login .cache_pc {
  display: block;
  position: absolute;
  top: 45px;
  left: -65px;
  z-index: 999;
  width: 360px;
  height: 140px;
  background: #fff;
  border: 1px solid #ccc;
}
</style>
