<template>
  <div class="cache_pc">
    <h4>최근본상품</h4>
    <div class="item_slide_horizontal" v-if="products && products.length > 0">
      <ul class="slide_horizontal_3">
        <slick ref="slick" :options="slickOptions">
          <li v-for="(item, index) in products" :key="index">
            <div class="item_cont" style="text-align:center;">
              <div class="item_photo_box">
                <goods-view-link :product="item" @clickLink="clickLink(item.productNo)">
                  <img :src="item.imageUrls[0]" :alt="item.productName" :title="item.productName" class="middle" />
                </goods-view-link>
              </div>
            </div>
          </li>
        </slick>
      </ul>
    </div>
    <p class="none" v-else>최근 본 상품이 존재하지 않습니다.</p>
    <p class="btn-close" @click.prevent="close">
      <a href="javacript:">
        <img src="../../assets/img/common/btn/btn_goods_del.png" alt="">
      </a>
    </p>
  </div>
</template>

<script>
import GoodsViewLink from '@/components/common/GoodsViewLink'
import Slick from 'vue-slick'
export default {
  props: ['products'],
  components: {
    Slick,
    GoodsViewLink
  },
  data () {
    return {
      slickOptions: {
        draggable: false,
        autoplay: true,
        infinite: true,
        slidesToShow: 3,
        slidesToScroll: 1
      }
    }
  },
  methods: {
    close () {
      this.$emit('close')
    },
    clickLink (productNo) {
      if (Number(this.$route.params.productNo) !== productNo) {
        this.$store.commit('product/INIT_PRODUCT')
      }
      this.$emit('close')
    }
  }
}
</script>

<style>
</style>
