<template>
  <div class="gnb_allmenu_wrap">
    <div class="gnb_allmenu">
      <div class="gnb_allmenu_box">
        <ul>
          <li style="width:20%;" v-for="depth1 in category.children" :key="depth1.categoryNo">
            <div class="all_menu_cont">
              <router-link :to="`/${pathName(category.label)}/categorylist/${category.categoryNo}/${depth1.categoryNo}`" @click.native="close">{{depth1.label}}</router-link>
              <ul class="all_depth1" v-if="depth1.children && depth1.children.length">
                <li v-for="depth2 in depth1.children" :key="depth2.categoryNo">
                  <router-link :to="`/${pathName(category.label)}/categorylist/${category.categoryNo}/${depth1.categoryNo}/${depth2.categoryNo}`" @click.native="close">{{depth2.label}}</router-link>
                  <ul class="all_depth2" v-if="depth2.children && depth2.children.length">
                    <li v-for="depth3 in depth2.children" :key="depth3.categoryNo">
                      <router-link :to="`/${pathName(category.label)}/categorylist/${category.categoryNo}/${depth1.categoryNo}/${depth2.categoryNo}/${depth3.categoryNo}`" @click.native="close">{{depth3.label}}</router-link>
                    </li>
                  </ul>
                </li>
              </ul>
            </div>
          </li>
        </ul>
      </div>
      <span class="btn_all_menu_close" @click.prevent="close">전체메뉴닫기</span>
    </div>
  </div>
</template>

<script>
import { getPathName } from '@/utils/utils'
export default {
  props: ['category'],
  methods: {
    close () {
      this.$emit('close')
    },
    pathName (label) {
      return getPathName(label)
    }
  }
}
</script>

<style>
</style>
