<template>
  <div class="scroll_box_cont">
    <h5>상품쿠폰적용</h5>
    <div class="top_table_type order_table_type coupon_table">
      <div class="table_shell">
        <!-- <template v-for="(product, index) in products">
          <template v-if="display.showProduct[index] === 0">
            <order-coupon-product-detail :product="product" :couponRequest="couponRequest" :key="product.productNo" :area="''" />
          </template>
        </template> -->
        <template v-for="product in products">
          <order-coupon-product-detail :product="product" :couponRequest="couponRequest" :key="product.productNo" :area="''" />
        </template>
      </div>
    </div>

    <br>
    <h5 class="tit">장바구니/배송비쿠폰적용</h5>
    <!-- <order-coupon-cart-and-delivery :cartCoupons="cartCoupons" :deliveryCoupons="deliveryCoupons" :display="display" :area="''" /> -->
    <order-coupon-cart-and-delivery :cartCoupons="commonCartCoupons" :deliveryCoupons="commonDeliveryCoupons" :area="''" />
  </div>
</template>

<script>
import OrderCouponCartAndDelivery from '@/components/order/order/OrderCouponCartAndDelivery'
import OrderCouponProductDetail from '@/components/order/order/OrderCouponProductDetail'

export default {
  props: ['display', 'products', 'couponRequest', 'cartCoupons', 'deliveryCoupons', 'orderCoupons'],
  components: {
    OrderCouponCartAndDelivery,
    OrderCouponProductDetail
  },
  data () {
    return {
      orderSheetNo: this.$store.state.route.params.orderSheetNo
    }
  },
  computed: {
    commonCartCoupons () {
      if (this.display.hasCommonCartCoupon) {
        return this.cartCoupons
      }
      return []
    },
    commonDeliveryCoupons () {
      if (this.display.hasCommonDeliveryCoupon) {
        return this.deliveryCoupons
      }
      return []
    }
  },
  methods: {
    closeLayer (value) {
      this.$emit('close', value)
    }
  }
}
</script>
