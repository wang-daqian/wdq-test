<template>
  <div class="delivery_info">
    <div class="order_zone_tit">
      <h4>배송지 정보</h4>
    </div>

    <div class="order_table_type width_auto">
      <table class="table_left">
        <colgroup>
          <col style="width:15%;">
          <col style="width:85%;">
        </colgroup>
        <tbody>
          <tr>
            <th scope="row">배송지 확인</th>
            <td>
              <div class="form_element">
                <ul>
                  <li>
                    <label :class="['choice_s',{'on':sortType === 'shippingNew'}]" @click.prevent="selectAddressType('shippingNew')">직접 입력</label>
                  </li>
                  <li>
                    <label :class="['choice_s',{'on':sortType === 'shippingSameCheck'}]" @click.prevent="selectAddressType('shippingSameCheck')">주문자정보와 동일</label>
                  </li>
                </ul>
              </div>
            </td>
          </tr>
          <tr>
            <th scope="row">
              <span class="important">받으실 분</span>
            </th>
            <td>
              <input type="text" ref="receiverName" v-model="showReceiverName" maxlength="20">
            </td>
          </tr>
          <tr>
            <th scope="row">
              <span class="important">주소</span>
            </th>
            <td class="member_address">
              <div class="address_postcode">
                <input type="text" name="receiverZonecode" readonly="readonly" v-model="showReceiverZipCd" ref="receiverZipCd">
                <input type="hidden" name="receiverZipcode">
                <span id="receiverZipcodeText" class="old_post_code"></span>
                <button type="button" class="btn_post_search" @click.prevent="openAddressesPopup">우편번호검색</button>
              </div>
              <div class="address_input">
                <input type="text" name="receiverAddress" readonly="readonly" v-model="showReceiverAddress" ref="receiverAddress">
                <input type="text" name="receiverAddressSub" v-model="showReceiverDetailAddress" ref="receiverDetailAddress" :style="{'margin-left':'5px'}">
              </div>
            </td>
          </tr>
          <tr>
            <th scope="row">
              <span class="important">휴대전화</span>
            </th>
            <td>
              <input type="text" id="receiverPhone" name="receiverPhone" v-model="showReceiverContact1" ref="receiverContact1" maxlength="11" @keydown="gdNum" @input="gdNum" @blur="gdNum">
            </td>
          </tr>
          <tr>
            <th scope="row">연락처</th>
            <td>
              <input type="text" id="receiverCellPhone" name="receiverCellPhone" v-model="showReceiverContact2" ref="receiverContact2" maxlength="12" @keydown="gdNumPhone" @input="gdNumPhone" @blur="gdNumPhone">
            </td>
          </tr>
          <tr v-if="requireCustomsIdNumber">
            <th scope="row" class="help">
              <span class="important">개인통관고유부호
                <a class="help-icon" @click="active.notice = !active.notice"></a>
              </span>
              <div class="toolhelp-base fade show" v-if="active.notice">
                <dl class="toolhelp-content">
                  <dt>개인통관고유부호란?</dt>
                  <dd>해외직배송 상품 구매 시 국내 통관 절차를 위해 ‘개인통관고유부호’를 제출해야 합니다.</dd>
                </dl>
                <div class="toolhelp-arrow">
                  <span></span>
                </div>
              </div>
            </th>
            <td class="help-txt">
              <input type="text" name="" placeholder="받는사람의 개인통관고유부호를 입력해 주세요." v-model="currentAddress.customsIdNumber" maxlength="13" ref="customsIdNumber">
              <span>개인통관고유부호 발급
                <a href="https://unipass.customs.go.kr/csp/persIndex.do" target="_blank">바로가기 ></a>
              </span>
            </td>
          </tr>
          <tr>
            <th scope="row">배송 메모</th>
            <td class="td_last_say">
              <input type="text" name="orderMemo" @input="setDeliveryMemoLength" v-model="showDeliveryMemo" maxlength="50" ref="orderMemo">
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <address-info @closePop="closeLayer" v-if="showAddLayer" />
  </div>
</template>

<script>
import AddressInfo from '@/components/common/address/AddressInfo'
import { validateNumber, replacePattern } from '@/utils/validateUtils'
import { mapActions } from 'vuex'

export default {
  props: ['requireCustomsIdNumber', 'shippingAddressInfo'],
  components: {
    AddressInfo
  },
  data () {
    return {
      checkedRecentAddressValue: true,
      currentAddress: {
        receiverName: '',
        receiverZipCd: '',
        receiverAddress: '',
        receiverJibunAddress: '',
        receiverDetailAddress: '',
        receiverContact1: '',
        receiverContact2: '',
        customsIdNumber: '',
        deliveryMemo: ''
      },
      active: {
        memo: false,
        notice: false
      },
      txt: {
        deliveryMemoLength: 0
      },
      sortType: 'shippingNew',
      showAddLayer: false
    }
  },
  computed: {
    showReceiverName: {
      get () {
        return this.currentAddress && this.currentAddress.receiverName
      },
      set (value) {
        this.currentAddress.receiverName = value
      }
    },
    showReceiverZipCd: {
      get () {
        return this.currentAddress && this.currentAddress.receiverZipCd
      },
      set (value) {
        this.currentAddress.receiverZipCd = value
      }
    },
    showReceiverAddress: {
      get () {
        return this.currentAddress && this.currentAddress.receiverAddress
      },
      set (value) {
        this.currentAddress.receiverAddress = value
      }
    },
    showReceiverDetailAddress: {
      get () {
        return this.currentAddress && this.currentAddress.receiverDetailAddress
      },
      set (value) {
        this.currentAddress.receiverDetailAddress = value
      }
    },
    showReceiverContact1: {
      get () {
        if (this.currentAddress && this.currentAddress.receiverContact1 !== '') {
          return replacePattern(this.currentAddress.receiverContact1, /[^\d]/g, '')
        } else {
          return ''
        }
      },
      set (value) {
        this.currentAddress.receiverContact1 = value
      }
    },
    showReceiverContact2: {
      get () {
        if (this.currentAddress && this.currentAddress.receiverContact2 !== '') {
          return replacePattern(this.currentAddress.receiverContact2, /[^\d]/g, '')
        } else {
          return ''
        }
      },
      set (value) {
        this.currentAddress.receiverContact2 = value
      }
    },
    showDeliveryMemo: {
      get () {
        return this.currentAddress.deliveryMemo
      },
      set (value) {
        this.currentAddress.deliveryMemo = value
      }
    },
    shippingAddressInput () {
      let shippingAddressInput = {
        addressNo: 0,
        receiverName: this.currentAddress.receiverName,
        addressName: '',
        receiverContact1: this.currentAddress.receiverContact1,
        receiverContact2: this.currentAddress.receiverContact2,
        receiverZipCd: this.currentAddress.receiverZipCd,
        receiverAddress: this.currentAddress.receiverAddress,
        receiverJibunAddress: this.currentAddress.receiverJibunAddress,
        receiverDetailAddress: this.currentAddress.receiverDetailAddress,
        deliveryMemo: this.currentAddress.deliveryMemo || '',
        customsIdNumber: this.currentAddress.customsIdNumber,
        // 주소지에 있는 countryCd를 써야하나?
        countryCd: 'KR'
      }

      // if (this.checkedRecentAddress) {
      //   shippingAddressInput = {
      //     ...this.currentAddress
      //   }
      if (this.requireCustomsIdNumber && !this.currentAddress.customsIdNumber) {
        shippingAddressInput.customsIdNumber = this.currentAddress.customsIdNumber
      }
      // }

      return shippingAddressInput
    },
    deliveryMemoInput () {
      return this.currentAddress.deliveryMemo
    },
    validateRule () {
      let validateRule = [
        {
          inputValue: this.currentAddress.receiverName,
          message: '받으실 분 정보를 입력해 주세요.',
          pattern: /\S+/,
          input: this.$refs.receiverName
        },
        {
          inputValue: this.currentAddress.receiverZipCd,
          message: '주소를 입력해주세요.',
          pattern: /\S+/,
          input: this.$refs.receiverZipCd
        },
        {
          inputValue: this.currentAddress.receiverAddress,
          message: '주소를 입력해주세요.',
          pattern: /\S+/,
          input: this.$refs.receiverDetailAddress
        },
        {
          inputValue: this.currentAddress.receiverContact1,
          message: '휴대전화를 입력해주세요.',
          pattern: /\S+/,
          input: this.$refs.receiverContact1
        },
        {
          inputValue: this.currentAddress.receiverContact1,
          message: '정확한 휴대전화를 입력해 주세요.',
          pattern: /^\d{10,11}$/,
          input: this.$refs.receiverContact1
        }
      ]

      if (this.requireCustomsIdNumber) {
        const customsIdNumberRule = [{
          inputValue: this.currentAddress.customsIdNumber,
          message: '개인통관고유부호가 유효하지 않습니다. ',
          pattern: /^[p|P]\d{12}$/,
          input: this.$refs.customsIdNumber
        }]
        validateRule.push(...customsIdNumberRule)

        return validateRule
      } else {
        return validateRule
      }
    },
    getAddressType () {
      return this.sortType
    }
  },
  created () {
    if (this.shippingAddressInfo && this.shippingAddressInfo.receiverName) {
      this.currentAddress.receiverName = this.shippingAddressInfo.receiverName
      this.currentAddress.receiverZipCd = this.shippingAddressInfo.receiverZipCd
      this.currentAddress.receiverAddress = this.shippingAddressInfo.receiverAddress
      this.currentAddress.receiverJibunAddress = this.shippingAddressInfo.receiverJibunAddress
      this.currentAddress.receiverDetailAddress = this.shippingAddressInfo.receiverDetailAddress
      this.currentAddress.receiverContact1 = this.shippingAddressInfo.receiverContact1
      this.currentAddress.receiverContact2 = this.shippingAddressInfo.receiverContact2
      this.currentAddress.deliveryMemo = this.shippingAddressInfo.deliveryMemo
      this.sortType = this.shippingAddressInfo.addressType
    }
  },
  methods: {
    ...mapActions('ordersheet', ['calculateOrderConpons']),

    selectAddressType (type) {
      this.sortType = type
      this.currentAddress.deliveryMemo = ''

      switch (type) {
        case 'shippingNew':
          this.resetCurrentAddress(null)
          break
        case 'shippingSameCheck':
          this.resetCurrentAddress(null)
          this.copy()
          break
        default:
          break
      }
    },

    resetCurrentAddress (address) {
      if (address !== null) {
        this.currentAddress.receiverName = address.receiverName
        this.currentAddress.receiverZipCd = address.receiverZipCd
        this.currentAddress.receiverAddress = address.receiverAddress
        this.currentAddress.receiverJibunAddress = address.receiverJibunAddress
        this.currentAddress.receiverDetailAddress = address.receiverDetailAddress
        this.currentAddress.receiverContact1 = address.receiverContact1
        this.currentAddress.receiverContact2 = address.receiverContact2
        this.currentAddress.customsIdNumber = address.customsIdNumber
        this.currentAddress.deliveryMemo = address.deliveryMemo
      } else {
        this.currentAddress.receiverName = ''
        this.currentAddress.receiverZipCd = ''
        this.currentAddress.receiverAddress = ''
        this.currentAddress.receiverJibunAddress = ''
        this.currentAddress.receiverDetailAddress = ''
        this.currentAddress.receiverContact1 = ''
        this.currentAddress.receiverContact2 = ''
        this.currentAddress.customsIdNumber = ''
        this.currentAddress.deliveryMemo = ''
      }
      if (this.currentAddress.receiverContact1 !== '') {
        this.currentAddress.receiverContact1 = replacePattern(this.currentAddress.receiverContact1, /[^\d]/g, '')
      }
      if (this.currentAddress.receiverContact2 !== '') {
        this.currentAddress.receiverContact2 = replacePattern(this.currentAddress.receiverContact2, /[^\d]/g, '')
      }
    },
    copy () {
      this.$emit('copyOrderer')
    },
    setOrderer (ordererInput) {
      this.currentAddress.receiverName = ordererInput.ordererName
      this.currentAddress.receiverContact1 = ordererInput.ordererContact1
      this.currentAddress.receiverContact2 = ordererInput.ordererContact2
    },
    setDeliveryMemo (memo) {
      this.active.memo = false
      this.currentAddress.deliveryMemo = memo
      this.setDeliveryMemoLength()
    },
    setDeliveryMemoLength () {
      this.txt.deliveryMemoLength = this.currentAddress.deliveryMemo.length
    },
    openAddressesPopup () {
      this.showAddLayer = true
      this.$store.commit('SHOW_LAYER_BG')
    },
    closeLayer (selected, address) {
      this.showAddLayer = false
      this.$store.commit('HIDDEN_LAYER_BG')
      if (selected) {
        this.callbackAddr(address)
      }
    },
    callbackAddr ({ zipCd, address, addressSub, receiverJibunAddress }) {
      this.currentAddress.receiverZipCd = zipCd
      this.currentAddress.receiverAddress = address
      this.currentAddress.receiverDetailAddress = addressSub
      this.currentAddress.receiverJibunAddress = receiverJibunAddress

      this.updatePaymentByAddress(address, receiverJibunAddress, zipCd)
    },
    validateNumber (event) {
      validateNumber(event)
    },
    updatePaymentByAddress (address, jibunAddress, zipCode) {
      const addressRequest = {
        addressRequest: {
          addressType: 'RECENT',
          countryCd: 'KR',
          customsIdNumber: '',
          defaultYn: '',
          receiverAddress: address,
          receiverContact1: '',
          receiverContact2: '',
          receiverDetailAddress: '',
          receiverJibunAddress: jibunAddress,
          receiverName: '',
          receiverZipCd: zipCode
        }
      }
      const orderSheetNo = this.$store.state.route.params.orderSheetNo
      this.calculateOrderConpons({ orderSheetNo, addressRequest })
    },
    gdNumPhone: function () {
      if (this.currentAddress.receiverContact2 !== '') {
        this.currentAddress.receiverContact2 = replacePattern(this.currentAddress.receiverContact2, /[^\d]/g, '')
      }
    },
    gdNum: function () {
      if (this.currentAddress.receiverContact1 !== '') {
        this.currentAddress.receiverContact1 = replacePattern(this.currentAddress.receiverContact1, /[^\d]/g, '')
      }
    }
  }

}
</script>
