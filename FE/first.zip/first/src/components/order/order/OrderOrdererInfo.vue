<template>
  <!-- [D] 1. 주문자 정보 영역 -->
  <div class="order_info">
    <div class="order_zone_tit">
      <h4>주문자 정보</h4>
    </div>
    <order-orderer-info-member v-if="logined" :orderer="orderer" ref="member" :ordererInfo="ordererInfo" />
    <order-orderer-info-non-member v-else ref="nonMember" :ordererInfo="ordererInfo" />
  </div>
</template>

<script>
import OrderOrdererInfoMember from '@/components/order/order/OrderOrdererInfoMember'
import OrderOrdererInfoNonMember from '@/components/order/order/OrderOrdererInfoNonMember'

export default {
  props: ['logined', 'orderer', 'ordererInfo'],
  components: {
    OrderOrdererInfoMember,
    OrderOrdererInfoNonMember
  },
  computed: {
    ordererInput () {
      let ordererInput = {}
      if (this.logined) {
        ordererInput = { ...this.$refs.member.ordererInput }
      } else {
        ordererInput = { ...this.$refs.nonMember.ordererInput }
      }
      return ordererInput
    },
    tempPasswordInput () {
      return this.logined ? null : this.$refs.nonMember.tempPassword
    },
    validateRule () {
      return this.logined ? this.$refs.member.validateRule : this.$refs.nonMember.validateRule
    },
    orderMemo () {
      let orderMemo = ''
      if (this.logined) {
        orderMemo = this.$refs.member.orderMemo
      } else {
        orderMemo = this.$refs.nonMember.orderMemo
      }
      return orderMemo
    }
  }
}
</script>
