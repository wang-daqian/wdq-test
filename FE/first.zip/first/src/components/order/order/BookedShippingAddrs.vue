<template>
  <div id="myShippingListLayer" class="layer_wrap delivery_add_list_layer" v-if="openLayer">
    <div id="shipping_layer" class="layer_wrap_cont" :style="ly_style">
      <div class="ly_tit">
        <h4>나의 배송지 관리</h4>
      </div>
      <div class="ly_cont">
        <div class="scroll_box">
          <h5>배송지 목록</h5>
          <div class="delivery_add_list">
            <div class="top_table_type scroll">
              <table>
                <colgroup>
                  <col style="width:10%">
                  <!-- 선택 -->
                  <col style="width:13%">
                  <!-- 배송지이름 -->
                  <col style="width:12%">
                  <!-- 받으실 분 -->
                  <col>
                  <!-- 주소 -->
                  <col style="width:20%">
                  <!-- 연락처 -->
                  <col style="width:12%">
                  <!-- 수정/삭제 -->
                </colgroup>
                <thead>
                  <tr>
                    <th>선택</th>
                    <th>배송지이름</th>
                    <th>받으실분</th>
                    <th>주 소</th>
                    <th>연락처</th>
                    <th>수정/삭제</th>
                  </tr>
                </thead>
                <tbody v-if="addresses">
                  <!-- <tr data-shipping-name="받으실 분" v-for="(address, index) in addresses" :key="index"> -->
                  <tr data-shipping-name="받으실 분" v-for="address in getPageData" :key="address.addressNo">
                    <td>
                      <span class="btn_gray_list">
                        <a href="javascript:" class="btn_gray_small js_shipping_address" @click.prevent="selectAddress(address)">
                          <span>선택</span>
                        </a>
                      </span>
                    </td>
                    <td>
                      <span v-if="address.defaultYn==='Y'">(기본배송지)</span>
                      <strong>{{address.addressName}}</strong>
                    </td>
                    <td>{{address.receiverName}}</td>
                    <td class="td_left">
                      <span>({{address.receiverZipCd}})</span> {{address.receiverAddress}}{{address.receiverDetailAddress}}
                    </td>
                    <td class="td_phone">
                      <span class="td_phone_num">휴대전화 : {{address.receiverContact1}}</span>
                      <span class="td_phone_num">연락처 : {{address.receiverContact2}}</span>
                    </td>
                    <td>
                      <span class="btn_gray_list">
                        <a href="javascript:" class="btn_gray_small btn_open_layer" data-sno="8" @click.prevent="updateAddress(address)">
                          <span>수정</span>
                        </a>
                      </span>
                      <span class="btn_gray_list">
                        <a href="javascript:" class="btn_gray_small js_delete" data-sno="8" data-default-fl="y" @click.prevent="deletAddrItem(address.addressNo,address.addressName)">
                          <span>삭제</span>
                        </a>
                      </span>
                    </td>
                  </tr>
                </tbody>
                <tbody v-else>
                  <tr>
                    <td colspan="6">
                      <p class="no_data">배송지 리스트가 없습니다.</p>
                    </td>
                  </tr>
                </tbody>
              </table>
              <br />
              <br />
              <!-- <pagination v-if="addresses&&addresses.length>=5" :page="1" :total_count="(addresses && addresses.length) || 0" :page_size="5" :page_term="5" @onPageChange="pageChange" ref="pagination" /> -->
            </div>
            <!-- <pagination v-if="addresses&&addresses.length>=5" :page="1" :total_count="(addresses && addresses.length) || 0" :page_size="5" :page_term="5" @onPageChange="pageChange" ref="pagination" /> -->
            <!-- <a href="javascript:" style="display:none" class="btn_ly_add_shipping btn_open_layer" @click.prevent="newRegBookPop">+ 새 배송지 추가</a> -->
          </div>
          <!-- //delivery_add_list -->
          <div class="pagination">
            <ul></ul>
          </div>
        </div>
        <!-- //scroll_box -->

      </div>
      <!-- //ly_cont -->
      <a href="#close" class="ly_close layer_close" @click.prevent="closeLayer">
        <img src="../../../assets/img/common/layer/btn_layer_close.png" alt="닫기">
      </a>
    </div>
    <!-- //layer_wrap_cont -->
  </div>
</template>

<script>
import $ from 'jquery'
import Pagination from '@/components/common/Pagination'
import { mapActions } from 'vuex'

export default {
  props: ['openLayer', 'addresses'],
  data () {
    return {
      ly_style: '',
      page: 1
    }
  },
  components: {
    Pagination
  },
  computed: {
    getPageData () {
      // return this.addresses.slice((this.page - 1) * 5, 5 * this.page)
      if (this.addresses && this.addresses.length > 5) {
        return this.addresses.slice(0, 5)
      }
      return this.addresses
    }
  },
  methods: {
    ...mapActions('shippingaddresses', ['deleteShippingAddresses']),

    closeLayer () {
      this.$emit('close')
    },
    showInit () {
      this.$nextTick(() => {
        const top = ($(window).height() - $('#shipping_layer').outerHeight()) / 2
        const left = ($(window).width() - $('#shipping_layer').outerWidth()) / 2
        this.ly_style = `position: absolute; margin: 0px; top: ${top > 0 ? top : 0}px; left: ${left > 0 ? left : 0}px;`
      })
    },
    pageChange (page) {
      this.page = page
    },
    newRegBookPop () {
      this.$emit('newBookReg')
    },
    deletAddrItem (addressNo, addressName) {
      if (confirm('배송지 ' + addressName + ' 을(를) 삭제하시겠습니까? ')) {
        this.deleteShippingAddresses(addressNo)
      }
    },
    updateAddress (address) {
      this.$emit('newBookReg', address)
    },
    selectAddress (address) {
      this.$emit('addrSelected', address)
    }
  },
  watch: {
    'openLayer': 'showInit'
  }
}
</script>
