<template>
  <div>
    <h3 class="tit">배송비쿠폰적용</h3>
    <div class="top_table_type order_table_type coupon_table">
      <template v-if="deliveryCoupons && deliveryCoupons.length > 0">
        <div class="table_shell">
        <table>
          <colgroup>
            <col style="width:50px;">
            <col style="width:200px">
            <col style="width:200px">
            <col>
          </colgroup>
          <thead>
            <tr>
              <th>&nbsp;</th>
              <th>쿠폰</th>
              <th>혜택</th>
              <th>사용기한</th>
            </tr>
          </thead>
          <tbody>
            <template v-if="initSortItem()" v-for="(coupon, index) in commonDeliveryCoupons">
              <tr :key="index">
                <td>
                  <span class="form_element">
                    <label :class="['check_s single',{'on':sortItem === coupon.couponIssueNo}]" @click.prevent="selectCartCoupon(coupon.couponIssueNo, coupon)">선택</label>
                  </span>
                </td>
                <td class="td_left">
                  <label for="check3">
                    <strong class="coupon_price">
                      <b>
                        {{showCouponDiscountAmt(coupon.couponDiscountAmt)}}원 할인
                      </b>
                      ({{coupon.couponName}})
                    </strong>
                    <!-- <span class="text_info">Transfer Coupon</span> -->
                  </label>
                </td>
                <td class="td_left">
                  <span class="text_info">{{makeTermsText(coupon)}}</span>
                </td>
                <td>
                  <span>{{coupon.useEndYmdt}}</span>
                </td>
              </tr>
            </template>
            <!-- <tr>
              <td class="coupon_total" colspan="5">배송비쿠폰수량:
                <span>{{showSelectedCouponDiscountAmt}}원</span>
              </td>
            </tr> -->
          </tbody>
        </table>
        </div>
      </template>
      <template v-else>
        <p class="no_data">쿠폰이 없습니다.</p>
      </template>
    </div>
  </div>
</template>

<script>
import { mapState } from 'vuex'
import { formatCurrency } from '@/utils/stringUtils'
import CouponProductCoupon from './OrderCouponProductCoupon'

export default {
  props: ['deliveryCoupons', 'display', 'deliveryCouponDiscountAmt'],

  data () {
    return {
      orderSheetNo: this.$store.state.route.params.orderSheetNo,
      sortItem: this.couponRequestCopy && this.couponRequestCopy.deliveryCouponIssueNo,
      selectedCouponDiscountAmt: this.deliveryCouponDiscountAmt
    }
  },
  components: {
    CouponProductCoupon
  },

  computed: {
    ...mapState('ordersheet', ['couponRequestCopy']),

    commonDeliveryCoupons () {
      if (this.display.hasCommonDeliveryCoupon) {
        return this.deliveryCoupons
      }
      return []
    },
    showSelectedCouponDiscountAmt () {
      return formatCurrency(this.selectedCouponDiscountAmt)
    },
    showCart () {
      if (this.area === 'PAYCO') {
        if (this.display.showCartAtPayco > 0) {
          return true
        } else {
          return false
        }
      } else {
        return true
      }
    }
  },
  methods: {
    initSortItem () {
      this.sortItem = this.couponRequestCopy && this.couponRequestCopy.deliveryCouponIssueNo
      return true
    },
    showCouponDiscountAmt (couponDiscountAmt) {
      return formatCurrency(couponDiscountAmt)
    },
    makeTermsText (coupon) {
      let text = ''

      if (coupon.freeDelivery) {
        text = '무료'
      } else if (coupon.fixedAmountDiscount) {
        text = formatCurrency(coupon.couponDiscountAmt) + '원'
      } else {
        text = `${coupon.discountRate}% (최대 ${formatCurrency(coupon.maxDiscountAmt)}원)`
      }
      return text
    },
    selectCartCoupon (index, coupon) {
      let couponIssueNo = coupon ? coupon.couponIssueNo : 0
      if (this.sortItem === index) {
        this.sortItem = -1
        couponIssueNo = 0
        this.selectedCouponDiscountAmt = 0
      } else {
        this.sortItem = index
        this.selectedCouponDiscountAmt = coupon.couponDiscountAmt
      }

      const couponReq = JSON.parse(JSON.stringify(this.couponRequestCopy))
      couponReq.deliveryCouponIssueNo = couponIssueNo
      this.$store.commit('ordersheet/SET_COUPONREQUEST_COPY', couponReq)

      this.$store.dispatch('ordersheet/calculateConpons', { orderSheetNo: this.orderSheetNo, couponRequest: this.couponRequestCopy })
    }
  }
}
</script>
