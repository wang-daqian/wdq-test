<template>
  <div id="couponOrderApplyLayer" class="layer_wrap coupon_apply_layer" v-if="openLayer">
    <div id="couponApply" class="layer_wrap_cont sp2" :style="ly_style">
      <div class="ly_tit">
        <h4>쿠폰 적용
        </h4>
      </div>
      <div class="ly_cont scroll_box">
        <order-coupon-area :orderCoupons="orderCoupons" :display="orderCouponDisplayModel" :products="orderCoupons.products" :couponRequest="couponRequestCopy" :cartCoupons="orderCoupons.cartCoupons" :deliveryCoupons="orderCoupons.deliveryCoupons" @close="closeLayer" />
        <!-- //ly_cont -->
        <a href="#close" class="ly_close layer_close" @click.prevent="closeLayer(false)">
          <img src="../../../assets/img/common/layer/btn_layer_close.png" alt="닫기">
        </a>
      </div>
      <order-coupon-amount :productCouponDiscountAmt="orderCoupons.productCouponDiscountAmt" :cartCouponDiscountAmt="orderCoupons.cartCouponDiscountAmt" :deliveryCouponDiscountAmt="orderCoupons.deliveryCouponDiscountAmt" :couponRequest="couponRequestCopy" @close="closeLayer" />
      <!-- //layer_wrap_cont -->

    </div>

  </div>
</template>

<script>
import { mapState, mapGetters } from 'vuex'
import { formatCurrency } from '@/utils/stringUtils'
import $ from 'jquery'
import OrderCouponArea from '@/components/order/order/OrderCouponArea'
import OrderCouponAmount from '@/components/order/order/OrderCouponAmount'

export default {
  props: ['openLayer', 'paymentInfo'],
  data () {
    return {
      active: {
        coupon: false
      },
      orderSheetNo: this.$store.state.route.params.orderSheetNo,
      ly_style: '',
      page: 1
    }
  },
  components: {
    OrderCouponArea,
    OrderCouponAmount
  },
  computed: {
    ...mapGetters('ordersheet', ['orderCouponDisplayModel']),
    ...mapState('ordersheet', ['orderCoupons', 'couponAmt', 'couponRequestCopy']),

    showTotalDiscountAmt () {
      let totalDiscountAmt = this.paymentInfo.productCouponAmt + this.paymentInfo.cartCouponAmt + this.paymentInfo.deliveryCouponAmt
      return formatCurrency(totalDiscountAmt)
    }
  },
  methods: {
    closeCouponPopup () {
      this.active.coupon = false
    },
    closeLayer (value) {
      this.$store.commit('ordersheet/COPY_COUPONREQUEST')
      // this.$store.commit('ordersheet/SET_USE_PAYCOCOUPON')
      this.$emit('close', value)
    },
    showInit () {
      this.$nextTick(() => {
        const top = ($(window).height() - $('#couponApply').outerHeight()) / 2
        const left = ($(window).width() - $('#couponApply').outerWidth()) / 2
        this.ly_style = `position: absolute; margin: 0px; top: ${top > 0 ? top : 0}px; left: ${left > 0 ? left : 0}px;`
      })
    },
    couponApply () {
      this.$store.dispatch('ordersheet/applyCouponOrder', { orderSheetNo: this.orderSheetNo }).then(() => {
        this.$store.commit('ordersheet/CHANGE_COUPONREQUEST')
        this.closeLayer(true)
      })
    }
  },
  watch: {
    'openLayer': 'showInit'
  }
}
</script>
