<template>
  <div style="margin-top: 50px;">
    <order-delivery-address-info-member v-if="logined" ref="member" :address="address" :shippingAddressInfo='shippingAddressInfo' :requireCustomsIdNumber="requireCustomsIdNumber" @copyOrderer="copyOrderer" @resetMileage="resetMileage" />
    <order-delivery-address-info-non-member v-else ref="nonMember" :requireCustomsIdNumber="requireCustomsIdNumber" :shippingAddressInfo='shippingAddressInfo' :ordererInput="ordererInput" @copyOrderer="copyOrderer" />
  </div>
</template>
<script>
import OrderDeliveryAddressInfoMember from '@/components/order/order/OrderDeliveryAddressInfoMember'
import OrderDeliveryAddressInfoNonMember from '@/components/order/order/OrderDeliveryAddressInfoNonMember'

export default {
  props: ['logined', 'address', 'requireCustomsIdNumber', 'ordererInput', 'shippingAddressInfo'],
  components: {
    OrderDeliveryAddressInfoMember,
    OrderDeliveryAddressInfoNonMember
  },
  computed: {
    shippingAddressInput () {
      let shippingAddressInput = {}
      if (this.logined) {
        // addressNo, addressName setting
        shippingAddressInput = { ...this.$refs.member.shippingAddressInput }
      } else {
        shippingAddressInput = { ...this.$refs.nonMember.shippingAddressInput }
      }
      return shippingAddressInput
    },
    deliveryMemoInput () {
      let deliveryMemoInput = {}
      if (this.logined) {
        deliveryMemoInput = this.$refs.member.deliveryMemoInput
      } else {
        deliveryMemoInput = this.$refs.nonMember.deliveryMemoInput
      }
      return deliveryMemoInput
    },
    validateRule () {
      return this.logined ? this.$refs.member.validateRule : this.$refs.nonMember.validateRule
    },
    isAddToShippingList () {
      return this.logined ? this.$refs.member.addToShippingList : ''
    },
    isReflectToMembInfo () {
      return this.logined ? this.$refs.member.reflectToMembInfo : ''
    },
    getAddressType () {
      return this.logined ? this.$refs.member.getAddressType : this.$refs.nonMember.getAddressType
    }
  },
  methods: {
    copyOrderer () {
      this.$emit('copyOrderer')
    },
    setOrdererInput (ordererInput) {
      if (this.logined) {
        this.$refs.member.setOrderer(ordererInput)
      } else {
        this.$refs.nonMember.setOrderer(ordererInput)
      }
    },
    setUsedMileageInt (mileage) {
      if (this.logined) {
        this.$refs.member.setUsedMileageInt(mileage)
      }
    },
    resetMileage () {
      this.$emit('resetMileage')
    }

  }
}
</script>
