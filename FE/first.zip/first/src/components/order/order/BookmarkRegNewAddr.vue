<template>
  <div id="registNewAddrLayer" class="layer_wrap delivery_add_list_layer" v-if="openLayer">
    <div id="registNewAddr" class="layer_wrap_cont" :style="ly_style">
      <form name="frmDeliveryAddressRegist" id="frmDeliveryAddressRegist" method="post" novalidate="novalidate">
        <input type="hidden" name="mode" value="shipping_regist">
        <input type="hidden" name="sno" value="">
        <input type="hidden" name="shippingNo" value="">
        <div class="ly_tit">
          <h4>나의 배송지 관리</h4>
        </div>
        <div class="ly_cont">
          <div class="scroll_box">
            <h5>배송지 등록</h5>
            <div class="left_table_type">
              <table>
                <colgroup>
                  <col style="width:20%;">
                  <col style="width:80%;">
                </colgroup>
                <tbody>
                  <tr>
                    <th scope="row">
                      <span class="important">배송지 이름</span>
                    </th>
                    <td>
                      <input type="text" ref="shippingTitle" v-model="mInput.addressName">
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">
                      <span class="important">받으실 분</span>
                    </th>
                    <td>
                      <input type="text" ref="shippingName" maxlength="30" v-model="mInput.receiverName" @keydown="gdEngKor" @input="gdEngKor">
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">
                      <span class="important">받으실 곳</span>
                    </th>
                    <td class="member_address">
                      <div class="address_postcode">
                        <input type="text" name="shippingZonecode" value="" readonly="readonly" v-model="mInput.receiverZipCd">
                        <button type="button" @click.prevent="openAddressesPopup" class="btn_post_search">우편번호검색</button>
                        <input type="hidden" name="shippingZipcode">
                      </div>
                      <div class="address_input">
                        <input type="text" name="shippingAddress" v-model="mInput.receiverAddress" readonly="readonly">
                        <input type="text" name="shippingAddressSub" v-model="mInput.receiverDetailAddress">
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">
                      <span class="important">휴대전화</span>
                    </th>
                    <td>
                      <input type="text" id="shippingPhone" ref="shippingPhone" v-model="mInput.receiverContact1" maxlength="11" @keydown="gdNum" @input="gdNum" @blur="gdNum">
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">연락처</th>
                    <td>
                      <input type="text" id="shippingCellPhone" ref="shippingCellPhone" v-model="mInput.receiverContact2" maxlength="12" @keydown="gdNumPhone" @input="gdNumPhone" @blur="gdNumPhone">
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
            <!-- <br>
            <div class="form_element">
              <input type="checkbox" id="defaultFl" name="defaultFl" value="y" class="checkbox" checked="checked" readonly="readonly">
              <label for="defaultFl" class="check_s on">
                <b>기본 배송지로 설정 합니다.</b>
              </label>
            </div> -->
          </div>
          <!-- //scroll_box -->
          <div class="btn_center_box">
            <button type="button" class="btn_ly_cancel layer_close" @click.prevent="closeLayer">
              <strong>취소</strong>
            </button>
            <button type="submit" class="btn_ly_save" @click.prevent="onClickReg">
              <strong>저장</strong>
            </button>
          </div>
        </div>
        <!-- //ly_cont -->
        <a href="#close" class="ly_close layer_close" @click.prevent="closeLayer">
          <img src="../../../assets/img/common/layer/btn_layer_close.png" alt="닫기">
        </a>
      </form>
    </div>
    <address-info @closePop="closeAddLayer" v-if="showAddLayer" />
  </div>
</template>
<script>
import $ from 'jquery'
import AddressInfo from '@/components/common/address/AddressInfo'
import { mapActions } from 'vuex'
import utils from '@/utils/memberutils'
import { replacePattern } from '@/utils/validateUtils'

export default {
  props: ['openLayer', 'defaultAddr'],
  data () {
    return {
      ly_style: '',
      mInput: {
        addressName: this.defaultAddr ? this.defaultAddr.addressName : '',
        receiverName: this.defaultAddr ? this.defaultAddr.receiverName : '',
        addressType: 'BOOK',
        defaultYn: 'N',
        receiverZipCd: this.defaultAddr ? this.defaultAddr.receiverZipCd : '',
        receiverAddress: this.defaultAddr ? this.defaultAddr.receiverAddress : '',
        receiverDetailAddress: this.defaultAddr ? this.defaultAddr.receiverDetailAddress : '',
        receiverJibunAddress: this.defaultAddr ? this.defaultAddr.receiverJibunAddress : '',
        receiverContact1: this.defaultAddr ? replacePattern(this.defaultAddr.receiverContact1, /[^\d]/g, '') : '',
        receiverContact2: this.defaultAddr ? replacePattern(this.defaultAddr.receiverContact2, /[^\d]/g, '') : ''
      },
      errTxt: '',
      showAddLayer: false
    }
  },
  components: {
    AddressInfo
  },
  computed: {

  },
  methods: {
    ...mapActions('shippingaddresses', ['newAddress', 'updateAddress']),
    closeLayer () {
      this.$emit('close')
    },
    showInit () {
      this.$nextTick(() => {
        const top = ($(window).height() - $('#registNewAddr').outerHeight()) / 2
        const left = ($(window).width() - $('#registNewAddr').outerWidth()) / 2
        this.ly_style = `position: absolute; margin: 0px; top: ${top > 0 ? top : 0}px; left: ${left > 0 ? left : 0}px;`
      })
      this.initData()
    },
    initData () {
      this.mInput.addressName = ''
      this.mInput.receiverName = ''
      this.mInput.receiverZipCd = ''
      this.mInput.receiverAddress = ''
      this.mInput.receiverDetailAddress = ''
      this.mInput.receiverJibunAddress = ''
      this.mInput.receiverContact1 = ''
      this.mInput.receiverContact2 = ''
    },
    openAddressesPopup () {
      this.showAddLayer = true
    },
    closeAddLayer (selected, address) {
      this.showAddLayer = false
      if (selected) {
        this.callbackAddr(address)
      }
    },
    callbackAddr ({ zipCd, address, addressSub, receiverJibunAddress }) {
      this.mInput.receiverZipCd = zipCd
      this.mInput.receiverAddress = address
      this.mInput.receiverDetailAddress = addressSub
      this.mInput.receiverJibunAddress = receiverJibunAddress
    },
    validateBeforeSave () {
      if (!utils.chkIsInput(this.mInput.addressName)) {
        this.errTxt = '배송지 이름을 입력하세요'
        this.$refs.shippingTitle.focus()
        return false
      }

      if (utils.chkIsInput(this.mInput.receiverName)) {

      } else {
        this.errTxt = '받으실 분 이름을 입력하세요'
        this.$refs.shippingName.focus()
        return false
      }

      // if (utils.chkIsInput(this.mInput.receiverDetailAddress)) {

      // } else {
      //   this.errTxt = '받으실 곳를 입력하세요'
      //   return false
      // }

      if (!utils.chkIsInput(this.mInput.receiverZipCd) || !utils.chkIsInput(this.mInput.receiverAddress)) {
        // this.errTxt = '우편번호를 입력하세요'
        this.errTxt = '받으실 곳을 입력하세요'
        return false
      }

      if (utils.chkIsInput(this.mInput.receiverContact1)) {
        if (!utils.chkPhone(this.mInput.receiverContact1)) {
          this.errTxt = '정확한 휴대전화를 입력해 주세요.'
          this.$refs.shippingPhone.focus()
          return false
        } else {

        }
      } else {
        this.errTxt = '휴대폰번호를 입력하세요'
        this.$refs.shippingPhone.focus()
        return false
      }
      return true
    },
    async onClickReg () {
      if (!this.validateBeforeSave()) {
        alert(this.errTxt)
        return false
      }

      if (this.defaultAddr !== null && typeof this.defaultAddr !== 'undefined') {
        const payload = {
          addressNo: this.defaultAddr.addressNo,
          data: this.mInput
        }
        await this.updateAddress(payload)
      } else {
        await this.newAddress(this.mInput)
      }
      this.$emit('regNewBookAddrPop')
    },
    gdNumPhone: function () {
      if (this.mInput.receiverContact2 !== '') {
        this.mInput.receiverContact2 = replacePattern(this.mInput.receiverContact2, /[^\d]/g, '')
      }
    },
    gdNum: function () {
      if (this.mInput.receiverContact1 !== '') {
        this.mInput.receiverContact1 = replacePattern(this.mInput.receiverContact1, /[^\d]/g, '')
      }
    },
    gdEngKor: function () {
      if (this.mInput.receiverName !== '') {
        this.mInput.receiverName = replacePattern(this.mInput.receiverName, /\s+/g, '')
      }
    }
  },
  watch: {
    'openLayer': 'showInit',
    defaultAddr: {
      handler (newValue, oldValue) {
        if (newValue) {
          this.mInput.addressName = newValue.addressName
          this.mInput.receiverName = newValue.receiverName
          this.mInput.receiverZipCd = newValue.receiverZipCd
          this.mInput.receiverAddress = newValue.receiverAddress
          this.mInput.receiverDetailAddress = newValue.receiverDetailAddress
          this.mInput.receiverJibunAddress = newValue.receiverJibunAddress
          this.mInput.receiverContact1 = newValue ? replacePattern(newValue.receiverContact1, /[^\d]/g, '') : ''
          this.mInput.receiverContact2 = newValue ? replacePattern(newValue.receiverContact2, /[^\d]/g, '') : ''
        }
      }
    }
  }
}
</script>
