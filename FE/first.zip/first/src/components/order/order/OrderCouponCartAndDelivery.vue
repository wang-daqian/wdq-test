<template>
  <!-- [D] 장바구니, 배송비 쿠폰 영역 -->
  <div class="top_table_type order_table_type coupon_table cart_coupon">
    <div class="table_shell">
      <table>
        <colgroup>
          <col style="width:20%;">
          <col style="width:80%">
        </colgroup>
        <thead>
        </thead>
        <tbody>
          <tr>
            <td class="td_left">장바구니쿠폰</td>
            <coupon-product-coupon v-if="showCart" :productNo="0" :coupons="cartCoupons" :type="'CART'" :area="area" />
          </tr>
          <tr>
            <td class="td_left">배송비쿠폰</td>
            <coupon-product-coupon v-if="showDelivery" :productNo="0" :coupons="deliveryCoupons" :type="'CART_DELIVERY'" :area="area" />
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>
import { formatCurrency } from '@/utils/stringUtils'
import CouponProductCoupon from './OrderCouponProductCoupon'
import { mapState } from 'vuex'

export default {
  props: ['cartCoupons', 'deliveryCoupons', 'display', 'area'],
  components: {
    CouponProductCoupon
  },
  computed: {
    showCart () {
      if (this.area === 'PAYCO') {
        if (this.display.showCartAtPayco > 0) {
          return true
        } else {
          return false
        }
      } else {
        return true
      }
    },
    showDelivery () {
      if (this.area === 'PAYCO') {
        if (this.display.showDeliveryAtPayco > 0) {
          return true
        } else {
          return false
        }
      } else {
        return true
      }
    },
    showMoneyAtDelivery () {
      if (this.area === 'PAYCO') {
        if (this.display.showCartAtPayco === 0) {
          if (this.display.showDeliveryAtPayco === 1) {
            return true
          } else {
            return false
          }
        }
        return false
      } else {
        return false
      }
    },
    ...mapState('ordersheet', ['couponRequestCopy']),
    ...mapState('ordersheet', ['selectedCartArea', 'selectedDeliveryArea']),
    showTotalCouponPrice () {
      let selectedCartAndDeliveryCoupon = 0
      let selectedCartCoupon = !this.cartCoupons ? this.cartCoupons : this.cartCoupons.filter(coupon => coupon.couponIssueNo === this.couponRequestCopy.cartCouponIssueNo)[0]
      let selectedDeliveryCoupon = !this.deliveryCoupons ? this.deliveryCoupons : this.deliveryCoupons.filter(coupon => coupon.couponIssueNo === this.couponRequestCopy.deliveryCouponIssueNo)[0]
      let cartCouponDiscountAmt = 0
      if (this.selectedCartArea === this.area) {
        cartCouponDiscountAmt = selectedCartCoupon ? selectedCartCoupon.couponDiscountAmt : 0
      }
      let deliveryCouponDiscountAmt = 0
      if (this.selectedDeliveryArea === this.area) {
        deliveryCouponDiscountAmt = selectedDeliveryCoupon ? selectedDeliveryCoupon.couponDiscountAmt : 0
      }
      selectedCartAndDeliveryCoupon = cartCouponDiscountAmt + deliveryCouponDiscountAmt
      return selectedCartAndDeliveryCoupon > 0 ? `- ${formatCurrency(selectedCartAndDeliveryCoupon)}` : selectedCartAndDeliveryCoupon
    }
  }
}
</script>
