<template>
  <tr>
    <td class="td_left">
      <goods-view-link :product="option" class="item_info" target="_blank">
        <input type="hidden" name="cartSno[]" value="59">
        <div class="pick_add_cont">
          <span class="pick_add_img">
            <img :src="option.imageUrl" width="40" :alt="option.showProductName" :title="option.showProductName" class="middle">
          </span>
          <div class="pick_add_info">
            <em>
              {{option.showBrandName}} {{option.showProductName}} {{option.optionManagementCd | dispManageCode}}
              <span class="no_ref" v-if="!option.refundable">환불불가</span>
            </em>

            <div class="pick_option_box">
              <template v-for="(showOption, index) in option.showOptions">
                <template class="bar" v-if="index != 0">/</template> {{showOption}}
              </template>
              {{option.showAddPrice}}
            </div>
          </div>
        </div>
      </goods-view-link>
    </td>
    <td class="td_order_amount">
      <div class="order_goods_num">
        <strong>{{option.orderCnt}}개</strong>
      </div>
    </td>
    <td>
      <strong class="order_sum_txt price">{{option.showStandardAmt}}원</strong>
    </td>
    <td class="td_benefit js-relative-none">
      <ul class="benefit_list">
        <li v-if="option.showDiscountAmt != 0" class="benefit_sale">
          <em>할인</em>
          <!-- <span>{{option.showDiscountAmt > 0 ? '- ' + option.showDiscountAmt : option.showDiscountAmt}}원</span> -->
          <span v-if="option.showImmediateDiscountAmt != 0">즉시할인
            <strong>{{option.showImmediateDiscountAmt}}원</strong>
          </span>
          <span v-if="option.showAdditionalDiscountAmt != 0">추가할인
            <strong> {{option.showAdditionalDiscountAmt}}원</strong>
          </span>
        </li>
        <!-- <li v-if="option.accumulationAmtWhenBuyConfirm > 0" class="benefit_mileage js_mileage">
          <em>적립</em>
          <span>상품
            <strong>{{showAccumulationAmt}}원</strong>
          </span>
        </li> -->
      </ul>
    </td>
    <td class="js-relative-none">
      <strong class="order_sum_txt">{{option.showPrice}}원</strong>
    </td>
    <template v-if="option.bundledFlg">
      <order-delivery-fee v-if="option.bundledFirst" :rowspan="option.bundledSize" :option="option" />
    </template>
    <template v-else>
      <order-delivery-fee :option="option" />
    </template>
  </tr>
</template>

<script>
import OrderDeliveryFee from '@/components/order/order/OrderDeliveryFee'
import GoodsViewLink from '@/components/common/GoodsViewLink'
import { formatCurrency } from '@/utils/stringUtils'

export default {
  props: ['option'],
  components: {
    OrderDeliveryFee,
    GoodsViewLink
  },
  computed: {
    showAccumulationAmt () {
      return '+' + formatCurrency(Math.ceil((this.option.accumulationAmtWhenBuyConfirm * this.option.orderCnt)))
    }
  }
}
</script>

<style>
.pick_option_box {
  color: #777777;
}
</style>
