<template>
  <div class="payment_progress">
    <div class="order_zone_tit">
      <h4>결제수단 선택</h4>
    </div>

    <div class="payment_progress_list">
      <div class="js_pay_content">
        <!-- N : 페이코결제 시작 -->
        <!-- N : 페이코결제 끝 -->

        <!-- N : 일반결제 시작 -->
        <div id="settlekind_general" class="general_payment">
          <dl>
            <dd>
              <ul class="payment_progress_select">
                <!-- <li v-if="isShowPayco" id="settlekindType_payco">
                  <input type="radio" id="settleKind_payco" value="PAYCO" v-model="payType">
                  <label for="settleKind_payco" class="choice_s">PAYCO</label>
                </li> -->
                <li v-if="isShowCreditCard" id="settlekindType_creditCard">
                  <input type="radio" id="settleKind_creditCard" value="CREDIT_CARD" v-model="payType">
                  <label for="settleKind_creditCard" class="choice_s">신용카드</label>
                </li>
                <li v-if="isShowVirtualAccount" id="virtualAccountType">
                  <input type="radio" id="virtualAccount" value="VIRTUAL_ACCOUNT" v-model="payType">
                  <label for="virtualAccount" class="choice_s">가상계좌</label>
                </li>
                <li v-if="isShowRealTimeAcocountTransfer" id="realTimeAccountTransferType">
                  <input type="radio" id="realTimeAccountTransfer" value="REALTIME_ACCOUNT_TRANSFER" v-model="payType">
                  <label for="realTimeAccountTransfer" class="choice_s">실시간계좌이체</label>
                </li>
                <li v-if="isShowEscowVirtualAccount" id="settlekindType_virtualAccount">
                  <input type="radio" id="settleKind_virtualAccount" value="ESCROW_VIRTUAL_ACCOUNT" v-model="payType">
                  <label for="settleKind_virtualAccount" class="choice_s">가상계좌(에스크로)</label>
                </li>
                <li v-if="isShowRealTransfer" id="settlekindType_realTimeAccount">
                  <input type="radio" id="settleKind_realTimeAccount" value="ESCROW_REALTIME_ACCOUNT_TRANSFER" v-model="payType">
                  <label for="settleKind_realTimeAccount" class="choice_s">실시간계좌이체(에스크로)</label>
                </li>
                <!-- <li id="settlekindType_mobile">
                  <input type="radio" id="settleKind_mobile" value="MOBILE" v-model="payType">
                  <label for="settleKind_mobile" class="choice_s">휴대폰결제</label>
                </li> -->
              </ul>
            </dd>
          </dl>
        </div>
        <!-- //general_payment -->
        <!-- N : 일반결제 끝 -->
        <!-- <div class="payments_tips">※안내: 결제수단 가상계좌 및 실시간 계좌이체는 추후 제공 예정입니다.</div> -->
      </div>

      <!-- N : 현금영수증/계산서 발행 시작 -->
      <div id="receiptSelect" class="cash_tax_get" hidden>
        <dl>
          <dt>현금영수증/계산서 발행</dt>
          <dd>
            <div class="form_element">
              <ul class="payment_progress_select">
                <li id="nonReceiptView">
                  <input type="radio" id="receiptNon" name="receiptFl" value="n" onclick="gd_receipt_display();">
                  <label for="receiptNon" class="choice_s on">
                    <div class="cash_receipt_non">신청안함</div>
                    <div class="cash_receipt_pg">현금영수증 (※ 결제창에서 신청)</div>
                  </label>
                </li>
                <li id="taxReceiptView">
                  <input type="radio" id="receiptTax" name="receiptFl" value="t" onclick="gd_receipt_display();">
                  <label for="receiptTax" class="choice_s">세금계산서</label>
                </li>
              </ul>
            </div>
          </dd>
        </dl>

        <!-- N : 세금 계산서 -->
        <div id="tax_info" class="tax_invoice_box js_receipt dn">
          <div class="order_table_type">
            <table summary="세금계산서 입력폼입니다." class="table_left">
              <colgroup>
                <col style="width:15%;">
                <col style="width:85%;">
              </colgroup>
              <tbody>
                <tr>
                  <th scope="row">사업자번호</th>
                  <td>
                    <input type="text" name="taxBusiNo" placeholder="- 없이 입력하세요" value="" maxlength="10">
                  </td>
                </tr>
                <tr>
                  <th scope="row">회사명</th>
                  <td>
                    <input type="text" name="taxCompany" value="" maxlength="50" data-pattern="gdMemberNmGlobal">
                  </td>
                </tr>
                <tr>
                  <th scope="row">대표자명</th>
                  <td>
                    <input type="text" name="taxCeoNm" value="">
                  </td>
                </tr>
                <tr>
                  <th scope="row">업태</th>
                  <td>
                    <input type="text" name="taxService" value="">
                  </td>
                </tr>
                <tr>
                  <th scope="row">종목</th>
                  <td>
                    <input type="text" name="taxItem" value="">
                  </td>
                </tr>
                <tr>
                  <th scope="row">사업장주소</th>
                  <td class="member_address">
                    <div class="address_postcode">
                      <input type="text" name="taxZonecode" value="" readonly="readonly">
                      <input type="hidden" name="taxZipcode" value="">
                      <span id="taxrZipcodeText" class="old_post_code"></span>
                      <button type="button" onclick="gd_postcode_search('taxZonecode', 'taxAddress', 'taxZipcode');" class="btn_post_search">우편번호검색</button>
                    </div>
                    <div class="address_input">
                      <input type="text" name="taxAddress" value="">
                      <input type="text" name="taxAddressSub" value="">
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <!-- //tax_invoice_box -->

      </div>
      <!-- //cash_tax_get -->
      <!-- N : 현금영수증/계산서 발행 끝-->

    </div>
    <!-- //payment_progress_list -->
    <div class="payment_final">
      <div class="payment_final_total">
        <dl>
          <dt>최종 결제 금액</dt>
          <dd>
            <span>
              <strong id="totalSettlePriceView">{{showPayAmt}}</strong>원</span>
          </dd>
        </dl>
      </div>
      <div v-if="logined">
        <order-agreement-member ref="orderAgreementMember"></order-agreement-member>
      </div>
      <div v-else>
        <order-agreement-non-member ref="orderAgreementNonMember"></order-agreement-non-member>
      </div>
      <div class="btn_center_box">
        <button class="btn_order_buy order-buy" @click.prevent="payments(usingPayType)">
          <em>결제하기</em>
        </button>
      </div>
    </div>
    <!-- //payment_final -->
  </div>
</template>

<script>
import { formatCurrency } from '@/utils/stringUtils'
import OrderAgreementMember from '@/components/order/order/OrderAgreementMember'
import OrderAgreementNonMember from '@/components/order/order/OrderAgreementNonMember'

export default {
  props: ['paymentInfo', 'logined', 'availablePayTypes', 'checkedPayTpye'],

  components: {
    OrderAgreementMember,
    OrderAgreementNonMember
  },
  data () {
    return {
      payType: this.checkedPayTpye,
      usedMileageInt: 0
    }
  },
  computed: {
    usingPayType () {
      return this.payType
    },
    showPayAmt: {
      get () {
        // return this.paymentInfo && formatCurrency(this.paymentInfo.paymentAmt - this.usedMileageInt)
        return this.paymentInfo && formatCurrency(this.paymentInfo.paymentAmt)
      }
    },
    agreeCheck: {
      get () {
        return (this.logined ? this.$refs.orderAgreementMember.agreeCheck : this.$refs.orderAgreementNonMember.agreeCheck)
      }
    },
    isShowPayco () {
      return this.availablePayTypes && this.availablePayTypes.some((type) => type.payType === 'PAYCO' && type.pgTypes.some((pg) => pg === 'PAYCO'))
    },
    isShowCreditCard () {
      return this.availablePayTypes && this.availablePayTypes.some((type) => type.payType === 'CREDIT_CARD' && type.pgTypes.some((pg) => pg === 'KCP'))
    },
    isShowVirtualAccount () {
      return this.availablePayTypes && this.availablePayTypes.some((type) => type.payType === 'VIRTUAL_ACCOUNT' && type.pgTypes.some((pg) => pg === 'KCP'))
    },
    isShowRealTimeAcocountTransfer () {
      return this.availablePayTypes && this.availablePayTypes.some((type) => type.payType === 'REALTIME_ACCOUNT_TRANSFER' && type.pgTypes.some((pg) => pg === 'KCP'))
    },
    isShowEscowVirtualAccount () {
      return this.availablePayTypes && this.availablePayTypes.some((type) => type.payType === 'ESCROW_VIRTUAL_ACCOUNT' && type.pgTypes.some((pg) => pg === 'KCP'))
    },
    isShowRealTransfer () {
      return this.availablePayTypes && this.availablePayTypes.some((type) => type.payType === 'ESCROW_REALTIME_ACCOUNT_TRANSFER' && type.pgTypes.some((pg) => pg === 'KCP'))
    }
  },
  methods: {
    setUsedMileageInt (mileage) {
      this.usedMileageInt = mileage
    },
    payments (payType) {
      this.$emit('payments', payType)
    }
  }
}
</script>

<style scope>
/* .payments_tips {
  margin-top: 10px;
  color: #3757dc;
  font-size: 12px;
} */
</style>
