<template>
  <div class="ly_buy">
    <div class="coupon_total_box sp2">
      <dl>
        <dt>총 상품할인금액</dt>
        <dd>
          <strong id="productCoupon"> {{this.showProductCouponDiscountAmt}}</strong>원</dd>
      </dl>
      <dl>
        <dt>장바구니 할인금액</dt>
        <dd>
          <strong id="cartCoupon">{{this.showCartCouponDiscountAmt}}</strong>원</dd>
      </dl>
      <dl>
        <dt>배송비 할인금액</dt>
        <dd>
          <strong id="shippingCoupon">{{this.showDeliveryAmt}}</strong>원</dd>
      </dl>
      <dl>
        <dt>총 할인금액</dt>
        <dd>
          <strong id="totalCoupon">{{this.showTotalDiscountAmt}}</strong>원</dd>
      </dl>
    </div>
    <!-- //coupon_total_box -->
    <div class="btn_center_box sp2">
      <button type="button" @click="maxCalcCoupon" class="btn_cart_gray_go sp2">
        <span>쿠폰최대할인 일괄적용</span>
      </button>
      <button type="button" id="btnCouponApply" class="btn_ly_coupon_apply sp2" @click="couponApply">
        <strong>쿠폰적용완료</strong>
      </button>
      <button type="button" class="btn_ly_cancel layer_close sp2" @click.prevent="closeLayer">
        <strong>취소</strong>
      </button>
    </div>
  </div>
</template>

<script>
import { formatCurrency } from '@/utils/stringUtils'
export default {
  props: ['productCouponDiscountAmt', 'cartCouponDiscountAmt', 'deliveryCouponDiscountAmt', 'couponRequest'],
  data () {
    return {
      orderSheetNo: this.$store.state.route.params.orderSheetNo
    }
  },
  computed: {
    totalDiscountAmt () {
      return this.productCouponDiscountAmt + this.cartCouponDiscountAmt + this.deliveryCouponDiscountAmt
    },
    showProductCouponDiscountAmt () {
      return formatCurrency(this.productCouponDiscountAmt)
    },
    showCartCouponDiscountAmt () {
      return formatCurrency(this.cartCouponDiscountAmt)
    },
    showDeliveryAmt () {
      return formatCurrency(this.deliveryCouponDiscountAmt)
    },
    showTotalDiscountAmt () {
      return formatCurrency(this.totalDiscountAmt)
    }
  },
  methods: {
    closeLayer () {
      this.$store.commit('ordersheet/COPY_COUPONREQUEST')
      // this.$store.commit('ordersheet/SET_USE_PAYCOCOUPON')
      this.$emit('close', false)
    },
    couponApply () {
      this.$store.dispatch('ordersheet/applyCouponOrder', { orderSheetNo: this.orderSheetNo }).then(() => {
        this.$store.commit('ordersheet/CHANGE_COUPONREQUEST')
        this.$emit('close', true)
      })
    },
    maxCalcCoupon () {
      alert('쿠폰적용완료 버튼을 선택하여 쿠폰할인을 최종적으로 적용하세요.')
      this.$store.dispatch('ordersheet/maxCalculateConpons', { orderSheetNo: this.orderSheetNo, couponRequest: this.couponRequest })
    }
  }
}
</script>
