<template>
  <div id="container">
    <div id="contents">
      <!-- 본문 시작 -->

      <div class="location_wrap">
        <div class="location_cont">
          <em>
            <a href="/" class="local_home">HOME</a> &gt; 주문완료</em>
        </div>
      </div>
      <!-- //location_wrap -->

      <div class="sub_content">

        <!-- //side_cont -->

        <div class="content_box">
          <div class="order_wrap">
            <div class="order_tit">
              <h2>결제실패</h2>
              <ol>
                <li>
                  <span>01</span> 장바구니
                  <span>
                    <img src="../../../assets/img/member/icon_join_step_off.png" alt="">
                  </span>
                </li>
                <li>
                  <span>02</span> 주문서작성/결제
                  <span>
                    <img src="../../../assets/img/member/icon_join_step_off.png" alt="">
                  </span>
                </li>
                <li class="page_on">
                  <span>03</span> 주문완료</li>
              </ol>
            </div>
            <!-- //member_tit -->

            <div class="order_cont">
              <div class="order_end">

                <!-- 재접속 등에 의한 기주문 완료 건으로 접속시 -->
                <div class="order_end_completion">
                  <span>
                    <img src="../../../assets/img/order/order_end_completion.png" alt="">
                  </span>
                  <p>
                    <strong>{{message}}</strong>
                    <br>
                    <em>실패사유를 확인하신 후 '이전페이지 가기' 또는 '장바구니 가기' 버튼을 통해 주문/결제를 다시 시도 하시거나, <br>계속 실패되시는 경우 고객센터(02-446-0114)로 문의 주시기 바랍니다.</em>
                  </p>
                </div>

              </div>
              <!-- //order_info -->
              <div class="btn_center_box">
                <a href="javascript:" class="btn_claim_cancel" @click.prevent="gotoPre">이전페이지 가기</a>
                <button class="btn_cart_gray_go" @click.prevent="gotoCart">장바구니 가기</button>
                <button class="btn_claim_ok" @click.prevent="gotoHome">홈으로 가기</button>
              </div>
            </div>
            <!-- //order_end -->
          </div>
          <!-- //order_cont -->
        </div>
        <!-- //order_wrap -->
      </div>
      <!-- //content_box -->

    </div>
    <!-- //sub_content -->
  </div>
</template>

<script>
export default {
  data () {
    return {
      message: this.$route.query.message || ''
    }
  },
  methods: {
    gotoHome () {
      if (opener) {
        opener.location.href = '/'
        self.close()
      } else {
        location.href = '/'
      }
    },
    gotoCart () {
      if (opener) {
        opener.location.href = '/order/cart'
      } else {
        location.href = '/order/cart'
      }
    },
    gotoPre () {
      if (opener) {
        opener.location.href = `/order/${this.$store.state.route.query.orderSheetNo}`
        self.close()
      } else {
        location.href = `/order/${this.$store.state.route.query.orderSheetNo}`
      }
    }
  }
}
</script>
