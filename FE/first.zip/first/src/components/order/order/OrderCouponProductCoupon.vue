<template>
  <td class="coupon_sel td_left">
    <template v-if="coupons && coupons.length > 0">
      <ul class="form_element">
        <li>
          <input type="radio" :name="makeCouponNameProperty(type)" :id="makeCouponNameProperty(type)" value="0" v-model.number="selectedCoupon" @change="selectCoupon(type, null)">
          <label class="choice_s" :for="makeCouponNameProperty(type)">
            <span class="rating_star">
              <span>적용안함</span>
            </span>
          </label><br>
        </li>
        <template v-for="(coupon, index) in coupons">
          <li :key="index" v-if="showCoupon(type, coupon, area)">
            <!-- <input type="radio" :name="makeCouponNameProperty(type)" :id="productNo + '_' + coupon.couponIssueNo" @change="selectCoupon(type, coupon)" :value="coupon.couponIssueNo" v-model.number="selectedCoupon" :disabled="!couponUsable(type,coupon.couponIssueNo) || (checkDisabled)"> -->
            <input type="radio" :name="makeCouponNameProperty(type)" :id="productNo + '_' + coupon.couponIssueNo" @change="selectCoupon(type, coupon)" :value="coupon.couponIssueNo" v-model.number="selectedCoupon" :disabled="couponUsed(type,coupon.couponIssueNo) || (checkDisabled)">
            <label class="choice_s" :for="productNo + '_' + coupon.couponIssueNo" :class="{ duplicated: couponUsable(type,coupon.couponIssueNo) && couponUsed(type,coupon.couponIssueNo) }">
              <span class="rating_star">
                <span>
                  <em>{{coupon.couponDiscountAmt|formatNumber}}원</em>
                </span>
                <span>{{makeCouponText(coupon)}}</span>
              </span>
            </label>
          </li>
        </template>
      </ul>
    </template>
    <template v-else>
      <p class="td_left no_coupon">적용 가능한 쿠폰이 없습니다.</p>
    </template>
  </td>
</template>

<script>
import { formatCurrency } from '@/utils/stringUtils'
import { mapState } from 'vuex'
export default {
  props: ['productNo', 'coupons', 'type', 'area'],
  data () {
    return {
      orderSheetNo: this.$store.state.route.params.orderSheetNo,
      txt: {
        'PRODUCT': '상품쿠폰',
        'PRODUCT_PLUS': '상품플러스쿠폰',
        'CART': '장바구니쿠폰',
        'CART_DELIVERY': '배송비쿠폰'
      },
      couponIssueNo: 0
    }
  },
  computed: {
    ...mapState('ordersheet', ['couponRequestCopy']),
    ...mapState('ordersheet', ['selectedCartArea', 'selectedDeliveryArea']),
    couponsTemp: {
      get () {
        if (this.couponRequestCopy) {
          return this.couponRequestCopy.productCoupons.filter(item => item.productNo === this.productNo)
        }
      }
    },
    selectedCoupon: {
      get () {
        if (this.couponRequestCopy) {
          if (this.type === 'CART') {
            if (this.area === this.selectedCartArea) {
              return this.couponRequestCopy.cartCouponIssueNo
            } else {
              return 0
            }
          } else if (this.type === 'CART_DELIVERY') {
            if (this.area === this.selectedDeliveryArea) {
              return this.couponRequestCopy.deliveryCouponIssueNo
            } else {
              return 0
            }
            // return this.couponRequestCopy.deliveryCouponIssueNo
          }

          if (this.couponsTemp[0]) {
            if (this.type === 'PRODUCT') {
              return this.couponsTemp[0].couponIssueNo
            } else if (this.type === 'PRODUCT_PLUS') {
              return this.couponsTemp[0].plusCouponIssueNo
            }
          }
        }
      },
      set (val) {
        if (this.type === 'PRODUCT') {
          this.$store.commit('ordersheet/SET_COUPONREQUEST_COUPONISS', { productNo: this.productNo, couponIssueNo: val, isCopy: true })
        } else if (this.type === 'PRODUCT_PLUS') {
          this.$store.commit('ordersheet/SET_COUPONREQUEST_PLUSCOUPONISS', { productNo: this.productNo, plusCouponIssueNo: val, isCopy: true })
        }
      }
    },
    ...mapState('ordersheet', ['otherCouponUsable']),
    checkDisabled () {
      if (this.type === 'CART' || this.type === 'CART_DELIVERY') return false
      return !this.otherCouponUsable
    }
  },
  methods: {
    couponUsed (type, issNo) {
      if (type === 'CART' || type === 'CART_DELIVERY') {
        return false
      }
      if (this.couponsTemp[0]) {
        if (type === 'PRODUCT_PLUS') {
          const plusCoupons = this.couponsTemp[0].couponPlusDisable.filter((item) => item.couponIssueNo === issNo)
          if (plusCoupons.length > 0) {
            return plusCoupons[0].disable
          }
        } else if (type === 'PRODUCT') {
          const coupons = this.couponsTemp[0].couponDisable.filter((item) => item.couponIssueNo === issNo)
          if (coupons.length > 0) {
            return coupons[0].disable
          }
        }
      }
      return false
    },
    couponUsable (type, issNo) {
      if (type === 'CART' || type === 'CART_DELIVERY') {
        return true
      }
      if (this.couponsTemp[0]) {
        if (type === 'PRODUCT_PLUS') {
          const plusCoupons = this.couponsTemp[0].couponPlusDisable.filter((item) => item.couponIssueNo === issNo)
          if (plusCoupons.length > 0) {
            return plusCoupons[0].usable
          }
        } else if (type === 'PRODUCT') {
          const coupons = this.couponsTemp[0].couponDisable.filter((item) => item.couponIssueNo === issNo)
          if (coupons.length > 0) {
            return coupons[0].usable
          }
        }
      }
      return true
    },
    makeCouponText (coupon) {
      let text = ''
      // const time = getStrYMDHM(new Date(coupon.useEndYmdt.replace(/-/g, '/')))
      const time = coupon.useEndYmdt
      if (coupon.freeDelivery) {
        text = `${coupon.couponName}(무료)${time}까지 사용가능`
      } else if (coupon.fixedAmountDiscount) {
        text = `${coupon.couponName}(${formatCurrency(coupon.couponDiscountAmt)}원)${time}까지 사용가능`
      } else {
        text = `${coupon.couponName}(${coupon.discountRate}% 최대 ${formatCurrency(coupon.maxDiscountAmt)}원)${time}까지 사용가능`
      }
      return text
    },
    makeCouponNameProperty (type) {
      let nameProperty = ''
      switch (type) {
        case 'PRODUCT':
        case 'PRODUCT_PLUS': // UNAUTHORIZED
          nameProperty = `cart_coupon_${this.productNo}_${this.type}`
          break
        case 'CART':
        case 'CART_DELIVERY':
          nameProperty = `cart_coupon_${this.type}${this.area}`
          break
      }
      return nameProperty
    },
    selectCoupon (type, coupon) {
      let previousCouponIssueNo = this.couponRequestCopy.cartCouponIssueNo
      this.couponIssueNo = coupon ? coupon.couponIssueNo : 0

      const couponReq = JSON.parse(JSON.stringify(this.couponRequestCopy))
      switch (type) {
        case 'PRODUCT':
          this.$store.commit('ordersheet/SET_COUPONREQUEST_COUPONISS', { productNo: this.productNo, couponIssueNo: this.couponIssueNo, isCopy: true })
          break
        case 'PRODUCT_PLUS':
          this.$store.commit('ordersheet/SET_COUPONREQUEST_PLUSCOUPONISS', { productNo: this.productNo, plusCouponIssueNo: this.couponIssueNo, isCopy: true })
          break
        case 'CART':
          if (coupon && !coupon.otherCouponUsable) {
            if (confirm('이 쿠폰 사용 시 상품쿠폰은 사용할 수 없습니다. 이 쿠폰을 사용하시겠습니까?')) {
              couponReq.productCoupons.forEach((item) => {
                item.couponIssueNo = 0
                item.plusCouponIssueNo = 0
                item.couponDisable.forEach(si => {
                  si.usable = false
                  si.disable = false
                })
                item.couponPlusDisable.forEach(si => {
                  si.usable = false
                  si.disable = false
                })
              })
              couponReq.cartCouponIssueNo = this.couponIssueNo
              this.$store.commit('ordersheet/SET_COUPONREQUEST_COPY', couponReq)
              this.$store.commit('ordersheet/CHANGE_OTHER_COUPON_USABLE', coupon.otherCouponUsable)
            } else {
              couponReq.cartCouponIssueNo = previousCouponIssueNo
              this.$store.commit('ordersheet/SET_COUPONREQUEST_COPY', couponReq)
              return
            }
          } else {
            let otherCouponUsable = coupon ? coupon.otherCouponUsable : true
            couponReq.cartCouponIssueNo = this.couponIssueNo
            this.$store.commit('ordersheet/SET_COUPONREQUEST_COPY', couponReq)
            this.$store.commit('ordersheet/CHANGE_OTHER_COUPON_USABLE', otherCouponUsable)
          }
          break
        case 'CART_DELIVERY':
          couponReq.deliveryCouponIssueNo = this.couponIssueNo
          this.$store.commit('ordersheet/SET_COUPONREQUEST_COPY', couponReq)
          break
      }
      this.$store.dispatch('ordersheet/calculateConpons', { orderSheetNo: this.orderSheetNo, couponRequest: this.couponRequestCopy })
    },
    showCoupon (type, coupon, area) {
      let isShow = false
      switch (type) {
        case 'CART':
        case 'CART_DELIVERY':
          if (area === 'PAYCO') {
            if (coupon.limitPayType === 'PAYCO') {
              isShow = true
            } else {
              isShow = false
            }
          } else {
            if (coupon.limitPayType === 'PAYCO') {
              isShow = false
            } else {
              isShow = true
            }
          }
          break
        default:
          isShow = true
          break
      }
      return isShow
    }
  }
}
</script>
