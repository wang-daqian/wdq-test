<template>
  <td class="td_delivery" :rowspan="this.rowspan">
    <template v-if="!option.deliverable">
      <span class="bx_price">
        <span class="number">{{option.showShippingFee}}</span>
      </span>
    </template>
    <template v-else-if="!option.free">
      <span class="bx_price">
        <!-- <span class="txt"> 기본 - 금액별배송비</span> -->
        <strong class="number">{{option.showShippingFee}}원</strong>
        <em class="add_txt" v-if="option.deliveryPayType === 'PAY_ON_DELIVERY'">(착불)</em>
      </span>
    </template>
    <template v-else>
      <span class="bx_price">
        <span class="txt">무료</span>
      </span>
    </template>
  </td>
</template>

<script>
export default {
  props: ['option', 'rowspan']
}
</script>
<style>
.bx_price .number {
  font-size: 13px;
  font-weight: bold;
  color: #333;
}
.bx_price .add_txt {
  display: block;
  font-size: 13px;
}
.bx_price .txt {
  font-size: 13px;
}
</style>
