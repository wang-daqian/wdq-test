<template>
  <div id="container">
    <div id="contents">
      <!-- 본문 시작 -->

      <div class="location_wrap">
        <div class="location_cont">
          <em>
            <a href="/" class="local_home">HOME</a> &gt; 주문완료</em>
        </div>
      </div>
      <!-- //location_wrap -->

      <div class="sub_content">

        <!-- //side_cont -->

        <div class="content_box">
          <div class="order_wrap">
            <div class="order_tit">
              <h2>주문완료</h2>
              <ol>
                <li>
                  <span>01</span> 장바구니
                  <span>
                    <img src="../../../assets/img/member/icon_join_step_off.png" alt="">
                  </span>
                </li>
                <li>
                  <span>02</span> 주문서작성/결제
                  <span>
                    <img src="../../../assets/img/member/icon_join_step_off.png" alt="">
                  </span>
                </li>
                <li class="page_on">
                  <span>03</span> 주문완료</li>
              </ol>
            </div>
            <!-- //member_tit -->

            <div class="order_cont" v-if="this.order">
              <div class="order_end">

                <!-- 주문 접수 완료 -->
                <div class="order_end_completion">
                  <span>
                    <img src="../../../assets/img/order/order_end_completion.png" alt="">
                  </span>
                  <p>
                    <strong>주문이 정상적으로 접수 되었습니다.</strong>
                    <br>
                    <em>감사합니다.</em>
                  </p>
                </div>

                <div class="order_zone_tit">
                  <h4>주문요약정보</h4>
                </div>

                <div class="order_table_type width_auto">
                  <table class="table_left">
                    <colgroup>
                      <col style="width:15%;">
                      <col style="width:85%;">
                    </colgroup>
                    <tbody>
                      <tr>
                        <th>결제수단</th>
                        <td v-if="this.order.payInfo.payType==='VIRTUAL_ACCOUNT' || this.order.payInfo.payType==='ESCROW_VIRTUAL_ACCOUNT'">
                          <div class="pay_with_list">
                            <strong>{{showPayTypeLabel}}</strong>
                          </div>
                        </td>
                        <td v-else-if="this.order.payInfo.payType==='CREDIT_CARD' || this.order.payInfo.payType==='PAYCO'">
                          <div class="pay_with_list">
                            <strong>{{showPayTypeLabel}}</strong>
                            <strong>{{showCardName}}</strong>
                          </div>
                        </td>
                        <td v-else-if="this.order">
                          <div class="pay_with_list">
                            <strong>{{showPayTypeLabel}}</strong>
                            <strong>{{showBankName}}</strong>
                          </div>
                        </td>
                      </tr>
                      <tr v-if="(this.order.payInfo.payType=='VIRTUAL_ACCOUNT' || this.order.payInfo.payType=='ESCROW_VIRTUAL_ACCOUNT') && isPayWait">
                        <th>입금정보</th>
                        <td v-if="this.order && this.order.payInfo">
                          <div class="pay_with_list">
                            <ul>
                              <li>입금자명 : {{showDepositorName}}</li>
                              <li>은행명 : {{showBankName}}</li>
                              <li>입금계좌 : {{this.order.payInfo.bankInfo.account}}</li>
                              <li>입금기한 : {{this.order.payInfo.bankInfo.paymentExpirationYmdt}} </li>
                            </ul>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <th>주문번호</th>
                        <td>{{orderNo}}</td>
                      </tr>
                      <tr>
                        <th>주문일자</th>
                        <td>{{showOrderYmdt}}</td>
                      </tr>
                      <tr>
                        <th>주문상품</th>
                        <td>
                          <p v-for="(item,index) in makeOrderItems()" :key="index">
                            {{item}}
                          </p>
                        </td>
                      </tr>
                      <tr>
                        <th>주문자명</th>
                        <td>{{showOrderName}}</td>
                      </tr>
                      <tr>
                        <th>배송정보</th>
                        <td>
                          <p>
                            <template v-if="this.order.shippingAddress.addressName">
                              <strong>{{this.order.shippingAddress.addressName}}</strong>
                              <br>
                            </template>
                            <strong>{{this.order.shippingAddress.receiverName}}</strong>
                            <br> {{this.showContact}}
                            <br> ({{this.order.shippingAddress.receiverZipCd}})
                            <br>{{this.order.shippingAddress.receiverAddress}} {{this.order.shippingAddress.receiverDetailAddress}}
                            <template v-if="this.order.deliveryMemo!=null">
                              <br> 배송 메모 : {{this.order.deliveryMemo}}
                            </template>
                          </p>
                        </td>
                      </tr>
                      <tr>
                        <th>상품 합계 금액</th>
                        <td>
                          <strong class="order_payment_sum">{{this.order.lastOrderAmount.standardAmt | formatNumber}}원</strong>
                          <span class="add_currency"></span>
                        </td>
                      </tr>
                      <tr>
                        <th>배송비</th>
                        <td>{{totalDeliveryAmt| formatNumber}}원
                          <span class="add_currency">
                            ( (배송비
                            <span class="goods-mileage">{{this.order.lastOrderAmount.deliveryAmt|formatNumber}}</span>원 - 배송비쿠폰할인
                            <span class="member-mileage">{{this.order.lastOrderAmount.deliveryCouponDiscountAmt|formatNumber}}</span>원) + 지역별추가배송비 {{this.order.lastOrderAmount.remoteDeliveryAmt|formatNumber}}원 )
                          </span>
                        </td>
                      </tr>
                      <tr>
                        <th>할인혜택</th>
                        <td>
                          <ul class="order_benefit_list">
                            <li class="order_benefit_sale">
                              <em>할인 :
                                <strong>(-) {{this.totalDiscountAmt | formatNumber}}원</strong>
                                <span>(즉시할인 {{this.order.lastOrderAmount.immediateDiscountAmt | formatNumber}}원 + 추가할인 {{this.order.lastOrderAmount.additionalDiscountAmt | formatNumber}}원 + 상품쿠폰할인 {{this.order.lastOrderAmount.productCouponDiscountAmt | formatNumber}}원 + 장바구니쿠폰 할인 {{this.order.lastOrderAmount.cartCouponDiscountAmt | formatNumber}}원)
                                </span>
                              </em>
                            </li>
                            <li v-if="isUseMallAccumulation" class="order_benefit_mileage">
                              <em> {{showAccumulationName}} 사용 :
                                <strong>(-) {{this.order.lastOrderAmount.subPayAmt | formatNumber}}{{showAccumulationUnit}}</strong>
                              </em>
                            </li>
                          </ul>
                        </td>
                      </tr>
                      <tr>
                        <th>총 결제 금액</th>
                        <td>
                          <strong class="order_payment_sum">{{this.order.lastOrderAmount.chargeAmt | formatNumber}}원</strong>
                          <span class="add_currency"></span>
                        </td>
                      </tr>
                      <tr hidden>
                        <th>현금영수증</th>
                        <td>
                          미발급
                        </td>
                      </tr>
                      <tr hidden>
                        <th>세금계산서</th>
                        <td>
                          미발급
                        </td>
                      </tr>
                      <tr v-if="isUseMallAccumulation">
                        <th>적립정보</th>
                        <td>
                          <ul class="order_benefit_list">
                            <li>
                              <em> 구매확정 시
                                <strong>{{Math.ceil(this.order.accumulationAmtWhenBuyConfirm) | formatNumber}}{{showAccumulationUnit}}</strong>
                                적립
                              </em>
                            </li>
                          </ul>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
              <!-- //order_info -->
              <div class="btn_center_box">
                <button class="btn_order_end_ok" @click.prevent="gotoHome">
                  <em>확인</em>
                </button>
              </div>
            </div>
            <!-- //order_end -->
          </div>
          <!-- //order_wrap -->
        </div>
        <!-- //content_box -->

      </div>
      <!-- //sub_content -->
    </div>
    <!-- //본문 끝 contents -->
  </div>
</template>
<script>
import { mapState, mapGetters } from 'vuex'

export default {
  metaInfo: {
    title: '주문완료'
  },
  data () {
    return {
      params: '',
      bankName: '',
      account: '',
      vaDate: '',
      payType: '',
      resp: ''
    }
  },
  computed: {
    ...mapState('myorder', ['order']),
    ...mapGetters('common', ['showAccumulationName', 'isUseMallAccumulation', 'showAccumulationUnit']),

    result: {
      get () {
        return this.$store.state.route.query.result
      }
    },
    orderSheetNo: {
      get () {
        return this.$store.state.route.query.orderSheetNo
      }
    },
    orderNo: {
      get () {
        return this.$store.state.route.query.orderNo
      }
    },
    message: {
      get () {
        return this.$store.state.route.query.message
      }
    },
    showPayTypeLabel () {
      return this.order && this.order.payTypeLabel
    },
    showBankName () {
      return this.order.payInfo.bankInfo && this.order.payInfo.bankInfo.bankName
    },
    showCardNo () {
      return this.order.payInfo.cardInfo && this.order.payInfo.cardInfo.cardNo
    },
    showCardName () {
      return this.order.payInfo.cardInfo && this.order.payInfo.cardInfo.cardName
    },
    showDepositorName () {
      return this.order.payInfo.bankInfo && this.order.payInfo.bankInfo.depositorName
    },
    showOrderYmdt () {
      return this.order && this.order.orderYmdt
    },
    showContact () {
      if (this.order && this.order.shippingAddress.receiverContact2) {
        return this.order.shippingAddress.receiverContact1 + '/' + this.order.shippingAddress.receiverContact2
      } else {
        return this.order.shippingAddress.receiverContact1
      }
    },
    showOrderName () {
      return (this.order && this.order.orderer) ? this.order.orderer.ordererName : ''
    },
    totalDiscountAmt () {
      return this.order.lastOrderAmount.immediateDiscountAmt + this.order.lastOrderAmount.additionalDiscountAmt + this.order.lastOrderAmount.productCouponDiscountAmt + this.order.lastOrderAmount.cartCouponDiscountAmt
    },
    totalDeliveryAmt () {
      return this.order.lastOrderAmount.deliveryAmt - this.order.lastOrderAmount.deliveryCouponDiscountAmt + this.order.lastOrderAmount.remoteDeliveryAmt
    },
    isPayWait () {
      let orderStatusType = ''

      if (this.order && this.order.orderOptionsGroupByPartner && this.order.orderOptionsGroupByPartner.length > 0) {
        this.order.orderOptionsGroupByPartner.some(p => {
          if (p.orderOptionsGroupByDelivery && p.orderOptionsGroupByDelivery.length > 0) {
            p.orderOptionsGroupByDelivery.some(d => {
              if (d.orderOptions && d.orderOptions.length > 0) {
                d.orderOptions.some(o => {
                  if (o.orderStatusType === 'DEPOSIT_WAIT' || o.orderStatusType === 'PAY_WAIT') {
                    orderStatusType = o.orderStatusType
                    return true
                  }
                })
              }
              return (orderStatusType === 'DEPOSIT_WAIT' || orderStatusType === 'PAY_WAIT')
            })
          }
          return (orderStatusType === 'DEPOSIT_WAIT' || orderStatusType === 'PAY_WAIT')
        })
      }
      if (orderStatusType === 'DEPOSIT_WAIT' || orderStatusType === 'PAY_WAIT') {
        return true
      } else {
        return false
      }
    }
  },
  methods: {
    gotoHome () {
      if (opener) {
        opener.location.href = '/'
        self.close()
      } else {
        location.href = '/'
      }
    },
    makeOrderItems () {
      let orderItems = []

      if (this.order && this.order.orderOptionsGroupByPartner && this.order.orderOptionsGroupByPartner.length > 0) {
        this.order.orderOptionsGroupByPartner.forEach(p => {
          if (p.orderOptionsGroupByDelivery && p.orderOptionsGroupByDelivery.length > 0) {
            p.orderOptionsGroupByDelivery.forEach(d => {
              if (d.orderOptions && d.orderOptions.length > 0) {
                d.orderOptions.forEach(o => {
                  let itemStr = ''
                  if (o.brandName != null) {
                    itemStr += o.brandName
                  }
                  if (o.productName != null) {
                    itemStr += o.productName
                  }
                  if (o.optionTitle != null) {
                    itemStr += o.optionTitle
                  }
                  // itemStr = `(${o.brandName})${o.productName}${o.optionTitle}`
                  if (itemStr !== '') {
                    orderItems.push(itemStr)
                  }
                })
              }
            })
          }
        })
      }

      return orderItems
    }
  }
}
</script>
