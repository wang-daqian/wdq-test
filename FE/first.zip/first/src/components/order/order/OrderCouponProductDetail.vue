<template>
  <div class="top_table_type order_table_type coupon_table cart_coupon">
    <div class="table_shell">
      <table>
        <colgroup>
          <col style="width:20%;">
          <col style="width:80%">
        </colgroup>
        <thead>
          <tr>
            <!-- <th colspan="2">{{product.showBrandName}} {{product.productName}} {{this.makeOptionText(product.mainOption, product.optionInputs)}}|{{product.totalOrderCnt}}개</th> -->
            <th colspan="2">{{product.showBrandName}} {{product.productName}}{{this.makeOptionText(product.mainOption, product.optionInputs)}}|{{product.totalOrderCnt}}개</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td class="td_left">상품쿠폰</td>
            <order-coupon-product-coupon :productNo="product.productNo" :coupons="product.productCoupons" :type="'PRODUCT'" :couponRequest='couponRequest' />
          </tr>
          <tr>
            <td class="td_left">상품플러스쿠폰</td>
            <order-coupon-product-coupon :productNo="product.productNo" :coupons="product.productPlusCoupons" :type="'PRODUCT_PLUS'" :couponRequest='couponRequest' />
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>
import { formatCurrency } from '@/utils/stringUtils'
import OrderCouponProductCoupon from '@/components/order/order/OrderCouponProductCoupon'

export default {
  props: ['product', 'couponRequest', 'area'],
  data () {
    return {

    }
  },
  components: {
    OrderCouponProductCoupon
  },
  computed: {
    productCoupon () {
      return this.couponRequest.productCoupons.filter(coupon => coupon.productNo === this.product.productNo)
    },
    selectedCouponIssueNo: {
      get () {
        const product = this.productCoupon
        if (product.length > 0) {
          return product[0].couponIssueNo
        }
      }
    },
    selectedPlusCouponIssueNo: {
      get () {
        const product = this.productCoupon
        if (product.length > 0) {
          return product[0].plusCouponIssueNo
        }
      }
    },
    showTotalCouponProductPrice () {
      let selectedCoupon = this.product.productCoupons.filter(coupon => coupon.couponIssueNo === this.selectedCouponIssueNo)[0]
      let selectedPlusCoupon = this.product.productPlusCoupons.filter(coupon => coupon.couponIssueNo === this.selectedPlusCouponIssueNo)[0]
      let couponDiscountAmt = selectedCoupon ? selectedCoupon.couponDiscountAmt : 0
      let plusCouponDiscountAmt = selectedPlusCoupon ? selectedPlusCoupon.couponDiscountAmt : 0
      let totalCouponProductPrice = couponDiscountAmt + plusCouponDiscountAmt
      return totalCouponProductPrice > 0 ? `- ${formatCurrency(totalCouponProductPrice)}` : totalCouponProductPrice
    }
  },
  methods: {
    MyMiliFormat (val) {
      return formatCurrency(val)
    },
    calcuCoupon () {
      const orderSheetNo = this.$store.state.route.params.orderSheetNo
      this.$store.dispatch('ordersheet/calculateConpons', { orderSheetNo, couponRequest: this.couponRequest })
    },
    makeOptionText (mainOption, showOptions) {
      if (mainOption) {
        let optionName = mainOption.split(':')[0].split('|')
        let optionValue = mainOption.split(':')[1].split('|')
        let optionStr = []
        let optionSize = optionName.length
        for (var index = 0; index < optionSize; index++) {
          optionStr.push(`${optionName[index]}: ${optionValue[index]}`)
        }
        if (showOptions && showOptions.length > 0) {
          showOptions.forEach((item) => {
            optionStr.push(`${item.inputLabel}:${item.inputValue}`)
          })
        }

        return '(' + optionStr.join(' / ') + ')'
      } else {
        return ''
      }
    }
  }
}
</script>
