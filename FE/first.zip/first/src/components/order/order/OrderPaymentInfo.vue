<template>
  <div v-if="order" class="payment_info">
    <div class="order_zone_tit">
      <h4>결제정보</h4>
    </div>

    <div class="order_table_type width_auto">
      <table class="table_left">
        <colgroup>
          <col style="width:15%;">
          <col style="width:85%;">
        </colgroup>
        <tbody>
          <tr>
            <th scope="row">상품 합계 금액</th>
            <td>
              <strong id="totalGoodsPrice" class="order_payment_sum">{{this.order.paymentInfo.totalStandardAmt|formatNumber}}원</strong>
            </td>
          </tr>
          <tr>
            <th scope="row">배송비</th>
            <td>
              <span id="totalDeliveryCharge">{{showTotalDeliveryAmt}}</span>원
              <span>
                ( (배송비
                <span class="goods-mileage">{{this.order.paymentInfo.deliveryAmt|formatNumber}}</span>원 - 배송비쿠폰할인
                <span class="member-mileage">{{showDeliveryCouponDiscountAmt|formatNumber}}</span>원) + 지역별추가배송비 {{this.order.paymentInfo.remoteDeliveryAmt|formatNumber}}원 )
              </span>
            </td>
          </tr>
          <tr id="rowDeliveryInsuranceFee" class="dn">
            <th scope="row">해외배송 보험료</th>
            <td>
              <span id="deliveryInsuranceFee">0</span>원
              <input type="hidden" name="deliveryInsuranceFee" value="0">
            </td>
          </tr>
          <tr id="rowDeliverAreaCharge" class="dn">
            <th scope="row">지역별 배송비</th>
            <td>
              <span id="deliveryAreaCharge">0</span>원
              <input type="hidden" name="totalDeliveryCharge" value="0">
              <input type="hidden" name="deliveryAreaCharge" value="0">
            </td>
          </tr>
          <tr>
            <th scope="row">할인혜택</th>
            <td>
              <ul class="order_benefit_list">
                <li>
                  <em id="saleDefault">
                    <strong>(-)
                      <b class="total-member-dc-price">{{showTotalDiscountAmt}}</b>원 </strong>
                    <span> (즉시할인 {{this.order.paymentInfo.totalImmediateDiscountAmt|formatNumber}}원 + 추가할인 {{this.order.paymentInfo.totalAdditionalDiscountAmt|formatNumber}}원 + 상품쿠폰할인 {{showProductCouponDiscountAmt}}원 + 장바구니쿠폰 할인 {{showCartCouponDiscountAmt}}원)
                    </span>
                  </em>
                  <em id="saleWithoutMember" class="dn">
                    <strong>(-) 0원</strong>
                    <span>( 상품 0원 , 회원 0원 , 쿠폰 0원 )
                    </span>
                  </em>
                </li>
              </ul>
            </td>
          </tr>
          <tr v-if='logined'>
            <th scope="row">쿠폰 사용</th>
            <td>
              <ul :class="isUsingCoupons?'order_benefit_list order_coupon_benefits':'order_benefit_list order_coupon_benefits dn'">
                <li class="order_benefit_sale">
                  <em>
                    총 상품할인금액 :
                    <strong>(-)
                      <b id="useDisplayCouponDcPrice">{{showProductCouponDiscountAmt}}</b>원</strong>
                  </em>
                </li>
                <li class="order_benefit_sale">
                  <em>
                    장바구니 할인금액 :
                    <strong>(-)
                      <b id="useDisplayCouponDelivery">{{showCartCouponDiscountAmt}}</b>원</strong>
                  </em>
                </li>
                <li class="order_benefit_sale">
                  <em>
                    배송비 할인금액 :
                    <strong>(-)
                      <b id="useDisplayCouponDelivery">{{showDeliveryCouponDiscountAmt}}</b>원</strong>
                  </em>
                </li>
                <li class="order_benefit_mileage js_mileage dn">
                  <em>
                    적립 {{showAccumulationName}} :
                    <strong>(+)
                      <b id="useDisplayCouponMileage">0</b>{{showAccumulationUnit}}</strong>
                  </em>
                </li>
              </ul>
              <span class="btn_gray_list">
                <button type="button" class="btn_gray_mid btn_open_layer" @click.prevent="openCouponApplyPop">
                  <span>쿠폰 조회 및 적용</span>
                </button>
              </span>
            </td>
          </tr>
          <tr v-if="logined && isUseMallAccumulation">
            <th scope="row">{{showAccumulationName}}</th>
            <td>
              <div class="order_money_use">
                <b>
                  <input type="text" :disabled="!showBtnActive" v-model="mInput.usedMileage" @blur="validateMileage" @focus="resetMileage"> {{showAccumulationUnit}}</b>
                <div class="form_element">
                  <span class="btn_gray_list">
                    <button v-if="showBtnActive" type="button" @click.prevent="maxUseClick">
                      <span>전액사용</span>
                    </button>
                    <p v-else type="button" href="#" class="off">
                      <span>전액사용</span>
                    </p>
                  </span>
                  <div class="money">
                    <span class="money_use_sum"> 보유 {{showAccumulationName}} : {{this.order.paymentInfo.accumulationAmt|formatNumber}} {{showAccumulationUnit}} </span>
                    <span class="money_use_sum"> 사용가능 {{showAccumulationName}} : {{availableReserve}} {{showAccumulationUnit}}</span>
                  </div>
                </div>
                <em :style="tipsShowFlg ? 'display: block;' : 'display: none;'" class="money_use_txt">
                  {{tipsShowTxt}}
                </em>
              </div>
            </td>
          </tr>
          <tr hidden>
            <th scope="row">예치금 사용</th>
            <td>
              <div class="order_money_use">
                <b>
                  <input type="text" name="useDeposit" onblur="gd_deposit_use_check();"> 원</b>
                <div class="form_element">
                  <input type="checkbox" id="useDepositAll" onclick="deposit_use_all();">
                  <label for="useDepositAll" class="check_s">전액 사용하기</label>
                  <span class="money_use_sum">(보유 예치금 : 0 원)</span>
                </div>
              </div>
            </td>
          </tr>
          <tr>
            <th scope="row">총 결제 금액</th>
            <td>
              <input type="hidden" name="settlePrice" value="112000">
              <input type="hidden" name="overseasSettlePrice" value="0">
              <input type="hidden" name="overseasSettleCurrency" value="KRW">
              <strong id="totalSettlePrice" class="order_payment_sum">{{showPayAmt}}</strong>원
            </td>
          </tr>
          <tr v-if='logined && isUseMallAccumulation'>
            <th scope="row">적립정보</th>
            <td>
              <ul class="order_benefit_list">
                <li>
                  <em id="mileageDefault">
                    구매확정 시
                    <strong>
                      <b class="total-member-mileage">{{showRewardAccuAmt}}</b>{{showAccumulationUnit}}</strong>
                    적립
                  </em>
                </li>
              </ul>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <order-coupon-apply @close="closeCouponApplyPop" :openLayer="openCouponApplyLayer" :paymentInfo="order.paymentInfo" />
  </div>
</template>
<script>
import { mapGetters, mapState, mapActions } from 'vuex'
import { formatCurrency, checkNumber } from '@/utils/stringUtils'
import OrderCouponApply from '@/components/order/order/OrderCouponApply'

export default {
  props: ['logined', 'order', 'subPayAmtInfo'],
  data () {
    return {
      mInput: {
        usedMileage: '0'
      },
      usedMileageInt: 0,
      openCouponApplyLayer: false,
      orderSheetNo: this.$store.state.route.params.orderSheetNo,
      tipsShowFlg: false,
      tipsShowTxt: '',
      btnActive: true
    }
  },
  components: {
    OrderCouponApply
  },
  computed: {
    ...mapGetters('ordersheet', ['orderCouponCnt']),
    ...mapGetters('common', ['showAccumulationName', 'showAccumulationUnit', 'isUseMallAccumulation']),
    ...mapState('ordersheet', ['orderCoupons', 'couponAmt', 'couponRequest', 'couponRequestCopy', 'ordersheet']),
    ...mapState('common', ['malls']),

    showProductCouponDiscountAmt () {
      return this.ordersheet ? formatCurrency(this.ordersheet.paymentInfo.productCouponAmt) : 0
    },
    showCartCouponDiscountAmt () {
      return this.ordersheet ? formatCurrency(this.ordersheet.paymentInfo.cartCouponAmt) : 0
    },
    showDeliveryCouponDiscountAmt () {
      return this.ordersheet ? formatCurrency(this.ordersheet.paymentInfo.deliveryCouponAmt) : 0
    },
    isUsingCoupons () {
      return (this.ordersheet ? (this.ordersheet.paymentInfo.productCouponAmt > 0 || this.ordersheet.paymentInfo.cartCouponAmt > 0 || this.ordersheet.paymentInfo.deliveryCouponAmt > 0) : false)
    },
    showTotalStandardAmt () {
      if (this.order !== null && this.order.paymentInfo !== null) {
        return formatCurrency(this.order.paymentInfo.totalStandardAmt)
      }
    },
    showTotalDeliveryAmt () {
      if (this.order !== null && this.order.paymentInfo !== null) {
        return formatCurrency((this.order.paymentInfo.deliveryAmt - this.ordersheet.paymentInfo.deliveryCouponAmt + this.order.paymentInfo.remoteDeliveryAmt))
      }
    },
    totalDiscountAmt () {
      if (this.order !== null && this.order.paymentInfo !== null) {
        return formatCurrency(this.order.paymentInfo.totalAdditionalDiscountAmt +
          this.order.paymentInfo.totalImmediateDiscountAmt)
        // +
        // this.order.paymentInfo.productCouponAmt +
        // this.order.paymentInfo.cartCouponAmt)
      }
    },
    showProductDiscount () {
      return formatCurrency(this.order.paymentInfo.totalAdditionalDiscountAmt +
        this.order.paymentInfo.totalImmediateDiscountAmt)
    },
    showCouponDiscount () {
      return formatCurrency(this.order.paymentInfo.productCouponAmt +
        this.order.paymentInfo.cartCouponAmt + this.order.paymentInfo.deliveryCouponAmt)
    },
    showTotalDiscountAmt () {
      return formatCurrency(this.order.paymentInfo.totalAdditionalDiscountAmt +
        this.order.paymentInfo.totalImmediateDiscountAmt + this.order.paymentInfo.productCouponAmt + this.order.paymentInfo.cartCouponAmt)
    },
    showRewardAccuAmt () {
      return formatCurrency(Math.ceil(this.order.paymentInfo.accumulationAmtWhenBuyConfirm))
    },
    showAvaliableAccuAmt () {
      let accuAmt = this.order.paymentInfo.availableAccumulationAmt > this.showPayAmt ? this.showPayAmt : this.order.paymentInfo.availableAccumulationAmt
      return formatCurrency(accuAmt)
    },
    showTotalAccuAmt () {
      return formatCurrency(this.order.paymentInfo.accumulationAmt)
    },
    showPayAmt: {
      get () {
        // return this.order && formatCurrency(this.order.paymentInfo.paymentAmt - this.usedMileageInt)
        return this.order && formatCurrency(this.order.paymentInfo.paymentAmt)
      }
    },
    paymentInfoUsedMileage () {
      return this.usedMileageInt
    },
    showBtnActive () {
      if (!this.checkAvailableReserve || this.order.paymentInfo.accumulationAmt <= 0) {
        return false
      } else {
        return true
      }
    },
    availableReserve () {
      if (!this.isAvailableAccumulation) {
        return 0
      }
      const availableMinAccumulationAmt = this.order.paymentInfo.availableMinAccumulationAmt
      const availableMaxAccumulationAmt = this.order.paymentInfo.availableMaxAccumulationAmt
      const accumulationAmt = this.order.paymentInfo.accumulationAmt
      const minAccumulationLimit = this.order.paymentInfo.minAccumulationLimit
      const totalStandardAmt = this.order.paymentInfo.totalStandardAmt
      if (totalStandardAmt < availableMinAccumulationAmt || minAccumulationLimit > availableMaxAccumulationAmt || minAccumulationLimit > accumulationAmt) {
        return 0
      } else {
        return formatCurrency(availableMaxAccumulationAmt)
      }
    },
    checkAvailableReserve () {
      if (!this.isAvailableAccumulation) {
        return false
      }
      const availableMinAccumulationAmt = this.order.paymentInfo.availableMinAccumulationAmt
      const availableMaxAccumulationAmt = this.order.paymentInfo.availableMaxAccumulationAmt
      const accumulationAmt = this.order.paymentInfo.accumulationAmt
      const minAccumulationLimit = this.order.paymentInfo.minAccumulationLimit
      const totalStandardAmt = this.order.paymentInfo.totalStandardAmt
      if (totalStandardAmt < availableMinAccumulationAmt || minAccumulationLimit > availableMaxAccumulationAmt || minAccumulationLimit > accumulationAmt) {
        return false
      } else {
        return availableMaxAccumulationAmt > 0
      }
    },
    isAvailableAccumulation () {
      return this.ordersheet ? this.ordersheet.paymentInfo.isAvailableAccumulation : false
    }
  },
  created () {
    if (this.subPayAmtInfo) {
      this.mInput.usedMileage = this.subPayAmtInfo
    }
  },
  methods: {
    ...mapActions('ordersheet', ['reCalculateOrder', 'calculateConpons']),

    validateMileage () {
      const availableMinAccumulationAmt = this.order.paymentInfo.availableMinAccumulationAmt
      const availableMaxAccumulationAmt = this.order.paymentInfo.availableMaxAccumulationAmt
      const minAccumulationLimit = this.order.paymentInfo.minAccumulationLimit
      const accumulationAmt = this.order.paymentInfo.accumulationAmt
      const totalStandardAmt = this.order.paymentInfo.totalStandardAmt
      this.tipsShowFlg = false

      if (totalStandardAmt < availableMinAccumulationAmt) {
        this.tipsShowFlg = true
        this.tipsShowTxt = availableMinAccumulationAmt + ' 이상 구매시에만' + this.showAccumulationName + '사용 가능합니다.'
        return
      } else if (minAccumulationLimit > availableMaxAccumulationAmt || minAccumulationLimit > accumulationAmt) {
        this.tipsShowFlg = true
        this.tipsShowTxt = '사용 적립금이 쇼핑몰 최소 적립금 기준보다 작습니다.'
        return
      }

      let avaliabelAccuAmt = (typeof availableMaxAccumulationAmt) === 'string' ? availableMaxAccumulationAmt.replace(new RegExp(/(,)/g), '') : availableMaxAccumulationAmt
      let value = this.mInput.usedMileage.replace(new RegExp(/(,)/g), '')
      if (value === '') {
        value = '0'
      }

      if (checkNumber(value)) {
        if (this.formatMileageInput(value) > Number(avaliabelAccuAmt)) {
          this.mInput.usedMileage = avaliabelAccuAmt + ''
          this.tipsShowFlg = true
          this.tipsShowTxt = this.showAccumulationName + '최대사용금액을 초과했습니다.최대사용금액으로 조정됩니다.'
        }
        this.mInput.usedMileage = this.formatMileageInput(this.mInput.usedMileage.replace(new RegExp(/(,)/g), ''))
        this.usedMileageInt = this.mInput.usedMileage
        this.mInput.usedMileage = formatCurrency(this.mInput.usedMileage)

        this.calculateOrderMileage()
        this.$emit('usedMileage', this.usedMileageInt)
      } else if (value === '') {

      } else {
        this.tipsShowFlg = true
        this.tipsShowTxt = '값을 정확하게 입력하세요'
      }
    },
    calculateOrderMileage () {
      const calculationRequest = {
        accumulationUseAmt: this.usedMileageInt
      }
      const orderSheetNo = this.$store.state.route.params.orderSheetNo
      this.reCalculateOrder({ orderSheetNo, calculationRequest }).catch((e) => {
        if (e.data.code === '03062' || e.data.code === 'O3063') {
          alert(e.data.message)

          this.mInput.usedMileage = this.order.paymentInfo.minAccumulationLimit
          this.usedMileageInt = this.mInput.usedMileage
          this.mInput.usedMileage = formatCurrency(this.mInput.usedMileage)

          this.calculateOrderMileage()
          this.$emit('usedMileage', this.usedMileageInt)
        }
      })
    },
    formatMileageInput (value) {
      let intValue = Number(value)
      return parseInt(intValue / 10) * 10
    },
    resetMileage () {
      this.mInput.usedMileage = ''
      this.usedMileageInt = 0
    },
    resetMileage2 () {
      this.mInput.usedMileage = '0'
      this.usedMileageInt = 0
    },
    maxUseClick () {
      const availableMaxAccumulationAmt = this.order.paymentInfo.availableMaxAccumulationAmt
      const haveAccumulationAmt = this.order.paymentInfo.accumulationAmt

      if (haveAccumulationAmt > availableMaxAccumulationAmt) {
        let avaliabelAccuAmt = (typeof availableMaxAccumulationAmt) === 'string' ? availableMaxAccumulationAmt.replace(new RegExp(/(,)/g), '') : availableMaxAccumulationAmt
        this.mInput.usedMileage = this.formatMileageInput(avaliabelAccuAmt)
      } else {
        let haveAccAmt = (typeof haveAccumulationAmt) === 'string' ? haveAccumulationAmt.replace(new RegExp(/(,)/g), '') : haveAccumulationAmt
        this.mInput.usedMileage = this.formatMileageInput(haveAccAmt)
      }
      this.usedMileageInt = this.mInput.usedMileage
      this.mInput.usedMileage = formatCurrency(this.mInput.usedMileage)

      this.calculateOrderMileage()
      this.$emit('usedMileage', this.usedMileageInt)
    },
    openCouponApplyPop () {
      if (!this.orderCouponCnt) {
        return alert('적용 가능한 쿠폰이 없습니다.')
      } else {
        this.mInput.usedMileage = '0'
        this.usedMileageInt = 0
        this.$emit('usedMileage', this.usedMileageInt)

        this.calculateOrderMileage()
        this.calculateConpons({ orderSheetNo: this.orderSheetNo, couponRequest: this.couponRequest })
        this.openCouponApplyLayer = true
        this.$store.commit('SHOW_LAYER_BG')
        this.$emit('disableScrollBar')
      }
    },
    closeCouponApplyPop (isApply) {
      this.openCouponApplyLayer = false
      this.$store.commit('HIDDEN_LAYER_BG')
      this.$emit('ableScrollBar')
    }
  }
}
</script>
