<template>
  <div class="cart_cont_list">
    <div class="order_cart_tit">
      <h3>주문상세내역</h3>
    </div>
    <!-- //order_cart_tit -->

    <div class="order_table_type scroll">
      <!-- 장바구니 상품리스트 시작 -->
      <table>
        <colgroup>
          <col>
          <!-- 상품명/옵션 -->
          <col style="width:5%">
          <!-- 수량 -->
          <col style="width:10%">
          <!-- 상품금액 -->
          <col style="width:13%">
          <!-- 할인/적립 -->
          <col style="width:10%">
          <!-- 합계금액 -->
          <col style="width:10%">
          <!-- 배송비 -->
        </colgroup>
        <thead>
          <tr>
            <th>상품/옵션 정보</th>
            <th>수량</th>
            <th>상품금액</th>
            <th class="js-relative-none">할인</th>
            <th class="js-relative-none">합계금액</th>
            <th>배송비</th>
          </tr>
        </thead>
        <tbody>
          <order-product v-for="(option, index) in orderProductOptions" :key="index" :option="option" />
        </tbody>
      </table>
      <!-- 장바구니 상품리스트 끝 -->
    </div>
  </div>
</template>

<script>
import OrderProduct from '@/components/order/order/OrderProduct'

export default {
  props: ['orderProductOptions'],
  components: {
    OrderProduct
  }
}
</script>
