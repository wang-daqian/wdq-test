<template>
  <div class="price_sum" v-if="order && this.order.paymentInfo">
    <div class="price_sum_cont">
      <div class="price_sum_list">
        <dl>
          <dt>총
            <strong>{{totalCnt}}</strong> 개의 상품금액 </dt>
          <dd>
            <strong>{{this.showTotalStandardAmt}}</strong>원</dd>
        </dl>
        <span v-if="totalDiscountAmt > 0">
          <img src="../../../assets/img/order/order_price_minus.png" alt="더하기">
        </span>
        <span v-else-if="totalDiscountAmt < 0">
          <img src="../../../assets/img/order/order_price_plus.png" alt="더하기">
        </span>
        <dl v-if="totalDiscountAmt !== 0">
          <dt>총 할인금액 </dt>
          <dd>
            <strong>{{showTotalDiscountAmt}}</strong>원</dd>
        </dl>
        <span>
          <img src="../../../assets/img/order/order_price_plus.png" alt="더하기">
        </span>
        <dl>
          <dt>배송비</dt>
          <dd>
            <strong>{{showTotalDeliveryAmt}}</strong>원</dd>
        </dl>
        <span>
          <img src="../../../assets/img/order/order_price_total.png" alt="합계 ">
        </span>
        <dl class="price_total ">
          <dt>합계</dt>
          <dd>
            <strong>{{showPayAmt}}</strong>원
          </dd>
        </dl>
      </div>
      <em v-if="isUseMallAccumulation && logined" class="tobe_mileage js_mileage ">적립예정 {{showAccumulationName}} :
        <span>{{accumulationAmtWhenBuyConfirm}}</span> {{showAccumulationUnit}}</em>
    </div>
    <!-- //price_sum_cont -->
  </div>
</template>

<script>
import { mapState, mapGetters } from 'vuex'
import { formatCurrency } from '@/utils/stringUtils'

export default {
  props: ['order', 'orderProductOptions', 'logined'],
  data () {
    return {
    }
  },
  computed: {
    ...mapState('fixedItems', ['meetFooterWithAreaOrderInformation', 'underAreaOrderInformation']),
    ...mapGetters('common', ['showAccumulationName', 'isUseMallAccumulation', 'showAccumulationUnit']),

    totalCnt () {
      let totalCnt = 0
      if (this.orderProductOptions && this.orderProductOptions.length > 0) {
        this.orderProductOptions.forEach(option => {
          totalCnt += option.orderCnt
        })
      }
      return totalCnt
    },
    totalStandardAmt () {
      if (this.order !== null && this.order.paymentInfo !== null) {
        return this.order.paymentInfo.totalStandardAmt
      }
    },
    totalDiscountAmt () {
      if (this.order !== null && this.order.paymentInfo !== null) {
        return this.order.paymentInfo.totalAdditionalDiscountAmt +
          this.order.paymentInfo.totalImmediateDiscountAmt
      }
    },
    totalDeliveryAmt () {
      if (this.order !== null && this.order.paymentInfo !== null) {
        return this.order.paymentInfo.deliveryAmt
      }
    },
    payAmt () {
      if (this.order !== null && this.order.paymentInfo !== null) {
        return this.totalStandardAmt - this.totalDiscountAmt + this.totalDeliveryAmt
      }
    },
    showTotalStandardAmt () {
      if (this.order !== null && this.order.paymentInfo !== null) {
        return formatCurrency(this.order.paymentInfo.totalStandardAmt)
      }
    },
    showTotalDiscountAmt () {
      // return this.totalDiscountAmt > 0 ? `- ${formatCurrency(this.totalDiscountAmt)}` : formatCurrency(this.totalDiscountAmt)
      return formatCurrency(this.totalDiscountAmt)
    },
    showTotalDeliveryAmt () {
      if (this.order !== null && this.order.paymentInfo !== null) {
        return formatCurrency((this.order.paymentInfo.deliveryAmt + this.order.paymentInfo.remoteDeliveryAmt))
      }
    },
    accumulationAmtWhenBuyConfirm () {
      return formatCurrency(Math.ceil(this.order.paymentInfo.accumulationAmtWhenBuyConfirm))
    },
    showPayAmt: {
      get () {
        return this.order && formatCurrency(this.order.paymentInfo.totalStandardAmt - this.totalDiscountAmt + (this.order.paymentInfo.deliveryAmt + this.order.paymentInfo.remoteDeliveryAmt))
      }
    }
  },
  watch: {

  },
  methods: {

  }
}
</script>
