<template>
  <div id="container">
    <div id="contents">
      <!-- 본문 시작 -->

      <div class="location_wrap">
        <div class="location_cont">
          <em>
            <a href="/" class="local_home">HOME</a> &gt; 주문완료</em>
        </div>
      </div>
      <!-- //location_wrap -->

      <div class="sub_content">

        <!-- //side_cont -->

        <div class="content_box">
          <div class="order_wrap">
            <div class="order_tit">
              <h2>주문완료</h2>
              <ol>
                <li>
                  <span>01</span> 장바구니
                  <span>
                    <img src="../../../assets/img/member/icon_join_step_off.png" alt="">
                  </span>
                </li>
                <li>
                  <span>02</span> 주문서작성/결제
                  <span>
                    <img src="../../../assets/img/member/icon_join_step_off.png" alt="">
                  </span>
                </li>
                <li class="page_on">
                  <span>03</span> 주문완료</li>
              </ol>
            </div>
            <!-- //member_tit -->

            <div class="order_cont">
              <div class="order_end">

                <!-- 재접속 등에 의한 기주문 완료 건으로 접속시 -->
                <div class="order_end_completion">
                  <span>
                    <img src="../../../assets/img/order/order_end_completion.png" alt="">
                  </span>
                  <p>
                    <strong>결제가 완료 되었습니다.</strong>
                    <br>
                    <em>주문번호 : {{orderNo}}</em>
                    <br>
                    <em>감사합니다.</em>
                  </p>
                </div>

              </div>
              <!-- //order_info -->
              <div class="btn_center_box">
                <button class="btn_order_end_ok" @click.prevent="gotoHome">
                  <em>확인</em>
                </button>
              </div>
            </div>
            <!-- //order_end -->
          </div>
          <!-- //order_cont -->
        </div>
        <!-- //order_wrap -->
      </div>
      <!-- //content_box -->

    </div>
    <!-- //sub_content -->
  </div>
</template>

<script>
export default {
  name: 'PaymentConfirmNonMember',
  metaInfo: {
    title: '주문완료'
  },
  methods: {
    gotoHome () {
      if (opener) {
        opener.location.href = '/'
        self.close()
      } else {
        location.href = '/'
      }
    }
  },
  computed: {
    orderNo: {
      get () {
        return this.$store.state.route.query.orderNo
      }
    }
  }
}
</script>
