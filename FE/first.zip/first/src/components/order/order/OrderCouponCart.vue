<template>
  <div>
    <h3 class="tit">장바구니쿠폰적용</h3>
    <div class="top_table_type order_table_type coupon_table">
      <template v-if="cartCoupons && cartCoupons.length > 0">
        <div class="table_shell">
        <table>
          <colgroup>
            <col style="width:50px;">
            <col style="width:200px">
            <col style="width:200px">
            <col>
          </colgroup>
          <thead>
            <tr>
              <th>&nbsp;</th>
              <th>쿠폰</th>
              <th>혜택</th>
              <th>사용기한</th>
            </tr>
          </thead>
          <tbody>
            <template v-if="initSortItem()" v-for="(coupon, index) in commonCartCoupons">
              <tr :key="index">
                <td>
                  <span class="form_element">
                    <label :class="['check_s single',{'on':sortItem === coupon.couponIssueNo}]" @click.prevent="selectCartCoupon(coupon.couponIssueNo, coupon)">선택</label>
                  </span>
                </td>
                <td class="td_left">
                  <label for="check3">
                    <strong class="coupon_price">
                      <b>
                        {{showCouponDiscountAmt(coupon.couponDiscountAmt)}}원 할인
                      </b>
                      ({{coupon.couponName}})
                    </strong>
                    <!-- <span class="text_info">Cart Coupon</span> -->
                  </label>
                </td>
                <td class="td_left">
                  <span class="text_info">{{makeTermsText(coupon)}}</span>
                </td>
                <td>
                  <span>{{coupon.useEndYmdt}}</span>
                </td>
              </tr>
            </template>
            <!-- <tr>
              <td class="coupon_total" colspan="5">장바구니쿠폰수량:
                <span>{{showSelectedCouponDiscountAmt}}원</span>
              </td>
            </tr> -->
          </tbody>
        </table>
        </div>
      </template>
      <template v-else>
        <p class="no_data">쿠폰이 없습니다.</p>
      </template>
    </div>
  </div>
</template>

<script>
import { mapState } from 'vuex'
import { formatCurrency } from '@/utils/stringUtils'
import CouponProductCoupon from './OrderCouponProductCoupon'

export default {
  props: ['cartCoupons', 'display', 'cartCouponDiscountAmt'],

  data () {
    return {
      orderSheetNo: this.$store.state.route.params.orderSheetNo,
      sortItem: this.couponRequestCopy && this.couponRequestCopy.cartCouponIssueNo,
      selectedCouponDiscountAmt: this.cartCouponDiscountAmt
    }
  },
  components: {
    CouponProductCoupon
  },

  computed: {
    ...mapState('ordersheet', ['couponRequestCopy']),

    commonCartCoupons () {
      if (this.display.hasCommonCartCoupon) {
        return this.cartCoupons
      }
      return []
    },
    showSelectedCouponDiscountAmt () {
      return formatCurrency(this.selectedCouponDiscountAmt)
    },
    showMoneyAtDelivery () {
      if (this.area === 'PAYCO') {
        if (this.display.showCartAtPayco === 0) {
          if (this.display.showDeliveryAtPayco === 1) {
            return true
          } else {
            return false
          }
        }
        return false
      } else {
        return false
      }
    }
  },
  methods: {
    initSortItem () {
      this.sortItem = this.couponRequestCopy && this.couponRequestCopy.cartCouponIssueNo
      return true
    },
    showCouponDiscountAmt (couponDiscountAmt) {
      return formatCurrency(couponDiscountAmt)
    },
    makeTermsText (coupon) {
      let text = ''

      if (coupon.freeDelivery) {
        text = '무료'
      } else if (coupon.fixedAmountDiscount) {
        text = formatCurrency(coupon.couponDiscountAmt) + '원'
      } else {
        text = `${coupon.discountRate}% (최대 ${formatCurrency(coupon.maxDiscountAmt)}원)`
      }
      return text
    },
    selectCartCoupon (index, coupon) {
      let couponIssueNo = coupon ? coupon.couponIssueNo : 0
      if (this.sortItem === index) {
        this.sortItem = -1
        couponIssueNo = 0
        this.selectedCouponDiscountAmt = 0
      } else {
        this.sortItem = index
        this.selectedCouponDiscountAmt = coupon.couponDiscountAmt
      }

      const couponReq = JSON.parse(JSON.stringify(this.couponRequestCopy))
      let previousCouponIssueNo = this.couponRequestCopy.cartCouponIssueNo

      if (coupon && !coupon.otherCouponUsable) {
        if (confirm('이 쿠폰 사용 시 상품쿠폰은 사용할 수 없습니다. 이 쿠폰을 사용하시겠습니까?')) {
          couponReq.productCoupons.forEach((item) => {
            item.couponIssueNo = 0
            item.plusCouponIssueNo = 0
            item.couponDisable.forEach(si => {
              si.usable = false
              si.disable = false
            })
            item.couponPlusDisable.forEach(si => {
              si.usable = false
              si.disable = false
            })
          })
          couponReq.cartCouponIssueNo = couponIssueNo
          this.$store.commit('ordersheet/SET_COUPONREQUEST_COPY', couponReq)
          this.$store.commit('ordersheet/CHANGE_OTHER_COUPON_USABLE', coupon.otherCouponUsable)
        } else {
          couponReq.cartCouponIssueNo = previousCouponIssueNo
          this.$store.commit('ordersheet/SET_COUPONREQUEST_COPY', couponReq)
          return
        }
      } else {
        let otherCouponUsable = coupon ? coupon.otherCouponUsable : true
        couponReq.cartCouponIssueNo = couponIssueNo
        this.$store.commit('ordersheet/SET_COUPONREQUEST_COPY', couponReq)
        this.$store.commit('ordersheet/CHANGE_OTHER_COUPON_USABLE', otherCouponUsable)
      }
      this.$store.dispatch('ordersheet/calculateConpons', { orderSheetNo: this.orderSheetNo, couponRequest: this.couponRequestCopy })
    }
  }
}
</script>
