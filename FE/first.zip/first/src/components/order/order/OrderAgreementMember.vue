<template>
  <div>
    <div class="payment_final_checkBox">
      <div class="form_element">
        <label :class="['check', {'on':allChecked()}]" @click.prevent="checkedAll">
          <em>
            <b>전체 동의</b>
          </em>
        </label>
      </div>
    </div>
    <div :class="showPIMerchantDetail?'payment_final_checkBox1 agreement_open':'payment_final_checkBox1 agreement_close'">
      <!-- 显示class名:agreement_open -->
      <div class="form_element">
        <label :class="agreeChecked1? 'check_s on': 'check_s'" @click.prevent="agreeChecked1 = !agreeChecked1" />
        <em class="agreement1">
          <a @click.prevent="showAgreeDetail">
            <b>(필수)</b> 개인정보 판매자 제공 동의
            <span class="icon_t">▼</span>
            <span class="icon_d">▲</span>
          </a>
        </em>
      </div>
      <div class="agreement_box">
        <!-- agreement -->
        <div class="agreement_Box">
          <ol>
            <li>1. 제공받는자<br> (주)퍼스트어패럴
            </li>
            <li>2. 제공목적: 판매자와구매자의원활한거래진행, 본인의사의확인, 고객상담및불만처리, 물품배송</li>
            <li>3. 제공하는개인정보항목: 주문자성명, 주문자이메일, 주문자휴대전화, 상품구매정보, 상품수령인정보(이름, 주소, 연락처), 해외배송상품인경우‘고유통관부호’</li>
            <li>4. 개인정보를제공받는자의개인정보보유및이용기간: 개인정보이용목적달성시까지보존함</li>
          </ol>
        </div>
        <!-- /agreement -->
      </div>
    </div>
    <div class="payment_final_checkBox2">
      <div class="form_element">
        <label :class="agreeChecked2? 'check_s on': 'check_s'" @click.prevent="agreeChecked2 = !agreeChecked2">
          <em>
            <b>(필수)</b> 구매하실 상품의 결제정보를 확인하였으며, 구매진행에 동의합니다.</em>
        </label>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data () {
    return {
      allAgreeChecked: false,
      agreeChecked1: false,
      agreeChecked2: false,
      showPIMerchantDetail: false
    }
  },
  computed: {
    agreeCheck: {
      get () {
        return this.allAgreeChecked
      }
    }
  },
  methods: {
    allChecked () {
      if (this.agreeChecked1 && this.agreeChecked2) {
        this.allAgreeChecked = true
      } else {
        this.allAgreeChecked = false
      }
      return this.allAgreeChecked
    },
    checkedAll () {
      this.allAgreeChecked = !this.allAgreeChecked
      if (this.allAgreeChecked) {
        this.agreeChecked1 = true
        this.agreeChecked2 = true
      } else {
        this.agreeChecked1 = false
        this.agreeChecked2 = false
      }
    },
    showAgreeDetail () {
      this.showPIMerchantDetail = !this.showPIMerchantDetail
    }
  }
}
</script>
