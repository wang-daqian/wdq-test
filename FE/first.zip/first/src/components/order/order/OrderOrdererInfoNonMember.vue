<template>
  <div class="order_table_type width_auto">
    <table class="table_left">
      <colgroup>
        <col style="width:15%;">
        <col style="width:85%;">
      </colgroup>
      <tbody>
        <tr>
          <th scope="row">
            <span class="important">주문자 정보</span>
          </th>
          <td>
            <input type="text" ref="orderName" v-model="ordererName" maxlength="20">
          </td>
        </tr>
        <tr>
          <th scope="row">
            <span class="important">휴대전화</span>
          </th>
          <td>
            <input type="text" id="phone" ref="orderPhone" v-model="showOrdererContact1" maxlength="11" @keydown="gdNum" @input="gdNum" @blur="gdNum">
          </td>
        </tr>
        <tr>
          <th scope="row">연락처</th>
          <td>
            <input type="text" id="orderCellPhone" ref="orderCellPhone" v-model="showOrdererContact2" maxlength="12" @keydown="gdNumPhone" @input="gdNumPhone" @blur="gdNumPhone">
          </td>
        </tr>
        <tr>
          <th scope="row">
            <span class="important">이메일</span>
          </th>
          <td class="member_email">
            <input type="text" name="email" v-model="email" ref="emailName">
            <!-- <vue-select-box :showValue="selectValue" :items="sizeItems" @selected="setDomain" /> -->
          </td>
        </tr>
        <tr>
          <th scope="row ">주문 메모</th>
          <td class="td_last_say">
            <input type="text" name="memo" v-model="memo" maxlength="50" ref="memo">
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
import { replacePattern } from '@/utils/validateUtils'
import VueSelectBox from '@/components/common/VueSelectBox'

export default {
  props: ['ordererInfo'],
  data () {
    return {
      ordererName: '',
      ordererContact2: '',
      ordererContact1: '',
      myInput: {
        emailName: '',
        emailDomain: ''
      },
      selectValue: '@',
      sizeItems: [
        {
          label: '직접입력',
          value: '@'
        },
        {
          label: 'naver.com',
          value: '@naver.com'
        },
        {
          label: 'hanmail.net',
          value: '@hanmail.net'
        },
        {
          label: 'daum.net',
          value: '@daum.net'
        },
        {
          label: 'nate.com',
          value: '@nate.com'
        },
        {
          label: 'hotmail.com',
          value: '@hotmail.com'
        },
        {
          label: 'gmail.com',
          value: '@gmail.com'
        },
        {
          label: 'icloud.com',
          value: '@icloud.com'
        }
      ],
      mEmail: '',
      memo: ''
    }
  },
  created () {
    if (this.ordererInfo) {
      this.ordererName = this.ordererInfo.ordererName
      this.ordererContact2 = this.ordererInfo.ordererContact2
      this.ordererContact1 = this.ordererInfo.ordererContact1
      this.mEmail = this.ordererInfo.ordererEmail
    }
  },
  components: {
    VueSelectBox
  },
  computed: {
    showOrdererContact1: {
      get () {
        return this.ordererContact1
      },
      set (value) {
        this.ordererContact1 = value
      }
    },
    showOrdererContact2: {
      get () {
        return this.ordererContact2
      },
      set (value) {
        this.ordererContact2 = value
      }
    },
    email: {
      get () {
        return this.mEmail
      },
      set (value) {
        this.myInput.emailName = value.split('@')[0] || ''
        this.myInput.emailDomain = '@' + value.split('@')[1] || ''
        this.mEmail = value
      }
    },
    ordererInput () {
      return {
        ordererName: this.ordererName,
        ordererContact1: this.ordererContact1,
        ordererContact2: this.ordererContact2,
        ordererEmail: `${this.myInput.emailName}${this.myInput.emailDomain}`
      }
    },
    orderMemo () {
      return this.memo
    },
    validateRule () {
      let validateRule = [
        {
          inputValue: this.ordererName,
          message: '주문자 정보를 입력해 주세요.',
          pattern: /\S+/,
          input: this.$refs.orderName
        },
        {
          inputValue: this.ordererContact1,
          message: '휴대전화를 입력해주세요.',
          pattern: /\S+/,
          input: this.$refs.orderPhone
        },
        {
          inputValue: this.ordererContact1,
          message: '정확한 휴대전화를 입력해 주세요.',
          pattern: /^\d{10,11}$/,
          input: this.$refs.orderPhone
        },
        {
          inputValue: this.mEmail,
          message: '올바른 이메일 주소를 입력해 주세요.',
          pattern: /^([A-Za-z0-9_\-.])+@([A-Za-z0-9_\-.])+\.([A-Za-z]{2,4})$/,
          input: this.$refs.emailName
        }
        // {
        //   inputValue: this.myInput.emailDomain.split('@')[1],
        //   message: '이메일 주소가 유효하지 않습니다.',
        //   pattern: /^[A-Za-z0-9-]+(\.[A-Za-z0-9]+)*(\.[A-Za-z]{2,})*$/,
        //   input: this.$refs.emailDomain
        // }
      ]

      return validateRule
    }
  },
  methods: {
    setDomain (domain) {
      this.selectValue = domain
      this.myInput.emailDomain = domain
      this.mEmail = this.mEmail.split('@')[0] + domain
    },
    gdNumPhone: function () {
      if (this.ordererContact2 !== '') {
        this.ordererContact2 = replacePattern(this.ordererContact2, /[^\d]/g, '')
      }
    },
    gdNum: function () {
      if (this.ordererContact1 !== '') {
        this.ordererContact1 = replacePattern(this.ordererContact1, /[^\d]/g, '')
      }
    }
  }
}
</script>
