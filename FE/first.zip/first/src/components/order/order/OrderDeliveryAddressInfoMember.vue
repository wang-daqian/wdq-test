<template>
  <div class="delivery_info">
    <div class="order_zone_tit">
      <h4>배송지 정보</h4>
    </div>

    <div class="order_table_type width_auto">
      <table class="table_left">
        <colgroup>
          <col style="width:15%;">
          <col style="width:85%;">
        </colgroup>
        <tbody>
          <tr>
            <th scope="row">배송지 확인</th>
            <td>
              <div class="form_element">
                <ul>
                  <li>
                    <label :class="['choice_s',{'on':sortType === 'shippingRecently'}]" @click.prevent="selectAddressType('shippingRecently')">최근 배송지</label>
                  </li>
                  <li>
                    <label :class="['choice_s',{'on':sortType === 'shippingNew'}]" @click.prevent="selectAddressType('shippingNew')">신규 배송지</label>
                  </li>
                  <!-- <li>
                    <label :class="['choice_s',{'on':sortType === 'shippingSameCheck'}]" @click.prevent="selectAddressType('shippingSameCheck')">주문자정보와 동일</label>
                  </li> -->
                </ul>
                <span class="btn_gray_list">
                  <a href="javascript:" class="btn_gray_small btn_open_layer js_shipping" @click.prevent="openBookedAddrPop">
                    <span>배송지 관리</span>
                  </a>
                </span>
              </div>
            </td>
          </tr>
          <template>
            <tr>
              <th scope="row">
                <span class="important">배송지 이름</span>
              </th>
              <td>
                <input type="text" ref="addressName" data-pattern="gdEngKor" v-model="showAddressName">
              </td>
            </tr>
            <tr>
              <th scope="row">
                <span class="important">받으실 분</span>
              </th>
              <td>
                <input type="text" ref="receiverName" data-pattern="gdEngKor" maxlength="20" v-model="showReceiverName">
              </td>
            </tr>
            <tr>
              <th scope="row">
                <span class="important">주소</span>
              </th>
              <td class="member_address">
                <div class="address_postcode">
                  <input type="text" name="receiverZonecode" readonly="readonly" v-model="showReceiverZipCd" ref="receiverZipCd">
                  <input type="hidden" name="receiverZipcode">
                  <span id="receiverZipcodeText" class="old_post_code"></span>
                  <button type="button" class="btn_post_search" @click.prevent="openAddressesPopup">우편번호검색</button>
                </div>
                <div class="address_input">
                  <input type="text" name="receiverAddress" readonly="readonly" v-model="showReceiverAddress" ref="receiverAddress">
                  <input type="text" name="receiverAddressSub" v-model="showReceiverDetailAddress" ref="receiverDetailAddress" :style="{'margin-left':'5px'}">
                </div>
              </td>
            </tr>
            <tr>
              <th scope=" row ">
                <span class="important ">휴대전화</span>
              </th>
              <td>
                <input type="text" id="receiverPhone" name="receiverPhone" v-model="showReceiverContact1" ref="receiverContact1" maxlength="11" @keydown="gdNum" @input="gdNum" @blur="gdNum">
              </td>
            </tr>
            <tr>
              <th scope="row ">연락처</th>
              <td>
                <input type="text" id="receiverCellPhone" name="receiverCellPhone" v-model="showReceiverContact2" ref="receiverContact2" maxlength="12" @keydown="gdNumPhone" @input="gdNumPhone" @blur="gdNumPhone">
              </td>
            </tr>
            <tr v-if="requireCustomsIdNumber">
              <th scope="row" class="help">
                <span class="important">개인통관고유부호
                  <a class="help-icon" @click="active.notice = !active.notice"></a>
                </span>
                <div class="toolhelp-base fade show" v-if="active.notice">
                  <dl class="toolhelp-content">
                    <dt>개인통관고유부호란?</dt>
                    <dd>해외직배송 상품 구매 시 국내 통관 절차를 위해 ‘개인통관고유부호’를 제출해야 합니다.</dd>
                  </dl>
                  <div class="toolhelp-arrow">
                    <span></span>
                  </div>
                </div>
              </th>
              <td class="help-txt">
                <input type="text" name="" placeholder="받는사람의 개인통관고유부호를 입력해 주세요." v-model="currentAddress.customsIdNumber" maxlength="13" ref="customsIdNumber">
                <span>개인통관고유부호 발급
                  <a href="https://unipass.customs.go.kr/csp/persIndex.do" target="_blank">바로가기 ></a>
                </span>
              </td>
            </tr>
            <tr>
              <th scope="row ">배송 메모</th>
              <td class="td_last_say">
                <input type="text" name="orderMemo" @input="setDeliveryMemoLength " v-model="showDeliveryMemo" maxlength="50 " ref="orderMemo">
              </td>
            </tr>
          </template>
        </tbody>
      </table>
    </div>
    <booked-shipping-addresses @close="closeBookedAddrPop " @newBookReg="openBookmarkPop " :openLayer="openBookedLayer " :addresses="bookedShippingAddresses " @addrSelected="bookAddrSelected " />
    <bookmark-reg-new-addr @close="closeNewBookAddrPop " :openLayer="openBookNewRegLayer " @regNewBookAddrPop="regNewBookAddrPop " :defaultAddr="modifiedBookedAddr " />
    <address-info @closePop="closeLayer" v-if="showAddLayer" />
  </div>
</template>

<script>
import AddressInfo from '@/components/common/address/AddressInfo'
import BookedShippingAddresses from '@/components/order/order/BookedShippingAddrs.vue'
import BookmarkRegNewAddr from '@/components/order/order/BookmarkRegNewAddr.vue'
import { validateNumber, replacePattern } from '@/utils/validateUtils'
import { mapState, mapActions } from 'vuex'

export default {
  props: ['address', 'requireCustomsIdNumber', 'shippingAddressInfo', 'deliveryMemo'],
  components: {
    AddressInfo,
    BookedShippingAddresses,
    BookmarkRegNewAddr
  },
  data () {
    return {
      checkedRecentAddressValue: true,
      currentAddress: {
        addressName: (this.address && this.address.recentAddresses[0]) ? this.address.recentAddresses[0].addressName : '',
        receiverName: (this.address && this.address.recentAddresses[0]) ? this.address.recentAddresses[0].receiverName : '',
        receiverZipCd: (this.address && this.address.recentAddresses[0]) ? this.address.recentAddresses[0].receiverZipCd : '',
        receiverAddress: (this.address && this.address.recentAddresses[0]) ? this.address.recentAddresses[0].receiverAddress : '',
        receiverJibunAddress: (this.address && this.address.recentAddresses[0]) ? this.address.recentAddresses[0].receiverJibunAddress : '',
        receiverDetailAddress: (this.address && this.address.recentAddresses[0]) ? this.address.recentAddresses[0].receiverDetailAddress : '',
        receiverContact1: (this.address && this.address.recentAddresses[0]) ? replacePattern(this.address.recentAddresses[0].receiverContact1, /[^\d]/g, '') : '',
        receiverContact2: (this.address && this.address.recentAddresses[0]) ? replacePattern(this.address.recentAddresses[0].receiverContact2, /[^\d]/g, '') : '',
        customsIdNumber: (this.address && this.address.recentAddresses[0]) ? this.address.recentAddresses[0].customsIdNumber : '',
        deliveryMemo: this.deliveryMemo
      },
      active: {
        memo: false,
        notice: false
      },
      txt: {
        deliveryMemoLength: 0
      },
      sortType: 'shippingRecently',
      openBookedLayer: false,
      openBookNewRegLayer: false,
      modifiedBookedAddr: null,
      addToShippingList: true,
      reflectToMembInfo: true,
      addressNo: 0,
      tempAddress: {
        addressName: '',
        receiverName: '',
        receiverZipCd: '',
        receiverAddress: '',
        receiverJibunAddress: '',
        receiverDetailAddress: '',
        receiverContact1: '',
        receiverContact2: '',
        customsIdNumber: '',
        deliveryMemo: ''
      },
      usedMileageInt: 0,
      showAddLayer: false
    }
  },
  computed: {
    ...mapState('ordersheet', ['couponRequestCopy']),

    showAddressName: {
      get () {
        return this.currentAddress && this.currentAddress.addressName
      },
      set (value) {
        this.currentAddress.addressName = value
      }
    },
    showReceiverName: {
      get () {
        return this.currentAddress && this.currentAddress.receiverName
      },
      set (value) {
        this.currentAddress.receiverName = value
      }
    },
    showReceiverZipCd: {
      get () {
        return this.currentAddress && this.currentAddress.receiverZipCd
      },
      set (value) {
        this.currentAddress.receiverZipCd = value
      }
    },
    showReceiverAddress: {
      get () {
        return this.currentAddress && this.currentAddress.receiverAddress
      },
      set (value) {
        this.currentAddress.receiverAddress = value
      }
    },
    showReceiverDetailAddress: {
      get () {
        return this.currentAddress && this.currentAddress.receiverDetailAddress
      },
      set (value) {
        this.currentAddress.receiverDetailAddress = value
      }
    },
    showReceiverContact1: {
      get () {
        if (this.currentAddress && this.currentAddress.receiverContact1 !== '') {
          return replacePattern(this.currentAddress.receiverContact1, /[^\d]/g, '')
        } else {
          return ''
        }
      },
      set (value) {
        this.currentAddress.receiverContact1 = value
      }
    },
    showReceiverContact2: {
      get () {
        if (this.currentAddress && this.currentAddress.receiverContact2 !== '') {
          return replacePattern(this.currentAddress.receiverContact2, /[^\d]/g, '')
        } else {
          return ''
        }
      },
      set (value) {
        this.currentAddress.receiverContact2 = value
      }
    },
    showDeliveryMemo: {
      get () {
        return this.currentAddress && this.currentAddress.deliveryMemo
      },
      set (value) {
        this.currentAddress.deliveryMemo = value
      }
    },
    emptyAddresses () {
      return this.address && this.address.length === 0
    },
    bookedShippingAddresses () {
      return this.address && this.address.recentAddresses
    },
    shippingAddressInput () {
      let address = null
      if (this.sortType === 'shippingRecently') {
        if (this.address && this.address.recentAddresses && this.address.recentAddresses.length > 0) {
          address = this.address.recentAddresses[0]
        }
        this.isModifiedRecentAddr(address)
      } else if (this.sortType === 'bookAddrSelected') {
        this.isModifiedRecentAddr(this.tempAddress)
      }
      let shippingAddressInput = {
        addressNo: this.addressNo,
        receiverName: this.currentAddress.receiverName,
        addressName: this.currentAddress.addressName,
        receiverContact1: this.currentAddress.receiverContact1,
        receiverContact2: this.currentAddress.receiverContact2,
        receiverZipCd: this.currentAddress.receiverZipCd,
        receiverAddress: this.currentAddress.receiverAddress,
        receiverJibunAddress: this.currentAddress.receiverJibunAddress,
        receiverDetailAddress: this.currentAddress.receiverDetailAddress,
        deliveryMemo: this.currentAddress.deliveryMemo || '',
        customsIdNumber: this.currentAddress.customsIdNumber,
        // 주소지에 있는 countryCd를 써야하나?
        countryCd: 'KR'
      }

      // if (this.checkedRecentAddress) {
      //   shippingAddressInput = {
      //     ...this.currentAddress
      //   }
      if (this.requireCustomsIdNumber && !this.currentAddress.customsIdNumber) {
        shippingAddressInput.customsIdNumber = this.currentAddress.customsIdNumber
      }
      // }

      return shippingAddressInput
    },
    deliveryMemoInput () {
      return this.currentAddress.deliveryMemo
    },
    validateRule () {
      let validateRule = [
        {
          inputValue: this.currentAddress.addressName,
          message: '배송지 이름을 입력해 주세요.',
          pattern: /\S+/,
          input: this.$refs.addressName
        },
        {
          inputValue: this.currentAddress.receiverName,
          message: '받으실 분 정보를 입력해 주세요.',
          pattern: /\S+/,
          input: this.$refs.receiverName
        },
        {
          inputValue: this.currentAddress.receiverZipCd,
          message: '주소를 입력해주세요.',
          pattern: /\S+/,
          input: this.$refs.receiverZipCd
        },
        {
          inputValue: this.currentAddress.receiverAddress,
          message: '주소를 입력해주세요.',
          pattern: /\S+/,
          input: this.$refs.receiverDetailAddress
        },
        {
          inputValue: this.currentAddress.receiverContact1,
          message: '휴대전화를 입력해주세요.',
          pattern: /\S+/,
          input: this.$refs.receiverContact1
        },
        {
          inputValue: this.currentAddress.receiverContact1,
          message: '정확한 휴대전화를 입력해 주세요.',
          pattern: /^\d{10,11}$/,
          input: this.$refs.receiverContact1
        }
      ]

      if (this.requireCustomsIdNumber) {
        const customsIdNumberRule = [{
          inputValue: this.currentAddress.customsIdNumber,
          message: '개인통관고유부호가 유효하지 않습니다. ',
          pattern: /^[p|P]\d{12}$/,
          input: this.$refs.customsIdNumber
        }]
        validateRule.push(...customsIdNumberRule)

        return validateRule
      } else {
        return validateRule
      }
    },
    isAddToShippingList () {
      return this.addToShippingList
    },
    isReflectToMembInfo () {
      return this.reflectToMembInfo
    },
    getAddressType () {
      return this.sortType
    }
  },
  created () {
    if (this.shippingAddressInfo && this.shippingAddressInfo.receiverName) {
      this.currentAddress.receiverName = this.shippingAddressInfo.receiverName
      this.currentAddress.addressName = this.shippingAddressInfo.addressName
      this.currentAddress.receiverZipCd = this.shippingAddressInfo.receiverZipCd
      this.currentAddress.receiverAddress = this.shippingAddressInfo.receiverAddress
      this.currentAddress.receiverJibunAddress = this.shippingAddressInfo.receiverJibunAddress
      this.currentAddress.receiverDetailAddress = this.shippingAddressInfo.receiverDetailAddress
      this.currentAddress.receiverContact1 = this.shippingAddressInfo.receiverContact1
      this.currentAddress.receiverContact2 = this.shippingAddressInfo.receiverContact2
      this.currentAddress.customsIdNumber = this.shippingAddressInfo.customsIdNumber
      this.currentAddress.deliveryMemo = this.shippingAddressInfo.deliveryMemo
      this.sortType = this.shippingAddressInfo.addressType
      this.addToShippingList = this.shippingAddressInfo.saveAddressBook
      this.reflectToMembInfo = this.shippingAddressInfo.updateMember
      this.addressNo = this.shippingAddressInfo.addressNo
    }
    this.updatePaymentByAddress()
  },
  methods: {
    ...mapActions('ordersheet', ['calculateOrderConpons', 'reCalculateOrder']),

    selectAddressType (type) {
      this.sortType = type
      this.currentAddress.deliveryMemo = ''
      let address = null
      this.resetTempAddress(null)

      switch (type) {
        case 'shippingRecently':

          if (this.address && this.address.recentAddresses && this.address.recentAddresses.length > 0) {
            address = this.address.recentAddresses[0]
          }
          this.resetCurrentAddress(address)
          break
        case 'shippingNew':
          this.resetCurrentAddress(null)
          break
        case 'shippingSameCheck':
          this.resetCurrentAddress(null)
          this.copy()
          break
        default:
          break
      }
    },
    isModifiedRecentAddr (address) {
      let isModified = false
      if (address === null || address === '' || this.currentAddress === null) {
        return true
      }

      if (this.currentAddress.addressName !== address.addressName || this.currentAddress.receiverName !== address.receiverName || this.currentAddress.receiverZipCd !== address.receiverZipCd || this.currentAddress.receiverAddress !== address.receiverAddress || this.currentAddress.receiverJibunAddress !== address.receiverJibunAddress || this.currentAddress.receiverDetailAddress !== address.receiverDetailAddress || this.currentAddress.receiverContact1 !== replacePattern(address.receiverContact1, /[^\d]/g, '') || this.currentAddress.receiverContact2 !== replacePattern(address.receiverContact2, /[^\d]/g, '') || this.currentAddress.customsIdNumber !== address.customsIdNumber) {
        isModified = true
      }

      if (isModified === true) {
        this.addToShippingList = true
        this.addressNo = 0
      } else {
        this.addToShippingList = false
        this.addressNo = address.addressNo
      }

      return isModified
    },

    isModifiedRecentAddr2 (address) {
      let isModified = false

      if (address === null || address === '' || typeof address === 'undefined') {
        isModified = true
        this.addToShippingList = true
        this.addressNo = 0
      } else {
        this.addToShippingList = false
        this.addressNo = address.addressNo
        this.addToShippingList = false
      }

      return isModified
    },
    resetCurrentAddress (address) {
      if (address !== null) {
        this.currentAddress.addressName = address.addressName
        this.currentAddress.receiverName = address.receiverName
        this.currentAddress.receiverZipCd = address.receiverZipCd
        this.currentAddress.receiverAddress = address.receiverAddress
        this.currentAddress.receiverJibunAddress = address.receiverJibunAddress
        this.currentAddress.receiverDetailAddress = address.receiverDetailAddress
        this.currentAddress.receiverContact1 = address.receiverContact1
        this.currentAddress.receiverContact2 = address.receiverContact2
        this.currentAddress.customsIdNumber = address.customsIdNumber
        this.currentAddress.deliveryMemo = address.deliveryMemo
      } else {
        this.currentAddress.addressName = ''
        this.currentAddress.receiverName = ''
        this.currentAddress.receiverZipCd = ''
        this.currentAddress.receiverAddress = ''
        this.currentAddress.receiverJibunAddress = ''
        this.currentAddress.receiverDetailAddress = ''
        this.currentAddress.receiverContact1 = ''
        this.currentAddress.receiverContact2 = ''
        this.currentAddress.customsIdNumber = ''
        this.currentAddress.deliveryMemo = ''
      }
      if (this.currentAddress.receiverContact1 !== '') {
        this.currentAddress.receiverContact1 = replacePattern(this.currentAddress.receiverContact1, /[^\d]/g, '')
      }
      if (this.currentAddress.receiverContact2 !== '') {
        this.currentAddress.receiverContact2 = replacePattern(this.currentAddress.receiverContact2, /[^\d]/g, '')
      }
    },
    copy () {
      this.$emit('copyOrderer')
    },
    setOrderer (ordererInput) {
      this.currentAddress.receiverName = ordererInput.ordererName
      this.currentAddress.receiverContact1 = ordererInput.ordererContact1
      this.currentAddress.receiverContact2 = ordererInput.ordererContact2
    },
    setDeliveryMemo (memo) {
      this.active.memo = false
      this.currentAddress.deliveryMemo = memo
      this.setDeliveryMemoLength()
    },
    setDeliveryMemoLength () {
      this.txt.deliveryMemoLength = this.currentAddress.deliveryMemo.length
    },
    openAddressesPopup () {
      this.showAddLayer = true
      this.$store.commit('SHOW_LAYER_BG')
    },
    closeLayer (selected, address) {
      this.showAddLayer = false
      this.$store.commit('HIDDEN_LAYER_BG')
      if (selected) {
        this.callbackAddr(address)
      }
    },
    callbackAddr ({ zipCd, address, addressSub, receiverJibunAddress }) {
      this.currentAddress.receiverZipCd = zipCd
      this.currentAddress.receiverAddress = address
      this.currentAddress.receiverDetailAddress = addressSub
      this.currentAddress.receiverJibunAddress = receiverJibunAddress

      //  this.updatePaymentByAddress(address, receiverJibunAddress, zipCd)
    },
    validateNumber (event) {
      validateNumber(event)
    },
    updatePaymentByAddress () {
      if (!this.currentAddress || this.currentAddress.receiverAddress === '') {
        return
      }
      const addressRequest = {
        addressRequest: {
          addressType: 'RECENT',
          countryCd: 'KR',
          customsIdNumber: '',
          defaultYn: '',
          receiverAddress: this.currentAddress.receiverAddress,
          receiverContact1: '',
          receiverContact2: '',
          receiverDetailAddress: '',
          receiverJibunAddress: this.currentAddress.receiverJibunAddress,
          receiverName: '',
          receiverZipCd: this.currentAddress.receiverZipCd
        },
        accumulationUseAmt: this.usedMileageInt
      }
      const orderSheetNo = this.$store.state.route.params.orderSheetNo
      this.calculateOrderConpons({ orderSheetNo, addressRequest }).catch((e) => {
        if (e.data.code === '03061') {
          alert(e.data.message)
          this.usedMileageInt = 0
          this.$emit('resetMileage')
          this.updatePaymentByAddress()
        }
      })
    },
    cutAddressName (addrName) {
      addrName = addrName.trim()
      if (addrName.length < 5) {
        return addrName
      }
      const name = addrName.substr(0, 4) + '...'
      return name
    },
    openBookedAddrPop () {
      this.openBookedLayer = true
      this.$store.commit('SHOW_LAYER_BG')
    },
    closeBookedAddrPop () {
      this.openBookedLayer = false
      this.$store.commit('HIDDEN_LAYER_BG')
    },
    openBookmarkPop (addressDefault) {
      this.modifiedBookedAddr = addressDefault
      this.closeBookedAddrPop()
      this.openBookNewRegLayer = true
      this.$store.commit('SHOW_LAYER_BG')
    },
    regNewBookAddrPop () {
      this.closeNewBookAddrPop()
      this.openBookedAddrPop()
    },
    closeNewBookAddrPop () {
      this.openBookNewRegLayer = false
      this.modifiedBookedAddr = null
      this.$store.commit('HIDDEN_LAYER_BG')
    },
    bookAddrSelected (address) {
      this.closeBookedAddrPop()
      this.resetTempAddress(address)
      this.sortType = 'bookAddrSelected'

      this.resetCurrentAddress(address)
    },
    resetTempAddress (address) {
      if (address !== null) {
        this.tempAddress.addressName = address.addressName
        this.tempAddress.addressNo = address.addressNo
        this.tempAddress.receiverName = address.receiverName
        this.tempAddress.receiverZipCd = address.receiverZipCd
        this.tempAddress.receiverAddress = address.receiverAddress
        this.tempAddress.receiverJibunAddress = address.receiverJibunAddress
        this.tempAddress.receiverDetailAddress = address.receiverDetailAddress
        this.tempAddress.receiverContact1 = address.receiverContact1
        this.tempAddress.receiverContact2 = address.receiverContact2
        this.tempAddress.customsIdNumber = address.customsIdNumber
        this.tempAddress.deliveryMemo = address.deliveryMemo
      } else {
        this.tempAddress.addressName = ''
        this.tempAddress.addressNo = ''
        this.tempAddress.receiverName = ''
        this.tempAddress.receiverZipCd = ''
        this.tempAddress.receiverAddress = ''
        this.tempAddress.receiverJibunAddress = ''
        this.tempAddress.receiverDetailAddress = ''
        this.tempAddress.receiverContact1 = ''
        this.tempAddress.receiverContact2 = ''
        this.tempAddress.customsIdNumber = ''
        this.tempAddress.deliveryMemo = ''
      }
      if (this.tempAddress.receiverContact1 !== '') {
        this.tempAddress.receiverContact1 = replacePattern(this.tempAddress.receiverContact1, /[^\d]/g, '')
      }
      if (this.tempAddress.receiverContact2 !== '') {
        this.tempAddress.receiverContact2 = replacePattern(this.tempAddress.receiverContact2, /[^\d]/g, '')
      }
    },
    gdNumPhone: function () {
      if (this.currentAddress.receiverContact2 !== '') {
        this.currentAddress.receiverContact2 = replacePattern(this.currentAddress.receiverContact2, /[^\d]/g, '')
      }
    },
    gdNum: function () {
      if (this.currentAddress.receiverContact1 !== '') {
        this.currentAddress.receiverContact1 = replacePattern(this.currentAddress.receiverContact1, /[^\d]/g, '')
      }
    },
    setUsedMileageInt (mileage) {
      this.usedMileageInt = mileage
    }
  },
  watch: {
    'address.recentAddresses' (address, old) {
      if (this.sortType === 'shippingRecently') {
        if (this.address && this.address.recentAddresses && this.address.recentAddresses.length > 0) {
          address = this.address.recentAddresses[0]
        }
        this.resetCurrentAddress(address)
      }
    },
    'currentAddress.receiverAddress': 'updatePaymentByAddress',
    'couponRequestCopy': 'updatePaymentByAddress'
  }
}
</script>
