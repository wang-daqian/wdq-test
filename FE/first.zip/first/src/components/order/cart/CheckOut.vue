<template>
  <div class="btn_order_box">
    <span class="btn_left_box">
      <button type="button" class="btn_order_choice_del" @click="deleteCart">선택 상품 삭제</button>
    </span>
    <span :class="['btn_right_box', {'width_important' : displayMode === 'PC'}]">
      <button type="button" class="btn_order_choice_buy" @click="buy('checked')">선택 상품 주문</button>
      <button type="button" class="btn_order_whole_buy" @click="buy('all')">전체 상품 주문</button>
    </span>
  </div>
</template>

<script>
import { setOrderInfoInStorage } from '@/utils/orderUtils'
import { mapActions, mapMutations } from 'vuex'
export default {
  props: ['displayMode', 'checkedOptions', 'cartItems', 'invalidCartItems'],
  methods: {
    ...mapActions('cart', ['deleteCartByCartNos']),
    ...mapMutations('ordersheet', ['RESET_OUTDATED_DATA']),

    buy (type) {
      let items = []
      let msg = ''
      if (type === 'checked') {
        if (this.checkedOptions.length) {
          // const checkedCartItems = this.checkedOptions.filter(item => !item.isInvalid)
          const checkedCartItems = this.checkedOptions.filter(item => {
            if (item.isInvalid && msg === '') {
              msg = item.errMessage
            }
            return !item.isInvalid
          })
          items = checkedCartItems.map((option, idx) => {
            return {
              cartNo: option.cartNo,
              productNo: option.productNo,
              optionNo: option.optionNo,
              orderCnt: option.orderCnt,
              additionalProductNo: 0,
              optionInputs: []
            }
          })
          if (this.checkedOptions.length !== items.length) {
            if (this.checkedOptions.length > 1) {
              msg = '선택하신 상품 중에 구매할 수 없는 상품이 있습니다. 다시 확인해 주세요.'
            } else {
              // msg = '이 상품은 장바구니에 담을 수 없습니다. 상품상세에서 바로 구매해 주세요.'
            }
          }
        } else {
          msg = '상품을 선택해 주세요.'
        }
      } else {
        if (this.cartItems.length) {
          this.cartItems.forEach((item) => {
            const t = item.products.map((m) => {
              return {
                cartNo: m.cartNo,
                productNo: m.productNo,
                optionNo: m.optionNo,
                orderCnt: m.orderCnt,
                additionalProductNo: 0,
                optionInputs: []
              }
            })
            items.push(...t)
          })
        }
        if (this.invalidCartItems.length) {
          if (this.cartItems.length + this.invalidCartItems.length > 1) {
            msg = '선택하신 상품 중에 구매할 수 없는 상품이 있습니다. 다시 확인해 주세요.'
          } else {
            // msg = '이 상품은 장바구니에 담을 수 없습니다. 상품상세에서 바로 구매해 주세요.'
            msg = this.invalidCartItems[0].errMessage
          }
        }
      }
      if (msg !== '') {
        alert(msg)
        return
      }
      this.RESET_OUTDATED_DATA()
      setOrderInfoInStorage(items, this.$route.fullPath)
      this.$store.dispatch('ordersheet/getSheetNo')
    },
    deleteCart () {
      if (this.checkedOptions.length) {
        if (confirm(`선택하신 ${this.checkedOptions.length}개 상품을 장바구니에서 삭제 하시겠습니까?`)) {
          this.deleteCartByCartNos(this.checkedOptions.map(item => item.cartNo))
        }
      }
    }
  }
}
</script>

<style scoped>
.btn_right_box {
  float: right;
}
.width_important {
  width: auto !important;
}
</style>
