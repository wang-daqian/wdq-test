<template>
  <div class="price_sum" v-if="checkedOptions">
    <div class="price_sum_cont">
      <div class="price_sum_list">
        <dl>
          <dt>총
            <strong id="totalGoodsCnt">{{checkedCount}}</strong> 개의 상품금액 </dt>
          <dd>
            <strong id="totalGoodsPrice">{{cartPrice.totalItemPrice | formatNumber}}</strong>원</dd>
        </dl>
        <span><img src="../../../assets/img/order/order_price_minus.png" alt="더하기"></span>
        <dl>
          <dt>총 할인금액 </dt>
          <dd>
            <strong>{{cartPrice.totalDiscountAmt | formatNumber}}</strong>원</dd>
        </dl>
        <span><img src="../../../assets/img/order/order_price_plus.png" alt="더하기"></span>
        <dl>
          <dt>배송비</dt>
          <dd>
            <strong id="totalDeliveryCharge">{{cartPrice.totalShippingCost | formatNumber}}</strong>원</dd>
        </dl>
        <span><img src="../../../assets/img/order/order_price_total.png" alt="합계"></span>
        <dl class="price_total">
          <dt>합계</dt>
          <dd>
            <strong id="totalSettlePrice">{{cartPrice.paymentAmount | formatNumber}}</strong>원
            <div class="add_currency">
              <em id="totalSettlePriceAdd"></em>
            </div>
          </dd>
        </dl>
      </div>
      <em id="deliveryChargeText" class="tobe_mileage"></em>
      <em v-if="isUseMallAccumulation && logined" class="tobe_mileage">적립예정 {{showAccumulationName}} :
        <span id="totalGoodsMileage">{{Math.ceil(cartPrice.accumulationAmtWhenBuyConfirm) | formatNumber}}</span> {{showAccumulationUnit}}</em>
    </div>
    <!-- //price_sum_cont -->
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { isLogin } from '@/utils/utils'

export default {
  props: ['checkedOptions', 'cartPrice'],
  data () {
    return {
      logined: isLogin()
    }
  },
  computed: {
    ...mapGetters('common', ['showAccumulationName', 'isUseMallAccumulation', 'showAccumulationUnit']),
    checkedCount () {
      if (this.checkedOptions) {
        return this.checkedOptions.filter((item) => !item.isInvalid).length
      }
    }
  }
}
</script>
