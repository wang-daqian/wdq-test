<template>
  <tr>
    <td class="td_chk">
      <div class="form_element">
        <label for="cartSno1_55" :class="['check_s',{'on':itemChecked || product.checked}]" @click.prevent="checkout()"></label>
      </div>
    </td>
    <td class="td_left">
      <div class="pick_add_cont">
        <span class="pick_add_img">
          <goods-view-link :product="product">
            <img :src="product.imageUrl" width="40" :alt="product.productName" :title="product.productName" class="middle">
          </goods-view-link>
        </span>
        <div class="pick_add_info">
          <em>
            <goods-view-link :product="product">
              {{product.productName}} {{product.optionManagementCd | dispManageCode}}
            </goods-view-link>
            <span class="no_ref" v-if="!(product.refundable || disable)">환불불가</span>
          </em>
          <div class="pick_option_box">
            <template v-if="disable">
              {{product.optionTitle}}
              <em class="chk_none">{{product.errMessage}}</em>
            </template>
            <template v-else>
              {{product.optionTitle}}
              <template v-if="product.addPrice > 0"> (+{{product.addPrice | formatNumber}}원)</template>
              <template v-if="product.addPrice < 0"> ({{product.addPrice | formatNumber}}원)</template>
            </template>
          </div>
        </div>
      </div>
      <!-- //pick_add_cont -->
      <!-- //pick_add_list -->
    </td>
    <td class="td_order_amount">
      <span class="bx_count">
        <button type="button" :class="['btn_minus', { 'cart_disabled' : disable }]" @click="cntAlter('MINUS', disable)">
          <span class="blind">수량 1 감소</span>
        </button>
        <input title="구매수량" v-model="dispQuantity" class="count_input" type="text" @change="gdNum" @keydown="gdNum" @input="gdNum" :disabled="disable">
        <button type="button" :class="['btn_plus', { 'cart_disabled' : disable }]" @click="cntAlter('PLUS', disable)">
          <span class="blind">수량 1 증가</span>
        </button>
      </span>
    </td>
    <td>
      <strong class="order_sum_txt price">{{((product.salePrice + product.addPrice) * quantity) | formatNumber}}원</strong>
    </td>
    <td class="td_benefit js-relative-none">
      <ul class="benefit_list">
        <li class="benefit_sale" v-if="product.immediateDiscountAmt + product.additionalDiscountAmt > 0">
          <em>할인</em>
          <span v-if="product.immediateDiscountAmt !=0">즉시할인
            <strong>{{(product.immediateDiscountAmt * quantity) | formatNumber}}원</strong>
          </span>
          <span v-if="product.additionalDiscountAmt !=0">추가할인
            <strong> {{(product.additionalDiscountAmt * quantity) | formatNumber}}원</strong>
          </span>
        </li>
      </ul>
    </td>
    <td class="js-relative-none">
      <strong class="order_sum_txt">{{(product.buyAmt * quantity) | formatNumber}}원</strong>
    </td>
    <template v-if="product.bundledFlg">
      <order-delivery-fee v-if="product.bundledFirst" :rowspan="rowspan" :option="product" />
    </template>
    <template v-else>
      <order-delivery-fee :option="product" />
    </template>
  </tr>
</template>

<script>
import { mapMutations, mapActions } from 'vuex'
import { replacePattern } from '@/utils/validateUtils'
import OrderDeliveryFee from '@/components/order/order/OrderDeliveryFee'
import GoodsViewLink from '@/components/common/GoodsViewLink'

export default {
  props: ['rowspan', 'product', 'deliveryAmt', 'disable'],
  data () {
    return {
      itemChecked: this.product.checked,
      quantity: this.product.orderCnt,
      dispQuantity: this.product.orderCnt
    }
  },
  components: {
    OrderDeliveryFee,
    GoodsViewLink
  },
  methods: {
    ...mapMutations('cart', ['CHANGE_CART_ITEM_SET', 'CHECK_CART_ITEM']),
    ...mapActions('cart', ['putCarts', 'calculate']),
    checkout () {
      this.itemChecked = !this.itemChecked
      this.CHANGE_CART_ITEM_SET({ cartNo: this.product.cartNo, optionNo: this.product.optionNo, checked: this.itemChecked, orderCnt: this.product.orderCnt, isInvalid: this.disable })
      this.CHECK_CART_ITEM()

      if (this.disable) {
        return
      }
      this.calculate()
    },
    gdNum: function () {
      let tempCnt = 0
      if (this.dispQuantity) {
        tempCnt = replacePattern(this.dispQuantity, /[^\d]/g, '')
        if (parseInt(tempCnt) > 9999) {
          tempCnt = 9999
        } else if (parseInt(tempCnt) <= 0 || isNaN(parseInt(tempCnt))) {
          tempCnt = 1
        } else {
          tempCnt = parseInt(tempCnt)
        }
      } else {
        tempCnt = 1
      }
      this.dispQuantity = this.$options.filters.formatNumber(tempCnt)
      this.quantity = tempCnt
    },
    cntAlter (type, disable) {
      if (disable) {
        return
      }
      if (type === 'PLUS') {
        this.quantity = Number(this.quantity) + 1
      }
      if (type === 'MINUS') {
        this.quantity = Number(this.quantity) - 1
      }
      if (this.quantity < 1) {
        this.quantity = 1
      } else if (this.quantity > 9999) {
        this.quantity = 9999
      }
      this.dispQuantity = this.$options.filters.formatNumber(this.quantity)
    }
  },
  watch: {
    product: {
      handler (newValue, oldValue) {
        this.itemChecked = newValue.checked
      },
      deep: true
    },
    quantity (newval, oldval) {
      if (this.quantity <= 0) {
        this.quantity = 1
      }
      const data = [{ cartNo: this.product.cartNo, orderCnt: this.quantity }]
      this.putCarts(data)
      this.CHANGE_CART_ITEM_SET({ cartNo: this.product.cartNo, optionNo: this.product.optionNo, checked: this.itemChecked, orderCnt: this.quantity })
    }
  }
}
</script>

<style scoped>
.cart_disabled {
  background: #f3f3f3;
}
</style>
