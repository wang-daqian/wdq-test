<template>
  <div class="cart_cont_list">
    <div class="order_cart_tit">
    </div>
    <!-- //order_cart_tit -->
    <div class="order_table_type scroll">
      <table :class="{'no_result' : cartItems && invalidCartItems && !cartItems.length && !invalidCartItems.length}">
        <colgroup>
          <col style="width:3%">
          <!-- 체크박스 -->
          <col>
          <!-- 상품명/옵션 -->
          <col style="width:5%">
          <!-- 수량 -->
          <col style="width:10%">
          <!-- 상품금액 -->
          <col style="width:13%">
          <!-- 할인/적립 -->
          <col style="width:10%">
          <!-- 합계금액 -->
          <col style="width:10%">
          <!-- 배송비 -->
        </colgroup>
        <thead>
          <tr>
            <th>
              <div class="form_element">
                <label for="allCheck1" :class="['check_s',{'on':checkAll}]" @click.prevent="checkedAll"></label>
              </div>
            </th>
            <th>상품/옵션 정보</th>
            <th>수량</th>
            <th>상품금액</th>
            <th class="js-relative-none">할인</th>
            <th class="js-relative-none">합계금액</th>
            <th>배송비</th>
          </tr>
        </thead>
        <tbody>
          <template v-for="(item, index) in cartItems">
            <item-row v-for="(product, idx) in item.products" :key="`${index}_${idx}_${product.cartNo}`" :product="product" :rowspan="(!idx)?item.products.length:0" :deliveryAmt="item.deliveryAmt" />
          </template>
          <template v-if="invalidCartItems && invalidCartItems.length">
            <item-row v-for="(product, idx) in invalidCartItems" :key="idx" :product="product" :disable="true" />
          </template>
        </tbody>
      </table>
    </div>
    <p v-if="cartItems && invalidCartItems && !cartItems.length && !invalidCartItems.length" class="no_data">장바구니에 담겨있는 상품이 없습니다.</p>
  </div>
</template>

<script>
import { mapMutations, mapActions } from 'vuex'
import ItemRow from '@/components/order/cart/ItemRow'
export default {
  props: ['invalidCartItems', 'cartItems', 'checkAll', 'pending'],
  data () {
    return {
    }
  },
  methods: {
    ...mapMutations('cart', ['CHANGE_CART_ITEM_CHECKOUT_ALL', 'CHECK_CART_ITEM']),
    ...mapActions('cart', ['calculate']),
    checkedAll () {
      this.CHANGE_CART_ITEM_CHECKOUT_ALL(!this.checkAll)
      this.CHECK_CART_ITEM()
      this.calculate()
    }
  },
  components: {
    ItemRow
  }
}
</script>

<style>
</style>
