<template>
  <div class="item_goods_tab">
    <ul>
      <li :class="index === 0 ? 'on' : ''">
        <a href="#" @click.prevent="custormAnchor('item_detail')">상품상세정보</a>
      </li>
      <li :class="index === 1 ? 'on' : ''">
        <a href="#" @click.prevent="custormAnchor('item_exchange')">반품 정보</a>
      </li>
      <li :class="index === 2 ? 'on' : ''">
        <a href="#" @click.prevent="custormAnchor('item_reviews')">상품후기
          <strong v-if="reviewTotalCount">({{reviewTotalCount}})</strong>
        </a>
      </li>
      <li :class="index === 3 ? 'on' : ''">
        <a href="#" @click.prevent="custormAnchor('item_qna')">상품문의
          <strong v-if="inquiriesTotalCount">({{inquiriesTotalCount}})</strong>
        </a>
      </li>
    </ul>
  </div>
</template>

<script>
import $ from 'jquery'
import { mapState } from 'vuex'
export default {
  props: ['index'],
  computed: {
    ...mapState('product', ['inquiriesTotalCount', 'reviewTotalCount'])
  },
  methods: {
    custormAnchor (anchorName) {
      if ($('#' + anchorName) && $('#' + anchorName).offset()) {
        const headerTop = $('#header_warp') ? $('#header_warp').height() : 0
        $(window).scrollTop($('#' + anchorName).offset().top - headerTop)
      }
    }
  }
}
</script>

<style>
</style>
