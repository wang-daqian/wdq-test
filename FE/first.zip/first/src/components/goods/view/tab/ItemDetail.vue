<template>
  <div id="item_detail">
    <item-goods-tab :index="0" />
    <div class="detail_cont">
      <h3>상품상세정보</h3>
      <div class="detail_explain_box">
        <div v-if="product.partnerNotice && product.partnerNotice.content" v-html="product.partnerNotice.content"></div>
        <div v-if="product.baseInfo.contentHeader" v-html="product.baseInfo.contentHeader"></div>
        <div v-if="product.baseInfo.optionImageViewable">
          <img v-for="img in optionImages" :key="img.optionNo" :src="img.imageUrl" />
        </div>
        <div v-else v-html="product.baseInfo.content"></div>
        <div v-if="product.baseInfo.contentFooter" v-html="product.baseInfo.contentFooter"></div>
      </div>
      <template v-if="dutyInfo && dutyInfo.length > 0">
        <h3>상품정보제공고시</h3>
        <div class="detail_info_box">
          <div class="datail_table">
            <table class="left_table_type">
              <tbody>
                <tr>
                  <th style="width:20%">{{dutyInfo[0].key}}</th>
                  <td style="width:30%">{{dutyInfo[0].value}}</td>
                  <th style="width:20%">{{dutyInfo[1] && dutyInfo[1].key}}</th>
                  <td style="width:30%">{{dutyInfo[1] && dutyInfo[1].value}}</td>
                </tr>
                <tr v-if="dutyInfo.length > 2">
                  <th style="width:20%">{{dutyInfo[2].key}}</th>
                  <td style="width:30%">{{dutyInfo[2].value}}</td>
                  <th style="width:20%">{{dutyInfo[3] && dutyInfo[3].key}}</th>
                  <td style="width:30%">{{dutyInfo[3] && dutyInfo[3].value}}</td>
                </tr>
                <tr v-if="dutyInfo.length > 4">
                  <th style="width:20%">{{dutyInfo[4].key}}</th>
                  <td style="width:30%">{{dutyInfo[4].value}}</td>
                  <th style="width:20%">{{dutyInfo[5] && dutyInfo[5].key}}</th>
                  <td style="width:30%">{{dutyInfo[5] && dutyInfo[5].value}}</td>
                </tr>
                <tr v-for="n in (dutyInfo.length - 6)" :key="n" v-if="dutyInfo.length > 6">
                  <th style="width:20%">{{dutyInfo[5 + n].key}}</th>
                  <td colspan="3" style="width:80%;">{{dutyInfo[5 + n].value}}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </template>
    </div>
  </div>
</template>

<script>
import $ from 'jquery'
import ItemGoodsTab from '@/components/goods/view/tab/ItemGoodsTab'

export default {
  props: ['product', 'dutyInfo', 'optionImages'],
  components: {
    ItemGoodsTab
  },
  mounted () {
    if ($('.detail_explain_box iframe')) {
      $('.detail_explain_box iframe').wrap(`<div style="position: relative; width: 100%; height: 0; padding-bottom: 56.25%;"></div>`)
    }
  }
}
</script>

<style>
.detail_explain_box img {
  max-width: 100% !important;
  height: auto !important;
}
iframe {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
}
</style>
