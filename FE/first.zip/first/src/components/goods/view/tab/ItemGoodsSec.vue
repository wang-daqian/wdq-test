<template>
  <div class="item_goods_sec" v-if="product">
    <item-detail :product="product" :dutyInfo="dutyInfo" :optionImages="optionImages" />
    <item-exchange :product="product" />
    <item-reviews :review="review" :reviewTotalCount="reviewTotalCount" :reviewRate="reviewRate" :product="product" />
    <item-qna :inquiries="inquiries" :inquiriesTotalCount="inquiriesTotalCount" :product="product" />
  </div>
</template>

<script>
import ItemDetail from '@/components/goods/view/tab/ItemDetail'
import ItemExchange from '@/components/goods/view/tab/ItemExchange'
import ItemReviews from '@/components/goods/view/tab/ItemReviews'
import ItemQna from '@/components/goods/view/tab/ItemQna'

export default {
  props: ['product', 'dutyInfo', 'optionImages', 'inquiries', 'inquiriesTotalCount', 'review', 'reviewTotalCount', 'reviewRate'],
  components: {
    ItemDetail,
    ItemExchange,
    ItemReviews,
    ItemQna
  }
}
</script>

<style>
</style>
