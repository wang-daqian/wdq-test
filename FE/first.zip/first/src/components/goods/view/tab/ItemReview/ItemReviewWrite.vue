<template>
  <div id="lygoodsReview" class="layer_wrap goods_board_layer">
    <div class="layer_wrap_cont">
      <div class="board_write_popup">
        <div class="ly_tit">
          <h4>상품후기 쓰기</h4>
        </div>
        <div class="ly_cont">
          <div class="scroll_box">
            <div class="top_item_photo_info">
              <div class="item_photo_box">
                <img :src="product.imageUrl" width="500" :alt="product.productName" :title="product.productName" class="middle">
              </div>
              <!-- //item_photo_view -->
              <div class="item_info_box">
                <h5>{{product.productName}}
                  <template v-if="product.productManagementCd">({{product.productManagementCd}})</template>
                </h5>
                <!-- <em>반응형 스킨으로 다양하게 활용하기 좋은 디자인</em> -->
              </div>
            </div>
            <!-- //top_item_photo_info -->
            <div class="board_write_box">
              <table class="board_write_table">
                <colgroup>
                  <col style="width:15%">
                  <col style="width:85%">
                </colgroup>
                <tbody>
                  <tr>
                    <th scope="row">평점</th>
                    <td>
                      <div class="form_element">
                        <ul class="rating_star_list">
                          <li>
                            <label for="rating5" :class="['choice_s', {'on':rating === '5'}]">
                              <span class="rating_star">
                                <span style="width:100%;">별5</span>
                              </span>
                            </label>
                            <input type="radio" id="rating5" name="goodsPt" value="5" v-model="rating">
                          </li>
                          <li>
                            <label for="rating4" :class="['choice_s', {'on':rating === '4'}]">
                              <span class="rating_star">
                                <span style="width:80%;">별4</span>
                              </span>
                            </label>
                            <input type="radio" id="rating4" name="goodsPt" value="4" v-model="rating">
                          </li>
                          <li>
                            <label for="rating3" :class="['choice_s', {'on':rating === '3'}]">
                              <span class="rating_star">
                                <span style="width:60%;">별3</span>
                              </span>
                            </label>
                            <input type="radio" id="rating3" name="goodsPt" value="3" v-model="rating">
                          </li>
                          <li>
                            <label for="rating2" :class="['choice_s', {'on':rating === '2'}]">
                              <span class="rating_star">
                                <span style="width:40%;">별2</span>
                              </span>
                            </label>
                            <input type="radio" id="rating2" name="goodsPt" value="2" v-model="rating">
                          </li>
                          <li>
                            <label for="rating1" :class="['choice_s', {'on':rating === '1'}]">
                              <span class="rating_star">
                                <span style="width:20%;">별1</span>
                              </span>
                            </label>
                            <input type="radio" id="rating1" name="goodsPt" value="1" v-model="rating">
                          </li>
                        </ul>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">내용</th>
                    <td class="wirte_editor">
                      <textarea id="editor" name="contents" cols="" rows="5" v-model="content" style="width: 100%; display: block;"></textarea>
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">사진</th>
                    <td id="uploadBox">
                      <div class="file_upload_sec" v-for="(f,idx) in filepath" :key="idx">
                        <label :for="`attach1${idx}`">
                          <input type="text" class="file_text" title="사진 첨부하기" readonly="readonly" :value="filepath[idx]">
                        </label>
                        <div class="btn_upload_box _btn">
                          <button type="button" class="btn_upload" title="찾아보기">
                            <em>찾아보기</em>
                          </button>&nbsp;
                          <input :style="isPC ? '' : 'top: 10px;'" type="file" :id="`attach1${idx}`" class="file" title="찾아보기" @change="onFileChange(idx, $event)" ref="flup" accept="image/*">

                          <span class="btn_gray_list" @click.prevent="minusFile(idx)">
                            <button type="button" id="delUploadBtn" class="btn_gray_big">
                              <span>- 삭제</span>
                            </button>
                          </span>
                          <span class="btn_gray_list" v-if="idx === 0" @click.prevent="plusFile()">
                            <button type="button" id="addUploadBtn" class="btn_gray_big">
                              <span>+ 추가</span>
                            </button>
                          </span>
                        </div>
                      </div>
                      <span>사진은 최대 10장까지 등록 가능합니다.</span>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
            <!-- //board_wirte_box -->
            <!-- //board_wirte_agree -->
          </div>
          <!-- //scroll_box -->
          <div class="btn_center_box">
            <a href="#" @click.prevent="closePop">
              <button class="btn_ly_cancel">
                <strong>취소</strong>
              </button>
            </a>
            <button class="btn_ly_write_ok" @click.prevent="reviewWrite">
              <strong>등록</strong>
            </button>
          </div>
        </div>
        <!-- //ly_cont -->
      </div>
      <!-- //ly_cont -->
      <a href="#" class="ly_close layer_close" @click.prevent="closePop">
        <img src="../../../../../assets/img/common/layer/btn_layer_close.png" alt="닫기">
      </a>
    </div>
  </div>
</template>

<script>
import { isPC } from '@/utils/utils'

export default {
  props: ['product', 'reviewableData'],
  data () {
    return {
      images: [''],
      filepath: [''],
      running: false,
      content: '',
      rating: ''
    }
  },
  computed: {
    isPC () {
      return isPC()
    }
  },
  methods: {
    closePop () {
      this.$emit('closePop')
    },
    reviewWrite () {
      if (this.rating === '') {
        alert('평점을 선택해 주세요.')
        return false
      }
      if (this.content.trim() === '') {
        alert('내용을 입력해 주세요.')
        return false
      }
      if (this.running) {
        return
      } else {
        this.running = true
      }
      const dispatch = this.$store.dispatch
      const paramsReview = {
        productNo: this.product.productNo,
        optionNo: this.product.reviewableData.mallOptionNo,
        orderOptionNo: this.product.reviewableData.orderProductOptionNo,
        rate: this.rating,
        content: this.content
      }

      Promise.all(this.images.map((image) => {
        if (image !== '') {
          const data = new FormData()
          data.append('file', image.file)
          return dispatch('common/uploadImages', data)
        } else {
          return ''
        }
      })).then(ret => {
        const urls = []
        ret.forEach(res => {
          if (res !== '') {
            urls.push(res.data.imageUrl)
          }
        })
        paramsReview.urls = urls
        this.running = false
        dispatch('product/postProductReviews', paramsReview).then(() => {
          alert('상품후기 작성이 완료되었습니다.')
          this.$emit('closePop', true)
          this.running = false
        }).catch((e) => {
          this.running = false
        })
      }).catch((e) => {
        this.running = false
      })
    },
    plusFile () {
      if (this.filepath.length < 10) {
        this.filepath.push('')
        this.images.push('')
      } else {
        alert('상품후기 사진은 10개까지 등록 가능합니다.')
      }
    },
    minusFile (index) {
      if (index === 0) {
        this.filepath.splice(index, 1, '')
        this.images.splice(index, 1, '')
      } else {
        this.filepath.splice(index, 1)
        this.images.splice(index, 1)
      }
    },
    onFileChange (idx, e) {
      var files = e.target.files || e.dataTransfer.files
      if (!files.length) {
        return
      }
      this.createImage(files, idx, e.target.value)
      e.target.value = ''
    },
    createImage (files, index, targetValue) {
      if (typeof FileReader === 'undefined') {
        alert('브라우저가 이미지 업로드를 지원하지 않습니다. 브라우저를 업그레이드 해주세요.')
        return false
      }

      const leng = files.length
      for (let i = 0; i < leng; i++) {
        if (files[i].size > 1048576) { // 1MB
          alert('각 사진은 최대 1MB까지 등록가능합니다.')
          return false
        }

        if (files[i].type.split('image').length === 1) {
          alert('이미지파일(jpg, jpeg, gif, png, bmp)만 등록해주세요.')
          return false
        }
      }

      const vm = this
      for (let i = 0; i < leng; i++) {
        const fileitem = {}
        fileitem.file = files[i]
        vm.name = files[i].name
        const reader = new FileReader()
        reader.readAsDataURL(files[i])
        reader.onload = function (e) {
          var image = new Image()
          image.src = e.target.result
          image.onload = function () {
            fileitem.filedata = e.target.result
            if (this.width > 500 || this.height > 500) {
              var canvas = document.createElement('canvas')
              // canvas default
              canvas.width = 500
              canvas.height = 500
              // image
              let size = vm.getSize(this.width, this.height)

              let ctx = canvas.getContext('2d')
              ctx.fillStyle = '#ffffff'
              ctx.fillRect(0, 0, 500, 500)
              ctx.drawImage(this, size.wd, size.hd, size.w, size.h)
              let base64 = canvas.toDataURL('image/jpeg')
              fileitem.file = vm.dataURLtoFile(base64, vm.name)
              fileitem.filedata = base64
            }
            vm.images.splice(index, 1, fileitem)
            vm.filepath.splice(index, 1, targetValue)
          }
        }
      }
    },
    getSize (width, height) {
      let size = {
        w: width,
        h: height,
        wd: 0,
        hd: 0
      }

      if (width > 500 && width === height) {
        size.w = 500
        size.h = 500
        return size
      }
      if (width > 500 && width > height) {
        let diff = width - 500
        size.w = 500
        size.h = height - height * (diff / width)
        size.hd = width === height ? 0 : (500 - size.h) / 2
        return size
      }
      if (height > 500 && width < height) {
        let diff = height - 500
        size.h = 500
        size.w = width - width * (diff / height)
        size.wd = (500 - size.w) / 2
        return size
      }
    },
    dataURLtoFile (dataurl, filename) {
      let arr = dataurl.split(',')
      let mime = arr[0].match(/:(.*?);/)[1]
      let bstr = atob(arr[1])
      let n = bstr.length
      let u8arr = new Uint8Array(n)
      while (n--) {
        u8arr[n] = bstr.charCodeAt(n)
      }
      return new File([u8arr], filename, { type: mime })
    }
  },
  watch: {
    content (newval, old) {
      if (newval.length > 1000) {
        this.content = old
      }
    }
  }
}
</script>

<style scoped>
._btn {
  width: 210px;
}
</style>
