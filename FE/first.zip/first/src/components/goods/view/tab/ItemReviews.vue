<template>
  <div id="item_reviews">
    <item-goods-tab :index="2" />

    <div class="reviews_cont">
      <h3>상품후기
        <span class="score" v-if="reviewRate">{{showRate}} / 5.0</span>
      </h3>
      <div id="ajax-goods-goodsreview-list">
        <div class="reviews_table">
          <table :class="['reviews_table_type', {'no_result' : !review || review.length === 0}]">
            <colgroup>
              <col width="13%">
              <col>
              <col width="13%">
              <col width="13%">
            </colgroup>
            <thead>
              <tr>
                <th>평점</th>
                <th>제목</th>
                <th>작성자</th>
                <th>작성일</th>
              </tr>
            </thead>
            <tbody>
              <template v-if="review && review.length > 0">
                <template v-for="(item) in review">
                  <tr @click.prevent="openContent(item.reviewNo)" :key="item.reviewNo" class="js_data_row" data-bdid="goodsreview" data-sno="7" data-auth="y" data-notice="n">
                    <td>
                      <span class="rating_star">
                        <span :style="{width:$options.filters.reviewrate(item.rate)}">별</span>
                      </span>
                    </td>
                    <td class="board_tit">
                      <a href="#" @click.prevent="">
                        <strong>{{item.content | subContent}}</strong>
                        <img v-if="item.fileUrls.length" src="../../../../assets/img/icon/icon_board_attach_img.png" alt="이미지첨부 있음">
                      </a>
                    </td>
                    <td>{{item.memberId | maskId}}</td>
                    <td>{{item.registerYmdt | getStrYMDHM('.')}}</td>
                  </tr>
                  <tr :key="item.reviewNo+'1'">
                    <td colspan="4" class="reviews_new_box" v-if="(currentReviewNo === item.reviewNo)">
                      <div class="board_cont">
                        <div class="board_view">
                          <ul class="pic_list" v-if="item.fileUrls.length">
                            <li v-for="(file, index) in item.fileUrls" :key="file">
                              <a href="#" @click.prevent="showLayer(item.fileUrls,index)">
                                <img :src="file">
                              </a>
                            </li>
                          </ul>
                          <p class="content_pre">{{item.content}}</p>
                        </div>

                        <div class="btn_view_comment_box clearfix" v-if="item.recommendCnt > 0 || !item.myReview">
                          <p class="recommend left" v-if="item.recommendCnt > 0">{{item.recommendCnt}}명이 추천했습니다.</p>
                          <span class="btn_gray_list right" v-if="!item.myReview">
                            <button type="button" class="btn_gray_mid" @click="reportReview">
                              <span>신고하기</span>
                            </button>
                          </span>
                          <span class="btn_gray_list right" v-if="!item.myReview">
                            <button type="button" class="btn_gray_mid" @click="recommend(item.reviewNo, item.recommendable)" v-if="item.recommendable">
                              <span>추천하기</span>
                            </button>
                            <button type="button" class="btn_gray_mid" @click="recommend(item.reviewNo, item.recommendable)" v-else>
                              <span>추천취소</span>
                            </button>
                          </span>
                        </div>
                        <!-- //btn_view_comment_box -->
                      </div>
                      <!-- //board_cont -->
                    </td>
                  </tr>
                </template>
              </template>
              <template v-else>
                <tr>
                  <td rowspan="5" align="center">작성된 상품후기가 없습니다.</td>
                </tr>
              </template>
            </tbody>
          </table>
        </div>
        <div class="pagination" v-if="review && review.length < reviewTotalCount">
          <p class="pagination-btn">
            <button type="button" class="btn_more" @click.prevent="fetchMore">더보기</button>
          </p>
        </div>
      </div>
      <div class="btn_reviews_box">
        <ul class="order">
          <li :class="{'on' : orderByType === 'RECOMMEND'}">
            <a href="#" @click.prevent="clickOrderBy('RECOMMEND')">추천순</a>
          </li>
          <li>|</li>
          <li :class="{'on' : orderByType === 'REGISTER_YMDT'}">
            <a href="#" @click.prevent="clickOrderBy('REGISTER_YMDT')">최신순</a>
          </li>
        </ul>
        <router-link to="/mypage/product/reviews" class="btn_reviews_more">내 상품후기 보기</router-link>
        <a href="#" class="btn_reviews_write" @click.prevent="reviewWrite">상품후기 글쓰기</a>
      </div>
      <!-- //btn_reviews_box -->
    </div>
    <!-- //reviews_cont -->
    <item-review-report v-if="reportReviewLay" @closePop="reportReview" :productNo="this.product.baseInfo.productNo" :reviewNo="currentReviewNo" />
    <item-review-write v-if="reviewWriteLay" @closePop="closeOrOpenReviewPop" :product="reviewProduct" :reviewableData="reviewableData" />

    <img-view-layer @close="closeLayer" :imgUrls="imgUrls" :clickInx="clickInx" :productName="product.baseInfo.productName" :managementCd="product.baseInfo.productManagementCd" :openLayer="openLayer" />
  </div>
</template>

<script>
import ItemGoodsTab from '@/components/goods/view/tab/ItemGoodsTab'
import ItemReviewReport from '@/components/goods/view/tab/ItemReview/ItemReviewReport'
import ItemReviewWrite from '@/components/goods/view/tab/ItemReview/ItemReviewWrite'
import ImgViewLayer from '@/components/common/ImgViewLayer'
import { mapActions, mapState } from 'vuex'
import { loginAndBack } from '@/utils/utils'
export default {
  props: ['product', 'review', 'reviewTotalCount', 'reviewRate'],
  data () {
    return {
      openLayer: false,
      imgUrls: [],
      clickInx: 0,
      currentReviewNo: 0,
      reportReviewLay: false,
      reviewWriteLay: false,
      reviewableData: null,
      orderByType: 'RECOMMEND'
    }
  },
  components: {
    ItemGoodsTab,
    ItemReviewReport,
    ItemReviewWrite,
    ImgViewLayer
  },
  methods: {
    ...mapActions('product', ['fetchProductReviewMore', 'productRecommend', 'fetchProductReview', 'orderByReview']),
    fetchMore () {
      this.fetchProductReviewMore()
    },
    clickOrderBy (orderBy) {
      this.orderByType = orderBy
      this.orderByReview(orderBy)
    },
    openContent (reviewNo) {
      if (this.currentReviewNo === reviewNo) {
        this.currentReviewNo = 0
      } else {
        this.currentReviewNo = reviewNo
      }
    },
    recommend (reviewNo, recommendFlg) {
      if (!loginAndBack(this.$router, this.$route)) {
        return
      }
      this.productRecommend({ reviewNo: reviewNo, productNo: this.product.baseInfo.productNo, recommendFlg })
    },
    reportReview () {
      this.reportReviewLay = !this.reportReviewLay
      if (this.reportReviewLay) {
        this.$store.commit('SHOW_LAYER_BG')
      } else {
        this.$store.commit('HIDDEN_LAYER_BG')
      }
    },
    closeOrOpenReviewPop (isWrited) {
      this.reviewWriteLay = !this.reviewWriteLay
      if (this.reviewWriteLay) {
        this.$store.commit('SHOW_LAYER_BG')
      } else {
        if (isWrited) {
          this.fetchProductReview(this.product.baseInfo.productNo)
        }
        this.$store.commit('HIDDEN_LAYER_BG')
      }
    },
    reviewWrite () {
      if (!loginAndBack(this.$router, this.$route)) {
        return
      }
      this.$store.dispatch('product/reviewableOption', { productNo: this.product.baseInfo.productNo }).then(() => {
        if (this.reviewable.reviewable) {
          this.revewOption()
          if (!this.reviewableData) {
            alert('평가할 수 없습니다.')
            return
          }
          this.closeOrOpenReviewPop()
        } else {
          alert('구매하지 않은 상품에는 상품후기를 작성하실 수 없습니다.')
        }
      })
    },
    revewOption () {
      const optionNos = this.options.flatOptions.map(item => item.optionNo)
      const optionReviewNos = this.reviewable.item.map(item => item.mallOptionNo)
      if (optionReviewNos.length) {
        this.reviewableData = this.reviewable.item.find((obj) => optionNos.some((optNo) => optNo === obj.mallOptionNo))
      }
    },
    showLayer (urls, idx) {
      this.imgUrls = urls
      this.clickInx = idx
      this.openLayer = true
      this.$store.commit('SHOW_LAYER_BG')
    },
    closeLayer () {
      this.openLayer = false
      this.$store.commit('HIDDEN_LAYER_BG')
    }
  },
  computed: {
    ...mapState('product', ['options', 'reviewable']),
    reviewProduct () {
      if (this.product) {
        return {
          imageUrl: this.product.baseInfo.imageUrls[0],
          productName: this.product.baseInfo.productName,
          productNo: this.product.baseInfo.productNo,
          reviewableData: this.reviewableData,
          productManagementCd: this.product.baseInfo.productManagementCd
        }
      }
    },
    showRate () {
      if (this.reviewRate) {
        if (this.reviewRate.toString().indexOf('.') === -1) {
          return this.reviewRate + '.0'
        }
        return this.reviewRate
      } else {
        return '5.0'
      }
    }
  }
}
</script>

<style>
#item_reviews img {
  max-width: 100% !important;
}
</style>
