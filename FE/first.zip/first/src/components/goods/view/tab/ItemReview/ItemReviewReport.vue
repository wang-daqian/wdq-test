<template>
  <div id="lyReport" class="layer_wrap report_layer">
    <div class="layer_wrap_cont" :style="lyStyle">
      <div class="ly_tit">
        <h4>
          상품후기 신고하기
        </h4>
      </div>
      <div class="ly_cont">
        <div class="report_layer_cont">
          <p class="tit">신고사유를 선택해 주세요.
            <small>(필수)</small>
          </p>
          <div class="form_element">
            <ul>
              <li>
                <input type="radio" id="rating1" name="goodsPt" v-model="reportType" value="SLANDER" checked="">
                <label for="rating1" class="choice_s">
                  <span class="rating_star">
                    <span>욕설 또는 비방</span>
                  </span>
                </label>
              </li>
              <li>
                <input type="radio" id="rating2" name="goodsPt" v-model="reportType" value="COPYRIGHT">
                <label for="rating2" class="choice_s">
                  <span class="rating_star">
                    <span>저작권 침해 및 기타사유</span>
                  </span>
                </label>
              </li>
            </ul>
          </div>
          <p class="tit">신고내용을 입력해 주세요.
            <small>(필수)</small>
          </p>
          <div class="bx_write">
            <textarea v-model="content" placeholder="상품후기와 관련 없는 글(비방, 욕설, 광고, 잘못된 정보 등)을 신고해 주시면 쇼핑몰 운영자의 확인 후 해당 상품후기의 노출 여부를 제한할 수 있습니다. 단, 타당한 사유 없이 허위로 상품후기를 신고할 경우 신고자의 활동에 제약이 걸릴 수 있으니 신중을 기하여 신고하여 주시기 바랍니다."></textarea>
            <span class="text_count">
              <span class="num">{{content.length | formatNumber}}</span>/1,000
            </span>
          </div>
        </div>
        <div class="btn_center_box">
          <button id="btnAllCouponDown" class="btn_ly_download" @click="report">
            <strong>등록하기</strong>
          </button>
        </div>
      </div>
      <!-- //ly_cont -->
      <a href="#" class="ly_close layer_close" @click.prevent="closePop">
        <img src="../../../../../assets/img/common/layer/btn_layer_close.png" alt="닫기">
      </a>
    </div>
    <!-- //layer_wrap_cont -->
  </div>
</template>

<script>
export default {
  props: ['productNo', 'reviewNo'],
  data () {
    return {
      lyStyle: '',
      reportType: 'SLANDER',
      content: ''
    }
  },
  methods: {
    report () {
      if (this.content.trim() === '') {
        alert('내용을 입력해 주세요.')
      } else {
        this.$store.dispatch('product/postProductReviewsReport', {
          productNo: this.productNo,
          reviewNo: this.reviewNo,
          reportReasonCd: this.reportType,
          content: this.content
        }).then(() => {
          this.content = ''
          this.reasonCode = 'SLANDER'
          alert('신고가 완료되었습니다.')
          this.closePop()
        })
      }
    },
    closePop () {
      this.$emit('closePop')
    }
  },
  watch: {
    content (newval, old) {
      if (newval.length > 1000) {
        this.content = old
      }
    }
  }
}
</script>

<style>
</style>
