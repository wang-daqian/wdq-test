<template>
  <div id="item_exchange">
    <item-goods-tab :index="1" />
    <!-- //item_goods_tab -->
    <div class="exchange_cont">
      <h3>반품 정보</h3>
      <div class="goods_info_sec">
        <table border="0" cellpadding="0" cellspacing="0">
          <colgroup>
            <col style="width: 140px;">
            <col>
          </colgroup>
          <tbody>
            <tr>
              <th scope="row">택배사</th>
              <template v-if="product.deliveryFee.deliveryCompanyTypeLabel === '' || product.deliveryFee.deliveryCompanyTypeLabel === undefined || product.deliveryFee.deliveryCompanyTypeLabel === null">
                <td>직접배송</td>
              </template>
              <template v-else>
                <td>{{ product.deliveryFee.deliveryCompanyTypeLabel}}</td>
              </template>
            </tr>
            <tr>
              <th scope="row">반품배송비</th>
              <td>
                편도 {{ product.deliveryFee.returnDeliveryAmt | formatNumber }}원
                <template v-if="product.deliveryFee.deliveryConditionType === 'FREE'">
                  (최초 배송비 무료인 경우 {{ product.deliveryFee.returnDeliveryAmt * 2 | formatNumber }}원 부과)
                </template>
              </td>
            </tr>
            <tr>
              <th scope="row">반품 주소지</th>
              <td>
                <template v-if="product.deliveryFee.returnWarehouse.zipCd">
                  ({{ product.deliveryFee.returnWarehouse.zipCd }})
                </template>
                {{ product.deliveryFee.returnWarehouse.addressStr }}
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <div class="admin_msg">
        <p>- 상품 수령 후 7일 이내 반품을 신청하실 수 있습니다.<br>단, 다음의 각 내용에 해당하는 반품은 신청이 불가능할 수 있습니다.</p>
        <p>- 소비자의 책임있는 사유로 상품 등이 멸실/훼손된 경우 (단지 상품 확인을 위한 포장 훼손 제외)</p>
        <p>- 소비자의 사용/소비에 의해 상품 등의 가치가 현저히 감소한 경우</p>
        <p>- 시간의 경과에 의해 재판매가 곤란할 정도로 상품 등의 가치가 현저히 감소한 경우</p>
        <p>- 복제가 가능한 상품 등의 포장을 훼손한 경우</p>
        <p>- 소비자의 주문에 따라 개별 생산되는 상품이 제작이 들어간 경우 사용 중 발생한 하자의 환불/수리/교환 등을 ‘공정거래위원회 소비자 분쟁 해결기준’에 준하여 처리됩니다. 그 절차와 내용은 제조사/판매자의 책임으로 진행되오니, 제조사의 A/S센터 또는 판매자에게 문의하시기 바랍니다.</p>
      </div>
      <p>※ 통신판매중개자인 퍼스트어패럴은 반품에 따른 판매자의 책임을 부담하지 않습니다.</p>
    </div>
    <!-- //exchange_cont -->
  </div>
</template>

<script>
import ItemGoodsTab from '@/components/goods/view/tab/ItemGoodsTab'

export default {
  props: ['product'],
  components: {
    ItemGoodsTab
  }
}
</script>

<style>
</style>
