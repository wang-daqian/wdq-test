<template>
  <div id="item_qna" v-if="inquiries">
    <item-goods-tab :index="3" />
    <div class="qna_cont">
      <h3>상품문의</h3>
      <div id="ajax-goods-goodsqa-list">
        <div class="qna_table">
          <table :class="['qna_table_type', {'no_result' : !inquiries || inquiries.length === 0}]">
            <colgroup>
              <col width="5%">
              <col width="10%">
              <col>
              <col width="13%">
              <col width="18%">
              <col width="10%">
            </colgroup>
            <thead>
              <tr>
                <th>번호</th>
                <th>말머리</th>
                <th>제목</th>
                <th>작성자</th>
                <th>작성일</th>
                <th>진행상황</th>
              </tr>
            </thead>
            <tbody>
              <template v-if="inquiries && inquiries.length > 0">
                <template v-for="(inquiryItem,indx) in inquiries">
                  <tr @click.prevent="openContent(inquiryItem.inquiryNo)" :key="inquiryItem.inquiryNo">
                    <td>{{inquiriesTotalCount - indx}}</td>
                    <td>{{inquiryType(inquiryItem.type)}}</td>
                    <td class="board_tit">
                      <a href="javascript:void(0)">
                        <img v-if="inquiryItem.secreted" src="../../../../assets/img/icon/icon_board_secret.png">
                        <strong v-if="!inquiryItem.administrator && !inquiryItem.myInquiry && inquiryItem.secreted">비공개 문의 입니다</strong>
                        <strong v-else>{{inquiryItem.content | subContent}}</strong>
                      </a>
                    </td>
                    <td>{{inquiryItem.memberId | maskId}}</td>
                    <td>{{inquiryItem.registerYmdt | getStrYMDHM('.')}}</td>
                    <td>
                      <template v-if="inquiryItem.answers">답변완료</template>
                      <template v-else>답변대기</template>
                    </td>
                  </tr>
                  <tr :key="'1'+inquiryItem.inquiryNo+'_'+indx" class="js_detail" data-bdid="goodsqa" data-sno="5" data-auth="y" style="display: table-row;" v-if="(currentInquiriesNo === inquiryItem.inquiryNo) && !(!inquiryItem.administrator && !inquiryItem.myInquiry && inquiryItem.secreted)">
                    <td colspan="6" class="qna_new_box open_detail" style="text-align: center;">
                      <table class="qa_table">
                        <colgroup>
                          <col width="5%">
                          <col width="10%">
                          <col>
                          <col width="13%">
                          <col width="18%">
                          <col width="10%">
                        </colgroup>
                        <tbody>
                          <tr>
                            <td></td>
                            <td></td>
                            <td class="board_tit">
                              <span class="icon_qna"><img src="../../../../assets/img/icon/board/icon_qna_q.png" alt="질문제목"></span>
                              <br>
                              <div class="content_pre">{{inquiryItem.content}}</div>
                              <div class="btn_view_qna_box" v-if="(inquiryItem.administrator || inquiryItem.myInquiry) && !inquiryItem.answers">
                                <span class="btn_gray_list">
                                  <button type="button" class="btn_gray_mid" @click="editInquiry(inquiryItem)">
                                    <span>수정</span>
                                  </button>
                                </span>
                                <span class="btn_gray_list">
                                  <button type="button" class="btn_gray_mid" @click="deleteInquiries(inquiryItem.inquiryNo)">
                                    <span>삭제</span>
                                  </button>
                                </span>
                              </div>
                            </td>
                            <td></td>
                            <td></td>
                            <td></td>
                          </tr>
                          <tr v-for="answer in inquiryItem.answers" :key="answer.inquiryNo">
                            <td></td>
                            <td></td>
                            <td class="board_tit">
                              <span class="icon_qna">
                                <img src="../../../../assets/img/icon/board/icon_qna_a.png" alt="답변">
                              </span>
                              <br>
                              <div class="content_pre">{{answer.content}}</div>
                            </td>
                            <td>퍼스트어패럴</td>
                            <td>{{answer.registerYmdt | getStrYMDHM('.')}}</td>
                            <td></td>
                          </tr>
                        </tbody>
                      </table>
                    </td>
                  </tr>
                </template>
              </template>
              <template v-else>
                <tr>
                  <td rowspan="5" align="center">작성된 상품문의가 없습니다.</td>
                </tr>
              </template>
            </tbody>
          </table>
        </div>
        <div class="pagination" v-if="inquiries && inquiries.length < inquiriesTotalCount">
          <p class="pagination-btn">
            <button type="button" class="btn_more" @click.prevent="fetchMore">더보기</button>
          </p>
        </div>
      </div>
      <div class="btn_qna_box">
        <router-link to="/mypage/product/inquiries" class="btn_reviews_more">내 상품문의 보기</router-link>
        <a href="#" @click.prevent="openQnaRequestlayer" class="btn_qna_write">상품문의 글쓰기</a>
      </div>
      <!-- //btn_qna_box -->
    </div>
    <!-- //qna_cont -->
    <item-qna-request-layer v-if="qnaRequestLayer && productInquiryTypes" :product="product" :productInquiryTypes="productInquiryTypes" @closeQnaRequestPop="openQnaRequestlayer" :inquiry="inquiry" />
  </div>
</template>

<script>
import ItemGoodsTab from '@/components/goods/view/tab/ItemGoodsTab'
import ItemQnaRequestLayer from '@/components/goods/view/tab/itemQna/ItemQnaRequestLayer'
import { mapActions, mapGetters } from 'vuex'
import { loginAndBack } from '@/utils/utils'

export default {
  props: ['product', 'inquiries', 'inquiriesTotalCount'],
  data () {
    return {
      currentInquiriesNo: 0,
      qnaRequestLayer: false,
      inquiry: null
    }
  },
  components: {
    ItemGoodsTab,
    ItemQnaRequestLayer
  },
  computed: {
    ...mapGetters('common', ['productInquiryTypes'])
  },
  methods: {
    ...mapActions('product', ['fetchProductInquiriesMore', 'deleteProductInquiries']),
    deleteInquiries (inquiryNo) {
      if (confirm('정말 삭제하시겠습니까?')) {
        this.deleteProductInquiries(inquiryNo)
      }
    },
    fetchMore () {
      this.fetchProductInquiriesMore()
    },
    openContent (inquiryNo) {
      if (this.currentInquiriesNo === inquiryNo) {
        this.currentInquiriesNo = 0
      } else {
        this.currentInquiriesNo = inquiryNo
      }
    },
    editInquiry (item) {
      this.inquiry = item
      this.qnaRequestLayer = !this.qnaRequestLayer
      if (this.qnaRequestLayer) {
        this.$store.commit('SHOW_LAYER_BG')
      }
    },
    openQnaRequestlayer () {
      if (!loginAndBack(this.$router, this.$route)) {
        return
      }

      this.qnaRequestLayer = !this.qnaRequestLayer
      if (this.qnaRequestLayer) {
        this.$store.commit('SHOW_LAYER_BG')
      } else {
        this.inquiry = null
        this.$store.commit('HIDDEN_LAYER_BG')
      }
    },
    inquiryType (inquiryTypeValue) {
      return this.productInquiryTypes.find((item) => inquiryTypeValue === item.value).label
    }
  }
}
</script>

<style>
</style>
