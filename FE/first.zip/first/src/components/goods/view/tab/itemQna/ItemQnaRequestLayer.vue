<template>
  <div id="lygoodsQa" class="layer_wrap goods_board_layer">
    <div class="layer_wrap_cont">
      <div class="board_write_popup">
        <div class="ly_tit">
          <h4>상품문의 쓰기</h4>
        </div>
        <div class="ly_cont">
          <div>
            <div class="top_item_photo_info">
              <div class="item_photo_box">
                <img :src="product.baseInfo.imageUrls[0]" :alt="product.baseInfo.productName" :title="product.baseInfo.productName" class="middle">
              </div>
              <!-- //item_photo_view -->
              <div class="item_info_box">
                <h5>{{product.baseInfo.productName}} {{product.baseInfo.productManagementCd | dispManageCode}}</h5>
              </div>
            </div>
            <!-- //top_item_photo_info -->
            <div class="board_write_box">
              <table class="board_write_table">
                <colgroup>
                  <col style="width:15%">
                  <col style="width:85%">
                </colgroup>
                <tbody>
                  <tr>
                    <th scope="row">문의유형</th>
                    <td>
                      <div class="category_select">
                        <div :class="['chosen-container', 'chosen-container-single', 'chosen-container-single-nosearch', {'chosen-with-drop':openDrop }] " style="width: 127px;" title="" id="category_chosen">
                          <a class="chosen-single" @click.prevent="openDrop = !openDrop">
                            <span>{{inquiryTypeLabel}}</span>
                            <div>
                              <b></b>
                            </div>
                          </a>
                          <div class="chosen-drop">
                            <div class="chosen-search"><input type="text" autocomplete="off" readonly=""></div>
                            <ul class="chosen-results">
                              <li @click="changeType(type)" v-for="type in productInquiryTypes" :key="type.value" :class="['active-result',{'result-selected highlighted': inquiryTypeValue === type.value}]">{{type.label}}</li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">내용</th>
                    <td class="wirte_editor">
                      <div class="form_element">
                        <label for="secret" :class="['check_s', {'on':secreted}]" @click="secreted=!secreted">비밀글</label>
                      </div>
                      <textarea id="editor" name="contents" cols="" rows="5" style="width: 100%; display: block;" v-model="content"></textarea>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          <!-- //scroll_box -->
          <div class="btn_center_box">
            <a href="#" @click.prevent="closePop">
              <button class="btn_ly_cancel">
                <strong>취소</strong>
              </button>
            </a>
            <button class="btn_ly_write_ok" v-post-click="{fn:postProductInquiry,actionid:'_postProductInquiry'}">
              <strong>등록</strong>
            </button>
          </div>
        </div>
        <!-- //ly_cont -->
      </div>
      <!-- //ly_cont -->
      <a href="#close" class="ly_close layer_close" @click.prevent="closePop">
        <img src="../../../../../assets/img/common/layer/btn_layer_close.png" alt="닫기">
      </a>
    </div>
  </div>
</template>

<script>
export default {
  props: ['product', 'productInquiryTypes', 'inquiry'],
  data () {
    return {
      inquiryTypeValue: this.productInquiryTypes[0].value,
      inquiryTypeLabel: this.productInquiryTypes[0].label,
      openDrop: false,
      title: '',
      secreted: false,
      content: '',
      inquiryNo: 0
    }
  },
  methods: {
    postProductInquiry () {
      if (this.content.trim() === '') {
        alert('내용을 입력해 주세요.')
        return false
      }
      if (this.inquiry) {
        this.$store.dispatch('product/putProductInquiry', {
          productNo: this.product.baseInfo.productNo,
          inquiryNo: this.inquiry.inquiryNo,
          title: this.title,
          content: this.content,
          secreted: this.secreted,
          type: this.inquiryTypeValue
        }).then(() => {
          this.closePop()
        })
      } else {
        this.$store.dispatch('product/postProductInquiry', {
          productNo: this.product.baseInfo.productNo,
          title: this.title,
          content: this.content,
          secreted: this.secreted,
          type: this.inquiryTypeValue
        }).then(() => {
          this.closePop()
        })
      }
      return true
    },
    changeType (type) {
      this.inquiryTypeValue = type.value
      this.inquiryTypeLabel = type.label
      this.openDrop = false
    },
    closePop () {
      this.$emit('closeQnaRequestPop')
    }
  },
  created () {
    if (this.inquiry) {
      this.title = this.inquiry.title
      this.secreted = this.inquiry.secreted
      this.content = this.inquiry.content
      this.inquiryNo = this.inquiry.inquiryNo
      this.inquiryTypeValue = this.inquiry.type
      this.inquiryTypeLabel = this.productInquiryTypes.find((item) => this.inquiryTypeValue === item.value).label
    } else {
      this.title = ''
      this.secreted = false
      this.content = ''
      this.inquiryNo = 0
      this.inquiryTypeValue = this.productInquiryTypes[0].value
      this.inquiryTypeLabel = this.productInquiryTypes[0].label
    }
  },
  watch: {
    title (newval, old) {
      if (newval.length > 200) {
        this.title = old
      }
    },
    content (newval, old) {
      if (newval.length > 1000) {
        this.content = old
      }
    }
  }
}
</script>

<style>
</style>
