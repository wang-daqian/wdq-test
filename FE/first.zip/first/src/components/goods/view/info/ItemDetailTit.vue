<template>
  <div class="item_detail_tit">
    <h3>{{product.baseInfo.productName}} {{product.baseInfo.productManagementCd | dispManageCode}} </h3>
    <div class="btn_layer btn_qa_share_box">
      <span class="btn_gray_list target_sns_share">
        <a href="javascript:" class="btn_gray_mid" @click.prevent="shareFlg = true">
          <em>공유</em>
        </a>
      </span>
      <div id="lySns" class="layer_area" v-if="shareFlg" v-click-outside="closeLayer">
        <div class="ly_wrap sns_layer">
          <div class="ly_tit">
            <strong>SNS 공유하기</strong>
          </div>
          <div class="ly_cont">
            <div class="sns_list">
              <ul>
                <li>
                  <a href="#" @click.prevent="shareSNS('FB')" data-width="750" data-height="300" data-sns="facebook" class="btn-social-popup">
                    <img src="../../../../assets/img/btn/sns-facebook.png">
                    <br>
                    <span>페이스북</span>
                  </a>
                </li>
                <li>
                  <a href="#" @click.prevent="shareSNS('TW')" data-width="500" data-height="250" data-sns="twitter" class="btn-social-popup">
                    <img src="../../../../assets/img/btn/sns-twitter.png">
                    <br>
                    <span>트위터</span>
                  </a>
                </li>
                <li>
                  <a href="#" @click.prevent="shareSNS('PT')" data-width="750" data-height="570" data-sns="pinterest" class="btn-social-popup">
                    <img src="../../../../assets/img/btn/sns-pinterest.png">
                    <br>
                    <span>핀터레스트</span>
                  </a>
                </li>

                <li>
                  <a href="#" @click.prevent="shareSNS('KS')" id="shareKakaoStoryBtn" data-sns="kakaostory">
                    <img src="../../../../assets/img/btn/sns-kakaostory.png">
                    <br>
                    <span>카카오스토리</span>
                  </a>
                </li>

              </ul>
              <div class="sns_copy_url">
                <input type="text" :value="copyurl" id="thisUrl">
                <button type="button" class="gd_clipboard" title="상품주소" @click="copy">
                  <em>URL복사</em>
                </button>
              </div>
            </div>
          </div>
          <!-- //ly_cont -->
          <a href="javascript:" class="ly_close" @click.prevent="shareFlg = false">
            <img src="../../../../assets/img/common/layer/btn_layer_close.png" alt="닫기">
          </a>
        </div>
        <!-- //ly_wrap -->
      </div>
    </div>
  </div>
</template>

<script>
import ClickOutside from 'vue-click-outside'
import $ from 'jquery'
import { shareAndLoadScript } from '@/utils/utils'
export default {
  props: ['product', 'options'],
  data () {
    return {
      shareFlg: false,
      copyurl: `${location.protocol}//${location.host}${this.$route.fullPath}`
    }
  },
  computed: {
    fbLink () {
      return `https://www.facebook.com/sharer/sharer.php?display=popup&redirect_uri=http%3A%2F%2Fwww.facebook.com&u=${encodeURIComponent(this.copyurl)}`
    },
    twLink () {
      return `https://twitter.com/intent/tweet?text=${encodeURIComponent(this.product.baseInfo.productName)}&url=${encodeURIComponent(this.copyurl)}`
    },
    ptLink () {
      return `https://www.pinterest.com/pin/create/button/?url=${encodeURIComponent(this.copyurl)}&description=${encodeURIComponent(this.product.baseInfo.productName)}&media=${encodeURIComponent(this.product.baseInfo.imageUrls[0])}`
    }
  },
  directives: {
    ClickOutside
  },
  methods: {
    shareSNS (type) {
      let link = ''
      if (type === 'FB') {
        link = this.fbLink
      } else if (type === 'TW') {
        link = this.twLink
      } else if (type === 'PT') {
        link = this.ptLink
      } else {
        link = ''
      }
      shareAndLoadScript({
        shareType: type,
        targetLink: link,
        msg: this.productName,
        link: this.thisUrl,
        linkText: '',
        imageLink: '',
        imgW: '',
        imgH: ''
      })
    },
    copy () {
      setTimeout(() => {
        const url = $('#thisUrl')
        url.select()
        document.execCommand('Copy')
      }, 20)
    },
    closeLayer () {
      this.shareFlg = false
    }
  }
}
</script>

<style>
</style>
