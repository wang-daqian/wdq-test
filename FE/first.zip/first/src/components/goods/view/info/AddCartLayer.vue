<template>
  <div id="addCartLayer" class="layer_wrap" v-if="openLayer">
    <div id="ly_add_cart" class="box add_cart_layer" :style="ly_style">
      <div class="view">
        <h2>장바구니 담기</h2>
        <div class="scroll_box">
          <p class="success">
            <strong>상품이 장바구니에 담겼습니다.</strong>
            <br>바로 확인하시겠습니까?</p>
        </div>
        <div class="btn_box">
          <button class="btn_cancel" @click.prevent="closeLayer">
            <span>취소</span>
          </button>
          <button class="btn_confirm btn_move_cart" @click.prevent="toCart">
            <span>확인</span>
          </button>
        </div>
        <button title="닫기" class="close layer_close" type="button" @click.prevent="closeLayer">
          닫기
        </button>
      </div>
    </div>
  </div>
</template>

<script>
/* global fbq */
import $ from 'jquery'

export default {
  props: ['openLayer'],
  data () {
    return {
      ly_style: ''
    }
  },
  methods: {
    closeLayer () {
      this.$emit('close')
    },
    showInit () {
      this.$nextTick(() => {
        const top = ($(window).height() - $('#ly_add_cart').outerHeight()) / 2
        const left = ($(window).width() - $('#ly_add_cart').outerWidth()) / 2
        this.ly_style = `position: absolute; margin: 0px; top: ${top > 0 ? top : 0}px; left: ${left > 0 ? left : 0}px;`
      })
    },
    toCart () {
      fbq('track', 'AddToCart')
      this.$router.push('/order/cart')
      this.$emit('close')
    }
  },
  watch: {
    'openLayer': 'showInit'
  }
}
</script>

<style>
</style>
