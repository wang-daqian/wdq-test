<template>
  <tbody>
    <tr class="check">
      <td class="cart_prdt_name">
        <div class="cart_tit_box">
          <strong class="cart_tit">
            <span>
              {{option.name}}
            </span>
          </strong>
        </div>
      </td>
      <td>
        <span class="count">
          <span class="goods_qty">
            <input type="text" class="text" title="수량" v-model="displayCnt" @change.prevent="cntSet" @keydown="cntSet" @input="cntSet" @blur="cntSet">
            <span>
              <button type="button" class="up goods_cnt" title="증가" @click.prevent="btnCntSet('plus')">증가</button>
              <button type="button" class="down goods_cnt" title="감소" @click.prevent="btnCntSet('minus')">감소</button>
            </span>
          </span>
        </span>
      </td>
      <td class="item_choice_price">
        <strong>{{ option.price * option.cnt | formatNumber }}</strong>원
      </td>
      <td>
        <button class="delete_goods" v-if="option.haveDel" @click.prevent="delOption">
          <img src="../../../../assets/img/icon/shop_cart/ico_cart_del.png" alt="삭제">
        </button>
      </td>
    </tr>
  </tbody>
</template>

<script>
import { replacePattern } from '@/utils/validateUtils'

export default {
  props: ['option'],
  data () {
    return {
      displayCnt: this.option.cnt
    }
  },
  methods: {
    cntSet () {
      let tempCnt = 0
      if (this.displayCnt) {
        tempCnt = replacePattern(this.displayCnt, /[^\d]/g, '')
        if (parseInt(tempCnt) > 9999) {
          tempCnt = 9999
        } else if (parseInt(tempCnt) <= 0 || isNaN(parseInt(tempCnt))) {
          tempCnt = 1
        } else {
          tempCnt = parseInt(tempCnt)
        }
      } else {
        tempCnt = 1
      }
      this.displayCnt = this.$options.filters.formatNumber(tempCnt)
      this.option.cnt = tempCnt
    },
    btnCntSet (type) {
      if (type === 'plus') {
        this.option.cnt = parseInt(this.option.cnt) + 1
      } else if (type === 'minus') {
        this.option.cnt -= 1
      }
      if (this.option.cnt < 1) {
        this.option.cnt = 1
      } else if (this.option.cnt > 9999) {
        this.option.cnt = 9999
      }
      this.displayCnt = this.$options.filters.formatNumber(this.option.cnt)
    },
    delOption () {
      this.$emit('delOption', this.option.optionNo)
    }
  }
}
</script>

<style>
</style>
