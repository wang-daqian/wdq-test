<template>
  <div class="item_detail_list">
    <dl class="item_price" v-if="product.status.saleStatusType !== 'ONSALE' || !product.status.display || product.stock.stockCnt === 0">
      <dt>소비자가</dt>
      <dd>
        <strong class="warning" v-if="product.status.saleStatusType !== 'ONSALE' || !product.status.display">구매불가</strong>
        <strong class="warning" v-else>품절</strong>
      </dd>
    </dl>
    <template v-else>
      <dl v-if="(product.price.immediateDiscountAmt + product.price.additionDiscountAmt > 0) || hasDownloadableCoupon">
        <dt>소비자가</dt>
        <dd>
          <del>
            <span>{{ product.price.salePrice | formatNumber }}</span>원 </del>
        </dd>
      </dl>
      <dl v-else>
        <dt>소비자가</dt>
        <dd>
          <span>{{ product.price.salePrice | formatNumber }}</span>원
          <span class="no_ref" v-if="!product.limitations.refundable">환불불가</span>
        </dd>
      </dl>
      <dl v-if="(product.price.immediateDiscountAmt + product.price.additionDiscountAmt > 0 ) && !hasDownloadableCoupon " class="item_price">
        <dt>할인판매가</dt>
        <dd>
          <strong class="saleMoney">{{ product.price.salePrice - product.price.immediateDiscountAmt - product.price.additionDiscountAmt | formatNumber }}원</strong>
          <span class="no_ref " v-if="!product.limitations.refundable ">환불불가</span>
          <i v-if="priceCalculate.discountRate >= 1" class="saleNumber">{{ priceCalculate.discountRate }}%</i>
        </dd>
      </dl>
      <dl v-else-if="(product.price.immediateDiscountAmt + product.price.additionDiscountAmt > 0)  && hasDownloadableCoupon " class="item_price">
        <dt>할인판매가</dt>
        <dd>
          <span>
            {{ product.price.salePrice - product.price.immediateDiscountAmt - product.price.additionDiscountAmt | formatNumber }}
          </span>
          원
          <span class="no_ref" v-if="!product.limitations.refundable">환불불가</span>
        </dd>
      </dl>
    </template>
    <dl class="item_discount_mileage " v-if="showDiscountFlg ">
      <dt>구매혜택</dt>
      <dd>
        <!-- <span @click.prevent="discountLayer=! discountLayer " class="item_discount " v-if="(product.price.immediateDiscountAmt + product.price.additionDiscountAmt> 0)">할인 :
          <strong class="total_benefit_price">{{ product.price.immediateDiscountAmt + product.price.additionDiscountAmt | formatNumber }}원</strong>
        </span> -->
        <template v-if="product.price.immediateDiscountAmt > 0">
          <span class="item_discount">즉시할인 :
            <strong class="total_benefit_price"> {{product.price.immediateDiscountAmt | formatNumber}}원</strong>
          </span>
        </template>
        <template v-if="product.price.additionDiscountAmt > 0">
          <span class="item_discount">추가할인 :
            <strong v-if="product.price.additionDiscountUnitType === 'WON'" class="total_benefit_price"> {{product.price.additionDiscountAmt | formatNumber}}원</strong>
            <strong v-else class="total_benefit_price">{{product.price.additionDiscountValue}}%(최대 {{product.price.additionDiscountAmt | formatNumber}}원 할인)</strong>
          </span>
        </template>
        <template v-if="isUseMallAccumulation && product.price.accumulationAmtWhenBuyConfirm > 0">
          <span class="item_mileage">
            <template v-if="!logined">적립금 혜택을 받으시려면 로그인해주세요.</template>
            <template v-else>
              예상적립 :
              <strong class="total_benefit_mileage">{{showAccumulationText}}</strong>
            </template>
          </span>
        </template>
      </dd>
    </dl>
    <dl v-if="hasDownloadableCoupon && !(product.status.saleStatusType !== 'ONSALE' || !product.status.display || product.stock.stockCnt === 0)">
      <dt>최대쿠폰적용가</dt>
      <dd>
        <strong class="saleMoney">{{ product.price.salePrice - product.price.immediateDiscountAmt - product.price.additionDiscountAmt - product.price.couponDiscountAmt | formatNumber }}원</strong>
        <span class="no_ref " v-if="!product.limitations.refundable ">환불불가</span>
        <i v-if="priceCalculate.discountRate >= 1" class="saleNumber">{{ priceCalculate.discountRate }}%</i>
        <span class="btn_gray_list">
          <a href="javascript:" id="lnCouponDown" class="btn_gray_small btn_alert_login" @click.prevent="showLayer">
            <em class="icon_download">쿠폰 다운받기</em>
          </a>
        </span>
      </dd>
    </dl>
    <dl class="item_delivery">
      <dt>배송비</dt>
      <dd>
        <template v-if="product.deliveryFee.deliveryConditionType === 'FREE'">
          <strong class="price">무료배송</strong>
        </template>
        <template v-if="product.deliveryFee.deliveryConditionType === 'CONDITIONAL'">
          <strong class="price">
            {{product.deliveryFee.deliveryAmt | formatNumber}}원 ({{ product.deliveryFee.aboveDeliveryAmt | formatNumber}}원 이상 구매 시 무료배송)
            <template v-if="product.deliveryFee.deliveryConditionType !== 'FREE' && product.deliveryFee.deliveryPrePayment === false">
              <em class="tag">착불</em>
            </template>
          </strong>
        </template>
        <template v-if="product.deliveryFee.deliveryConditionType === 'FIXED_FEE'">
          <strong class="price">
            {{ product.deliveryFee.deliveryAmt | formatNumber}}원
            <template v-if="product.deliveryFee.deliveryConditionType !== 'FREE' && product.deliveryFee.deliveryPrePayment === false">
              <em class="tag">착불</em>
            </template>
          </strong>
        </template>
        <template v-if="product.deliveryFee.remoteDeliveryAreaFees.length !== 0">
          <strong>도서산간지역 추가 배송비 발생</strong>
          <ItemSummaryInfoDelivery></ItemSummaryInfoDelivery>
        </template>
      </dd>
    </dl>
    <dl v-if="showLimitFlg ">
      <dt>구매제한</dt>
      <template v-if="buyLimit ">
        <dd v-html="buyLimit "></dd>
      </template>
    </dl>
    <ly-coupon-down @close="closeCouponLayer" :product="product" :openLayer="openLayer" :couponCompare="couponCompare" />
  </div>
</template>

<script>
import { isLogin } from '@/utils/utils'
import ClickOutside from 'vue-click-outside'
import LyCouponDown from '@/components/goods/view/info/LyCouponDown'
import ItemSummaryInfoDelivery from './ItemSummaryInfoDelivery'
import { mapGetters } from 'vuex'
import { productPrice2 } from '@/utils/stringUtils'

export default {
  props: ['product', 'couponCompare'],
  data () {
    return {
      openLayer: false,
      discountLayer: false,
      logined: isLogin()
    }
  },
  components: {
    LyCouponDown,
    ItemSummaryInfoDelivery
  },
  directives: {
    ClickOutside
  },
  computed: {
    ...mapGetters('common', ['showAccumulationName', 'isUseMallAccumulation', 'showAccumulationUnit', 'accumulationDisplayFormatType', 'accumulationRate']),
    buyLimit () {
      let brFlag = false
      let msg = ''

      if (this.product.limitations.minBuyCnt >= 1) {
        msg = `최소 ${this.product.limitations.minBuyCnt}개부터 구매가능`
        brFlag = true
      }
      if (this.product.limitations.maxBuyPersonCnt) {
        if (brFlag) {
          msg += '<br />'
        }
        let str = this.$options.filters.formatNumber(this.product.limitations.maxBuyPersonCnt)
        msg += `1인 구매 시 최대 ${str}개까지 구매가능`
        brFlag = true
      }
      if (this.product.limitations.maxBuyTimeCnt) {
        if (brFlag) {
          msg += '<br />'
        }
        let str = this.$options.filters.formatNumber(this.product.limitations.maxBuyTimeCnt)
        msg += `1회 구매 시 최대 ${str}개까지 구매가능`
        brFlag = true
      }
      if (this.product.limitations.maxBuyDays) {
        if (brFlag) {
          msg += '<br />'
        }
        let str = this.$options.filters.formatNumber(this.product.limitations.maxBuyPeriodCnt)
        msg += `${this.product.limitations.maxBuyDays}일 동안 최대 ${str}개까지 구매가능`
      }
      return msg
    },
    showAccumulationText () {
      let productAccumulationPrice = Math.ceil(this.product.price.accumulationAmtWhenBuyConfirm)
      let productAccumulationRate = this.product.price.accumulationRate
      let mallAccumulationRate = this.accumulationRate
      if (productAccumulationPrice === null && productAccumulationRate === null) {
        return mallAccumulationRate + '%'
      }
      let res = ''
      if (this.accumulationDisplayFormatType === 'FIXED_AMT') {
        res = this.$options.filters.formatNumber(productAccumulationPrice) + this.showAccumulationUnit
      } else if (this.accumulationDisplayFormatType === 'FIXED_RATE') {
        res = productAccumulationRate + '%'
      } else if (this.accumulationDisplayFormatType === 'FIRST_FIXED_RATE') {
        res = productAccumulationRate + '% / ' + this.$options.filters.formatNumber(productAccumulationPrice) + this.showAccumulationUnit
      } else if (this.accumulationDisplayFormatType === 'FIRST_FIXED_AMT') {
        res = this.$options.filters.formatNumber(productAccumulationPrice) + this.showAccumulationUnit + ' / ' + productAccumulationRate + '%'
      }
      return res
    },
    showLimitFlg () {
      return this.product.stock.stockCnt > 0 && this.product.limitations && (this.product.limitations.minBuyCnt || this.product.limitations.maxBuyPersonCnt || this.product.limitations.maxBuyTimeCnt || this.product.limitations.maxBuyDays)
    },
    showDiscountFlg () {
      return this.product.stock.stockCnt > 0 && ((this.product.price.immediateDiscountAmt + this.product.price.additionDiscountAmt > 0) || (this.isUseMallAccumulation && this.product.price.accumulationAmtWhenBuyConfirm > 0))
    },
    priceCalculate () {
      return productPrice2(this.product.price.salePrice,
        this.product.price.additionDiscountAmt,
        this.product.price.immediateDiscountAmt,
        this.product.price.couponDiscountAmt)
    },
    hasDownloadableCoupon () {
      if (this.couponCompare && this.couponCompare.length) {
        return true
      } else {
        return false
      }
    }
  },
  methods: {
    closeDiscountLayer () {
      this.discountLayer = false
    },
    showLayer () {
      if (!isLogin()) {
        this.$router.push({
          path: '/member/login',
          query: {
            redirect: encodeURIComponent(`${location.protocol}//${location.host}${this.$route.fullPath}`)
          }
        })
        return
      }
      this.openLayer = true
      this.$store.commit('SHOW_LAYER_BG')
    },
    closeCouponLayer () {
      this.openLayer = false
      this.$store.commit('HIDDEN_LAYER_BG')
    }
  }
}
</script>

<style>
</style>
