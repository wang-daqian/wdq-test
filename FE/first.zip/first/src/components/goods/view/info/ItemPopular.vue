<template>
  <div class="item_goods_slider">
    <div class="main_goods_cont">
      <!-- 메인 상품 노출 -->
      <div class="goods_list main_wrap_2">
        <div class="goods_list_cont goods_content_2">
          <div class="item_slide_horizontal">
            <h3>실시간 이슈 아이템</h3>
            <ul class="slide_horizontal_4 goods_sp">
              <slick ref="slick" :options="slickOptions">
                <li v-for="(item,idx) in items" :key="item.productNo+''+idx">
                  <div class="item_cont" style="text-align:center;">
                    <div class="item_photo_box">
                      <goods-view-link :product="item">
                        <img :src="item.imageUrls[0]" :alt="item.productName" :title="item.productName" class="middle">
                      </goods-view-link>
                      <!-- //item_photo_box -->
                    </div>
                    <div class="item_info_cont" style="display:block; text-align: center;">
                      <div class="item_tit_box">
                        <goods-view-link :product="item">
                          <strong class="item_name" style="direction:ltr;">{{item.productName}} {{item.productManagementCd | dispManageCode}}</strong>
                        </goods-view-link>
                      </div>
                      <!-- //item_tit_box -->
                      <div class="item_money_box">
                        <del class="il_b" v-if="item.immediateDiscountAmt + item.additionDiscountAmt + item.couponDiscountAmt> 0">{{ item.salePrice | formatNumber }}원</del>
                        <strong class="item_price il_b">
                          <span>{{ item.salePrice - item.immediateDiscountAmt - item.additionDiscountAmt - item.couponDiscountAmt| formatNumber }}원</span>
                        </strong>
                        <i v-if="priceCalculate(item).discountRate >= 1" class="saleNumber02">{{ priceCalculate(item).discountRate }}%</i>
                      </div>
                      <!-- //item_money_box -->
                    </div>
                    <!-- //item_info_cont -->
                  </div>
                  <!-- //item_cont -->
                </li>
              </slick>
            </ul>
          </div>
        </div>
      </div>
      <!-- 메인 상품 노출 -->
    </div>
    <!-- //main_goods_cont -->
  </div>

</template>

<script>
import GoodsViewLink from '@/components/common/GoodsViewLink'
import Slick from 'vue-slick'
import { productPrice2 } from '@/utils/stringUtils'

export default {
  props: ['items'],
  data () {
    return {
      slickOptions: {
        draggable: false,
        autoplay: false,
        infinite: true,
        slidesToShow: 6,
        slidesToScroll: 1,
        responsive: [{
          breakpoint: 1366,
          settings: {
            slidesToShow: 3
          }
        }]
      }
    }
  },
  components: {
    Slick,
    GoodsViewLink
  },
  methods: {
    priceCalculate (item) {
      return productPrice2(item.salePrice,
        item.additionDiscountAmt,
        item.immediateDiscountAmt,
        item.couponDiscountAmt)
    }
  }
}
</script>
