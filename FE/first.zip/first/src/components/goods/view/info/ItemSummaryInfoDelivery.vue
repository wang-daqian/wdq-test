<template>
  <span class="btn_layer" v-click-outside="close">
    <span class="btn_gray">
      <a href="" class="btn_gray_noti" @click.prevent="open">
        <em>조건별배송</em>
      </a>
    </span>
    <div id="lyDelivery" class="layer_area other_info" v-if="deliveryPopup">
      <strong class="tit">추가배송비 지역정보</strong>
      <p class="dsc">본 상품을 주문하실 때 아래 표기 된 지역으로 배송하실 경우
        <br>도서산간 추가배송비가 부과됩니다.</p>
      <div class="bx_table">
        <div class="tbl_head">
          <table>
            <colgroup>
              <col style="width:235px">
              <col>
            </colgroup>
            <thead>
              <tr>
                <th scope="col">지역명</th>
                <th scope="col">추가배송비</th>
              </tr>
            </thead>
          </table>
        </div>
        <div class="tbl_body">
          <table>
            <colgroup>
              <col style="width:215px">
              <col>
            </colgroup>
            <tbody>
              <template v-for="(remoteDeliveryAreaFee, index) in product.deliveryFee.remoteDeliveryAreaFees">
              <tr :key="index">
                <td>{{ remoteDeliveryAreaFee.address }}</td>
                <td>{{ remoteDeliveryAreaFee.extraDeliveryAmt | formatNumber }}원</td>
              </tr>
            </template>
            </tbody>
          </table>
        </div>
      </div>
      <a class="btn_close ly_close" href="" @click.prevent="close">닫기</a>
    </div>
  </span>
</template>

<script>
import { mapState } from 'vuex'
import ClickOutside from 'vue-click-outside'

export default {
  data () {
    return {
      deliveryPopup: false
    }
  },
  computed: {
    ...mapState('product', ['product'])
  },
  directives: {
    ClickOutside
  },
  methods: {
    open () {
      this.deliveryPopup = !this.deliveryPopup
    },
    close () {
      this.deliveryPopup = false
    }
  }
}
</script>
