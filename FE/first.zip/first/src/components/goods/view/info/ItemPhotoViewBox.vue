<template>
  <div class="item_photo_view_box">
    <div class="item_photo_view">
      <div class="item_photo_big">
        <span class="img_photo_big">
          <a href="javascript:" id="mainImage" class="zoom_layer_open btn_open_layer" @click.prevent="showLayer">
            <img id="_TRK_PN_ID" :src="mainImage" width="500" :alt="product.baseInfo.productName" :title="product.baseInfo.productName" class="middle">
          </a>
        </span>
        <a href="javascript:" class="btn_zoom zoom_layer_open btn_open_layer" @click.prevent="showLayer">
          <img src="../../../../assets/img/icon/goods_icon/icon_zoom.png" alt="">
        </a>
      </div>
      <div id="view_photo_slide" class="item_photo_slide">
        <ul class="slider_wrap slider_goods_nav">
          <slick id="view_photo_slick" ref="slick" :options="slickOptions">
            <li v-for="(item, index) in product.baseInfo.imageUrls" :key="index">
              <a href="javascript:" @click.prevent="gdChangeImage(index)">
                <img :src="item" width="68" class="middle">
              </a>
            </li>
          </slick>
        </ul>
      </div>
    </div>
    <item-photo-layer @close="closeLayer" :product="product" :openLayer="openLayer" />
  </div>
</template>

<script>
import $ from 'jquery'
import Slick from 'vue-slick'
import ItemPhotoLayer from '@/components/goods/view/info/ItemPhotoLayer'

export default {
  props: ['displayMode', 'product'],
  data () {
    return {
      mainImageIndex: 0,
      openLayer: false,
      slickOptions: {
        draggable: false,
        autoplay: false,
        infinite: false,
        slidesToShow: 5,
        slidesToScroll: 1,
        responsive: [{
          breakpoint: 1366,
          settings: {
            slidesToShow: 5
          }
        },
        {
          breakpoint: 768,
          settings: {
            slidesToShow: 3
          }
        }]
      }
    }
  },
  computed: {
    mainImage () {
      return this.product.baseInfo.imageUrls[this.mainImageIndex]
    }
  },
  components: {
    Slick,
    ItemPhotoLayer
  },
  methods: {
    gdChangeImage (index) {
      this.mainImageIndex = index
    },
    showLayer () {
      if (this.displayMode === 'PC') {
        this.openLayer = true
        this.$store.commit('SHOW_LAYER_BG')
      }
    },
    closeLayer () {
      this.openLayer = false
      this.$store.commit('HIDDEN_LAYER_BG')
    },
    slickPrev () {
      this.mainImageIndex--
      this.mainImageIndex = this.mainImageIndex < 0 ? 0 : this.mainImageIndex
    },
    slickNext () {
      this.mainImageIndex++
      this.mainImageIndex = this.mainImageIndex >= this.product.baseInfo.imageUrls.length ? this.product.baseInfo.imageUrls.length - 1 : this.mainImageIndex
    }
  },
  mounted () {
    $('#view_photo_slide .slick-prev').on('click', this.slickPrev)
    $('#view_photo_slide .slick-next').on('click', this.slickNext)
  }
}
</script>

<style scope>
#view_photo_slide .slider_goods_nav {
  padding: 0;
}

#view_photo_slick {
  padding: 0 20px;
}
</style>
