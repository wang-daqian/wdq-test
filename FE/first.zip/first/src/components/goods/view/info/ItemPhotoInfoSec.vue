<template>
  <div class="item_photo_info_sec" v-if="product">
    <item-photo-view-box :displayMode="displayMode" :product="product" />
    <div class="item_info_box">
      <!-- //time_sale -->
      <div class="item_tit_detail_cont">
        <item-detail-tit :product="product" :options="options" />
        <item-detail-list :product="product" :couponCompare="couponCompare" />
        <item-choice-list :product="product" :options="options" v-if="product && options" />
      </div>
    </div>
  </div>
</template>

<script>
import ItemPhotoViewBox from '@/components/goods/view/info/ItemPhotoViewBox'
import ItemDetailTit from '@/components/goods/view/info/ItemDetailTit'
import ItemDetailList from '@/components/goods/view/info/ItemDetailList'
import ItemChoiceList from '@/components/goods/view/info/ItemChoiceList'

export default {
  props: ['displayMode', 'product', 'options', 'couponCompare'],
  components: {
    ItemPhotoViewBox,
    ItemDetailTit,
    ItemDetailList,
    ItemChoiceList
  }
}
</script>

<style>
</style>
