<template>
  <div class="option_total_display_area item_choice_list" v-if="options">
    <div class="item_add_option_box item_detail_list" v-if="options.flatOptions.length > 1 && showProductFlg">
      <dl>
        <dt>선택</dt>
        <dd>
          <div class="bx_select" v-click-outside="closeOption">
            <a href="javascript:" :class="['txt_select', {'on' : showOptions}]" @click.prevent="showOptions = true">
              옵션을 선택하세요
              <span class="sp ico_arrow">목록 열기</span>
            </a>
            <div :class="['popup_select_option', {'on' : showOptions}]">
              <div class="bx_tit">
                <strong class="tit">옵션을 선택하세요.</strong>
              </div>

              <template v-if="options.type === 'COMBINATION'">
                <ul class="lst_select_option">

                  <template v-for="(label, index) in options.labels">
                    <li :class="{'on' : optionStep == index}" :key="index">
                      <a href="javascript:" @click.prevent="selectLabel(index)">
                        <span class="name">{{label}}</span>

                        <template v-if="selectedOptionDepth[index]">
                          <span class="value">{{selectedOptionDepth[index].value}}</span>
                        </template>

                        <span class="ico_arrow">목록 열기</span>
                      </a>

                      <ul class="lst_sub_option">

                        <template v-if="optionItems[index]" v-for="(optionTemp, idx) in optionItems[index]">
                          <li :class="{'disabled' : optionTemp.stockCnt === 0}" :key="idx">
                            <a href="javascript:" @click.prevent="selectValue(index, idx)">
                              {{optionTemp.value}}
                              <template v-if="optionTemp.addPrice">
                                ({{optionTemp.addPrice > 0 ? '+' : ''}}{{ optionTemp.addPrice | formatNumber }}원)
                              </template>
                              <!-- <template v-if="optionTemp.stockCnt > 0">
                                <span class="status">재고: {{ optionTemp.stockCnt }}개</span>
                              </template> -->
                              <template v-if="optionTemp.stockCnt === 0">
                                <span class="status">품절</span>
                              </template>
                            </a>
                          </li>
                        </template>

                      </ul>
                    </li>
                  </template>

                </ul>
              </template>

              <template v-if="options.type === 'STANDARD'">
                <ul class="lst_select_option">
                  <li v-for="(item, index) in options.flatOptions" :key="index" class="on">
                    <ul class="lst_sub_option">
                      <li>
                        <a href="javascript:" @click.prevent="selectEndValue(item.optionNo)">
                          {{item.label}} : {{item.value}}
                          <template v-if="item.addPrice">
                            ({{item.addPrice > 0 ? '+' : ''}}{{ item.addPrice | formatNumber }}원)
                          </template>
                          <template v-if="item.stockCnt === 0">
                            <span class="status">품절</span>
                          </template>
                        </a>
                      </li>
                    </ul>
                  </li>
                </ul>
              </template>
              <button type="button" class="btn_close" @click.prevent="closeOption">
                <span class="sp">닫기</span>
              </button>
            </div>
          </div>
        </dd>
      </dl>
    </div>
    <table class="option_display_area" border="0" cellpadding="0" cellspacing="0">
      <colgroup>
        <col width="200px">
        <col width="80px">
        <col width="80px">
        <col width="40px">
      </colgroup>

      <option-item v-for="option in selectedOptions" :key="option.optionNo" :option="option" v-if="selectedOptions.length && showProductFlg" @delOption="delOption" />
    </table>
    <div class="item_price_cont" v-if="selectedOptions.length && showProductFlg">
      <div class="end_price item_tatal_box">
        <dl class="total_amount">
          <dt>총 합계금액</dt>
          <dd>
            <strong class="total_price"> {{ totalPrice | formatNumber }}
              <b>원</b>
            </strong>
          </dd>
        </dl>
      </div>
    </div>
    <div class="btn_choice_box" v-if="showProductFlg">
      <button class="btn_add_wish" @click.prevent="addToWish">
        <img src="../../../../assets/img/icon/heart_on.png" alt="" v-if="product.liked">
        <img src="../../../../assets/img/icon/heart.png" alt="" v-else>
      </button>
      <template v-if="isPC">
        <button class="btn_add_cart" @click.prevent="addToCart" @mousedown="trkTrace" v-if="product.limitations.canAddToCart">장바구니</button>
        <button class="btn_add_order" @click.prevent="buy" @mousedown="trkTrace">바로 구매</button>
      </template>
      <template v-else>
        <button class="btn_add_cart" @click.prevent="addToCart" @touchstart="trkTrace" v-if="product.limitations.canAddToCart">장바구니</button>
        <button class="btn_add_order" @click.prevent="buy" @touchstart="trkTrace">바로 구매</button>
      </template>
    </div>
    <add-cart-layer @close="closeCart" :openLayer="openCartLayer" />
    <add-wish-layer @close="closeWish" :openLayer="openWishLayer" />
  </div>
</template>

<script>
import { isLogin, isPC } from '@/utils/utils'
import { setOrderInfoInStorage } from '@/utils/orderUtils'
import ClickOutside from 'vue-click-outside'
import OptionItem from '@/components/goods/view/info/OptionItem'
import AddCartLayer from '@/components/goods/view/info/AddCartLayer'
import AddWishLayer from '@/components/goods/view/info/AddWishLayer'
import { mapMutations, mapState } from 'vuex'
import { gaEventAddtoCart } from '@/utils/gaEventUtils'

export default {
  props: ['product', 'options'],
  components: {
    OptionItem,
    AddCartLayer,
    AddWishLayer
  },
  directives: {
    ClickOutside
  },
  data () {
    return {
      showOptions: false,
      optionStep: 0,
      selectedOptions: [],
      optionItems: [],
      selectedOptionDepth: [],
      openCartLayer: false,
      openWishLayer: false,
      openLayer: false
    }
  },
  methods: {
    ...mapMutations('ordersheet', ['RESET_OUTDATED_DATA']),

    closeOption () {
      this.showOptions = false
      this.optionStep = 0
      this.selectedOptionDepth = []
    },
    selectLabel (index) {
      if (this.optionStep > index) {
        this.selectedOptionDepth = this.selectedOptionDepth.filter((item, idx) => idx < index)
        this.optionStep = index
      }
    },
    selectValue (index, idx) {
      let tempOption = this.optionItems[index].find((item, opi) => opi === idx)
      this.selectedOptionDepth[index] = tempOption
      if (index < this.options.labels.length - 1) {
        this.optionItems[index + 1] = tempOption && tempOption.children
        this.optionStep = index + 1
      } else {
        this.selectEndValue(tempOption.optionNo)
      }
    },
    selectEndValue (optionNo) {
      let haveFlg = false
      this.selectedOptions.forEach(item => {
        if (item.optionNo === optionNo) {
          haveFlg = true
          alert('이미 선택한 옵션입니다.')
        }
      })
      if (!haveFlg) {
        const tempOption = this.options.flatOptions.find(item => item.optionNo === optionNo)
        this.selectedOptions.push({
          optionNo: tempOption.optionNo,
          name: this.$options.filters.optionName(tempOption.label, tempOption.value, tempOption.addPrice),
          cnt: 1,
          // price: this.product.price.salePrice - this.product.price.immediateDiscountAmt - this.product.price.additionDiscountAmt + tempOption.addPrice,
          price: tempOption.buyPrice,
          haveDel: true
        })
      }
      this.closeOption()
    },
    delOption (optionNo) {
      this.selectedOptions = this.selectedOptions.filter(item => item.optionNo !== optionNo)
    },
    clickCheck (type, callback) {
      if (this.selectedOptions.length) {
        if (isLogin() && this.hasUsableCouponsNotDownloaded) {
          let confirmMsg = ''
          if (type === 'addToCart') {
            confirmMsg = '이 상품에 적용 가능한 쿠폰 다운로드 후 \n장바구니에 담겠습니까?'
          } else {
            confirmMsg = '이 상품에 적용 가능한 쿠폰 다운로드 후 \n바로구매 하시겠습니까?'
          }
          if (confirm(confirmMsg)) {
            this.$store.dispatch('coupon/downAllCoupons', { productNo: this.product.baseInfo.productNo }).then(() => {
              callback()
            })
          } else {
            callback()
          }
        } else {
          callback()
        }
      } else {
        alert('상품 옵션을 선택해 주세요.')
      }
    },
    addToCart () {
      this.clickCheck('addToCart', () => {
        let maxCartNo = 0
        const cartItems = JSON.parse(window.localStorage.cartInfo || '[]')
        if (cartItems.length > 0) {
          cartItems.forEach(cartItem => {
            if (cartItem.cartNo > maxCartNo) {
              maxCartNo = cartItem.cartNo
            }
          })
        }

        let totalCnt = 0
        let items = []
        this.selectedOptions.forEach((option, idx) => {
          items.push({
            cartNo: (maxCartNo + idx + 1),
            productNo: this.product.baseInfo.productNo,
            optionNo: option.optionNo,
            orderCnt: option.cnt,
            additionalProductNo: 0
          })
          totalCnt += option.cnt
        })
        this.$store.dispatch('cart/addToCart', items).then(() => {
          this.openCartLayer = true
          this.$store.commit('SHOW_LAYER_BG')
          /** gtag.js */
          gaEventAddtoCart(this.product, totalCnt)
        })
      })
    },
    buy () {
      this.clickCheck('buy', () => {
        this.RESET_OUTDATED_DATA()
        const items = this.selectedOptions.map((option, idx) => {
          return {
            productNo: this.product.baseInfo.productNo,
            optionNo: option.optionNo,
            orderCnt: option.cnt,
            additionalProductNo: 0,
            optionInputs: [],
            channelType: this.$route.query.channelType
          }
        })

        setOrderInfoInStorage(items, this.$route.fullPath)
        this.$store.dispatch('ordersheet/getSheetNo')
      })
    },
    closeCart () {
      this.openCartLayer = false
      this.$store.commit('HIDDEN_LAYER_BG')
    },
    addToWish () {
      if (isLogin()) {
        this.$store.dispatch('wishlist/pageLikeProducts', [this.product.baseInfo.productNo]).then(() => {
          this.product.liked = !this.product.liked
          if (this.product.liked) {
            this.openWishLayer = true
            this.$store.commit('SHOW_LAYER_BG')
          }
        })
      } else {
        this.$router.push('/member/login')
      }
    },
    closeWish () {
      this.openWishLayer = false
      this.$store.commit('HIDDEN_LAYER_BG')
    },
    trkTrace () {
      return "eval('try{ _trk_clickTrace('SCI', _TRK_PN); }catch(_e){ }');"
    }
  },
  computed: {
    ...mapState('coupon', ['coupons']),

    totalPrice () {
      if (this.selectedOptions.length) {
        let price = 0
        this.selectedOptions.forEach(item => {
          price += item.cnt * item.price
        })
        return price
      }
    },
    showProductFlg () {
      return this.product.stock.stockCnt > 0 && this.product.status.saleStatusType === 'ONSALE' && this.product.status.display
    },
    isPC () {
      return isPC()
    },
    hasUsableCouponsNotDownloaded () {
      let notDownloaded = false

      if (this.coupons) {
        this.coupons.forEach(coupon => {
          if (coupon.downloadable && coupon.couponStatus.myIssuedCnt === 0) {
            notDownloaded = true
          }
        })
      }
      return notDownloaded
    }
  },
  mounted () {
    if (this.options) {
      this.optionItems[0] = this.options.multiLevelOptions
    }
    if (this.product && this.options && this.options.flatOptions.length === 1) {
      const tempOption = this.options.flatOptions[0]
      let optionName = this.$options.filters.optionName(tempOption.label, tempOption.value, tempOption.addPrice)
      if (this.options.type === 'DEFAULT') {
        optionName = this.product.baseInfo.productName
      }
      this.selectedOptions.push({
        optionNo: tempOption.optionNo,
        name: optionName,
        cnt: 1,
        price: this.product.price.salePrice - this.product.price.immediateDiscountAmt - this.product.price.additionDiscountAmt + tempOption.addPrice,
        haveDel: false
      })
    }
  }
}
</script>

<style>
</style>
