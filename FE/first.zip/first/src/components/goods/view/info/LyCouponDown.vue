<template>
  <div id="lyCouponDown" class="layer_wrap coupon_down_layer" v-if="openLayer && couponCompare">
    <div id="ly_coupon_wrap" class="layer_wrap_cont" :style="ly_style">
      <div class="ly_tit">
        <h4>
          쿠폰 다운받기
          <span>다운로드 가능한 총
            <strong class="goods-coupon-cnt">{{couponCompare.length}}개</strong>의 쿠폰이 있습니다.</span>
          <strong class="maximum">최대쿠폰할인
            <span class="maximumSum">{{product.price.couponDiscountAmt | formatNumber}}원</span>
          </strong>
        </h4>
      </div>
      <div class="ly_cont">
        <div class="scroll_box">
          <div class="top_table_type">
            <div class="table_shell">
              <table>
                <colgroup>
                  <col style="width:150px">
                  <col style="width:300px">
                  <col>
                </colgroup>
                <thead>
                  <tr>
                    <th>쿠폰</th>
                    <th>혜택</th>
                    <th>다운받기</th>
                  </tr>
                </thead>
                <tbody>
                  <tr v-for="item in couponCompare" :key="item.couponIssueNo">
                    <td>
                      <strong>{{item.couponName}}</strong>
                    </td>
                    <td class="td_left">
                      <strong class="coupon_price">
                        <b v-if="item.discountInfo.discountRate && item.discountInfo.discountRate > 0">{{item.discountInfo.discountRate}} %</b>
                        <b v-else>{{item.discountInfo.discountAmt | formatNumber}} 원</b>
                        상품할인</strong>
                      <span class="text_info">
                        <template v-if="item.discountInfo.discountRate && item.discountInfo.maxDiscountAmt">
                          - 최대 {{item.discountInfo.maxDiscountAmt | formatNumber}}원 할인<br/>
                        </template>
                        <template v-if="item.useConstraint.minSalePrice && item.useConstraint.maxSalePrice">
                          - {{item.useConstraint.minSalePrice | formatNumber}}원 이상 ~ {{item.useConstraint.maxSalePrice | formatNumber}}원 이하 사용가능<br/>
                        </template>
                        <template v-else-if="item.useConstraint.minSalePrice && !item.useConstraint.maxSalePrice">
                          - {{item.useConstraint.minSalePrice | formatNumber}}원 이상 사용가능<br/>
                        </template>
                        <template v-else-if="!item.useConstraint.minSalePrice && item.useConstraint.maxSalePrice">
                          - {{item.useConstraint.maxSalePrice | formatNumber}}원 이하 사용가능<br/>
                        </template>
                      </span>
                    </td>
                    <td>
                      <div class="btn_down_box">
                        <span class="btn_gray_list btn_coupon_down" data-coupon-no="7">
                          <a href="#" @click.prevent="downLoadCoupons(item.couponNo)" class="btn_gray_small">
                            <em class="icon_download">쿠폰 다운받기</em>
                          </a>
                        </span>
                        <em class="text_info">{{item.dateInfo.issueEndYmdt | getStrDate('. ')}}<br />까지 발급 가능</em>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
        <!-- //scroll_box -->
        <div class="btn_center_box">
          <button class="btn_ly_cancel layer_close" @click="closeLayer">
            <strong>취소</strong>
          </button>
          <button class="btn_ly_download" @click="downloadAll">
            <strong>쿠폰 전체 다운받기</strong>
          </button>
        </div>
      </div>
      <!-- //ly_cont -->
      <a href="javascript:" class="ly_close layer_close" @click.prevent="closeLayer">
        <img src="../../../../assets/img/common/layer/btn_layer_close.png" alt="닫기">
      </a>
    </div>
  </div>
</template>

<script>
import $ from 'jquery'

export default {
  props: ['product', 'openLayer', 'couponCompare'],
  data () {
    return {
      ly_style: ''
    }
  },
  methods: {
    closeLayer () {
      this.$emit('close')
    },
    showInit () {
      this.$nextTick(() => {
        const top = ($(window).height() - $('#ly_coupon_wrap').outerHeight()) / 2
        const left = ($(window).width() - $('#ly_coupon_wrap').outerWidth()) / 2
        this.ly_style = `position: absolute; margin: 0px; top: ${top > 0 ? top : 0}px; left: ${left > 0 ? left : 0}px;`
      })
    },
    downLoadCoupons (couponNo) {
      this.$store.dispatch('coupon/downLoadCoupons', { couponNo: couponNo, productNo: this.product.baseInfo.productNo })
    },
    downloadAll () {
      this.$store.dispatch('coupon/downLoadAllCoupons', { productNo: this.product.baseInfo.productNo }).then(() => {
        this.closeLayer()
      })
    }
  },
  watch: {
    'openLayer': 'showInit'
  },
  mounted () {
  }
}
</script>

<style>
</style>
