<template>
  <div>
    <div class="goods_pick_list">
      <div class="pick_list_box">
        <span class="pick_list_num" v-if="type !== 'search'">상품
          <strong>{{totalCount | formatNumber}}</strong> 개
        </span>
        <ul class="pick_list" v-if="getSortType()">
          <template v-if="type === 'search'">
            <!-- <li>
              <label :class="sortType === 0 ? 'on' : ''" @click.prevent="sortTypeClick(0)">MD추천순</label>
            </li> -->
            <li>
              <label :class="sortType === 0 ? 'on' : ''" @click.prevent="sortTypeClick(0)">판매인기순</label>
            </li>
            <li>
              <label :class="sortType === 2 ? 'on' : ''" @click.prevent="sortTypeClick(2)">낮은가격순</label>
            </li>
            <li>
              <label :class="sortType === 3 ? 'on' : ''" @click.prevent="sortTypeClick(3)">높은가격순</label>
            </li>
            <li>
              <label :class="sortType === 4 ? 'on' : ''" @click.prevent="sortTypeClick(4)">상품평순</label>
            </li>
          </template>
          <template v-else>
            <li>
              <label :class="sortType === 0 ? 'on' : ''" @click.prevent="sortTypeClick(0)">최신순</label>
            </li>
            <!-- <li>
              <label :class="sortType === 1 ? 'on' : ''" @click.prevent="sortTypeClick(1)">최신순</label>
            </li> -->
            <li>
              <label :class="sortType === 3 ? 'on' : ''" @click.prevent="sortTypeClick(3)">낮은가격순</label>
            </li>
            <li>
              <label :class="sortType === 4 ? 'on' : ''" @click.prevent="sortTypeClick(4)">높은가격순</label>
            </li>
            <li>
              <label :class="sortType === 5 ? 'on' : ''" @click.prevent="sortTypeClick(5)">상품평순</label>
            </li>
          </template>
        </ul>
        <div class="choice_num_view" v-if="getPageSize()">
          <vue-select-box :showValue="pageSize" :items="sizeItems" @selected="setPageSize" />
        </div>
      </div>
    </div>

    <item-list :list="list" :noPromotion="noPromotion" />

    <div class="pagination" v-if="list && list.length < totalCount">
      <p class="pagination-btn">
        <button type="button" class="btn_more" @click.prevent="fetchMore">더보기</button>
      </p>
    </div>
  </div>
</template>

<script>
import { mapActions, mapMutations, mapState } from 'vuex'
import VueSelectBox from '@/components/common/VueSelectBox'
import ItemList from '@/components/goods/ItemList'

export default {
  props: ['list', 'totalCount', 'type', 'noPromotion'],
  components: {
    VueSelectBox,
    ItemList
  },
  data () {
    return {
      sortType: 0,
      pageSize: 20,
      sizeItems: [
        {
          label: '20개씩보기',
          value: 20
        },
        {
          label: '40개씩보기',
          value: 40
        },
        {
          label: '60개씩보기',
          value: 60
        },
        {
          label: '80개씩보기',
          value: 80
        }
      ]
    }
  },
  computed: {
    ...mapState('productList', ['initSortType', 'initPageSize'])
  },
  methods: {
    ...mapMutations('productList', ['SET_INIT_SORTTYPE', 'SET_INIT_PAGESIZE', 'CLEAR_BK_PARAMS']),
    ...mapActions('productList', ['fetchMore']),

    sortTypeClick (index) {
      this.sortType = index
      let sorts = ''
      if (this.type === 'search') {
        if (index === 0) {
          sorts = 'POPULAR:DESC'
        } else if (index === 2) {
          sorts = 'DISCOUNTED_PRICE:ASC'
        } else if (index === 3) {
          sorts = 'DISCOUNTED_PRICE:DESC'
        } else if (index === 4) {
          sorts = 'REVIEW:DESC'
        }
      } else {
        if (index === 0) {
          sorts = 'MD_RECOMMEND:ASC'
        } else if (index === 1) {
          sorts = 'SALE_YMD:DESC'
        } else if (index === 2) {
          sorts = 'POPULAR:DESC'
        } else if (index === 3) {
          sorts = 'DISCOUNTED_PRICE:ASC'
        } else if (index === 4) {
          sorts = 'DISCOUNTED_PRICE:DESC'
        } else if (index === 5) {
          sorts = 'REVIEW:DESC'
        }
      }
      this.$store.dispatch('productList/filterList', { sortType: sorts, isBkData: true })
      this.SET_INIT_SORTTYPE({ index, sorts })
    },
    setPageSize (value) {
      this.pageSize = value
      this.$store.dispatch('productList/filterList', { pageSize: this.pageSize, isBkData: true })
      this.SET_INIT_PAGESIZE(this.pageSize)
    },
    resetParams () {
      this.sortType = 0
      this.pageSize = 20
    },
    getSortType () {
      this.sortType = this.initSortType ? this.initSortType : 0
      return true
    },
    getPageSize () {
      this.pageSize = this.initPageSize ? this.initPageSize : 20
      return true
    }
  },
  watch: {
    '$route': 'resetParams'
  },
  destroyed () {
    // this.CLEAR_BK_PARAMS()
  }
}
</script>

<style>
</style>
