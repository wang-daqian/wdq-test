<template>
  <div class="goods_list_item" :style="displayMode === 'MO' ? 'margin-top: 5px;' : ''">
    <div class="goods_list_item_tit">
      <h2>{{categoryName.label}}</h2>
    </div>
    <div class="list_item_category" v-if="categoryName.children">
      <ul>
        <li v-for="item in categoryName.children" :key="item.categoryNo">
          <router-link :to="item.link_to">
            <span>{{item.label}}</span>
          </router-link>
        </li>
      </ul>
    </div>

    <product-list :list="list" :totalCount="totalCount" :noPromotion="true" />
  </div>
</template>

<script>
import ProductList from '@/components/goods/ProductList'

export default {
  props: ['displayMode', 'categoryName', 'list', 'totalCount'],
  components: {
    ProductList
  }
}
</script>

<style>
</style>
