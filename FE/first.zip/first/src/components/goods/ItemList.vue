<template>
  <div class="goods_list">
    <div class="goods_list_cont">
      <div class="item_gallery_type">
        <ul v-if="list && list.length">
          <li style="width:25%;" v-for="(item, index) in list" :key="index">
            <div class="item_cont">
              <div class="item_photo_box">
                <goods-view-link :product="item">
                  <img v-lazy="imageUrl(item.imageUrls,item.listImageUrls)" :alt="item.productName" :title="item.productName" width="248" class="middle" />
                </goods-view-link>
              </div>
              <div class="item_info_cont">
                <div class="item_tit_box">
                  <goods-view-link :product="item">
                    <strong class="item_name">{{item.productName}} {{item.productManagementCd | dispManageCode}}</strong>
                    <span class="item_name_explain" v-if="!noPromotion">{{item.promotionText}}</span>
                  </goods-view-link>
                </div>
                <div class="item_money_box">
                  <del v-if="item.immediateDiscountAmt + item.additionDiscountAmt + item.couponDiscountAmt > 0">{{ item.salePrice | formatNumber }}원</del>
                  <strong class="item_price">
                    <span>{{ item.salePrice - item.immediateDiscountAmt - item.additionDiscountAmt - item.couponDiscountAmt | formatNumber }}원</span>
                  </strong>
                  <i v-if="priceCalculate(item).discountRate >= 1" class="saleNumber02">{{ priceCalculate(item).discountRate }}%</i>
                </div>
                <div class="item_icon_box">
                </div>
              </div>
            </div>
          </li>
        </ul>

        <div class="mypage_no_data" align="center" :style="{'margin-top':'60px'}" v-else>
          {{showMsg}}
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import GoodsViewLink from '@/components/common/GoodsViewLink'
import { productPrice2 } from '@/utils/stringUtils'

export default {
  data () {
    return {
      msg: '상품이 존재하지 않습니다.'
    }
  },
  props: ['list', 'noPromotion', 'nodataMsg'],
  components: {
    GoodsViewLink
  },
  computed: {
    showMsg () {
      return this.nodataMsg ? this.nodataMsg : this.msg
    }
  },
  methods: {
    imageUrl (imageurls, listImageUrls) {
      if (listImageUrls && listImageUrls.length) {
        return listImageUrls[0]
      } else if (imageurls && imageurls.length) {
        return imageurls[0]
      } else {
        return ''
      }
    },
    priceCalculate (item) {
      return productPrice2(item.salePrice,
        item.additionDiscountAmt,
        item.immediateDiscountAmt,
        item.couponDiscountAmt)
    }
  }
}
</script>

<style>
</style>
