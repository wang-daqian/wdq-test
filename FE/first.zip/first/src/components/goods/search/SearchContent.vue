<template>
  <div class="content">
    <div class="goods_search_cont">
      <strong class="search_text_result">
        <span>"{{searchkey}}"</span> 검색결과 {{totalCount | formatNumber}}개
      </strong>
      <div class="goods_search_box">
        <div class="search_again_box">
          <div class="form_element">
            <label :class="['check_s', {'on' : reSearchFlg}]" @click.prevent="reSearchFlg = !reSearchFlg">결과 내 재검색</label>
          </div>
          <div class="keyword-div">
            <input type="text" class="keyword_input" ref="searchinut" v-model="words" autocomplete="off" @keypress.enter="reSearch">
          </div>
          <button type="submit" class="btn_goods_search" @click.prevent="reSearch">
            <em>검색</em>
          </button>
        </div>
        <div id="detailSearch" class="dn"></div>
      </div>

      <product-list :list="list" :totalCount="totalCount" :type="'search'" :noPromotion="true" />
    </div>
  </div>
</template>

<script>
import { setRecentWords } from '@/utils/utils'
import ProductList from '@/components/goods/ProductList'
import { gaEventSearch } from '@/utils/gaEventUtils'

export default {
  props: ['list', 'totalCount'],
  components: {
    ProductList
  },
  data () {
    return {
      searchkey: this.$route.query.q,
      oldWords: '',
      words: '',
      reSearchFlg: false
    }
  },
  methods: {
    initData () {
      this.searchkey = this.$route.query.q
      this.oldWords = ''
      this.words = ''
      this.reSearchFlg = false
    },
    reSearch () {
      this.$refs.searchinut.blur()
      if (this.reSearchFlg) {
        if (this.words.trim()) {
          if (this.oldWords !== this.words) {
            this.oldWords = this.words.trim()
            this.$store.dispatch('productList/filterList', { keyInReFlg: true, keywordInResult: this.words.trim() })
          }
        } else {
          alert('검색어를 입력해 주세요.')
        }
      } else {
        if (this.words.trim()) {
          this.words = this.words.trim()
          setRecentWords(this.words)
          /** gtag.js */
          gaEventSearch(this.words)
          this.$router.push(`/searchlist?q=${this.words}`)
        } else {
          alert('검색어를 입력해 주세요.')
        }
      }
    }
  },
  watch: {
    '$route': 'initData'
  }
}
</script>

<style>
</style>
