<template>
  <div class="side_cont">
    <span class="btn_side_mobile">상품 상세 검색하기</span>
    <div class="sub_search_box">
      <fieldset id="frmSearchDetail">
        <dl>
          <dt>카테고리</dt>
          <dd>
            <div class="select_box">
              <vue-select-box v-if="brands" :showValue="brandNo" :items="brands" @selected="selectBrand" />
            </div>
            <div class="select_box">
              <vue-select-box v-if="depth1s" :showValue="depth1" :items="depth1s" @selected="selectDepth1" />
            </div>
            <div class="select_box">
              <vue-select-box v-if="depth2s" :showValue="depth2" :items="depth2s" @selected="selectDepth2" />
            </div>
            <div class="select_box">
              <vue-select-box v-if="depth3s" :showValue="depth3" :items="depth3s" @selected="selectDepth3" />
            </div>
          </dd>
        </dl>
        <dl>
          <dt>혜택/조건</dt>
          <dd>
            <div class="benefit_box">
              <span>
                <label :class="freeFlg ? 'active on' : ''" title="무료배송" @click.prevent="freeFlg = !freeFlg">무료배송</label>
              </span>
            </div>
          </dd>
        </dl>
        <dl>
          <dt>가격</dt>
          <dd>
            <div class="price_box">
              <input type="number" class="text" v-model="minPrice" />
              <span> ~ </span>
              <input type="number" class="text" v-model="maxPrice" />
              <span>원</span>
            </div>
          </dd>
        </dl>
        <div class="quick_btn" @click.prevent="filterSearch">
          <input type="button" id="btnSearchSubmit" value="검색">
        </div>
      </fieldset>
    </div>
  </div>
</template>

<script>
import VueSelectBox from '@/components/common/VueSelectBox'

export default {
  props: ['categories'],
  components: {
    VueSelectBox
  },
  data () {
    return {
      freeFlg: false,
      brandNo: 0,
      depth1: 0,
      depth2: 0,
      depth3: 0,
      minPrice: '',
      maxPrice: ''
    }
  },
  methods: {
    initData () {
      this.freeFlg = false
      this.brandNo = 0
      this.depth1 = 0
      this.depth2 = 0
      this.depth3 = 0
      this.minPrice = ''
      this.maxPrice = ''
    },
    filterSearch () {
      let params = {
        categoryNo: this.depth3 || this.depth2 || this.depth1 || this.brandNo,
        freeFlg: this.freeFlg,
        minPrice: this.minPrice,
        maxPrice: this.maxPrice,
        priceFlg: true
      }
      this.$store.dispatch('productList/filterList', params)
    },
    selectBrand (value) {
      this.brandNo = value
      this.depth1 = 0
      this.depth2 = 0
      this.depth3 = 0
    },
    selectDepth1 (value) {
      this.depth1 = value
      this.depth2 = 0
      this.depth3 = 0
    },
    selectDepth2 (value) {
      this.depth2 = value
      this.depth3 = 0
    },
    selectDepth3 (value) {
      this.depth3 = value
    }
  },
  computed: {
    brands () {
      const brands = [{
        label: '=카테고리선택=',
        value: 0
      }]
      if (this.categories) {
        brands.push(
          ...this.categories.map(item => {
            return {
              label: item.label,
              value: item.categoryNo
            }
          })
        )
      }
      return brands
    },
    depth1s () {
      const depth1s = [{
        label: '=카테고리선택=',
        value: 0
      }]
      if (this.brandNo) {
        const brand = this.categories.find(item => item.categoryNo === Number(this.brandNo))
        const depth1Cates = brand && brand.children
        if (depth1Cates) {
          depth1s.push(
            ...depth1Cates.map(item => {
              return {
                label: item.label,
                value: item.categoryNo
              }
            })
          )
        }
      }
      return depth1s
    },
    depth2s () {
      const depth2s = [{
        label: '=카테고리선택=',
        value: 0
      }]
      if (this.depth1) {
        const brand = this.categories.find(item => item.categoryNo === Number(this.brandNo))
        const depth1Cates = brand && brand.children
        const depth1Info = depth1Cates.find(item => item.categoryNo === Number(this.depth1))
        const depth2Cates = depth1Info && depth1Info.children
        if (depth2Cates) {
          depth2s.push(
            ...depth2Cates.map(item => {
              return {
                label: item.label,
                value: item.categoryNo
              }
            })
          )
        }
      }
      return depth2s
    },
    depth3s () {
      const depth3s = [{
        label: '=카테고리선택=',
        value: 0
      }]
      if (this.depth2) {
        const brand = this.categories.find(item => item.categoryNo === Number(this.brandNo))
        const depth1Cates = brand && brand.children
        const depth1Info = depth1Cates.find(item => item.categoryNo === Number(this.depth1))
        const depth2Cates = depth1Info && depth1Info.children
        const depth2Info = depth2Cates.find(item => item.categoryNo === Number(this.depth2))
        const depth3Cates = depth2Info && depth2Info.children
        if (depth3Cates) {
          depth3s.push(
            ...depth3Cates.map(item => {
              return {
                label: item.label,
                value: item.categoryNo
              }
            })
          )
        }
      }
      return depth3s
    }
  },
  watch: {
    '$route': 'initData'
  }
}
</script>

<style>
</style>
