<template>
  <div class="inner" v-if="event && event.sectionMenu && event.sectionMenu.length > 0">
    <ul class="lst_tab_category" v-if="event.sectionMenu.length > 1">

      <li v-for="(section, index) in event.sectionMenu" :key="index">
        <a href="#" @click.prevent="sectionClick(index)">
          <span>{{ section.label }}</span>
        </a>
      </li>
      <li v-for="n in blankCount()" :key="`blank_${n}`">
        <a></a>
      </li>
    </ul>

    <event-list v-for="(section, index) in event.sectionMenu" :key="index" :section="section" :index="index" :showMenu="event.sectionMenu.length > 1" />
  </div>
</template>

<script>
import $ from 'jquery'
import { mapState } from 'vuex'
import EventList from '@/components/event/EventList'

export default {
  data () {
    return {
      sectionSelect: this.$route.hash ? parseInt(this.$route.hash.replace('#category', '')) : 0
    }
  },
  components: {
    EventList
  },
  computed: {
    columnClass () {
      let colClass = 'event_list_cont column4'
      if (event) {

      }
      return colClass
    },
    ...mapState('event', ['event'])
  },
  methods: {
    blankCount () {
      if (this.event && this.event.sectionMenu) {
        return this.event.sectionMenu.length % 6 === 0 ? 0 : 6 - this.event.sectionMenu.length % 6
      }
    },
    sectionClick (index) {
      if ($('#category' + index) && $('#category' + index).offset()) {
        const headerTop = $('#header_warp') ? $('#header_warp').height() : 0
        $(window).scrollTop($('#category' + index).offset().top - headerTop)
      }
      this.sectionSelect = index
    }
  }
}
</script>
