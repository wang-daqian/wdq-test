<template>
  <div class="area_event_topic">
    <div class="inner">
      <h3 class="blind">이벤트 및 기획전 알림</h3>
      <strong class="tit_topic">{{ event.label }}</strong>
    </div>
  </div>
</template>

<script>
import { mapState } from 'vuex'

export default {
  data () {
    return {}
  },
  computed: {
    ...mapState('event', ['event'])
  }
}
</script>
