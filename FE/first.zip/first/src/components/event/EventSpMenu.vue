<template>
  <div class="category_slider_menu">
    <ul class="menu">
      <template v-for="(section, index) in event.sectionMenu">
        <li :key="index">
          <a href="#" @click.prevent="sectionClick(index)">
            <span>{{ section.label }}</span>
          </a>
        </li>
      </template>
      <template v-for="(n,index) in blankCount()">
        <li :key="`${'blank_' + index}`">
          <a>&nbsp;</a>
        </li>
      </template>
    </ul>
  </div>
</template>

<script>
import $ from 'jquery'
import { mapState } from 'vuex'

export default {
  data () {
    return {
      sectionSelect: this.$route.hash ? parseInt(this.$route.hash.replace('#category', '')) : 0
    }
  },
  computed: {
    ...mapState('event', ['event'])
  },
  methods: {
    blankCount () {
      if (this.event && this.event.sectionMenu) {
        return this.event.sectionMenu.length % 6 === 0 ? 0 : 6 - this.event.sectionMenu.length % 6
      }
    },
    sectionClick (index) {
      if ($('#category' + index) && $('#category' + index).offset()) {
        const headerTop = $('#header_warp') ? $('#header_warp').height() : 0
        $(window).scrollTop($('#category' + index).offset().top - headerTop)
      }
      this.sectionSelect = index
    }
  }
}
</script>
