<template>
  <li>
    <div class="item_cont">
      <div class="item_photo_box">
        <goods-view-link :product="product">
          <img :src="product.imageUrls[0]" alt="코드픽스 샘플 상품" title="코드픽스 샘플 상품" class="middle">
        </goods-view-link>
      </div>
      <!-- //item_photo_box -->
      <div class="item_info_cont">
        <div class="item_tit_box">
          <goods-view-link :product="product">
            <strong class="item_name">{{ product.productName }} {{ product.productManagementCd | dispManageCode}}</strong>
          </goods-view-link>
        </div>
        <!-- //item_tit_box -->
        <div class="item_money_box">
          <strong class="item_price">
            <del v-if="priceCalculate.discountAmt > 0">{{product.salePrice | formatNumber}}원 </del>
            <strong class="item_price">
              <span>{{priceCalculate.finalSalePrice | formatNumber}}원 </span>
            </strong>
          </strong>
          <i v-if="priceCalculate.discountRate >= 1" class="saleNumber02">{{ priceCalculate.discountRate }}%</i>
        </div>
      </div>
    </div>
  </li>
</template>

<script>
import GoodsViewLink from '@/components/common/GoodsViewLink'

export default {
  props: ['product'],
  components: {
    GoodsViewLink
  },
  computed: {
    priceCalculate () {
      return this.productPrice(this.product.salePrice,
        this.product.additionDiscountAmt,
        this.product.immediateDiscountAmt,
        this.product.couponDiscountAmt)
    }
  },
  methods: {
    productPrice (salePrice, additionDiscountAmt, immediateDiscountAmt, couponDiscountAmt) {
      let discountAmt = ((additionDiscountAmt || 0) + (immediateDiscountAmt || 0) + (couponDiscountAmt || 0))
      return {
        discountAmt: discountAmt,
        discountRate: Math.round((discountAmt / salePrice) * 100) || 0,
        finalSalePrice: salePrice - discountAmt
      }
    }
  }
}
</script>
