<template>
  <div class="area_event_coupon" v-if="event && event.coupon && event.coupon.coupons.length > 0">
    <div class="inner">
      <div class="bx_coupon_big">

        <template v-for="coupon in event.coupon.coupons">
          <a href="javascript:" :class="{ disabled: coupon.downloadable === false, percent: coupon.discountInfo.fixedAmt === true}" @click="downloadCoupon(coupon.couponNo)" :key="coupon.couponNo">
            <strong class="tit">{{ coupon.couponName }}</strong>
            <span class="bx_price">
              <template v-if="coupon.discountInfo.freeDelivery">
                <strong class="number">무료배송</strong>
              </template>
              <template v-else>
                <template v-if="coupon.discountInfo.fixedAmt">
                  <strong class="number">{{ coupon.discountInfo.discountAmt | formatNumber }}
                    <span class="txt">원</span>
                  </strong>
                </template>
                <template v-else>
                  <strong class="number">{{ coupon.discountInfo.discountRate }}
                    <span class="txt">%</span>
                  </strong>
                </template>
              </template>
            </span>
            <div class="dsc_info">
              <template v-if="!coupon.discountInfo.fixedAmt">
                <span :class="{ discount: coupon.useConstraint.minSalePrice, ticket: !coupon.useConstraint.minSalePrice }">최대 {{ coupon.discountInfo.maxDiscountAmt | formatNumber }}원 할인</span>
              </template>
              <template v-if="coupon.useConstraint.minSalePrice && coupon.useConstraint.maxSalePrice">
                <span class="ticket">{{ coupon.useConstraint.minSalePrice | formatNumber }}원 이상 ~ {{ coupon.useConstraint.maxSalePrice | formatNumber }}원 이하 사용 가능</span>
              </template>
              <template v-if="coupon.useConstraint.minSalePrice && !coupon.useConstraint.maxSalePrice">
                <span class="ticket">{{ coupon.useConstraint.minSalePrice | formatNumber }}원 이상 사용 가능</span>
              </template>
              <template v-if="!coupon.useConstraint.minSalePrice && coupon.useConstraint.maxSalePrice">
                <span class="ticket">{{ coupon.useConstraint.maxSalePrice | formatNumber }}원 이하 사용 가능</span>
              </template>
              <span class="limit">{{ coupon.dateInfo.issueEndYmdt.split(' ')[0].replace(/-/gi,'.') }} 까지 발급 가능</span>
            </div>
            <span class="ico_download">
              <span class="sp">쿠폰 다운로드</span>
            </span>
          </a>
        </template>
      </div>

      <div class="bx_caution" v-if="event && event.coupon && event.coupon.guideImageUrl" v-html="replaceImageUrl">
      </div>
    </div>
  </div>
</template>

<script>
import { mapState } from 'vuex'
import { isLogin } from '@/utils/utils'

export default {
  data () {
    return {}
  },
  props: {},
  components: {},
  computed: {
    ...mapState('event', ['event']),
    replaceImageUrl () {
      let r = this.event.coupon.guideImageUrl
      r = r.replace(/&lt;/g, '<').replace(/&gt;/g, '>')
      return r
    }
  },
  methods: {
    downloadCoupon (couponNo) {
      let now = new Date()
      let startDate = new Date(this.event.startYmdt.replace(' ', 'T'))
      let endDate = new Date(this.event.endYmdt.replace(' ', 'T'))
      if (startDate > now) {
        alert('쿠폰 다운로드 기간이 아닙니다.')
        return
      }
      if (endDate < now) {
        alert('종료된 기획전입니다.')
        return
      }
      if (!isLogin()) {
        this.$router.push({
          path: '/member/login',
          query: {
            redirect: `${location.protocol}//${location.host}${this.$route.fullPath.split('#')[0]}`
          }
        })
      } else {
        this.$store.dispatch('coupon/eventDownLoad', { couponNo: couponNo }).then(() => {
          alert('할인쿠폰이 발급되었습니다.')
        })
      }
    }
  }
}
</script>
