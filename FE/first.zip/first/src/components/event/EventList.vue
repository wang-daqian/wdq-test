<template>
  <div>
    <em :id="`${'category' + index}`" class="tit_category" v-if="showMenu">{{ section.label }}</em>
    <div :class="columnClass">
      <div class="item_event_type">
        <ul>
          <template v-for="(product,label) in section.products">
            <ProductCard :product="product" :key="label"></ProductCard>
          </template>
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
import ProductCard from '@/components/event/ProductCard'

export default {
  props: ['section', 'index', 'showMenu'],
  components: {
    ProductCard
  },
  computed: {
    columnClass () {
      let colClass = 'event_list_cont column4'
      if (this.section) {
        colClass = `event_list_cont column${this.section.pcPerRow}`
        if (this.section.mobilePerRow === 1) {
          colClass = colClass + ' column1'
        }
      }
      return colClass
    }
  }
}
</script>
