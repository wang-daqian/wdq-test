<template>
  <div class="mypage_top_info">
    <div class="mypage_top_txt" v-if="mySummary && mySummary.memberGrade">
      <div class="grade_txt" v-if="member">
        <p>{{ member.memberName }}님의</p>
        <p> 회원등급은
          <span>{{mySummary.memberGrade.label}}등급</span> 입니다.
        </p>
        <div class="btn_layer">
          <span class="btn_gray_list">
            <a href="#" class="btn_gray_small" @click.prevent="openMemberGrade = !openMemberGrade">
              <em>등급혜택보기</em>
            </a>
          </span>

          <!-- N : 회원등급혜택 레이어 시작 -->
          <div id="lyGrade" class="layer_area" v-if="openMemberGrade">
            <div class="ly_wrap grade_layer">
              <div class="ly_tit">
                <strong>등급혜택 안내</strong>
              </div>
              <div class="ly_cont">
                <div class="grade_list">
                  <dl>
                    <dt>회원 등급</dt>
                    <dd>{{mySummary.memberGrade.label}}</dd>
                  </dl>
                  <dl v-if="showGroup">
                    <dt>회원 그룹</dt>
                    <dd>{{showGroup.memberGroupName}}</dd>
                  </dl>
                  <dl v-if="showAddMore">
                    <dt>추가 적립</dt>
                    <dd>구매금액당 {{showAccumulationRate}}% 추가 적립</dd>
                  </dl>
                </div>
              </div>
              <!-- //ly_cont -->
              <a href="#" class="ly_close" @click.prevent="openMemberGrade = false">
                <img src="../../../assets/img/common/layer/btn_layer_close.png" alt="닫기">
              </a>
            </div>
            <!-- //ly_wrap -->
          </div>
          <!-- N : 회원등급혜택 레이어 끝 -->

        </div>
      </div>
      <!-- //grade_txt -->
    </div>
    <!-- //mypage_top_txt -->

    <div class="mypage_top_wallet">
      <ul>
        <li>
          <span>
            <img src="../../../assets/img/icon/mypage/icon_coupon.png" alt="">
          </span>
          <span>
            <em>쿠폰</em>
            <router-link to="/mypage/coupon">
              <strong>{{mySummary && mySummary.usableCouponCnt}}</strong>
            </router-link>장</span>
        </li>
        <li v-if="isUseMallAccumulation">
          <span>
            <img src="../../../assets/img/icon/mypage/icon_mileage.png" alt="">
          </span>
          <span>
            <em>{{showAccumulationName}}</em>
            <router-link to="/mypage/mileagelist">
              <strong>{{mMileages && MyMiliFormat(mMileages.totalAvailableAmt)}}</strong>
            </router-link>{{showAccumulationUnit}}</span>
        </li>
      </ul>
    </div>
    <!-- //mypage_top_wallet -->

  </div>

</template>

<script>
import { mapState, mapGetters } from 'vuex'
import { formatCurrency } from '@/utils/stringUtils'

export default {
  name: 'MyPage',
  metaInfo: {
    bodyAttrs: {
      class: 'mypage'
    }
  },
  data () {
    return {
      openMemberGrade: false
    }
  },
  computed: {
    ...mapState('member', ['mySummary', 'member', 'mMileages']),
    ...mapGetters('common', ['showAccumulationName', 'isUseMallAccumulation', 'showAccumulationUnit']),

    showMinOrderAmt () {
      return this.mySummary.memberGrade && this.mySummary.memberGrade.minOrderAmt ? this.mySummary.memberGrade.minOrderAmt : 0
    },
    showAddMore () {
      if ((this.mySummary.memberGrade && this.mySummary.memberGrade.accumulationRate != null) || (this.mySummary.memberGroups && this.mySummary.memberGroups.length > 0)) {
        return true
      } else {
        return false
      }
    },
    showGroup () {
      if (this.mySummary.memberGroups.length > 0) {
        let maxRate = Math.max.apply(Math, this.mySummary.memberGroups.map((group) => { return group.accumulationRate }))
        return this.mySummary.memberGroups.find((group) => { return group.accumulationRate === maxRate })
      }
      return null
    },
    showAccumulationRate () {
      let memberAccRate = this.mySummary.memberGrade && this.mySummary.memberGrade.accumulationRate ? this.mySummary.memberGrade.accumulationRate : 0
      if (this.showGroup && this.showGroup.accumulationRate > memberAccRate) {
        return this.showGroup.accumulationRate
      }
      return memberAccRate
    }
  },
  methods: {
    MyMiliFormat (val) {
      return formatCurrency(val)
    }
  },
  beforeCreate () {
    this.$store.dispatch('member/memberInformation')
    this.$store.dispatch('member/mySummary')
    this.$store.dispatch('member/mileAge')
  }
}
</script>
