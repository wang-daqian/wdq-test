<template>
  <div id="lyZoom" class="layer_wrap zoom_layer" v-if="openLayer">
    <div id="ly_zoom_wrap" class="layer_wrap_cont" :style="ly_style">
      <div class="ly_tit">
        <h4>{{showTitle}}<span v-if="product">{{product.baseInfo.productName}} {{product.baseInfo.productManagementCd | dispManageCode}}</span></h4>
      </div>
      <div class="ly_cont">
        <div class="item_photo_view_box">
          <div class="item_photo_view">
            <div class="item_photo_big" id="magnifyImage">
              <span class="img_photo_big">
                <img :src="mainImage" width="500" class="middle">
              </span>
            </div>
            <!-- //item_photo_big -->
            <div class="item_photo_slide">
              <button type="button" class="slick_goods_prev arrows_btn" @click.prevent="slickPrev">
                <img src="../../../assets/img/common/btn/btn_vertical_prev.png" alt="이전 상품 이미지">
              </button>
              <ul class="slider_wrap ly_slider_goods_nav">
                <slick ref="slick" :options="slickOptions">
                  <li v-for="(item, index) in imageUrls" :key="index">
                    <a href="javascript:" @click.prevent="gdChangeImage(index)">
                      <img :src="item" width="68" class="middle">
                    </a>
                  </li>
                </slick>
              </ul>
              <button type="button" class="slick_goods_next arrows_btn" @click.prevent="slickNext">
                <img src="../../../assets/img/common/btn/btn_vertical_next.png" alt="다음 상품 이미지">
              </button>
            </div>
          </div>
        </div>
      </div>
      <!-- //ly_cont -->
      <a href="javascript:" class="ly_close layer_close" @click.prevent="closeLayer">
        <img src="../../../assets/img/common/layer/btn_layer_close.png" alt="닫기">
      </a>
    </div>
    <!-- //layer_wrap_cont -->
  </div>
</template>

<script>
import Slick from 'vue-slick'
import $ from 'jquery'

export default {
  props: ['imageUrls', 'openLayer', 'imgStartIndex', 'product'],
  data () {
    return {
      mainImageIndex: 0,
      ly_style: '',
      slickOptions: {
        vertical: true,
        arrows: false,
        draggable: false,
        autoplay: false,
        infinite: false,
        slidesToShow: 5,
        slidesToScroll: 1
      }
    }
  },
  computed: {
    mainImage () {
      return this.imageUrls[this.mainImageIndex]
    },
    showTitle () {
      if (this.product) {
        return '상품후기 이미지'
      } else {
        return 'Q&A 이미지'
      }
    }
  },
  components: {
    Slick
  },
  methods: {
    gdChangeImage (index) {
      this.mainImageIndex = index
    },
    closeLayer () {
      this.$emit('close')
    },
    slickPrev () {
      this.mainImageIndex--
      this.mainImageIndex = this.mainImageIndex < 0 ? 0 : this.mainImageIndex
      this.$refs.slick.prev()
    },
    slickNext () {
      this.mainImageIndex++
      this.mainImageIndex = this.mainImageIndex >= this.imageUrls.length ? this.imageUrls.length - 1 : this.mainImageIndex
      this.$refs.slick.next()
    },
    showInit () {
      this.$nextTick(() => {
        const top = ($(window).height() - $('#ly_zoom_wrap').outerHeight()) / 2
        const left = ($(window).width() - $('#ly_zoom_wrap').outerWidth()) / 2
        this.ly_style = `position: absolute; margin: 0px; top: ${top > 0 ? top : 0}px; left: ${left > 0 ? left : 0}px;`
      })
    }
  },
  watch: {
    'openLayer': 'showInit',
    imgStartIndex () {
      this.mainImageIndex = this.imgStartIndex
    }
  }
}
</script>

<style>
</style>
