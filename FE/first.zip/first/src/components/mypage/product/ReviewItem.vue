<template>
  <tr style="height:50px">
    <td class="td_left">
      <div class="pick_add_cont">
        <span class="pick_add_img">
          <goods-view-link :product="review">
            <img :src="review.imageUrl" width="50" class="middle">
          </goods-view-link>
        </span>
        <div class="pick_add_info">
          <goods-view-link :product="review">
            <em class="name" style="display: block;">{{review.productName}} {{review.productManagementCd | dispManageCode}}</em>
          </goods-view-link>
        </div>
      </div>
    </td>
    <td>
      <div class="rating_star_box">
        <span class="rating_star">
          <span :style="`width:${disStar}%;`">별 다섯개중 다섯개</span>
        </span>
      </div>
    </td>
    <td class="board_tit td_left">
      <router-link :to="`/mypage/product/${review.productNo}/product-reviews/${review.reviewNo}`">
        {{review.content | subContent}}
      </router-link>
    </td>
    <td>{{review.registerYmdt | getStrYMDHM('.')}}</td>
  </tr>
</template>

<script>
import GoodsViewLink from '@/components/common/GoodsViewLink'

export default {
  name: 'ReviewItem',
  components: {
    GoodsViewLink
  },
  computed: {
    disStar () {
      return 100 * (this.review.rate / 5)
    }
  },
  props: ['review']
}
</script>
