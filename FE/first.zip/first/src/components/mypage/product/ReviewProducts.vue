<template>
  <div id="addGoodsLayer" class="">
    <div id="lyCouponDown" class="layer_wrap add_goods_layer" style="height: 745px; position: fixed; left: 50%; top: 50%; margin-left: -395.5px; margin-top: -372.5px;">
      <div class="layer_wrap_cont">
        <div class="ly_tit">
          <h4>상품 선택</h4>
        </div>
        <div class="ly_cont">
          <div class="scroll_box">
            <div class="table_shell">
              <div class="top_table_type">
                <form id="frmSelect">
                  <span class="pick_list_num">상품
                    <strong v-if="reviewProducts">{{reviewProductstotalCount}}</strong> 건</span>
                  <table>
                    <colgroup>
                      <col style="width:80px">
                      <col>
                      <col style="width:137px">
                    </colgroup>
                    <thead>
                      <tr>
                        <th>선택</th>
                        <th>상품명</th>
                        <th>상품금액</th>
                      </tr>
                    </thead>
                    <tbody>
                      <product-item v-for="product in reviewProducts" :key="product.orderOptionNo" :product="product" :pageType="'review'" :checkedProduct="checkedProduct" @setChecked="setChecked(product)" />
                    </tbody>
                  </table>
                </form>
              </div>
              <div class="pagination" v-if="reviewProducts && reviewProducts.length < reviewProductstotalCount">
                <p class="pagination-btn">
                  <button type="button" class="btn_more" @click.prevent="fetchMore">더보기</button>
                </p>
              </div>
            </div>
          </div>
          <!-- //scroll_box -->

          <div class="btn_center_box">
            <button type="button" class="btn_ly_cancel layer_close" @click.prevent="closeSearch">
              <strong>취소</strong>
            </button>
            <button type="button" class="btn_ly_ok js_select_confirm" @click.prevent="productChecked">
              <strong>확인</strong>
            </button>
          </div>
        </div>
        <!-- //ly_cont -->
        <a href="" class="ly_close layer_close" @click.prevent="closeSearch">
          <img src="../../../assets/img/common/layer/btn_layer_close.png" alt="닫기">
        </a>
      </div>
      <!-- //layer_wrap_cont -->
    </div>
    <!-- //layer_wrap -->
  </div>
</template>

<script>
import ProductItem from '@/components/mypage/product/ProductItem'

export default {
  name: 'ReviewProducts',
  data () {
    return {
      checkedProduct: null
    }
  },
  props: ['reviewProducts', 'reviewProductstotalCount'],
  components: {
    ProductItem
  },
  methods: {
    closeSearch () {
      this.$emit('showSearchPopup')
    },
    productChecked () {
      if (this.checkedProduct === null) {
        alert('상품을 선택해주세요.')
        return false
      }
      this.$emit('productChecked', this.checkedProduct)
      this.closeSearch()
    },
    setChecked (product) {
      this.checkedProduct = product
    },
    fetchMore () {
      this.$store.dispatch('profilereview/getReviewProductsMore')
    }
  }
}
</script>
