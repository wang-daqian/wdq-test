<template>
  <div id="addGoodsLayer" class="">
    <div id="lyCouponDown" class="layer_wrap add_goods_layer" style="height: 745px; position: fixed; left: 50%; top: 50%; margin-left: -395.5px; margin-top: -372.5px;">
      <div class="layer_wrap_cont">
        <div class="ly_tit">
          <h4>상품 선택</h4>
        </div>
        <div class="ly_cont">
          <form id="frmBoardSearch" name="frmBoardSearch" action="../share/layer_goods_search.php" onsubmit="return false;">
            <div class="ly_date_list_box">
              <div class="ly_date_select_list">
                <h5>카테고리</h5>
                <div class="select_box">
                  <vue-select-box :showValue="depth1No" :items="cates" @selected="setType1" :width="seletBoxWidth" />
                </div>
                <div class="select_box">
                  <vue-select-box :showValue="depth2No" :items="depth2Categproes" @selected="setType2" :width="seletBoxWidth" />
                </div>
                <div class="select_box">
                  <vue-select-box :showValue="depth3No" :items="depth3Categproes" @selected="setType3" :width="seletBoxWidth" />
                </div>
                <div class="select_box">
                  <vue-select-box :showValue="depth4No" :items="depth4Categproes" @selected="setType4" :width="seletBoxWidth" />
                </div>
              </div>
              <!-- //ly_date_select_list -->

              <div class="ly_date_search_list">
                <h5>검색어</h5>
                <vue-select-box :showValue="selectSearchType" :items="searchTypes" @selected="setSearchType" :width="seletBoxWidth" />
                <input type="text" name="keyword" maxlength="20" placeholder="검색어를 입력해주세요." v-model="keyword" style="margin-left: 5px" @keypress.enter="search">
              </div>
              <!-- //ly_date_search_list -->
            </div>
            <!-- //ly_date_list_box -->

            <div class="btn_center_box">
              <button type="button" class="btn_ly_date_check js_select_search" @click.prevent="search">
                <em>조회</em>
              </button>
            </div>
          </form>

          <div class="scroll_box">
            <div class="table_shell">
              <div class="top_table_type">
                <form id="frmSelect">
                  <span class="pick_list_num">상품
                    <strong v-if="list">{{totalCount}}</strong> 건</span>
                  <table>
                    <colgroup>
                      <col style="width:80px">
                      <col>
                      <col style="width:137px">
                    </colgroup>
                    <thead>
                      <tr>
                        <th>선택</th>
                        <th>상품명</th>
                        <th>상품금액</th>
                      </tr>
                    </thead>
                    <tbody>
                      <product-item v-for="(product,index) in list" :key="index" :product="product" :pageType="'inquiry'" :checkedProduct="checkedProduct" @setChecked="setChecked(product)" />
                    </tbody>
                  </table>
                </form>
              </div>
              <div class="pagination" v-if="list && list.length < totalCount">
                <p class="pagination-btn">
                  <button type="button" class="btn_more" @click.prevent="fetchMore">더보기</button>
                </p>
              </div>
            </div>
          </div>
          <!-- //scroll_box -->

          <div class="btn_center_box">
            <button type="button" class="btn_ly_cancel layer_close" @click.prevent="closeSearch">
              <strong>취소</strong>
            </button>
            <button type="button" class="btn_ly_ok js_select_confirm" @click.prevent="productChecked">
              <strong>확인</strong>
            </button>
          </div>
        </div>
        <!-- //ly_cont -->
        <a href="" class="ly_close layer_close" @click.prevent="closeSearch">
          <img src="../../../assets/img/common/layer/btn_layer_close.png" alt="닫기">
        </a>
      </div>
      <!-- //layer_wrap_cont -->
    </div>
    <!-- //layer_wrap -->
  </div>
</template>

<script>
import { mapState } from 'vuex'
import VueSelectBox from '@/components/common/VueSelectBox'

import ProductItem from '@/components/mypage/product/ProductItem'

export default {
  name: 'ProductSearch',
  data () {
    return {
      depth1No: '0',
      depth2No: '0',
      depth2CategproesAll: [],
      depth2Categproes: [
        {
          label: '=카테고리선택=',
          value: '0'
        }
      ],
      depth3No: '0',
      depth3CategproesAll: [],
      depth3Categproes: [
        {
          label: '=카테고리선택=',
          value: '0'
        }
      ],
      depth4No: '0',
      depth4CategproesAll: [],
      depth4Categproes: [
        {
          label: '=카테고리선택=',
          value: '0'
        }
      ],
      searchCategory: '0',
      keyword: '',
      checkedProduct: null,
      seletBoxWidth: '120px',
      selectSearchType: '',
      searchTypes: [
        {
          label: '상품명',
          value: ''
        }
      ]
    }
  },
  watch: {
    depth1No: function () {
      this.depth2No = '0'
      this.depth2CategproesAll = this.depth1No === '0' ? this.getItems(true) : this.categories.find(item => item.categoryNo === this.depth1No).children
      this.depth2Categproes = this.depth1No === '0' ? this.getItems(true) : this.getItems(false, this.depth2CategproesAll, this.depth1No)
      this.searchCategory = this.depth1No
    },
    depth2No: function () {
      this.depth3No = '0'
      this.depth3CategproesAll = this.depth2No === '0' ? this.getItems(true) : this.depth2CategproesAll.find(item => item.categoryNo === this.depth2No).children
      this.depth3Categproes = this.depth2No === '0' ? this.getItems(true) : this.getItems(false, this.depth3CategproesAll, this.depth2No)
      this.searchCategory = this.depth2No === '0' ? this.depth1No : this.depth2No
    },
    depth3No: function () {
      this.depth4No = '0'
      this.depth4CategproesAll = this.depth3No === '0' ? this.getItems(true) : this.depth3CategproesAll.find(item => item.categoryNo === this.depth3No).children
      this.depth4Categproes = this.depth3No === '0' ? this.getItems(true) : this.getItems(false, this.depth4CategproesAll, this.depth3No)
      this.searchCategory = this.depth3No === '0' ? this.depth2No : this.depth3No
    },
    depth4No: function () {
      this.searchCategory = this.depth4No === '0' ? this.depth3No : this.depth4No
    }
  },
  computed: {
    ...mapState('category', ['categories']),
    ...mapState('productList', ['list', 'totalCount']),
    cates () {
      if (this.categories) {
        let item = this.categories.map(item => {
          return {
            label: item.label,
            value: item.categoryNo
          }
        })
        let defaultItem = [
          {
            label: '=카테고리선택=',
            value: '0'
          }
        ]
        let result = defaultItem.concat(item)
        return result
      }
    }
  },
  components: {
    VueSelectBox,
    ProductItem
  },
  methods: {
    setSearchType (value) {
      this.selectSearchType = value
    },
    setType1 (value) {
      this.depth1No = value
    },
    setType2 (value) {
      this.depth2No = value
    },
    setType3 (value) {
      this.depth3No = value
    },
    setType4 (value) {
      this.depth4No = value
    },
    getItems (isDefault, categories, categoryNo) {
      var item = []
      if (!isDefault && categories) {
        item = categories.map(item => {
          return {
            label: item.label,
            value: item.categoryNo
          }
        })
      }

      let defaultItem = [
        {
          label: '=카테고리선택=',
          value: '0'
        }
      ]
      let result = defaultItem.concat(item)
      return result
    },
    fetchMore () {
      this.$store.dispatch('productList/fetchMore')
    },
    closeSearch () {
      this.$emit('showSearchPopup')
      this.$store.dispatch('productList/ResetList')
    },
    search () {
      if (this.keyword === '' && this.searchCategory === '0') {
        alert('카테고리나 검색어를 선택/입력 해주세요.')
        return false
      }

      let searchParams = {}
      if (this.keyword !== '') {
        searchParams.keyword = this.keyword
      }
      if (this.searchCategory !== '0') {
        searchParams.categoryNo = this.searchCategory
      }
      this.$store.dispatch('productList/fetchListByCategoryKeyword', searchParams)
    },
    setChecked (product) {
      this.checkedProduct = product
    },
    productChecked () {
      if (this.checkedProduct === null) {
        alert('상품을 선택해주세요.')
        return false
      }
      this.$emit('productChecked', this.checkedProduct)
      this.closeSearch()
    }
  }
}
</script>
