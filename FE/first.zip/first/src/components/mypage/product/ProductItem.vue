<template>
  <tr>
    <td colspan="2" class="td_left">
      <div class="form_element">
        <input type="radio" name="goodsNo[]" class="radio">
        <label class="choice_s" v-bind:class="{ on: radioChecked }" @click.prevent="setChecked(product)">
          <div class="pick_add_cont">
            <span class="pick_add_img">
              <img :src="getDisImageUrl" alt="">
            </span>
            <div class="pick_add_info">
              <em>{{product.productName}} {{product.productManagementCd | dispManageCode}}{{product.optionManagementCd | dispManageCode}}</em>
            </div>
          </div>
          <!-- //pick_add_info -->
        </label>
      </div>
    </td>
    <td class="js_item_price">
      <strong>{{ getDisPrice | formatNumber }}</strong>
      원
    </td>
  </tr>
</template>

<script>
export default {
  name: 'ProductItem',
  computed: {
    radioChecked () {
      if (this.checkedProduct) {
        if (this.$route.name === 'ProductSignInInquiry' && this.checkedProduct.productNo === this.product.productNo) {
          return true
        }
        if (this.$route.name !== 'ProductSignInInquiry' && this.checkedProduct.orderNo === this.product.orderNo && this.checkedProduct.orderOptionNo === this.product.orderOptionNo) {
          return true
        }
      }
      return false
    },
    getDisImageUrl () {
      let disImageUrl = null
      if (this.pageType === 'inquiry') {
        disImageUrl = this.product.listImageUrls[0]
      } else if (this.pageType === 'review') {
        disImageUrl = this.product.imageUrl
      }
      return disImageUrl
    },
    getDisPrice () {
      let disPrice = null
      if (this.pageType === 'inquiry') {
        disPrice = this.product.salePrice
      } else if (this.pageType === 'review') {
        disPrice = this.product.price.salePrice
      }
      return disPrice
    }
  },
  props: ['product', 'checkedProduct', 'pageType'],
  methods: {
    setChecked (product) {
      product.imageUrl = this.getDisImageUrl
      this.$emit('setChecked', product)
    }
  }
}
</script>
