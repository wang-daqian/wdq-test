<template>
  <div id="lyZoom" class="layer_wrap ss_layer" v-if="openLayer">
    <div class="layer_wrap_cont">
      <!-- 메인 상품 노출 -->
      <div class="layer_ss_list">
        <div class="item_slide_horizontal">
          <ul class="slide_horizontal goods_sp">
            <slick ref="slick" :options="slickOptions">
              <li v-for="(item, index) in imageUrls" :key="index">
                <div class="ss_img">
                  <img :src="item" width="68" class="middle">
                </div>
              </li>
            </slick>
          </ul>
        </div>
      </div>
      <!-- //ly_cont -->
      <a href="#close" class="ly_close layer_close" @click.prevent="closeLayer">
        <img src="../../../assets/img/common/layer/btn_layer_close.png" alt="닫기">
      </a>
    </div>
    <!-- //layer_wrap_cont -->
  </div>
</template>

<script>
import Slick from 'vue-slick'
import $ from 'jquery'

export default {
  props: ['imageUrls', 'openLayer', 'imgStartIndex'],
  data () {
    return {
      mainImageIndex: 0,
      slickOptions: {
        draggable: false,
        autoplay: false,
        infinite: false,
        slidesToShow: 1,
        slidesToScroll: 1,
        responsive: [{
          breakpoint: 1366,
          settings: {
            slidesToShow: 1
          }
        }]
      }
    }
  },
  computed: {
    mainImage () {
      return this.imageUrls[this.mainImageIndex]
    }
  },
  components: {
    Slick
  },
  methods: {
    closeLayer () {
      this.$emit('close')
    },
    slickPrev () {
      this.mainImageIndex--
      this.mainImageIndex = this.mainImageIndex < 0 ? 0 : this.mainImageIndex
      this.$refs.slick.prev()
    },
    slickNext () {
      this.mainImageIndex++
      this.mainImageIndex = this.mainImageIndex >= this.imageUrls.length ? this.imageUrls.length - 1 : this.mainImageIndex
      this.$refs.slick.next()
    }
  },
  watch: {
    imgStartIndex () {
      this.mainImageIndex = this.imgStartIndex
    }
  },
  mounted () {
    $('#view_photo_slide .slick-prev').on('click', this.slickPrev)
    $('#view_photo_slide .slick-next').on('click', this.slickNext)
  }
}
</script>

<style>
</style>
