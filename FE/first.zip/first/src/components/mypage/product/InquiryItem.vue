<template>
  <tr style="height:50px">
    <td>{{showInquiryLabel}}</td>
    <td class="td_left">
      <div class="pick_add_cont">
        <span class="pick_add_img">
          <goods-view-link :product="inquiry">
            <img :src="inquiry.imageUrl" width="50" :alt="inquiry.productName" :title="inquiry.productName" class="middle">
          </goods-view-link>
        </span>
        <div class="pick_add_info">
          <goods-view-link :product="inquiry">
            <em class="name" style="display: block;">{{inquiry.productName}} {{inquiry.productManagementCd | dispManageCode}}</em>
          </goods-view-link>
          <em class="name" style="display: block;">
          </em>
        </div>
        <em class="name" style="display: block;">
        </em>
      </div>
      <em class="name" style="display: block;">
      </em>
    </td>
    <td class="board_tit ">
      <router-link :to="`/mypage/product/${inquiry.productNo}/inquiries/${inquiry.inquiryNo}`">
        <img src="../../../assets/img/icon/icon_board_secret.png" align="absmiddle" v-if="inquiry.secreted">
        <strong>{{inquiry.content | subContent}}</strong>
      </router-link>
    </td>
    <td>{{inquiry.registerYmdt | getStrYMDHM('.')}}</td>
    <td v-html="inquiry.answers ? '답변완료' : '답변대기'"></td>
  </tr>
</template>

<script>
import GoodsViewLink from '@/components/common/GoodsViewLink'

export default {
  name: 'InquiryItem',
  components: {
    GoodsViewLink
  },
  computed: {
    inquiryType () {
      if (this.productInquiryTypes && this.productInquiryTypes.length > 0) {
        const inquiryType = this.productInquiryTypes.find(inquiry => inquiry.value === this.inquiry.type)
        return inquiryType
      } else {
        return null
      }
    },
    showInquiryLabel () {
      return this.inquiryType ? this.inquiryType.label : ''
    }
  },
  props: ['inquiry', 'productInquiryTypes']
}
</script>
