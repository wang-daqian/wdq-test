
<template>
  <div class="date_check_box">
    <form method="get" name="frmDateSearch">
      <h3> 조회기간 </h3>
      <div class="date_check_list" data-target-name="wDate[]">
        <button style="display:none" type="button" data-value="0" @click.prevent="setCalendar('1day')" :class="{on: period=='1day'}">오늘</button>
        <button style="display:none" type="button" data-value="7" @click.prevent="setCalendar('1week')" :class="{on: period=='1week'}">7일</button>
        <button style="display:none" type="button" data-value="15" @click.prevent="setCalendar('15days')" :class="{on: period=='15days'}">15일</button>
        <button type="button" data-value="30" @click.prevent="setCalendar('1month')" :class="{on: period=='1month'}">1개월</button>
        <button type="button" data-value="90" @click.prevent="setCalendar('3months')" :class="{on: period=='3months'}">3개월</button>
        <button type="button" data-value="180" @click.prevent="setCalendar('6months')" :class="{on: period=='6months'}">6개월</button>
        <button type="button" class="oneYear" data-value="365" @click.prevent="setCalendar('1year')" :class="{on: period=='1year'}">1년</button>
      </div>
      <!-- //date_check_list class="date_check_calendar" -->
      <div class="date_check_calendar">
        <div class="card row">
          <date-picker v-click-outside="closeDatePicker" id="dateFrom" ref="dateFrom" :date="startTime" :option="option" :limit="limit" v-model="startTime" @change="changeTime"></date-picker>
          <span> ~ </span>
          <date-picker v-click-outside="closeDatePicker2" id="dateTo" ref="dateTo" :date="endTime" :option="option" :limit="limit" @change="changeTime"></date-picker>
        </div>
      </div>

      <button type="submit" class="btn_date_check" @click.prevent="getData">
        <em>조회</em>
      </button>

      <!-- //date_check_calendar -->

    </form>
  </div>
</template>
<script >
import myDatepicker from 'vue-datepicker/vue-datepicker-es6.vue'
import { getUrlParam } from '@/utils/utils'
import { addDay, getToday, addMonth } from '@/utils/dateUtils'
import ClickOutside from 'vue-click-outside'

// import $ from 'jquery'

export default {
  props: ['type'],
  directives: {
    ClickOutside
  },
  data () {
    return {
      period: '1month',
      // for Vue 2.0
      startTime: {
        time: getToday()
      },
      endTime: {
        time: getToday()
      },
      option: {
        type: 'day',
        week: ['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su'],
        month: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
        format: 'YYYY-MM-DD',
        placeholder: getToday(),
        inputStyle: {
          'display': 'inline-block',
          'padding': '4px',
          'line-height': '20px',
          'line-width': '120px',
          'font-size': '12px',
          'border': '2px solid #fff',
          'box-shadow': '0 1px 3px 0 rgba(0, 0, 0, 0.2)',
          'border-radius': '2px',
          'color': '#5F5F5F'
        },
        color: {
          header: '#ccc',
          headerText: '#f00'
        },
        buttons: {
          ok: 'Ok',
          cancel: 'Cancel'
        },
        overlayOpacity: 0.5, // 0.5 as default
        dismissible: true // as true as default
      },
      timeoption: {
        type: 'min',
        week: ['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su'],
        month: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
        format: 'YYYY-MM-DD'
      },
      multiOption: {
        type: 'multi-day',
        week: ['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su'],
        month: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
        format: 'YYYY-MM-DD'
      },
      limit: [{
        type: 'weekday',
        available: [1, 2, 3, 4, 5, 6, 0]
      },
      {
        type: 'fromto',
        from: '2016-01-01',
        to: '2030-01-01'
      }]
    }
  },
  components: {
    'date-picker': myDatepicker
  },
  methods: {
    closeDatePicker () {
      this.$refs.dateFrom.showInfo.check = false
    },
    closeDatePicker2 () {
      this.$refs.dateTo.showInfo.check = false
    },
    setCalendar (periodType) {
      this.period = periodType

      switch (periodType) {
        case '1day':
          this.startTime.time = getToday()
          this.endTime.time = getToday()
          break
        case '1week':
          this.startTime.time = addDay(getToday(), -7)
          this.endTime.time = getToday()
          break
        case '15days':
          this.startTime.time = addDay(getToday(), -15)
          this.endTime.time = getToday()
          break
        case '1month':
          this.startTime.time = addMonth(new Date(), -1)
          this.endTime.time = getToday()
          break
        case '3months':
          this.startTime.time = addMonth(new Date(), -3)
          this.endTime.time = getToday()
          break
        case '6months':
          this.startTime.time = addMonth(new Date(), -6)
          this.endTime.time = getToday()
          break
        case '1year':
          this.startTime.time = addMonth(new Date(), -12)
          this.endTime.time = getToday()
          break
        default:
          break
      }
    },
    getData () {
      let dataType = this.type
      if (dataType == null) {
        return
      }

      let startYmd = this.startTime.time
      if (startYmd === null || startYmd === '') {
        startYmd = getToday()
      }
      let endYmd = this.endTime.time
      if (endYmd === null || endYmd === '') {
        endYmd = getToday()
      }
      this.$emit('initData')
      switch (dataType) {
        case 'order':
          this.$router.push({
            path: '/mypage/orderlist',
            query: {
              type: 'ORDER',
              startYmd: startYmd,
              endYmd: endYmd
            }
          })
          break
        case 'cancel':
          this.$router.push({
            path: '/mypage/orderlist/cancellist',
            query: {
              type: 'CANCEL',
              startYmd: startYmd,
              endYmd: endYmd
            }
          })
          break
        case 'product':
          this.$router.push({
            path: 'inquiries',
            query: {
              startYmd: startYmd,
              endYmd: endYmd
            }
          })
          break
        default:
          break
      }
    },
    changeTime () {
      if (this.startTime.time > this.endTime.time) {
        let temp = this.endTime.time
        this.endTime.time = this.startTime.time
        this.startTime.time = temp
      }
      var sDate = new Date(this.startTime.time)
      var eDate = new Date(this.endTime.time)

      const yearInterval = eDate.getFullYear() - sDate.getFullYear()
      const monthInterval = (eDate.getMonth() > sDate.getMonth() ? eDate.getMonth() - sDate.getMonth() : eDate.getMonth() + 12 - sDate.getMonth())
      const dayInterval = eDate.getDate() - sDate.getDate()
      const days = parseInt(Math.abs(eDate - sDate) / 1000 / 60 / 60 / 24)
      const isToday = this.startTime.time === getToday()

      this.period = ''

      /* eslint-disable */
      if (yearInterval > 1) {
        this.period = ''
        return
      } else if (yearInterval === 1) {
        if (monthInterval === 0 && dayInterval === 0) {
          this.period = '1year'
          return
        }
      }

      if (monthInterval > 6) {
        this.period = ''
      } else if (monthInterval === 6) {
        if (dayInterval === 0) {
          this.period = '6months'
        }
      } else if (monthInterval === 3) {
        if (dayInterval === 0) {
          this.period = '3months'
        }
      } else if (monthInterval <= 1) {
        if (monthInterval === 1 && dayInterval === 0) {
          this.period = '1month'
        } else {
          if (days === 15) {
            this.period = '15days'
          } else if (days === 7) {
            this.period = '1week'
          } else if (days === 0 && isToday) {
            this.period = '1day'
          }
        }
      }
      /* eslint-enable */
    },
    initPeriodParam () {
      this.startTime.time = getToday()
      this.endTime.time = addMonth(new Date(), -1)
      this.changeTime()
    }
  },
  mounted () {
    this.startTime.time = getUrlParam('startYmd')
    this.endTime.time = getUrlParam('endYmd')

    if (!this.startTime.time && !this.endTime.time) {
      this.startTime.time = getToday()
      this.endTime.time = addMonth(new Date(), -1)
    }
    this.changeTime()
  }
}
</script>
<style>
.cov-vue-date .datepickbox .cov-datepicker {
  background: url(../../../assets/img/member/icon_calendar.png) no-repeat right
    center;
  width: 120px;
}

.cov-vue-date {
  position: relative;
}

.cov-date-body {
  position: absolute !important;
  top: 0 !important;
  left: 0 !important;
  transform: translate(0, 0) !important;
}

.datepicker-overlay {
  background: none !important;
  position: absolute !important;
  top: 31px !important;
  width: 275px !important;
  height: 340px !important;
  border: #ccc 1px solid;
}
.cov-date-monthly {
  height: 50px !important;
  background-color: #fff !important;
}
.cov-date-monthly > div {
  height: 50px !important;
}
#dateTo .cov-date-caption,
#dateFrom .cov-date-caption {
  padding: 0 !important;
}
#dateTo .cov-date-caption br,
#dateFrom .cov-date-caption br {
  display: none;
}
#dateTo .cov-date-caption span,
#dateFrom .cov-date-caption span {
  margin: 0 5px;
  line-height: 50px;
  font-size: 16px;
  color: #000;
}
.cov-picker-box {
  padding: 0 25px 0 25px !important;
  height: 240px !important;
}
.date-item {
  font-size: 16px !important;
  padding: 5px 0 !important;
}
#dateTo .cov-date-caption span small,
#dateFrom .cov-date-caption span small {
  font-size: 16px;
}

.cov-date-next::before,
.cov-date-previous::before {
  width: 12px !important;
  background: #000 !important;
  margin-top: -4px !important;
}

.cov-date-next::after,
.cov-date-previous::after {
  width: 12px !important;
  background: #000 !important;
  margin-top: 4px !important;
}

.day.checked {
  background: #000 !important;
}
</style>
