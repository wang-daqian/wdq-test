<template>
  <tr>
    <td>
      <strong>{{address.addressName}}</strong>
    </td>
    <td>{{address.receiverName}}</td>
    <td class="td_left">
      <span>({{address.receiverZipCd}})</span>{{showAddress}}
    </td>
    <td class="td_phone">
      <span class="td_phone_num">휴대전화 : {{address.receiverContact1}}</span>
      <span class="td_phone_num">연락처 : {{address.receiverContact2}}</span>
    </td>
    <td>
      <span class="btn_gray_list">
        <a href="javascript:" class="btn_gray_small btn_open_layer" data-sno="8" @click.prevent="goModify(address)">
          <span>수정</span>
        </a>
      </span>
      <span class="btn_gray_list">
        <a href="javascript:" class="btn_gray_small js_delete" data-sno="8" data-default-fl="y" @click.prevent="del()">
          <span>삭제</span>
        </a>
      </span>
    </td>
  </tr>
</template>

<script>

export default {
  name: 'Address',
  data () {
    return {
    }
  },
  computed: {
    delMessage () {
      return '나의 배송지 [' + this.address.addressName + ']을(를) 정말로 삭제하시겠습니까?'
    },
    showAddress () {
      if (this.address.receiverDetailAddress) {
        return `${this.address.receiverAddress}, ${this.address.receiverDetailAddress}`
      }
      return this.address.receiverAddress
    }
  },
  props: {
    address: {
      type: Object,
      required: true
    }
  },
  methods: {
    goModify (address) {
      this.$emit('goModify', address)
    },
    del () {
      if (confirm(this.delMessage)) {
        this.$store.dispatch('profile/delShippingAddress', this.address.addressNo).then(() => {
          this.$router.go(0)
        })
      }
    }
  }
}
</script>
