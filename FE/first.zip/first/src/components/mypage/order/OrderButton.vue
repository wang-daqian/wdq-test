<template>
  <div class="ctl_item_bottom">
    <div :class="'btn_box btn_' + option.buttonCount">
      <template v-for="button in option.buttons">
        <a href="#" v-if="button === 'CANCEL'" @click.prevent="cancelOrder" class="btn_buy_white" :key="button">취소신청</a>
        <a href="#" v-if="button === 'VIEW_DELIVERY'" @click.prevent="deliveryTracking" class="btn_buy_ok" :key="button">배송조회</a>
        <a href="#" v-if="button === 'WRITE_REVIEW' && !nonMember" @click.prevent="reviewOption" class="btn_buy_white" :class="{btn_color: reviewState}" :key="button">상품후기작성</a>
        <a href="#" v-if="button === 'CANCEL_VIEW_CLAIM_ING'" @click.prevent="showCancelDetailPopup" class="btn_buy_ok" :key="button" style="display:none">취소처리현황</a>
        <a href="#" v-if="button === 'CANCEL_VIEW_CLAIM'" @click.prevent="showCancelDetailPopup" class="btn_buy_ok" :key="button" style="display:none">취소처리결과</a>
        <a href="#" v-if="button === 'RETURN_VIEW_CLAIM_ING'" @click.prevent="showReturnDetailPopup" class="btn_buy_ok" :key="button" style="display:none">반품처리현황</a>
        <a href="#" v-if="button === 'RETURN_VIEW_CLAIM'" @click.prevent="showReturnDetailPopup" class="btn_buy_ok" :key="button" style="display:none">반품처리결과</a>
        <a href="#" v-if="button === 'RETURN'" @click.prevent="requestReturn" class="btn_buy_white" :key="button">반품신청</a>
        <a href="#" v-if="button === 'WITHDRAW_CANCEL'" @click.prevent="withdrawClaim" class="btn_buy_white" :key="button">취소철회</a>
        <a href="#" v-if="button === 'WITHDRAW_RETURN'" @click.prevent="withdrawClaimReturn" class="btn_buy_white" :key="button">반품철회</a>
        <span v-if="button === 'NOT_REFUNDABLE'" class="tbl_btn btn_disabled" :key="button">환불불가</span>
        <span v-if="button === 'FORBID_ACTION'" :key="button">-</span>
        <a href="#" v-if="button === 'DEPOSIT_WAIT'" @click.prevent="cancelAllOrder" class="btn_buy_white" :key="button">취소신청</a>
        <a href="#" v-if="button === 'CONFIRM_ORDER'" @click.prevent="confirmOrder" class="btn_buy_ok" :key="button">구매확정</a>
      </template>
      <a href="#" @click.prevent="showInquiryPopup" class="btn_buy_white" style="display:none" v-if="!nonMember">문의하기</a>
    </div>
  </div>
</template>

<script>
import { mapActions } from 'vuex'

export default {
  props: ['option', 'nonMember', 'claimNo', 'payType'],
  computed: {
    reviewState () {
      return (this.option.orderStatusType === 'BUY_CONFIRM') || (this.option.orderStatusType === 'DELIVERY_DONE' && !this.option.deliverable)
    }
  },
  methods: {
    ...mapActions('myorder', ['putClaimsWithdraw', 'getClaimResult', 'getMutiReturnClaimResult', 'postOrderClaimCancel', 'putOrderOptionConfirm']),
    ...mapActions('guestorder', ['getGuestMutiReturnClaimResult', 'putGuestClaimsWithdraw', 'postGuestOrderClaimCancel', 'putGuestOrderOptionConfirm']),

    cancelOrder () {
      if (this.payType === 'ESCROW_REALTIME_ACCOUNT_TRANSFER' || this.payType === 'ESCROW_VIRTUAL_ACCOUNT') {
        alert('에스크로 결제 건은 전체취소만 신청이 가능합니다.')
        return
      }
      const thisUrl = `${location.protocol}//${location.host}${this.$route.fullPath}`
      if (this.nonMember) {
        this.$router.push({
          path: '/nonmember/cancel/' + this.option.orderOptionNo,
          query: {
            fromUrl: thisUrl
          }
        })
      } else {
        this.$router.push({
          path: '/mypage/cancel/' + this.option.orderOptionNo,
          query: {
            fromUrl: thisUrl
          }
        })
      }
    },
    cancelAllOrder () {
      if (this.nonMember) {
        this.postGuestOrderClaimCancel({ orderNo: this.option.orderNo }).then(() => {
          alert('주문취소가 정상적으로 되었습니다.')
          this.$router.go(0)
        })
      } else {
        this.postOrderClaimCancel({ orderNo: this.option.orderNo }).then(() => {
          alert('주문취소가 정상적으로 되었습니다.')
          this.$router.go(0)
        })
      }
    },
    deliveryTracking () {
      // deliverable -> 배송안함 상품 true / false
      // 직접배송일 경우에는 무엇으로 함?
      if (this.option.deliverable && !this.option.delivery.retrieveInvoiceUrl) {
        return alert('직접배송의 경우 배송조회를 지원하지 않습니다. 판매자에게 문의해주세요. ')
      } else {
        window.open(this.option.delivery.retrieveInvoiceUrl)
      }
    },
    reviewOption () {
      const thisUrl = `${location.protocol}//${location.host}${this.$route.fullPath}`
      this.$router.push({
        path: '/mypage/product/signinreview',
        query: {
          nextUrl: thisUrl,
          optionNo: this.option.optionNo,
          orderOptionNo: this.option.orderOptionNo,
          productNo: this.option.productNo
        }
      })
    },
    requestReturn () {
      if (this.payType === 'ESCROW_REALTIME_ACCOUNT_TRANSFER' || this.payType === 'ESCROW_VIRTUAL_ACCOUNT') {
        alert('에스크로 결제 건의 반품은 고객센터에 문의해주세요.')
        return
      }
      if (this.nonMember) {
        const thisUrl = `${location.protocol}//${location.host}${this.$route.fullPath}`
        this.$router.push({
          path: '/nonmember/return/' + this.option.orderOptionNo,
          query: {
            fromUrl: thisUrl
          }
        })
      } else {
        const thisUrl = `${location.protocol}//${location.host}${this.$route.fullPath}`
        this.$router.push({
          path: '/mypage/return/' + this.option.orderOptionNo,
          query: {
            fromUrl: thisUrl
          }
        })
      }
    },
    withdrawClaim () {
      const withdrawparam = {
        orderOptionNo: this.option.orderOptionNo
      }
      if (this.nonMember) {
        this.$store.dispatch('guestorder/putGuestClaimWithdraw', withdrawparam).then(() => {
          alert('철회되었습니다.')
          window.location.href = `/nonmember/orderdetail/${this.option.orderNo}`
        })
      } else {
        this.$store.dispatch('myorder/getClaimResult', {
          claimParams: {
            orderOptionNo: this.option.orderOptionNo
          }
        }).then(ret => {
          if ((ret && ret.data.claimedOption.claimStatusType !== 'RETURN_REQUEST') && (ret && ret.data.claimedOption.claimStatusType !== 'CANCEL_REQUEST')) {
            alert('주문상품의 상태가 변경되었습니다. 확인 후 다시 시도해 주세요.')
            this.$router.push({
              path: '/mypage/orderlist/cancellist',
              query: {
                orderListTab: false
              }
            })
          } else {
            this.$store.dispatch('myorder/putOrderOptionClaimWithdraw', withdrawparam).then(() => {
              alert('철회되었습니다.')
              this.$router.push({
                path: '/mypage/orderlist',
                query: {
                  orderListTab: true
                }
              })
            })
          }
        })
      }
    },
    withdrawClaimReturn () {
      if (this.nonMember) {
        this.putGuestClaimsWithdraw(this.claimNo).then(() => {
          alert('철회되었습니다.')
          window.location.href = `/nonmember/orderdetail/${this.option.orderNo}`
        })
      } else {
        this.getMutiReturnClaimResult(this.claimNo).then(ret => {
          if ((ret && ret.data.claimedOption.claimStatusType !== 'RETURN_REQUEST') && (ret && ret.data.claimedOption.claimStatusType !== 'CANCEL_REQUEST')) {
            alert('주문상품의 상태가 변경되었습니다. 확인 후 다시 시도해 주세요.')
            this.$router.push({
              path: '/mypage/orderlist/cancellist',
              query: {
                orderListTab: false
              }
            })
          } else {
            this.putClaimsWithdraw(this.claimNo).then(() => {
              alert('철회되었습니다.')
              this.$router.push({
                path: '/mypage/orderlist',
                query: {
                  orderListTab: true
                }
              })
            })
          }
        })
      }
    },
    showCancelDetailPopup () {
      this.$emit('showCancelDetailPopup', this.option.orderOptionNo)
    },
    showReturnDetailPopup () {
      this.$emit('showReturnDetailPopup', this.option.orderOptionNo)
    },
    confirmOrder () {
      if (this.nonMember) {
        this.putGuestOrderOptionConfirm(this.option.orderOptionNo).then(() => {
          alert('구매확정 처리되었습니다.')
          this.$router.go(0)
        })
      } else {
        this.putOrderOptionConfirm(this.option.orderOptionNo).then(() => {
          alert('구매확정 처리되었습니다.')
          this.$router.go(0)
        })
      }
    }
  }
}
</script>

<style>
</style>
