<template>
  <div class="orderer_info">
    <div class="mypage_zone_tit">
      <h4>주문자 정보</h4>
    </div>

    <div class="mypage_table_type">
      <table class="table_left no_result">
        <colgroup>
          <col style="width:15%;">
          <col style="width:85%;">
        </colgroup>
        <tbody>
          <tr>
            <th scope="row">주문자 정보</th>
            <td>{{orderer.ordererName}}</td>
          </tr>
          <tr>
            <th scope="row">휴대전화</th>
            <td> {{orderer.ordererContact1}}
            </td>
          </tr>
          <tr>
            <th scope="row">연락처</th>
            <td>
              {{orderer.ordererContact2}}
            </td>
          </tr>
          <tr>
            <th scope="row">이메일</th>
            <td>{{orderer.ordererEmail}}</td>
          </tr>
          <tr>
            <th scope="row">주문 메모</th>
            <td>{{orderMemo}}</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>
<script>
import { mapState } from 'vuex'

export default {
  props: ['orderer', 'orderMemo'],
  computed: {
    ...mapState('member', ['member'])
  }
}
</script>
