<template>
  <div class="payment_info">
    <div class="mypage_zone_tit">
      <h4>결제정보</h4>
    </div>

    <div class="mypage_table_type">
      <table class="table_left no_result">
        <colgroup>
          <col style="width:15%;">
          <col style="width:85%;">
        </colgroup>
        <tbody>
          <tr>
            <th scope="row">상품 합계 금액</th>
            <td>{{order.showPriceInfo.showStandardAmt}}원</td>
          </tr>
          <tr>
            <th scope="row">배송비</th>
            <td>
              {{totalDeliveryAmt|formatNumber}}원
              <span>
                ( (배송비
                <span class="goods-mileage">{{this.order.firstOrderAmount.deliveryAmt|formatNumber}}</span>원 - 배송비쿠폰할인
                <span class="member-mileage">{{this.order.firstOrderAmount.deliveryCouponDiscountAmt|formatNumber}}</span>원) + 지역별추가배송비 {{this.order.firstOrderAmount.remoteDeliveryAmt|formatNumber}}원 )
              </span>
            </td>
          </tr>
          <tr>
            <th scope="row">할인혜택</th>
            <td class="order_cont">
              <ul class="order_benefit_list">
                <li class="order_benefit_sale">
                  <em>할인 :
                    <strong>(-) {{MyMiliForma(this.totalDiscountAmt)}}원</strong>
                    <span> (즉시할인 {{this.order.firstOrderAmount.immediateDiscountAmt|formatNumber}}원 + 추가할인 {{this.order.firstOrderAmount.additionalDiscountAmt|formatNumber}}원 + 상품쿠폰할인 {{this.order.firstOrderAmount.productCouponDiscountAmt|formatNumber}}원 + 장바구니쿠폰 할인 {{this.order.firstOrderAmount.cartCouponDiscountAmt|formatNumber}}원)
                    </span>
                  </em>
                </li>
                <li v-if="isUseMallAccumulation" class="order_benefit_mileage">
                  <em> {{showAccumulationName}} 사용 :
                    <strong>(-) {{MyMiliForma(this.order.firstOrderAmount.subPayAmt)}}{{showAccumulationUnit}}</strong>
                    <!-- <span>( 상품 {{MyMiliForma(this.order.lastOrderAmount.subPayAmt)}}{{showAccumulationUnit}} )</span> -->
                  </em>
                </li>
              </ul>
            </td>
          </tr>
          <tr>
            <th scope="row">총 결제 금액</th>
            <td>
              <strong class="total_pay_money">{{(this.order.firstOrderAmount.payAmt -this.order.firstOrderAmount.subPayAmt)|formatNumber}}원</strong>
            </td>
          </tr>
          <tr>
            <th scope="row">결제수단</th>
            <td>
              <div class="pay_with_list" v-if="this.order && this.order.payInfo">
                <template v-if="this.order.payInfo.payType==='VIRTUAL_ACCOUNT' || this.order.payInfo.payType==='ESCROW_VIRTUAL_ACCOUNT'">
                  <strong>{{showPayTypeLabel}}</strong>
                </template>
                <template v-else-if="this.order.payInfo.payType==='CREDIT_CARD' || this.order.payInfo.payType==='PAYCO'">
                  <strong>{{showPayTypeLabel}}</strong>
                  <strong>{{showCardName}}</strong>
                </template>
                <template v-else>
                  <strong>{{showPayTypeLabel}}</strong>
                  <strong>{{showBankName}}</strong>
                </template>
                <template v-if="showReceipt && showReceipt.length > 0">
                  <ul>
                    <li class="btn">
                      <a v-for="info in showReceipt" :key="info.receiptType" @click="openReceipt(info.url, info.receiptType)">
                        <span class="btn_gray_list">
                          <button type="button" class="btn_gray_mid">
                            <span>{{showBtnText(info.receiptType)}}</span>
                          </button>
                        </span>
                      </a>
                    </li>
                  </ul>
                </template>
              </div>
            </td>
          </tr>
          <tr v-if="(this.order.payInfo.payType=='VIRTUAL_ACCOUNT' || this.order.payInfo.payType=='ESCROW_VIRTUAL_ACCOUNT') && isPayWait">
            <th>입금정보</th>
            <td v-if="this.order && this.order.payInfo">
              <div class="pay_with_list">
                <ul>
                  <li>입금자명 : {{showDepositorName}}</li>
                  <li>은행명 : {{showBankName}}</li>
                  <li>입금계좌 : {{this.order.payInfo.bankInfo.account}}</li>
                  <li>입금기한 : {{this.order.payInfo.bankInfo.paymentExpirationYmdt}} </li>
                </ul>
              </div>
            </td>
          </tr>
          <!-- <tr v-if="!nonMember && isUseMallAccumulation">
            <th scope="row">적립 {{showAccumulationName}}</th>
            <td>
              <div class="saving_mileage">
                <strong>적립 예정 {{showAccumulationName}}</strong>
                <dl>
                  <dt>구매 {{showAccumulationName}}</dt>
                  <dd>{{showEarnedMileage}}{{showAccumulationUnit}}</dd>
                </dl>
                <dl>
                  <dt>총 {{showAccumulationName}}</dt>
                  <dd>{{MyMiliForma(mMileages.totalAvailableAmt)}}{{showAccumulationUnit}}</dd>
                </dl>
              </div>
            </td>
          </tr> -->
          <tr v-if="isUseMallAccumulation">
            <th scope="row">적립정보</th>
            <td class="order_cont">
              <ul class="order_benefit_list">
                <li>
                  <em> 구매확정 시
                    <strong>{{Math.ceil(this.order.accumulationAmtWhenBuyConfirm) | formatNumber}}{{showAccumulationUnit}}</strong>
                    적립
                  </em>
                </li>
              </ul>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>
import { mapState, mapGetters } from 'vuex'
import { formatCurrency } from '@/utils/stringUtils'

export default {
  props: ['order', 'nonMember'],
  computed: {
    ...mapState('member', ['mMileages']),
    ...mapGetters('common', ['showAccumulationName', 'isUseMallAccumulation', 'showAccumulationUnit']),

    totalDeliveryAmt () {
      return this.order.firstOrderAmount.deliveryAmt - this.order.firstOrderAmount.deliveryCouponDiscountAmt + this.order.firstOrderAmount.remoteDeliveryAmt
    },
    totalDiscountAmt () {
      return this.order.firstOrderAmount.immediateDiscountAmt + this.order.firstOrderAmount.additionalDiscountAmt + this.order.firstOrderAmount.productCouponDiscountAmt + this.order.firstOrderAmount.cartCouponDiscountAmt
    },
    showBankName () {
      return this.order.payInfo.bankInfo && this.order.payInfo.bankInfo.bankName
    },
    showPayTypeLabel () {
      return this.order && this.order.payTypeLabel
    },
    showCardName () {
      return this.order.payInfo.cardInfo && this.order.payInfo.cardInfo.cardName
    },
    showDepositorName () {
      return this.order.payInfo.bankInfo && this.order.payInfo.bankInfo.depositorName
    },
    showEarnedMileage () {
      return this.order.payInfo && this.order.payInfo.pointAmt > 0 ? this.order.payInfo.pointAmt : 0
    },
    isPayWait () {
      let orderStatusType = ''

      if (this.order && this.order.orderOptionsGroupByPartner && this.order.orderOptionsGroupByPartner.length > 0) {
        this.order.orderOptionsGroupByPartner.some(p => {
          if (p.orderOptionsGroupByDelivery && p.orderOptionsGroupByDelivery.length > 0) {
            p.orderOptionsGroupByDelivery.some(d => {
              if (d.orderOptions && d.orderOptions.length > 0) {
                d.orderOptions.some(o => {
                  if (o.orderStatusType === 'DEPOSIT_WAIT' || o.orderStatusType === 'PAY_WAIT') {
                    orderStatusType = o.orderStatusType
                    return true
                  }
                })
              }
              return (orderStatusType === 'DEPOSIT_WAIT' || orderStatusType === 'PAY_WAIT')
            })
          }
          return (orderStatusType === 'DEPOSIT_WAIT' || orderStatusType === 'PAY_WAIT')
        })
      }
      if (orderStatusType === 'DEPOSIT_WAIT' || orderStatusType === 'PAY_WAIT') {
        return true
      } else {
        return false
      }
    },
    showReceipt () {
      if (this.order && this.order.receiptInfos.length > 0) {
        if (this.order.payType === 'ESCROW_VIRTUAL_ACCOUNT' || this.order.payType === 'ESCROW_REALTIME_ACCOUNT_TRANSFER' || this.order.payType === 'VIRTUAL_ACCOUNT' || this.order.payType === 'REALTIME_ACCOUNT_TRANSFER') {
          let receiptInfos = []
          let cash = this.order.receiptInfos.find(r => { return r.receiptType === 'CASH_RECEIPT' })
          if (cash !== undefined && cash != null) {
            receiptInfos.push(cash)
            return receiptInfos
          }
          return this.order.receiptInfos
        }
        return null
      }
    }
  },
  methods: {
    MyMiliForma (val) {
      return formatCurrency(val)
    },
    showBtnText (type) {
      if (type === 'SALE_STATEMENT') {
        return '매출전표 출력 '
      } else if (type === 'TRADE_STATEMENT') {
        return '거래명세표 출력'
      } else if (type === 'CASH_RECEIPT') {
        return '현금영수증 출력'
      }
    },
    openReceipt (url, type) {
      window.open(url, this.showBtnText(type), 'width=490, height=600')
    }
  }
}
</script>
