<template>
  <div class="delivery_info">
    <div class="mypage_zone_tit">
      <h4>배송지 정보</h4>
    </div>

    <div class="mypage_table_type">
      <table class="table_left no_result">
        <colgroup>
          <col style="width:15%;">
          <col style="width:85%;">
        </colgroup>
        <tbody>
          <!-- <tr v-if="!nonMember">
            <th scope="row">배송지 이름</th>
            <td> {{showShippingAddress.addressName}}</td>
          </tr> -->
          <tr>
            <th scope="row">받으실 분</th>
            <td> {{showShippingAddress.receiverName}}</td>
          </tr>
          <tr>
            <th scope="row">주소</th>
            <td>
              ({{showShippingAddress.receiverZipCd}}) {{showShippingAddress.receiverAddress}} {{showShippingAddress.receiverDetailAddress}}
            </td>
          </tr>
          <tr>
            <th scope="row">휴대전화</th>
            <td>
              {{showShippingAddress.receiverContact1}}
            </td>
          </tr>
          <tr>
            <th scope="row">연락처</th>
            <td>
              {{showShippingAddress.receiverContact2}}
            </td>
          </tr>
          <tr>
            <th scope="row">배송 메모</th>
            <td>{{showDeliveryMemo}}</td>
          </tr>
        </tbody>
      </table>

    </div>
  </div>
</template>

<script>

export default {
  props: ['orderNo', 'shippingAddress', 'nonMember'],
  components: {
  },
  data () {
    return {
      updatedAddressFlag: false
    }
  },
  computed: {
    showShippingAddress () {
      let shippingAddressInput = !this.updatedAddressFlag ? this.shippingAddress : this.$refs.orderDetailAddress.shippingAddressInput
      return shippingAddressInput
    },
    showDeliveryMemo () {
      let deliveryMemoInput = !this.updatedAddressFlag ? this.shippingAddress.deliveryMemo : this.$refs.orderDetailAddress.deliveryMemoInput
      return deliveryMemoInput
    }
  },
  methods: {
    setShippingAddress () {
      this.updatedAddressFlag = true
    }
  }
}
</script>
