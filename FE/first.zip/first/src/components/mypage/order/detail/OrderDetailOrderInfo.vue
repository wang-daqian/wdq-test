 <template v-if="order && order.orderNo !== null">
  <div class="mypage_lately_info_cont">
    <!-- 주문상품 리스트 -->
    <div class="mypage_table_type">
      <table :class="order && order.orderNo !== null?'scroll_table':'no_result'">
        <colgroup>
          <col style="width:15%">
          <!-- 날짜/주문번호 -->
          <col style="width:40%">
          <!-- 상품명/옵션 -->
          <col style="width:15%">
          <!-- 상품금액/수량 -->
          <col style="width:15%">
          <!-- 주문상태 -->
          <col style="width:15%">
          <!-- 확인/리뷰 -->
        </colgroup>
        <thead>
          <tr>
            <th>날짜</th>
            <th>상품명/옵션</th>
            <th>상품금액/수량</th>
            <th>주문상태</th>
            <th>
              상태
            </th>
          </tr>
        </thead>
        <order v-if="order && order.orderNo !== null" :key="order.orderNo" :order="order" :showOrderType="'BOTH'" :nonMember="nonMember" :type="type" :notShowOrderNo="notShowOrderNo" />
      </table>
    </div>
    <!--// 주문상품 리스트 -->
  </div>
</template>

<script>
import Order from '@/components/mypage/order/Order'
export default {
  props: ['order', 'nonMember', 'type', 'notShowOrderNo'],
  components: {
    Order
  },
  methods: {

  }
}
</script>
