<template>
  <div v-if="refundInfo" class="my_order_wrap">
    <div class="my_order_content">
      <div v-if="isShowReturnAddress" class="mypage_claim_collect">
        <div class="mypage_zone_tit">
          <h4>반품수거정보</h4>
        </div>

        <div class="mypage_table_type">
          <table class="table_left">
            <colgroup>
              <col style="width:24%;">
              <col style="width:76%;">
            </colgroup>
            <tbody v-if="isBuyerDirectReturn">
              <tr>
                <th scope="row">반품수거방법</th>
                <td> {{showReturnMethods}}</td>
              </tr>
            </tbody>
            <tbody v-else>
              <tr>
                <th scope="row">반품수거방법</th>
                <td> {{showReturnMethods}}</td>
              </tr>
              <tr>
                <th scope="row">반품자명</th>
                <td>
                  {{showName}}
                </td>
              </tr>
              <tr>
                <th scope="row">수거지주소</th>
                <td>
                  {{showReturnAddress}}
                </td>
              </tr>
              <tr>
                <th scope="row">휴대전화</th>
                <td>
                  {{showContact1}}
                </td>
              </tr>
              <tr>
                <th scope="row">연락처</th>
                <td> {{showContact2}}</td>
              </tr>
              <tr>
                <th scope="row">수거시참고사항</th>
                <td>{{showNote}}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      <!-- //mypage_claim_collect -->

      <div :class="['delivery_info', {'one_w100':!isShowReturnAddress} ]">
        <div class="mypage_zone_tit">
          <h4>환불정보</h4>
        </div>

        <div class="mypage_table_type">
          <table class="table_left no_result">
            <colgroup v-if='!isShowReturnAddress'>
              <col style="width:15%;">
              <col style="width:85%;">
            </colgroup>
            <colgroup v-else>
              <col style="width:24%;">
              <col style="width:76%;">
            </colgroup>
            <tbody>
              <tr>
                <th scope="row">환불상품금액</th>
                <!-- <td> {{order.showPriceInfo.claimProductAmt}}원</td> -->
                <td> {{refundInfo.productAmtInfo.totalAmt|formatNumber}}원</td>
              </tr>
              <tr v-if="refundInfo.deliveryAmtInfo">
                <th scope="row">환불배송비</th>
                <td v-if="refundInfo.deliveryAmtInfo.totalAmt<0">
                  (-){{showClaimDeliveryAmt|formatNumber}}원
                </td>
                <td v-else-if="refundInfo.deliveryAmtInfo.totalAmt>0">
                  (+){{showClaimDeliveryAmt|formatNumber}}원
                </td>
                <td v-else>
                  0원
                </td>
              </tr>
              <tr>
                <th scope="row">환불차감금액</th>
                <td>
                  {{refundInfo.subtractionAmtInfo.totalAmt|formatNumber}}원
                </td>
              </tr>
              <tr>
                <th scope="row">환불 적립금</th>
                <td>
                  {{refundInfo.refundSubPayAmt|formatNumber}}원
                </td>
              </tr>
              <tr>
                <th scope="row">환불금액</th>
                <td>
                  {{refundInfo.refundMainPayAmt|formatNumber}}원
                </td>
              </tr>
              <tr>
                <th scope="row">환불수단</th>
                <!-- <td>{{refundInfo.refundPayType}}</td> -->
                <template v-if="this.payInfo.payType==='VIRTUAL_ACCOUNT' || this.payInfo.payType==='ESCROW_VIRTUAL_ACCOUNT'">
                  <td>{{showPayTypeLabel}}</td>
                </template>
                <template v-else-if="this.payInfo.payType==='CREDIT_CARD' || this.payInfo.payType==='PAYCO'">
                  <td>
                    <p>{{showPayTypeLabel}}</p>
                    <p>{{showCardName}}</p>
                  </td>
                </template>
                <template v-else>
                  <td>
                    <p>{{showPayTypeLabel}}</p>
                    <p>{{showBankName}}</p>
                  </td>
                </template>
              </tr>
            </tbody>
          </table>

        </div>
      </div>
      <!-- //delivery_info -->
    </div>
    <!-- //my_order_content -->
  </div>

</template>

<script>

export default {
  props: ['payInfo', 'refundInfo'],
  computed: {
    isShowReturnAddress () {
      return this.refundInfo && this.refundInfo.returnAddress
    },
    isBuyerDirectReturn () {
      if (this.refundInfo.returnWayType === 'BUYER_DIRECT_RETURN') {
        return true
      } else {
        return false
      }
    },
    showReturnMethods () {
      if (this.refundInfo.returnWayType === 'BUYER_DIRECT_RETURN') {
        return '구매자직접반품'
      } else if (this.refundInfo.returnWayType === 'SELLER_COLLECT') {
        return '판매자수거요청'
      } else {
        return ''
      }
    },
    showName () {
      return this.refundInfo.returnAddress ? this.refundInfo.returnAddress.name : ''
    },
    showReturnAddress () {
      return this.refundInfo.returnAddress ? this.refundInfo.returnAddress.addressStr : ''
    },
    showContact1 () {
      return this.refundInfo.returnAddress ? this.refundInfo.returnAddress.contact1 : ''
    },
    showContact2 () {
      return this.refundInfo.returnAddress ? this.refundInfo.returnAddress.contact2 : ''
    },
    showNote () {
      return this.refundInfo.returnAddress ? this.refundInfo.returnAddress.note : ''
    },
    showClaimDeliveryAmt () {
      return this.refundInfo.deliveryAmtInfo.totalAmt.toString().includes('-') ? this.refundInfo.deliveryAmtInfo.totalAmt.toString().replace('-', '') : this.refundInfo.deliveryAmtInfo.totalAmt
    },

    showBankName () {
      return this.payInfo && this.payInfo.bankInfo && this.payInfo.bankInfo.bankName
    },
    showPayTypeLabel () {
      // return this.refundInfo.refundPayTypeLabel
      return this.refundInfo.refundTypeLabel
    },
    showCardName () {
      return this.payInfo && this.payInfo.cardInfo && this.payInfo.cardInfo.cardName
    }
  }
}
</script>
