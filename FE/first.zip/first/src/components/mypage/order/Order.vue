<template>
  <!-- [D] 주문내역 있는 경우 -->
  <tbody>
    <template v-if="showOrderType === 'ORDER'">
      <order-option v-for="(option,index) in order.orderOptions" :optinLen="lenShowOrderOption" :showFirst="isShowFirstTr(index,'ORDER')" :key="option.orderOptionNo" :option="option" :showYmd="order.showYmd" :type="type" @showReturnDetailPopup="showReturnDetailPopup" :nonMember="nonMember" v-if="!option.claimStatusType" :showOrderType="showOrderType" :payType="order.payType" :allCancel="canAllCancel()" @showCancelDetailPopup="showCancelDetailPopup" />
    </template>
    <template v-if="showOrderType === 'CANCEL'">
      <order-option v-for="(option,index) in order.orderOptions" :optinLen="lenShowCancelOption" :showFirst="isShowFirstTr(index,'CANCEL')" :key="option.orderOptionNo" :option="option" :showYmd="order.showYmd" :type="type" :nonMember="nonMember" v-if="option.claimStatusType" :showOrderType="showOrderType" :firstReturnOrderOptionNos="withDrawClaimNos('WITHDRAW_RETURN')" :firstCancelOrderOptionNos="withDrawClaimNos('WITHDRAW_CANCEL')" :payType="order.payType" @showReturnDetailPopup="showReturnDetailPopup" @showCancelDetailPopup="showCancelDetailPopup" />
    </template>
    <template v-if="showOrderType === 'BOTH'">
      <order-option v-for="(option, index) in order.orderOptions" :optinLen="order.orderOptions.length" :showFirst="index===0" :key="option.orderOptionNo" :option="option" :nonMember="nonMember" :type="type" :showYmd="order.showYmd" :showOrderType="showOrderType" :notShowOrderNo="notShowOrderNo" :firstReturnOrderOptionNos="withDrawClaimNos('WITHDRAW_RETURN')" :firstCancelOrderOptionNos="withDrawClaimNos('WITHDRAW_CANCEL')" :payType="order.payType" :allCancel="canAllCancel()" @showReturnDetailPopup="showReturnDetailPopup" @showCancelDetailPopup="showCancelDetailPopup" />
    </template>
  </tbody>
</template>

<script>
import OrderOption from '@/components/mypage/order/OrderOption'

export default {
  data () {
    return {
    }
  },
  props: {
    order: {
      type: Object,
      required: true
    },
    showOrderType: {
      type: String,
      required: true
    },
    type: {
      type: String
    },
    nonMember: {
      type: Boolean
    },
    notShowOrderNo: {
      type: Boolean
    }
  },
  components: {
    OrderOption
  },
  computed: {
    lenShowOrderOption () {
      let len = 0

      this.order.orderOptions.forEach(Option => {
        if (!Option.claimStatusType) {
          len++
        }
      })

      return len
    },
    lenShowCancelOption () {
      let len = 0

      this.order.orderOptions.forEach(Option => {
        if (Option.claimStatusType) {
          len++
        }
      })
      return len
    },
    firstDispOrderOption () {
      let index = 0

      for (let i = 0; i < this.order.orderOptions.length; i++) {
        if (this.order.orderOptions[i].claimStatusType === null) {
          index = i
          break
        }
      }

      return index
    },
    firstDispCancelOption () {
      let index = 0

      for (let i = 0; i < this.order.orderOptions.length; i++) {
        if (this.order.orderOptions[i].claimStatusType !== null) {
          index = i
          break
        }
      }
      return index
    }
  },
  methods: {
    showAddReviewPopup (orderOption) {
      this.$emit('showAddReviewPopup', orderOption)
    },
    showCancelDetailPopup (orderOptionNo) {
      this.$emit('showCancelDetailPopup', orderOptionNo)
    },
    showReturnDetailPopup (orderOptionNo) {
      this.$emit('showReturnDetailPopup', orderOptionNo)
    },
    withDrawClaimNos (type) {
      const options = this.order.orderOptions.filter((item) => {
        return item.buttons ? item.buttons.some((btn) => btn === type) : ''
      })
      if (options.length === 0) {
        return null
      }
      let optionLen = 1
      let claimNo
      let orderOptionNo
      let withDrawOrderOptionNos = []

      for (let index = 0; index < options.length; index++) {
        claimNo = options[index].claimNo
        orderOptionNo = options[index].orderOptionNo
        optionLen = 1
        if (!withDrawOrderOptionNos.some((item) => { return item.claimNo === claimNo })) {
          for (let k = index + 1; k < options.length; k++) {
            if (claimNo === options[k].claimNo) {
              optionLen++
            }
          }
          withDrawOrderOptionNos.push({ claimNo: claimNo, orderOptionNo: orderOptionNo, optionLen: optionLen })
        }
      }
      return withDrawOrderOptionNos
    },
    isShowFirstTr (index, type) {
      if (type === 'ORDER') {
        return ((index - this.firstDispOrderOption) === 0)
      } else if (type === 'CANCEL') {
        return ((index - this.firstDispCancelOption) === 0)
      }
    },
    canAllCancel () {
      if (this.order && this.order.orderOptions) {
        let allPayDone = false
        if ((this.order.orderOptions.length > 1) || (this.order.payType === 'ESCROW_REALTIME_ACCOUNT_TRANSFER' || this.order.payType === 'ESCROW_VIRTUAL_ACCOUNT')) {
          allPayDone = !this.order.orderOptions.some((option) => {
            if (option.orderStatusType !== 'PAY_DONE' || option.claimStatusType !== null || !option.refundable) {
              return true
            }
          })
        }
        return allPayDone
      }
      return false
    }
  },
  mounted () {
  }
}
</script>
