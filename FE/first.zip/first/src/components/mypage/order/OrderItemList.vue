<template>
  <div>
    <div class="mypage_table_type">
      <table :class="orders && orders.length == 0 ? 'no_result' : 'scroll_table'">
        <colgroup>
          <col style="width:15%">
          <!-- 날짜/주문번호 -->
          <col>
          <!-- 상품명/옵션 -->
          <col style="width:15%">
          <!-- 상품금액/수량 -->
          <col style="width:15%">
          <!-- 주문상태 -->
          <col style="width:5%">
          <!-- 확인/리뷰 -->
        </colgroup>
        <thead>
          <tr>
            <th>날짜/주문번호</th>
            <th>상품명/옵션</th>
            <th>상품금액/수량</th>
            <th>주문상태</th>
            <th>상태</th>
          </tr>
        </thead>
        <template v-if="orders && orders.length > 0">
          <order v-for="order in getPageData" :key="order.orderNo" :order="order" :type="'list'" :showOrderType="'ORDER'" />
        </template>
        <template v-if="orders && orders.length === 0">
          <tr>
            <td colspan="5">
              <p class="no_data">조회내역이 없습니다.</p>
            </td>
          </tr>
        </template>
      </table>
    </div>
    <pagination v-if="totalCount>=5" :page="1" :total_count="totalCount||0" :page_size="5" :page_term="5" @onPageChange="pageChange" ref="pagination" />
  </div>
</template>

<script>
import Order from '@/components/mypage/order/Order'
import Pagination from '@/components/common/Pagination'

export default {
  props: ['orders', 'totalCount'],
  data () {
    return {
      page: 1
    }
  },
  components: {
    Order,
    Pagination
  },
  computed: {
    getPageData () {
      return this.orders.slice((this.page - 1) * 5, 5 * this.page)
    }
  },
  methods: {
    pageChange (page) {
      this.page = page
      if ((this.page - 1) % 5 === 0) {
        this.$store.dispatch('myorder/fetchMore')
      }
    },
    initData () {
      this.page = 1
    }
  }
}
</script>
