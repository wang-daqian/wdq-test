<template>
  <tr v-if="option" class="row_line">
    <td class="td_left">
      <div class="pick_add_cont">
        <span class="pick_add_img">
          <goods-view-link :product="option">
            <img :src="option.imageUrl?option.imageUrl:''" width="50" :alt="option.productName" :title="option.productName" class="middle">
          </goods-view-link>
        </span>
        <div class="pick_add_info">
          <goods-view-link :product="option">
            <em class="name" style="display: block">
              {{option.showBrandName}} {{option.productName}} {{option.optionManagementCd | dispManageCode}}
            </em>
            <span class="option">
              <template v-for="(showOption, index) in option.showOptions">
                <template v-if="index === 0">{{showOption}}</template>
                <template v-else> / {{showOption}}</template>
              </template>
              <template v-if="option.showAddPrice">
                {{option.showAddPrice}}
              </template>
            </span>
          </goods-view-link>
        </div>
      </div>
      <!-- //pick_add_info -->
    </td>
    <td>
      <strong>{{option.price.buyAmt|formatNumber}}원</strong>
      <template v-if="option.showOrderCnt">
        /{{option.showOrderCnt}}
      </template>
    </td>
    <td>
      <em>
        {{option.statusLabel}}
      </em>
      <div class="btn_gray_list" hidden>
        <a href="#" class="btn_gray_small js_btn_order_delivery">
          <span>수취확인</span>
        </a>
      </div>
    </td>

    <td>
      <strong>{{this.option.orderCnt}}</strong>
    </td>
  </tr>

</template>

<script>
import GoodsViewLink from '@/components/common/GoodsViewLink'

export default {
  data () {
    return {
      showPopFlg: false,
      quantity: this.option.orderCnt
    }
  },
  props: ['option', 'nonMember'],
  components: {
    GoodsViewLink
  },
  methods: {

  }
}
</script>
