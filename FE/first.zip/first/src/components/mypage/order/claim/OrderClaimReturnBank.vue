<template>
  <div class="mypage_claim_info" v-if="isShowBankAccountInfo">
    <div v-if="this.claimType ==='cancel'" class="mypage_zone_tit">
      <h4>취소정보</h4>
    </div>
    <div v-else class="mypage_zone_tit">
      <h4>반품정보</h4>
    </div>

    <div class="mypage_table_type">
      <table class="table_left no_result">
        <colgroup>
          <col style="width:15%;">
          <col style="width:85%;">
        </colgroup>
        <tbody>
          <tr>
            <th scope="row"> 은행 </th>
            <td class="mypage_claim_select">
              <vue-select-box :showValue="bankSelected" :items="showBankList" @selected="updateBankType" :width="seletBoxWidth" :noLeftMargin="true" />
            </td>
          </tr>
          <tr>
            <th scope="row">계좌번호</th>
            <td><input type="text" v-model="showBankAccount" name="bankAccount" @keyup="validateNumber" @keydown="validateNumber" @blur="validateNumber"></td>
          </tr>
          <tr>
            <th scope="row">예금주</th>
            <td><input type="text" v-model="bankDepositorName" name="bankDepositorName"></td>
          </tr>
        </tbody>
      </table>
      <p v-if="this.claimType ==='cancel'">
        <strong class="chk_none">결제하신 수단에 따라 취소 방법이 차이가 날 수 있습니다.</strong>
      </p>
      <p v-else>
        <strong class="chk_none ">결제하신 수단에 따라 반품 방법이 차이가 날 수 있습니다.</strong>
      </p>
    </div>

  </div>
</template>

<script>
import VueSelectBox from '@/components/common/VueSelectBox'
import { mapState } from 'vuex'
import { validateNumber, changeKoreanToEmptyString } from '@/utils/validateUtils'

export default {
  props: ['payType', 'claimType'],
  data () {
    return {
      seletBoxWidth: '240px',
      bankSelected: '',
      bankAccount: '',
      bankDepositorName: ''
    }
  },
  components: {
    VueSelectBox
  },
  computed: {
    ...mapState('common', ['malls']),

    isShowBankAccountInfo () {
      if (this.payType) {
        if (this.payType === 'ATM' || this.payType === 'ACCOUNT' || this.payType === 'REALTIME_ACCOUNT_TRANSFER' || this.payType === 'EASY_ACCOUNT' || this.payType === 'VIRTUAL_ACCOUNT' || this.payType === 'ESCROW_VIRTUAL_ACCOUNT') {
          return true
        }
        return false
      } else {
        return false
      }
    },
    inquiryTypeItems () {
      if (this.malls && this.malls.inquiryType) {
        return this.malls.inquiryType.map(type => {
          return { label: type.inquiryTypeName, value: type.inquiryTypeNo }
        })
      }
    },
    showBankList () {
      let bankItems = [{
        label: '선택하세요',
        value: ''
      }]

      if (this.malls && this.malls.bankType) {
        let items = this.malls.bankType.map(type => {
          return { label: type.name, value: type.value }
        })
        bankItems = [...bankItems, ...items]
      }

      return bankItems
    },
    showBankAccount: {
      get () {
        return this.bankAccount
      },
      set (value) {
        this.bankAccount = changeKoreanToEmptyString(value)
      }
    }
  },
  methods: {
    validateNumber (event) {
      validateNumber(event)
    },
    updateBankType (bankType) {
      this.bankSelected = bankType
    },
    getBankAccountInfo () {
      if (this.isShowBankAccountInfo) {
        if (this.bankSelected === '' || this.bankSelected === null || this.bankAccount === '' || this.bankAccount === null || this.bankDepositorName === '' || this.bankDepositorName === null) {
          return 'Error'
        } else {
          const bankAccountInfo = {
            bank: this.bankSelected,
            bankAccount: this.bankAccount,
            bankDepositorName: this.bankDepositorName
          }
          return bankAccountInfo
        }
      } else {
        return null
      }
    },
    showBankErrorAlert () {
      if (this.bankSelected === '' || this.bankSelected === null) {
        alert('은행을 선택해 주세요.')
      } else if (this.bankAccount === '' || this.bankAccount === null) {
        alert('계좌번호를 입력해 주세요.')
      } else if (this.bankDepositorName === '' || this.bankDepositorName === null) {
        alert('예금주를 입력해 주세요.')
      }
    }
  }
}
</script>
