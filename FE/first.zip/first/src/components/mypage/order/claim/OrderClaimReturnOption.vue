<template>
  <tr v-if="option" class="row_line">
    <!-- <td v-if="showFirst" :rowspan="optinLen" class="order_day_num"> -->
    <!-- <em>{{showYmd}}</em> -->
    <!-- <router-link :to="`/mypage/orderdetail/${orderNo}`" class="order_num_link">
        <span>{{orderNo}}</span>
      </router-link> -->
    <!-- </td> -->
    <td v-if="optinLen>1" class="check_td_box">
      <div class="form_element">
        <label :class="['check_s',{'on':option.checked}]" @click.prevent="checkout()" />
      </div>
    </td>
    <td class="td_left">
      <div class="pick_add_cont">
        <span class="pick_add_img">
          <goods-view-link :product="option">
            <img :src="option.imageUrl?option.imageUrl:''" width="50" :alt="option.productName" :title="option.productName" class="middle">
          </goods-view-link>
        </span>
        <div class="pick_add_info">
          <goods-view-link :product="option">
            <em class="name" style="display: block">
              {{option.showBrandName}} {{option.productName}} {{option.optionManagementCd | dispManageCode}}
            </em>
            <span class="option">
              {{option.optionTitle}}
              <template v-if="option.showAddPrice">
                {{option.showAddPrice}}
              </template>
            </span>
          </goods-view-link>
        </div>
      </div>
      <!-- //pick_add_info -->
    </td>
    <td>
      <strong>{{option.price.buyAmt|formatNumber}}원</strong>
      <template v-if="option.orderCnt>0">
        /{{option.orderCnt}}개
      </template>
    </td>
    <td>
      {{option.statusLabel}}
      <div class="btn_gray_list" hidden>
        <a href="#" class="btn_gray_small js_btn_order_delivery">
          <span>수취확인</span>
        </a>
      </div>
    </td>
    <td>
      <span class="bx_count">
        <button type="button" class="btn_minus" @click="quantity=Number(quantity)-1">
          <span class="blind">수량 1 감소</span>
        </button>
        <input title="구매수량" v-model="quantity" class="count_input" type="text" @keydown="gdNum" @input="gdNum">
        <button type="button" class="btn_plus" @click="quantity=Number(quantity)+1">
          <span class="blind">수량 1 증가</span>
        </button>
      </span>
    </td>
  </tr>

</template>

<script>
import { replacePattern } from '@/utils/validateUtils'
import { mapMutations } from 'vuex'
import GoodsViewLink from '@/components/common/GoodsViewLink'

export default {
  data () {
    return {
      showPopFlg: false,
      quantity: this.option.orderCnt
    }
  },
  props: ['option', 'nonMember', 'type', 'orderNo', 'optinLen', 'showFirst'],
  components: {
    GoodsViewLink
  },
  methods: {
    ...mapMutations('myorder', ['CHANGE_RETURN_ITEMS_SET']),
    ...mapMutations('guestorder', ['CHANGE_GUEST_RETURN_ITEMS_SET']),

    gdNum: function () {
      if (this.quantity !== '') {
        this.quantity = replacePattern(this.quantity, /[^\d]/g, '')
      }
    },
    checkout () {
      if (this.nonMember) {
        this.CHANGE_GUEST_RETURN_ITEMS_SET({ orderOptionNo: this.option.orderOptionNo, checked: !this.option.checked })
      } else {
        this.CHANGE_RETURN_ITEMS_SET({ orderOptionNo: this.option.orderOptionNo, checked: !this.option.checked })
      }
    }
  },
  watch: {
    quantity (newval, oldval) {
      if (this.quantity <= 1) {
        this.quantity = 1
      } else if (this.quantity >= this.option.orderCnt) {
        this.quantity = this.option.orderCnt
      }
      const optionData = { quantity: this.quantity, orderOptionNo: this.option.orderOptionNo }
      this.$emit('updateCnt', optionData)
    }
  }
}
</script>
