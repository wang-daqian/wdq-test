<template>
  <div class="mypage_claim_collect">
    <div class="mypage_zone_tit">
      <h4>반품수거정보</h4>
    </div>

    <div class="mypage_table_type collect_tb">
      <table class="table_left">
        <colgroup>
          <col style="width:15%;">
          <col style="width:85%;">
        </colgroup>
        <tbody>
          <tr>
            <th scope="row">
              <span class="important">반품수거방법</span>
            </th>
            <td>
              <div class="form_element">
                <ul>
                  <li>
                    <input type="radio" name="returnWayType" id="sellerCollect" value="SELLER_COLLECT" v-model="returnWayType">
                    <label for="sellerCollect" :class="returnWayType === 'SELLER_COLLECT' ? 'choice_s on' : 'choice_s'">판매자수거요청</label>
                    <input type="radio" name="returnWayType" id="buyerDirectReturn" value="BUYER_DIRECT_RETURN" v-model="returnWayType">
                    <label for="buyerDirectReturn" :class="returnWayType === 'BUYER_DIRECT_RETURN' ? 'choice_s on' : 'choice_s'" style="margin-left: 10px;">구매자직접반품</label>
                  </li>
                </ul>
                <dl class="collection">
                  <dt>반품수거안내</dt>
                  <dd>반품상황에 따라 (반품)택배비를 차감할 수 있습니다.</dd>
                  <template v-if="returnWayType === 'SELLER_COLLECT'">
                    <dd>반품신청이 완료되면 입력하신 수거지주소로 반품수거가 진행됩니다.</dd>
                    <dd>CJ택배기사가 1~2일 내에 직접 방문합니다.</dd>
                    <dd>반품등록일 오후 5시까지 접수분은 익일로 반품접수가 됩니다.</dd>
                    <dd>단, 토/일/공휴일은 다음 근무일에 처리가 됩니다.</dd>
                  </template>
                  <template v-else>
                    <dd>반품신청이 완료되면 구매자가 반품할 상품을 반품주소로 직접 보내주셔야 합니다.(착불 불가)</dd>
                    <dd>반품주소: ({{returnWarehouse.zipCd}}) {{returnWarehouse.address}} {{returnWarehouse.detailAddress}} / {{returnWarehouse.receiverName}} / {{returnWarehouse.contact}}</dd>
                  </template>
                </dl>
              </div>
            </td>
          </tr>
          <template v-if="returnWayType === 'SELLER_COLLECT'">
            <tr>
              <th scope="row">
                <span class="important">반품자명</span>
              </th>
              <td>
                <input type="text" ref="returnInfoName" v-model="showReceiverName" data-pattern="gdEngKor" maxlength="20">
              </td>
            </tr>
            <tr>
              <th scope="row">
                <span class="important">수거지주소</span>
              </th>
              <td class="member_address">
                <div class="address_postcode">
                  <input type="text" name="receiverZonecode" readonly="readonly" v-model="showReceiverZipCd" ref="receiverZipCd">
                  <input type="hidden" name="receiverZipcode">
                  <span id="receiverZipcodeText" class="old_post_code"></span>
                  <button type="button" class="btn_post_search" @click.prevent="openAddressesPopup">우편번호검색</button>
                </div>
                <div class="address_input ipt_w100">
                  <input type="text" name="receiverAddress" readonly="readonly" v-model="showReceiverAddress" ref="receiverAddress">
                  <input type="text" name="receiverAddressSub" v-model="showReceiverDetailAddress" ref="receiverDetailAddress" :style="{'margin-left':'5px'}">
                </div>
              </td>
            </tr>
            <tr>
              <th scope="row">
                <span class="important">휴대전화</span>
              </th>
              <td>
                <input type="text" id="receiverPhone" name="receiverPhone" v-model="showReceiverContact1" ref="receiverContact1" maxlength="11" @keydown="gdNum" @input="gdNum" @blur="gdNum">
              </td>
            </tr>
            <tr>
              <th scope="row">
                연락처
              </th>
              <td>
                <input type="text" id="receiverCellPhone" name="receiverCellPhone" v-model="showReceiverContact2" ref="receiverContact2" maxlength="12" @keydown="gdNumPhone" @input="gdNumPhone" @blur="gdNumPhone">
              </td>
            </tr>
            <tr>
              <th scope="row">수거시참고사항</th>
              <td class="td_last_say ipt_w100">
                <input type="text" name="orderMemo" @input="setDeliveryMemoLength " v-model="showDeliveryMemo" maxlength="50 " ref="orderMemo">
              </td>
            </tr>
          </template>
        </tbody>
      </table>
    </div>
    <address-info @closePop="closeLayer" v-if="showAddLayer" />
  </div>
</template>

<script>
import AddressInfo from '@/components/common/address/AddressInfo'
import { validateNumber, replacePattern } from '@/utils/validateUtils'

export default {
  props: ['address', 'returnWarehouse'],
  components: {
    AddressInfo
  },
  data () {
    return {
      returnWayType: 'SELLER_COLLECT',
      currentAddress: {
        receiverName: this.address ? this.address.receiverName : '',
        receiverZipCd: this.address ? this.address.receiverZipCd : '',
        receiverAddress: this.address ? this.address.receiverAddress : '',
        receiverJibunAddress: this.address ? this.address.receiverJibunAddress : '',
        receiverDetailAddress: this.address ? this.address.receiverDetailAddress : '',
        receiverContact1: this.address ? replacePattern(this.address.receiverContact1, /[^\d]/g, '') : '',
        receiverContact2: this.address ? replacePattern(this.address.receiverContact2, /[^\d]/g, '') : '',
        customsIdNumber: this.address ? this.address.customsIdNumber : '',
        deliveryMemo: this.deliveryMemo
      },
      txt: {
        deliveryMemoLength: 0
      },
      showAddLayer: false
    }
  },

  computed: {
    showReceiverName: {
      get () {
        return this.currentAddress && this.currentAddress.receiverName
      },
      set (value) {
        this.currentAddress.receiverName = value
      }
    },
    showReceiverZipCd: {
      get () {
        return this.currentAddress && this.currentAddress.receiverZipCd
      },
      set (value) {
        this.currentAddress.receiverZipCd = value
      }
    },
    showReceiverAddress: {
      get () {
        return this.currentAddress && this.currentAddress.receiverAddress
      },
      set (value) {
        this.currentAddress.receiverAddress = value
      }
    },
    showReceiverDetailAddress: {
      get () {
        return this.currentAddress && this.currentAddress.receiverDetailAddress
      },
      set (value) {
        this.currentAddress.receiverDetailAddress = value
      }
    },
    showReceiverContact1: {
      get () {
        if (this.currentAddress && this.currentAddress.receiverContact1 !== '') {
          return replacePattern(this.currentAddress.receiverContact1, /[^\d]/g, '')
        } else {
          return ''
        }
      },
      set (value) {
        this.currentAddress.receiverContact1 = value
      }
    },
    showReceiverContact2: {
      get () {
        if (this.currentAddress && this.currentAddress.receiverContact2 !== '') {
          return replacePattern(this.currentAddress.receiverContact2, /[^\d]/g, '')
        } else {
          return ''
        }
      },
      set (value) {
        this.currentAddress.receiverContact2 = value
      }
    },
    showDeliveryMemo: {
      get () {
        return this.currentAddress && this.currentAddress.deliveryMemo
      },
      set (value) {
        this.currentAddress.deliveryMemo = value
      }
    }
  },
  methods: {
    validateNumber (event) {
      validateNumber(event)
    },
    openAddressesPopup () {
      this.showAddLayer = true
      this.$store.commit('SHOW_LAYER_BG')
    },
    closeLayer (selected, address) {
      this.showAddLayer = false
      this.$store.commit('HIDDEN_LAYER_BG')
      if (selected) {
        this.callbackAddr(address)
      }
    },
    callbackAddr ({ zipCd, address, addressSub, receiverJibunAddress }) {
      this.currentAddress.receiverZipCd = zipCd
      this.currentAddress.receiverAddress = address
      this.currentAddress.receiverDetailAddress = addressSub
      this.currentAddress.receiverJibunAddress = receiverJibunAddress

      //  this.updatePaymentByAddress(address, receiverJibunAddress, zipCd)
    },
    gdNumPhone: function () {
      if (this.currentAddress.receiverContact2 !== '') {
        this.currentAddress.receiverContact2 = replacePattern(this.currentAddress.receiverContact2, /[^\d]/g, '')
      }
    },
    gdNum: function () {
      if (this.currentAddress.receiverContact1 !== '') {
        this.currentAddress.receiverContact1 = replacePattern(this.currentAddress.receiverContact1, /[^\d]/g, '')
      }
    },
    setDeliveryMemo (memo) {
      this.currentAddress.deliveryMemo = memo
      this.setDeliveryMemoLength()
    },
    setDeliveryMemoLength () {
      this.txt.deliveryMemoLength = this.currentAddress.deliveryMemo.length
    },
    isInputEffective () {
      if (this.currentAddress.receiverName === '' ||
        this.currentAddress.receiverName === null ||
        this.currentAddress.receiverZipCd === '' ||
        this.currentAddress.receiverZipCd === null ||
        this.currentAddress.receiverAddress === '' ||
        this.currentAddress.receiverAddress === null ||
        this.currentAddress.receiverContact1 === '' ||
        this.currentAddress.receiverContact1 === null ||
        this.currentAddress.receiverContact1.length < 10) {
        return false
      } else {
        return true
      }
    },
    getCollectInfo () {
      if (!this.isInputEffective() && this.returnWayType === 'SELLER_COLLECT') {
        return 'Error'
      } else {
        let returnAddress = {
          addressNo: this.address.addressNo,
          receiverName: this.currentAddress.receiverName,
          addressName: this.currentAddress.addressName,
          receiverContact1: this.currentAddress.receiverContact1,
          receiverContact2: this.currentAddress.receiverContact2,
          receiverZipCd: this.currentAddress.receiverZipCd,
          receiverAddress: this.currentAddress.receiverAddress,
          receiverJibunAddress: this.currentAddress.receiverJibunAddress,
          receiverDetailAddress: this.currentAddress.receiverDetailAddress,
          deliveryMemo: this.currentAddress.deliveryMemo || '',
          // 주소지에 있는 countryCd를 써야하나?
          countryCd: 'KR'
        }
        return returnAddress
      }
    },
    getReturnWayType () {
      return this.returnWayType
    },
    showCollectErrorAlert () {
      if (this.currentAddress.receiverName === '' || this.currentAddress.receiverName === null) {
        alert('반품자명을 입력해 주세요.')
      } else if (this.currentAddress.receiverZipCd === '' || this.currentAddress.receiverZipCd === null || this.currentAddress.receiverAddress === '' || this.currentAddress.receiverAddress === null) {
        alert('수거지주소 항목값을 입력해주세요.')
      } else if (this.currentAddress.receiverContact1 === '' || this.currentAddress.receiverContact1 === null) {
        alert('휴대전화를 입력해 주세요.')
      } else if (this.currentAddress.receiverContact1 && this.currentAddress.receiverContact1.length < 10) {
        alert('정확한 휴대전화를 입력해 주세요.')
      }
    },
    checkCollectInfoDetailAddress () {
      if (this.currentAddress.receiverDetailAddress === '' || this.currentAddress.receiverDetailAddress === null) {
        return false
      } else {
        return true
      }
    },
    showCollectDetailAddressTips () {
      if ((this.currentAddress.receiverDetailAddress === '' || this.currentAddress.receiverDetailAddress === null) && this.returnWayType === 'SELLER_COLLECT') {
        if (!confirm('상세주소를 입력하지 않고 반품하시겠습니까?')) {
          this.$refs.receiverDetailAddress.focus()
          return false
        } else {
          return true
        }
      }
      return true
    }
  }
}
</script>
