<template>
  <tr class="row_line">
    <td v-if="showFirst" :rowspan="optinLen" class="order_day_num">
      <em>{{showYmd}}</em>
      <template v-if="notShowOrderNo">
      </template>
      <template v-else>
        <router-link v-if="type === 'list'" :to="routerLinkTo" class="order_num_link">
          <span>{{option.orderNo}}</span>
        </router-link>
      </template>
      <a v-if="allCancel" href="#" class="btn_all_cancel order_num_btn" @click.prevent="cancelAllOrder">전체취소</a>
    </td>
    <td class="td_left">
      <div class="pick_add_cont">
        <span class="pick_add_img">
          <goods-view-link :product="option">
            <img :src="option.imageUrl" width="50" :alt="option.productName" :title="option.productName" class="middle">
          </goods-view-link>
        </span>
        <div class="pick_add_info">
          <goods-view-link :product="option">
            <em class="name" style="display: block">
              {{option.showBrandName}} {{option.productName}} {{option.optionManagementCd | dispManageCode}}
            </em>
            <span class="option">
              <template v-for="(showOption, index) in option.showOptions">
                <template v-if="index === 0">{{showOption}}</template>
                <template v-else> / {{showOption}}</template>
              </template>
              <template v-if="option.showAddPrice">
                {{option.showAddPrice}}
              </template>
              <!--
              <template v-if="option.showOrderCnt">
                {{option.showOrderCnt}}
              </template>
              -->
            </span>
          </goods-view-link>
        </div>
      </div>
      <!-- //pick_add_info -->
    </td>
    <td>
      <strong>{{option.showPrice}}원</strong>
      <template v-if="option.showOrderCnt">
        /{{option.showOrderCnt}}
      </template>
    </td>
    <td>
      <em>
        {{option.statusLabel}}
      </em>
      <div class="btn_gray_list" hidden>
        <a href="#" class="btn_gray_small js_btn_order_delivery">
          <span>수취확인</span>
        </a>
      </div>
    </td>
    <template v-if="isContainSpecBtn('WITHDRAW_RETURN')">
      <td class="check_btn" v-if="isFirstReturnOption()" :rowspan="mergedRowLen">
        <order-button :option="option" :nonMember="nonMember" :claimNo="option.claimNo" />
      </td>
    </template>
    <template v-else-if="isContainSpecBtn('WITHDRAW_CANCEL')">
      <td class="check_btn" v-if="isFirstCancelOption()" :rowspan="withDrawCancelRowLen">
        <order-button :option="option" :nonMember="nonMember" :claimNo="option.claimNo" />
      </td>
    </template>
    <template v-else-if="isBtnWithDepositWait()">
      <td class="check_btn" v-if="showFirst" :rowspan="optinLen">
        <order-button :option="option" :nonMember="nonMember" :payType="this.payType" />
      </td>
    </template>
    <template v-else>
      <td class="check_btn">
        <order-button :option="option" :nonMember="nonMember" @showReturnDetailPopup="showReturnDetailPopup" @showCancelDetailPopup="showCancelDetailPopup" :payType="this.payType" />
      </td>
    </template>

  </tr>

</template>

<script>
import OrderButton from '@/components/mypage/order/OrderButton'
import GoodsViewLink from '@/components/common/GoodsViewLink'

export default {
  data () {
    return {
      showPopFlg: false,
      mergedRowLen: 1,
      withDrawCancelRowLen: 1
    }
  },
  props: ['option', 'optinLen', 'showFirst', 'nonMember', 'showYmd', 'type', 'notShowOrderNo', 'firstReturnOrderOptionNos', 'firstCancelOrderOptionNos', 'payType', 'allCancel'],
  components: {
    OrderButton,
    GoodsViewLink
  },
  computed: {
    routerLinkTo () {
      if (this.nonMember) {
        return `/nonmember/orderdetail/${this.option.orderNo}`
      } else {
        return `/mypage/orderdetail/${this.option.orderNo}`
      }
    }
  },
  methods: {
    showAddReviewPopup (orderOption) {
      this.$emit('showAddReviewPopup', orderOption)
    },
    showCancelDetailPopup (orderOptionNo) {
      this.$emit('showCancelDetailPopup', orderOptionNo)
    },
    showReturnDetailPopup (orderOptionNo) {
      this.$emit('showReturnDetailPopup', orderOptionNo)
    },
    isContainSpecBtn (type) {
      if (this.option && this.option.buttons) {
        if (this.option.buttons.some((button) => button === type)) {
          return true
        }
      }
      return false
    },
    isBtnWithDepositWait () {
      if (this.option) {
        if (this.option.orderStatusType === 'DEPOSIT_WAIT') {
          return true
        }
      }
      return false
    },
    isFirstReturnOption () {
      if (this.firstReturnOrderOptionNos && this.firstReturnOrderOptionNos.length > 0) {
        const returnOrderOption = this.firstReturnOrderOptionNos.find((item) => {
          return item.orderOptionNo === this.option.orderOptionNo
        })
        if (returnOrderOption) {
          this.mergedRowLen = returnOrderOption.optionLen
          return true
        } else {
          return false
        }
      } else {
        return false
      }
    },
    isFirstCancelOption () {
      if (this.firstCancelOrderOptionNos && this.firstCancelOrderOptionNos.length > 0) {
        const cancelOrderOption = this.firstCancelOrderOptionNos.find((item) => {
          return item.orderOptionNo === this.option.orderOptionNo
        })
        if (cancelOrderOption) {
          this.withDrawCancelRowLen = cancelOrderOption.optionLen
          return true
        } else {
          return false
        }
      } else {
        return false
      }
    },
    cancelAllOrder () {
      const thisUrl = `${location.protocol}//${location.host}${this.$route.fullPath}`
      if (this.nonMember) {
        this.$router.push({
          path: '/nonmember/ordercancel/' + this.option.orderNo,
          query: {
            fromUrl: thisUrl
          }
        })
      } else {
        this.$router.push({
          path: '/mypage/ordercancel/' + this.option.orderNo,
          query: {
            fromUrl: thisUrl
          }
        })
      }
    }
  }
}
</script>

<style>
.order_day_num em {
  display: block;
}

.pick_add_info .name {
  display: block;
}
.pick_add_info .option {
  display: block;
  margin-top: 10px;
  color: #9b9b9b;
}
</style>
