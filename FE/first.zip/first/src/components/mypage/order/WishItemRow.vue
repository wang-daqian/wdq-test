<template>
  <tr v-if="product">
    <td>
      <span class="form_element">
        <label :class="['check_s',{'on':itemChecked}]" @click.prevent="checkout()">
        </label>
      </span>
    </td>
    <td class="td_left">
      <div class="pick_add_cont">
        <template v-if="product.stockCnt === 0||(product.saleStatusType !== 'READY'&&product.saleStatusType !=='ONSALE')">
          <span class="pick_add_img">
            <img :src="product.imageUrls[0]" width="150" :alt="product.productName" :title="product.productName" class="middle">
          </span>
        </template>
        <template v-else>
          <goods-view-link class="pick_add_img" :product="product">
            <img :src="product.imageUrls[0]" width="150" :alt="product.productName" :title="product.productName" class="middle">
          </goods-view-link>
        </template>

        <div class="pick_add_info">
          <template v-if="product.stockCnt === 0||(product.saleStatusType !== 'READY'&&product.saleStatusType !=='ONSALE')">
            <em>
              <template v-if="product.brandName">
                [{{product.brandName}}]
              </template>
              {{ product.productName }} {{ product.productManagementCd | dispManageCode }}
            </em>
            <p class="txtEx">
              <strong>구매불가</strong>
              <span>이 상품은 상품정보 변경 또는 재고소진으로 주문이 불가합니다.</span>
            </p>
          </template>
          <template v-else>
            <goods-view-link class="item_title" :product="product">
              <template v-if="product.brandName">
                [{{product.brandName}}]
              </template>
              {{ product.productName }} {{ product.productManagementCd | dispManageCode }}
            </goods-view-link>
          </template>
        </div>
      </div>
      <!-- //pick_add_info -->
      <!-- //pick_add_list -->
    </td>
    <td>
      <strong>{{ priceCalculate.finalSalePrice | formatNumber }}원</strong>
      <i v-if="priceCalculate.discountRate >= 1" class="saleNumber02">{{ priceCalculate.discountRate }}%</i>
      <div class="btn_gray_list" style="display:none">
        <a href="#optionViewLayer " class="btn_gray_small btn_open_layer ">
          <span>옵션/수량변경</span>
        </a>
      </div>
    </td>
    <td class="js-relative-none" style="display:none">
      <ul class="benefit_list">
        <li class="benefit_mileage" v-if="priceCalculate.discountRate !== 0">
          <em>적립</em>
          <span>상품
            <strong>{{ priceCalculate.discountRate }}%</strong>
          </span>
        </li>
      </ul>
    </td>
    <td>
      <div>
        <a href="# " class="btn_wish_cart js_cart_wish" style="display:none">
          <em>장바구니</em>
        </a>

        <a href="javascript:" class="btn_wish_del" @click="likeDeleteProduct(product.productNo)">
          <em>삭제하기</em>
        </a>
      </div>
    </td>
  </tr>
</template>

<script>
import { productPrice2 } from '@/utils/stringUtils'
import { mapMutations, mapActions } from 'vuex'
import GoodsViewLink from '@/components/common/GoodsViewLink'

export default {
  props: ['product'],
  components: {
    GoodsViewLink
  },
  data () {
    return {
      itemChecked: this.product.checked
    }
  },
  watch: {
    product: {
      handler (newValue, oldValue) {
        this.itemChecked = newValue.checked
      },
      deep: true
    }
  },
  computed: {
    priceCalculate () {
      return productPrice2(this.product.salePrice,
        this.product.additionDiscountAmt,
        this.product.immediateDiscountAmt,
        this.product.couponDiscountAmt)
    }
  },
  methods: {
    ...mapActions('wishlist', ['pageLikeProducts']),
    ...mapMutations('wishlist', ['CHANGE_WISH_ITEM_SET', 'CHANGE_WISH_ITEM_CHECKOUT_ALL']),
    ...mapActions('member', ['mySummary']),

    checkout () {
      this.itemChecked = !this.itemChecked
      this.CHANGE_WISH_ITEM_SET({ productNo: this.product.productNo, checked: this.itemChecked })
    },
    likeDeleteProduct (productNo) {
      if (confirm('상품을 삭제하시겠습니까?')) {
        this.pageLikeProducts([productNo]).then(() => {
          this.mySummary()
          this.CHANGE_WISH_ITEM_CHECKOUT_ALL(false)
        })
      }
    },
    getIconSticker (product) {
      const tempSticker = []
      if (product.stickerLabels) {
        if (product.stickerLabels.some(sticker => sticker === '기부천사')) {
          tempSticker.push('기부천사')
        }
        if (product.hasCoupons.brand || product.hasCoupons.category || product.hasCoupons.partner || product.hasCoupons.product) {
          tempSticker.push('쿠폰')
        }
        if (product.deliveryConditionType === 'FREE') {
          tempSticker.push('무료배송')
        }
      } else {
        if (product.hasCoupons.brand || product.hasCoupons.category || product.hasCoupons.partner || product.hasCoupons.product) {
          tempSticker.push('쿠폰')
        }
        if (product.deliveryConditionType === 'FREE') {
          tempSticker.push('무료배송')
        }
      }
      if (tempSticker.length === 4) {
        tempSticker.pop()
        tempSticker.pop()
      }
      if (tempSticker.length === 3) {
        tempSticker.pop()
      }
      return tempSticker
    }
  }
}
</script>
