<template>
  <div class="mypage_lately_goods">
    <div class="mypage_zone_tit">
      <h3>최근 본 상품
        <span v-if="member">{{member.memberName}}님께서 최근 본 상품입니다.</span>
      </h3>
    </div>
    <!-- //goods_list_cont -->
    <item-list :list="recentProducts" :noPromotion="true" :nodataMsg="nodataMsg"/>
  </div>
</template>

<script>
import ItemList from '@/components/goods/ItemList.vue'
export default {
  data () {
    return {
      nodataMsg: '최근 본 상품이 존재하지 않습니다.'
    }
  },
  props: ['reProducts', 'member'],
  components: {
    ItemList
  },
  computed: {
    recentProducts () {
      return this.reProducts && this.reProducts.filter((item, idx) => idx < 4)
    }
  }
}
</script>

<style>
</style>
