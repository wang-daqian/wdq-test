<template>

  <div class="mypage_order_info">
    <div class="mypage_zone_tit">
      <h3>진행 중인 주문
        <span>최근 30일 내에 진행중인 주문정보입니다.</span>
      </h3>
    </div>
    <div class="mypage_order_info_cont">
      <ol>
        <li class="">
          <b>입금대기</b>
          <strong>{{orderStatus.depositWaitCnt}}</strong>
        </li>
        <li class="">
          <b>결제완료</b>
          <strong>{{orderStatus.payDoneCnt}}</strong>
        </li>
        <li class="">
          <b>상품준비중</b>
          <strong>{{orderStatus.productPrepareCnt}}</strong>
        </li>
        <li class="">
          <b>배송준비중</b>
          <strong>{{orderStatus.deliveryPrepareCnt}}</strong>
        </li>
        <li class="">
          <b>배송중</b>
          <strong>{{orderStatus.deliveryIngCnt}}</strong>
        </li>
        <li class="">
          <b>배송완료</b>
          <strong>{{orderStatus.deliveryDoneCnt}}</strong>
        </li>
        <li class="">
          <b>구매확정</b>
          <strong>{{orderStatus.buyConfirmCnt}}</strong>
        </li>
      </ol>
      <div class="order_case_list">
        <ul>
          <li>
            <b>• 취소</b>
            <span>{{orderStatus.cancelProcessingCnt}}건</span>
          </li>
          <!-- <li>
            <b>• 교환</b>
            <span>{{orderStatus.exchangeDoneCnt}}건</span>
          </li> -->
          <li>
            <b>• 반품</b>
            <span>{{orderStatus.returnProcessingCnt}}건</span>
          </li>
        </ul>
      </div>
    </div>
    <!-- //mypage_order_info_cont -->
  </div>
</template>

<script>
export default {
  props: ['orderStatus']
}
</script>

<style>
</style>
