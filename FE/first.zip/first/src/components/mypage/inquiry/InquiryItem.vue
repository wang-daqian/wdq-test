<template>
  <tr style="height:50px">
    <td> {{inquiry.registerYmdt | getStrYMDHM('.')}} </td>
    <td> [{{inquiry.inquiryType.inquiryTypeName}}] </td>
    <td class="board_tit">
        <router-link :to="`/mypage/profile/inquiries/${inquiry.inquiryNo}`">
            <strong>{{inquiry.inquiryTitle | subContent}}</strong>
        </router-link>
    </td>
    <td v-html="inquiry.inquiryStatus === 'ANSWERED' ? '답변완료' : '답변대기'"></td>
  </tr>
</template>

<script>
import { mypageDisDate } from '@/utils/dateUtils'

export default {
  name: 'InquiryItem',
  props: ['inquiry'],
  methods: {
    formatDate (date) {
      return mypageDisDate(date, '.')
    }
  }
}
</script>
