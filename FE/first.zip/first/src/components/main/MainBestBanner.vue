<template>
  <div class="main_content_best">
    <div class="banner" :style="`background-image: url('${showImageUrl}');`" @mousemove="imageMouseover" @mouseout="imageMouseout"></div>
    <a :href="landingUrl" :target="banner.browerTargetType === 'NEW' ? '_blank' : false" @mousemove="imageMouseover" @mouseout="imageMouseout">
      <span class="best_text_off">{{banner.name}}</span>
      <span class="best_text_info">{{banner.description}}</span>
      <span class="best_text_btn">VIEW MORE</span>
    </a>
  </div>
</template>

<script>
export default {
  data () {
    return {
      showImageUrl: this.banner.imageUrl
    }
  },
  props: ['banner'],
  computed: {
    landingUrl () {
      return this.banner && ((this.banner.landingUrlType === 'EVENT' && '/event/' + this.banner.landingUrl) || this.banner.landingUrl)
    }
  },
  methods: {
    imageMouseover () {
      if (this.banner.mouseOverImageUrl != null) {
        this.showImageUrl = this.banner.mouseOverImageUrl
      }
    },
    imageMouseout () {
      this.showImageUrl = this.banner.imageUrl
    }
  }
}
</script>

<style>
</style>
