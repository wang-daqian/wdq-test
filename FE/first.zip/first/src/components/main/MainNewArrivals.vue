<template>
  <div class="main_goods_slider">
    <div class="main_goods_cont">
      <div class="goods_list main_wrap_2">
        <div class="goods_list_tit">
          <h3>NEW ARRIVALS</h3>
        </div>
        <div class="arrivals_tab_tit" v-if="pageName === 'MainHome'">
          <ul>
            <li :class="showIndex === index ? 'on' : ''" v-for="(item, index) in newArrivalsList" :key="index">
              <a href="javascript:" @click.prevent="showIndex = index">{{item.label}}</a>
            </li>
          </ul>
        </div>
        <div class="goods_list_cont goods_content_2">
          <div class="item_slide_horizontal">
            <template v-if="pageName === 'MainHome'">
              <ul class="slide_horizontal_2" v-for="(newArrivals, index) in newArrivalsList" :key="index" v-if="(index === showIndex && displayMode === 'PC') || (index === 0 && displayMode === 'MO')">
                <slick ref="slick" :options="slickOptions">
                  <li v-for="(item, index) in newArrivals.products" :key="index">
                    <div class="item_cont" style="text-align:center;">
                      <div class="item_photo_box">
                        <goods-view-link :product="item">
                          <img :src="item.imageUrls[0]" :alt="item.productName" :title="item.productName" class="middle" />
                        </goods-view-link>
                        <!-- //item_photo_box -->
                      </div>
                      <div class="item_info_cont" style="display:block; text-align: center;">
                        <div class="item_tit_box">
                          <goods-view-link :product="item">
                            <strong class="item_name" style="direction:ltr;">{{item.productName}} {{item.productManagementCd | dispManageCode}}</strong>
                          </goods-view-link>
                        </div>
                        <!-- //item_tit_box -->
                        <div class="item_money_box">
                          <del class="il_b" v-if="item.immediateDiscountAmt + item.additionDiscountAmt + item.couponDiscountAmt > 0">{{ item.salePrice | formatNumber }}원 </del>
                          <strong class="item_price il_b">
                            <span>{{ item.salePrice - item.immediateDiscountAmt - item.additionDiscountAmt - item.couponDiscountAmt | formatNumber }}원 </span>
                          </strong>
                          <i v-if="priceCalculate(item).discountRate >= 1" class="saleNumber02">{{ priceCalculate(item).discountRate }}%</i>
                        </div>
                        <div class="item_icon_box">
                        </div>
                      </div>
                    </div>
                  </li>
                </slick>
              </ul>
            </template>
            <ul class="slide_horizontal_2" v-else>
              <slick ref="slick" :options="slickOptions">
                <li v-for="(item, index) in newArrivalsList[0].products" :key="index">
                  <div class="item_cont" style="text-align:center;">
                    <div class="item_photo_box">
                      <goods-view-link :product="item">
                        <img :src="item.imageUrls[0]" :alt="item.productName" :title="item.productName" class="middle" />
                      </goods-view-link>
                      <!-- //item_photo_box -->
                    </div>
                    <div class="item_info_cont" style="display:block; text-align: center;">
                      <div class="item_tit_box">
                        <goods-view-link :product="item">
                          <strong class="item_name" style="direction:ltr;">{{item.productName}} {{item.productManagementCd | dispManageCode}}</strong>
                        </goods-view-link>
                      </div>
                      <!-- //item_tit_box -->
                      <div class="item_money_box">
                        <del class="il_b" v-if="item.immediateDiscountAmt + item.additionDiscountAmt + item.couponDiscountAmt > 0">{{ item.salePrice | formatNumber }}원 </del>
                        <strong class="item_price il_b">
                          <span>{{ item.salePrice - item.immediateDiscountAmt - item.additionDiscountAmt - item.couponDiscountAmt | formatNumber }}원 </span>
                        </strong>
                        <i v-if="priceCalculate(item).discountRate >= 1" class="saleNumber02">{{ priceCalculate(item).discountRate }}%</i>
                      </div>
                      <div class="item_icon_box">
                      </div>
                    </div>
                  </div>
                </li>
              </slick>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import GoodsViewLink from '@/components/common/GoodsViewLink'
import Slick from 'vue-slick'
import { productPrice2 } from '@/utils/stringUtils'

export default {
  props: ['displayMode', 'newArrivalsList'],
  data () {
    return {
      showIndex: 0,
      slickOptions: {
        draggable: false,
        autoplay: true,
        infinite: true,
        slidesToShow: 4,
        slidesToScroll: 1,
        responsive: [
          {
            breakpoint: 1370,
            settings: {
              centerPadding: '80px',
              centerMode: true,
              slidesToShow: 3
            }
          },
          {
            breakpoint: 770,
            settings: {
              centerPadding: '80px',
              centerMode: true,
              slidesToShow: 1
            }
          }
        ]
      }
    }
  },
  components: {
    GoodsViewLink,
    Slick
  },
  computed: {
    pageName () {
      return this.$route.name
    }
  },
  methods: {
    priceCalculate (item) {
      return productPrice2(item.salePrice,
        item.additionDiscountAmt,
        item.immediateDiscountAmt,
        item.couponDiscountAmt)
    }
  }
}
</script>

<style>
</style>
