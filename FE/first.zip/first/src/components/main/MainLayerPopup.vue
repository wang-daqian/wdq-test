<template>
  <div :class="['layerPopup', displayMode === 'PC' ? 'm-pc' : 'm-sp']">
    <div class="main_popup">
      <div class="main_popup_con" v-html="popupInfo.content">
      </div>
      <div class="main_popup_btn">
        <button type="button" class="btn_style3" @click.prevent="close('oneday')">오늘 하루 안보기</button>
        <button type="button" class="btn_style1" @click.prevent="close('close')">닫기</button>
      </div>
    </div>
  </div>
</template>

<script>
import { mapMutations } from 'vuex'
import { getToday } from '@/utils/dateUtils'
import cookies from 'js-cookie'
import $ from 'jquery'

export default {
  props: ['displayMode', 'popupInfo'],
  methods: {
    close (type) {
      if (type === 'oneday') {
        cookies.set('firstMallMainPop', getToday(), { 'max-age': (2 * 24 * 60 * 60) })
      }
      this.$emit('closePop')
    },
    ...mapMutations('display', ['CLEAR_POPUPS_INFO'])
  },
  created () {
    setTimeout(() => {
      $('body').addClass('overflow_pop_hidden')
    }, 25)
  },
  destroyed () {
    this.CLEAR_POPUPS_INFO()
    $('body').removeClass('overflow_pop_hidden')
  }
}
</script>

<style>
.overflow_pop_hidden {
  position: fixed;
  left: 0;
  width: 100%;
  /* overflow-y: scroll; */
}
</style>
