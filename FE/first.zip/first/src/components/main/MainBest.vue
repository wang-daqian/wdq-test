<template>
  <div class="main_goods_cont main_goods_tab">
    <div class="goods_list main_wrap_1">
      <div class="goods_list_tit">
        <h3>BEST</h3>
      </div>
      <div class="goods_list_cont goods_content_1">
        <div class="tab_goods_1 item_hl_tab_type">
          <div class="goods_tab_tit" v-if="pageName === 'MainHome'">
            <ul>
              <li :class="showIndex === index ? 'on' : ''" v-for="(item, index) in bestList" :key="index">
                <a href="javascript:" @click.prevent="showIndex = index">{{item.label}}</a>
              </li>
            </ul>
          </div>
          <div class="goods_tab_cont">
            <div class="goods_tab_box on">
              <template v-if="pageName === 'MainHome'">
                <ul v-for="(best, index) in bestList" :key="index" v-show="(index === showIndex && displayMode === 'PC') || (index === 0 && displayMode === 'MO')">
                  <main-best-item v-for="(item, i) in best.products" :key="i" :item="item" />
                </ul>
              </template>
              <ul v-else>
                <main-best-item v-for="(item, index) in bestList[0].products" :key="index" :item="item" />
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import MainBestItem from '@/components/main/MainBestItem'

export default {
  props: ['displayMode', 'bestList'],
  data () {
    return {
      showIndex: 0
    }
  },
  components: {
    MainBestItem
  },
  computed: {
    pageName () {
      return this.$route.name
    }
  }
}
</script>

<style>
</style>
