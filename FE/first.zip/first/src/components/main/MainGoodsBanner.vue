<template>
  <div class="main_content main_goods_banner main_content_other">
    <div class="main_goods_goods_cont">
      <div class="goods_list main_wrap_3">
        <div class="goods_list_cont goods_content_3">
          <div class="item_simple_type">
            <ul>
              <li class="sp2" v-for="(item, index) in banner1" :key="index" @mousemove="imageMouseover('BANNER1', index)" @mouseout="imageMouseout('BANNER1', index)">
                <span v-if="item.landingUrlType === 'IMAGEMAP'">
                  <slot name="top"></slot>
                  <map :name="'${index}banner1'" v-html="item.landingUrl"></map>
                  <img :usemap="'${index}banner1'" v-lazy="banner1ShowImages[index]" alt="">
                  <slot name="bottom"></slot>
                </span>
                <a v-else :href="landingUrl(item)" :target="item.browerTargetType === 'NEW' ? '_blank' : false">
                  <img v-lazy="banner1ShowImages[index]" alt="" >
                </a>
              </li>
              <li class="sp1 main_bnr" v-if="banner2" @mousemove="imageMouseover('BANNER2')" @mouseout="imageMouseout('BANNER2')">
                <span v-if="banner2.landingUrlType === 'IMAGEMAP'">
                  <slot name="top"></slot>
                  <map name="banner2" v-html="banner2.landingUrl"></map>
                  <img usemap="'banner2" v-lazy="banner2ShowImage" alt="">
                  <slot name="bottom"></slot>
                </span>
                <a v-else :href="landingUrl(banner2)" :target="banner2.browerTargetType === 'NEW' ? '_blank' : false">
                  <img v-lazy="banner2ShowImage" alt="" >
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <ul class="main_goods_banner_cont" v-if="banner3">
      <li class="slider-img right_bnr" @mousemove="imageMouseover('BANNER3')" @mouseout="imageMouseout('BANNER3')">
        <span v-if="banner3.landingUrlType === 'IMAGEMAP'">
          <slot name="top"></slot>
          <map name="banner3" v-html="banner3.landingUrl"></map>
          <img usemap="banner3" v-lazy="banner3ShowImage" alt="">
          <slot name="bottom"></slot>
        </span>
        <a v-else :href="landingUrl(banner3)" :target="banner3.browerTargetType === 'NEW' ? '_blank' : false">
          <img v-lazy="banner3ShowImage" alt="" >
        </a>
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  data () {
    return {
      banner1ShowImages: [
        this.banner1[0].imageUrl,
        this.banner1[1].imageUrl
      ],
      banner2ShowImage: this.banner2.imageUrl,
      banner3ShowImage: this.banner3.imageUrl
    }
  },
  props: ['banner1', 'banner2', 'banner3'],
  methods: {
    imageMouseover (type, index) {
      if (type === 'BANNER1' && this.banner1[index].mouseOverImageUrl) {
        this.banner1ShowImages.splice(index, 1, this.banner1[index].mouseOverImageUrl)
      }
      if (type === 'BANNER2' && this.banner2.mouseOverImageUrl) {
        this.banner2ShowImage = this.banner2.mouseOverImageUrl
      }
      if (type === 'BANNER3' && this.banner3.mouseOverImageUrl) {
        this.banner3ShowImage = this.banner3.mouseOverImageUrl
      }
    },
    imageMouseout (type, index) {
      if (type === 'BANNER1') {
        this.banner1ShowImages.splice(index, 1, this.banner1[index].imageUrl)
      }
      if (type === 'BANNER2') {
        this.banner2ShowImage = this.banner2.imageUrl
      }
      if (type === 'BANNER3') {
        this.banner3ShowImage = this.banner3.imageUrl
      }
    },
    landingUrl (bander) {
      return bander && ((bander.landingUrlType === 'EVENT' && '/event/' + bander.landingUrl) || bander.landingUrl)
    }
  }
}
</script>

<style>
</style>
