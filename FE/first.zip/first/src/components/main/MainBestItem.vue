<template>
  <li @mouseover="mouseOver = true" @mouseout="mouseOver = false">
    <goods-view-link :product="item">
      <div class="item_cont">
        <div class="item_photo_box" :style="mouseOver ? 'border: 1px solid rgb(24, 24, 24);' : ''">
          <a href="javascript:">
            <img v-lazy="item.imageUrls[0]" :alt="item.productName" :title="item.productName" class="middle" />
          </a>
          <div class="item_info_cont" :style="mouseOver ? 'width: 248px; transform: translateX(-50%); display: block;' : 'width: 248px; transform: translateX(-50%); display: none;'">
            <div class="item_tit_box">
              <a href="javascript:">
                <strong class="item_name">{{item.productName}} {{item.productManagementCd | dispManageCode}}</strong>
                <span class="item_name_explain">{{item.promotionText}}</span>
              </a>
            </div>
            <div class="item_money_box">
              <del v-if="item.immediateDiscountAmt + item.additionDiscountAmt + item.couponDiscountAmt> 0">{{ item.salePrice | formatNumber }}원</del>
              <strong class="item_price">
                <span>{{ item.salePrice - item.immediateDiscountAmt - item.additionDiscountAmt - item.couponDiscountAmt | formatNumber }}원</span>
              </strong>
              <i v-if="priceCalculate.discountRate >= 1" class="saleNumber02">{{ priceCalculate.discountRate }}%</i>
            </div>
            <div class="item_icon_box">
            </div>
          </div>
        </div>
      </div>
    </goods-view-link>
  </li>
</template>

<script>
import GoodsViewLink from '@/components/common/GoodsViewLink'
import { productPrice2 } from '@/utils/stringUtils'

export default {
  props: ['item'],
  components: {
    GoodsViewLink
  },
  data () {
    return {
      mouseOver: false
    }
  },
  computed: {
    priceCalculate () {
      return productPrice2(this.item.salePrice,
        this.item.additionDiscountAmt,
        this.item.immediateDiscountAmt,
        this.item.couponDiscountAmt)
    }
  }
}
</script>

<style>
</style>
