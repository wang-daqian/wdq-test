<template>
  <div class="main_content main_content_items">
    <div class="goods_list main_wrap_7">
      <div class="goods_list_tit">
        <h3>MD’S RECOMMEND ITEMS</h3>
      </div>
      <div class="goods_list_cont goods_content_7">
        <div class="item_gallery_type">
          <ul>
            <li v-for="(item, index) in products" :key="index">
              <div class="item_cont">
                <div class="item_photo_box">
                  <goods-view-link :product="item">
                    <img v-lazy="item.imageUrls[0]" :alt="item.productName" :title="item.productName" class="middle" />
                  </goods-view-link>
                </div>
                <div class="item_info_cont">
                  <div class="item_tit_box">
                    <goods-view-link :product="item">
                      <strong class="item_name">{{item.productName}} {{item.productManagementCd | dispManageCode}}</strong>
                      <span class="item_name_explain">{{item.promotionText}}</span>
                    </goods-view-link>
                  </div>
                  <div class="item_money_box">
                    <del v-if="item.immediateDiscountAmt + item.additionDiscountAmt + item.couponDiscountAmt> 0">{{ item.salePrice | formatNumber }}원 </del>
                    <strong class="item_price">
                      <span>{{ item.salePrice - item.immediateDiscountAmt - item.additionDiscountAmt - item.couponDiscountAmt | formatNumber }}원</span>
                    </strong>
                    <i v-if="priceCalculate(item).discountRate >= 1" class="saleNumber02">{{ priceCalculate(item).discountRate }}%</i>
                  </div>
                  <div class="item_icon_box">
                  </div>
                </div>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import GoodsViewLink from '@/components/common/GoodsViewLink'
import { productPrice2 } from '@/utils/stringUtils'

export default {
  props: ['products'],
  components: {
    GoodsViewLink
  },
  methods: {
    priceCalculate (item) {
      return productPrice2(item.salePrice,
        item.additionDiscountAmt,
        item.immediateDiscountAmt,
        item.couponDiscountAmt)
    }
  }
}
</script>
