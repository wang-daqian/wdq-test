<template>
  <div class="main_visual">
    <slick class="slider-wrap main-slider-banner-01" ref="slick" :options="slickOptions">
      <div class="slider-gradient" v-for="(item, index) in banners" :key="index" :style="{ background: `linear-gradient(to right, ${item.leftSpaceColor} 0%, ${item.leftSpaceColor} 50%, ${item.rightSpaceColor} 50%, ${item.rightSpaceColor} 50%, ${item.rightSpaceColor} 100%)`}">
        <main-slider-item :item="item" />
      </div>
    </slick>
  </div>
</template>

<script>
import Slick from 'vue-slick'
import MainSliderItem from '@/components/main/MainSliderItem'

export default {
  props: ['banners'],
  data () {
    return {
      slickOptions: {
        autoplay: true,
        dots: true,
        arrows: false,
        infinite: true,
        autoplaySpeed: 3000,
        speed: 1300,
        slidesToShow: 1,
        fade: true,
        centerMode: true,
        // variableWidth: true,
        adaptiveHeight: true,
        draggable: false
      }
    }
  },
  components: {
    Slick,
    MainSliderItem
  }
}
</script>

<style>
  .slider-gradient {
    vertical-align: top;
  }
</style>
