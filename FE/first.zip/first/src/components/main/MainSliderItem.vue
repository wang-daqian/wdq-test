<template>
  <div class="slider-img" :style="`background-image:url('${showImageUrl}');`" @mousemove="imageMouseover" @mouseout="imageMouseout">
    <template v-if="item.landingUrlType === 'IMAGEMAP'" >
      <slot name="top"></slot>
      <map :name="'${index}top'" v-html="item.landingUrl" @mousemove="imageMouseover" @mouseout="imageMouseout"></map>
      <img :usemap="'${index}top'" v-lazy="showImageUrl" alt="" >
      <slot name="bottom"></slot>
    </template>
    <a v-else :href="landingUrl" :target="item.browerTargetType === 'NEW' ? '_blank' : false">
      <img v-lazy="showImageUrl" alt="" >
    </a>
  </div>
</template>

<script>
export default {
  name: 'MainSliderItem',
  data () {
    return {
      showImageUrl: this.item.imageUrl
    }
  },
  computed: {
    landingUrl () {
      return this.item && ((this.item.landingUrlType === 'EVENT' && '/event/' + this.item.landingUrl) || this.item.landingUrl)
    }
  },
  props: ['item'],
  methods: {
    imageMouseover () {
      if (this.item.mouseOverImageUrl != null) {
        this.showImageUrl = this.item.mouseOverImageUrl
      }
    },
    imageMouseout () {
      this.showImageUrl = this.item.imageUrl
    }
  }
}
</script>
