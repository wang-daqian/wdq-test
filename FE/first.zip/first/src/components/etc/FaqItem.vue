<template>
  <li :class="{on: open}">
    <a href="#" @click.prevent="onClick">
      <span class="ico_circle" :class="{ 'txt': best }">{{ tag }}</span>
      <span class="title" v-if="faqItem">{{ faqItem.title }}</span>
      <!-- [D] 목록 닫힐 경우 문구변경 필요 (목록 열림 -> 목록 닫힘) -->
      <span class="btn">{{ open ? '목록 닫힘' : '목록 열림' }}</span>
    </a>
    <div class="area_txt" v-if="open" v-html="content"></div>
  </li>
</template>
<script>
export default {
  name: 'FaqItem',
  props: ['faqItem', 'index', 'search', 'categoryNo'],
  data () {
    return {
      open: false,
      content: ''
    }
  },
  computed: {
    tag () {
      if (this.best) {
        return 'Best ' + (this.index + 1)
      } else {
        return 'Q'
      }
    },
    best () {
      return !this.search && this.index <= 4 && this.categoryNo === 0
    }
  },
  methods: {
    onClick () {
      this.open = !this.open
      if (!this.content) {
        let params = {
          boardNo: process.env.VUE_APP_NCP_FAQ_BOARDNO,
          articleNo: this.faqItem.articleNo
        }
        this.$store.dispatch('board/boardDetail', params).then(res => {
          this.content = res.data && res.data.content
        })
      }
    }
  }
}
</script>
