<template>
  <tr>
    <td>{{idx}}</td>
    <td class="title">
      <router-link :to="`/etc/center/notice/${notice.articleNo}`">
        {{notice.title}}
      </router-link>
    </td>
    <td>{{disYmdt}}</td>
  </tr>
</template>

<script>
import { getStrDate } from '@/utils/dateUtils'

export default {
  name: 'NoticeItem',
  props: ['notice', 'idx'],
  data () {
    return {}
  },
  computed: {
    disYmdt () {
      return this.notice.modifyYmdt ? getStrDate(this.notice.modifyYmdt, '.') : getStrDate(this.notice.registerYmdt, '.')
    }
  }
}
</script>
