import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import { sync } from 'vuex-router-sync'
import './filters'
import { scriptLoader } from '@/utils/utils'
import { directive } from '@/directives'
import VueLazyload from 'vue-lazyload'

Vue.config.productionTip = false
sync(store, router)
Vue.use(VueLazyload)
new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
directive()
Promise.all([
  scriptLoader(process.env.VUE_APP_NCP_API_BASE_URL + 'search/' + process.env.VUE_APP_NCP_SEARCH_JS)
])
