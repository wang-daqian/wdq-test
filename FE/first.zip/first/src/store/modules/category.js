import { getPathName } from '@/utils/utils'

export default {
  namespaced: true,
  state: {
    categories: null
  },
  actions: {
    async fetchCategories ({ state, dispatch }) {
      await dispatch('common/fetchMalls', {}, { root: true }).then(malls => {
        state.categories = malls.categories.multiLevelCategories
      })
      return state.categories
    }
  },
  getters: {
    getBrandInfo: (state) => ({ brandNo, brandName }) => {
      if (state.categories) {
        if (brandNo) {
          return state.categories.find(item => item.categoryNo === Number(brandNo))
        } else if (brandName) {
          if (brandName === 'FrenchCat') {
            return state.categories.find(item => item.label === 'FRENCH CAT')
          } else if (brandName === 'Tiffany') {
            return state.categories.find(item => item.label === 'TIFFANY')
          } else if (brandName === 'Elecone') {
            return state.categories.find(item => item.label === 'ELECONE')
          } else if (brandName === 'GuessKids') {
            return state.categories.find(item => item.label === 'GUESS KIDS')
          } else if (brandName === 'Nubaby') {
            return state.categories.find(item => item.label === 'NUBABY')
          }
        }
        return state.categories.find(item => item.label === 'HOME')
      }
    },
    getListMenu: (state) => (noList) => {
      if (state.categories && noList && noList.length > 1) {
        const listMenu = []
        const depth1Menu = []
        const depth2Menu = []
        const depth3Menu = []
        const root = state.categories.find(item => item.categoryNo === Number(noList[0]))
        root && root.children && root.children.forEach(depth1 => {
          let tempDepth1 = {
            categoryNo: depth1.categoryNo,
            link_to: `/${getPathName(root.label)}/categorylist/${root.categoryNo}/${depth1.categoryNo}`,
            label: depth1.label,
            selected: depth1.categoryNo === Number(noList[1])
          }
          if (depth1.categoryNo === Number(noList[1]) && depth1.children) {
            depth1.children.forEach(depth2 => {
              const tempDepth2 = {
                categoryNo: depth2.categoryNo,
                link_to: `/${getPathName(root.label)}/categorylist/${root.categoryNo}/${depth1.categoryNo}/${depth2.categoryNo}`,
                label: depth2.label,
                selected: depth2.categoryNo === Number(noList[2])
              }
              if (depth2.categoryNo === Number(noList[2]) && depth2.children) {
                depth2.children.forEach(depth3 => {
                  const tempDepth3 = {
                    categoryNo: depth3.categoryNo,
                    link_to: `/${getPathName(root.label)}/categorylist/${root.categoryNo}/${depth1.categoryNo}/${depth2.categoryNo}/${depth3.categoryNo}`,
                    label: depth3.label,
                    selected: depth3.categoryNo === Number(noList[3])
                  }
                  depth3Menu.push(tempDepth3)
                })
                tempDepth2.children = depth3Menu
              }
              depth2Menu.push(tempDepth2)
            })
            tempDepth1.children = depth2Menu
          }
          depth1Menu.push(tempDepth1)
        })
        listMenu.push({
          selectItem: depth1Menu.find(item => item.selected),
          items: depth1Menu
        })
        if (noList[2]) {
          listMenu.push({
            selectItem: depth2Menu.find(item => item.selected),
            items: depth2Menu
          })
        }
        if (noList[3]) {
          listMenu.push({
            selectItem: depth3Menu.find(item => item.selected),
            items: depth3Menu
          })
        }
        return listMenu
      }
    },
    mainBestCategory (state, getters, rootState) {
      if (state.categories) {
        const mainBestCategory = []
        if (rootState.route.params.brandNo) {
          const temp = state.categories.find(item => item.categoryNo === Number(rootState.route.params.brandNo))
          mainBestCategory.push(temp)
          mainBestCategory.push(...temp.children)
        } else {
          mainBestCategory.push(state.categories.find(item => item.label === 'HOME'))
          mainBestCategory.push(...state.categories.filter(item => item.label !== 'HOME'))
        }
        return mainBestCategory
      }
    }
  },
  mutations: {
  }
}
