import { createNcpApiStore } from '@/api'

const apiStore = createNcpApiStore([
  {
    action: '_delOnlyFirstApperal',
    property: 'delOnlyFirstApperal',
    path: 'profile/data',
    method: 'delete'
  },
  {
    action: '_checkPassword',
    property: 'checkPassword',
    path: 'profile/check-password',
    method: 'post'
  },
  {
    action: '_authentications',
    property: 'authenticationRes',
    path: 'authentications',
    method: 'post'
  },
  {
    action: '_certiAuthentications',
    property: 'certiAuthentications',
    path: 'authentications',
    method: 'get'
  }
])

export default {
  namespaced: true,
  mixins: [apiStore],
  actions: {
    // 핑다몰만 탈퇴
    delOnlyFirstApperal ({ dispatch }, reasonData) {
      return dispatch('_delOnlyFirstApperal', { params: { reason: reasonData } })
    },
    // 비밀번호 확인
    checkPassword ({ dispatch }, passwordData) {
      return dispatch('_checkPassword', { data: { password: passwordData } })
    },
    authentications ({ commit, dispatch, state }, payload) {
      return dispatch('_authentications', { data: payload })
    },
    certiAuthentications ({ commit, dispatch, state }, playload) {
      return dispatch('_certiAuthentications', { params: { notiAccount: playload.notiAccount, memberNo: playload.memberNo, usage: playload.usage, type: playload.type, certificatedNumber: playload.certificatedNumber } })
    }
  },
  mutations: {
  }
}
