import { createNcpApiStore } from '@/api'
import Vue from 'vue'
import { gaEventViewPromotion } from '@/utils/gaEventUtils'

const apiStore = createNcpApiStore([
  {
    action: 'fetch',
    property: 'event',
    path: 'display/events/{eventNo}?saleStatus=ONSALE&order=ADMIN_SETTING',
    pathParams: ['eventNo']
  },
  {
    action: 'fetchOtherEvent',
    property: 'otherEvent',
    path: 'display/events'
  }
])

export default {
  namespaced: true,
  mixins: [apiStore],
  actions: {
    async fetchEventDetail ({ state, commit, dispatch }, eventNo) {
      await dispatch('fetch', { params: { eventNo, hasMaxCouponAmt: true } }).then(() => {
        /** gtag.js */
        gaEventViewPromotion(state.event)
      })
      await commit('FORMAT_DATAS')
    }
  },
  mutations: {
    FORMAT_DATAS (state) {
      if (state.event) {
        const sectionMenu = []
        if (state.event.section && state.event.section.length > 0) {
          state.event.section.forEach((item) => {
            if (item.products && item.products.length > 0) {
              sectionMenu.push(item)
            }
          })
          Vue.set(state.event, 'sectionMenu', sectionMenu)
        }
      }
    }
  }
}
