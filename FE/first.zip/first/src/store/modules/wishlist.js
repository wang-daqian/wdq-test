import { createNcpApiStore } from '@/api'
import { getDateFormatYMDHM } from '@/utils/dateUtils'
import { isLogin } from '@/utils/utils'

const defaultParams = {
  'pageNumber': 1,
  'pageSize': 10,
  'hasTotalCount': true,
  'hasMaxCouponAmt': true
}

const apiStore = createNcpApiStore([
  {
    action: '_fetchLikeProducts',
    property: 'likeProducts',
    path: 'profile/like-products',
    method: 'get',
    queryParams: true,
    onSuccess (state, payload) {
      payload.data.items.forEach(element => {
        element.saleStartYmdt = getDateFormatYMDHM(element.saleStartYmdt)
        element.checked = false
      })
      state.likeProducts = [...state.likeProducts || [], ...payload.data.items]
      state.totalCount = payload.data.totalCount
    }
  },
  {
    action: '_postLikeProducts',
    property: 'result',
    path: 'profile/like-products',
    method: 'post'
  }
])

export default {
  namespaced: true,
  state: {
    fetchListParams: {},
    totalCount: 0,
    loading: true,
    checkAll: false
  },
  mixins: [apiStore],
  actions: {
    async fetchLikeProducts ({ state, dispatch, commit }) {
      if (!isLogin()) {
        return
      }
      commit('RESET_LIST')
      commit('SET_PARAMS')
      await dispatch('_fetchLikeProducts', { params: state.fetchListParams })
    },
    async postLikeProducts ({ dispatch }, productNos) {
      await dispatch('_postLikeProducts', { data: { productNos } })
    },
    async pageLikeProducts ({ state, dispatch, commit }, productNos) {
      await dispatch('_postLikeProducts', { data: { productNos } })
      commit('RESET_LIST')
      commit('SET_PARAMS')
      await dispatch('_fetchLikeProducts', { params: state.fetchListParams })
    },
    getLikeProductsMore ({ state, dispatch, commit }) {
      commit('SET_PARAMS', {
        pageNumber: (state.fetchListParams.pageNumber + 1)
      })
      return dispatch('_fetchLikeProducts', { params: state.fetchListParams }).then(() => {
        if (state.likeProducts.length >= state.likeProducts.totalCount) {
          state.loading = false
        }
      })
    }
  },
  getters: {
    likeProductNos (state) {
      if (state.likeProducts && state.likeProducts.items) {
        return state.likeProducts.items.map((item) => item.productNo)
      }
      return []
    }
  },
  mutations: {
    SET_PARAMS (state, params) {
      state.fetchListParams = {
        ...state.fetchListParams,
        ...params
      }
    },
    RESET_LIST (state) {
      state.likeProducts = []
      state.totalCount = 0
      state.loading = true
      state.fetchListParams = defaultParams
      state.checkAll = false
    },
    CHANGE_WISH_ITEM_CHECKOUT_ALL (state, checked) {
      state.checkAll = checked
      state.likeProducts.forEach((item) => {
        item.checked = checked
      })
    },
    CHANGE_WISH_ITEM_SET (state, { productNo, checked }) {
      const product = state.likeProducts.find(item => item.productNo === productNo)
      if (product) {
        product.checked = checked
        state.checkAll = !state.likeProducts.some((citem) => {
          return !citem.checked
        })
      }
    }
  }
}
