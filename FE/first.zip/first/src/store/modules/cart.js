import { createNcpApiStore } from '@/api'
import { isLogin } from '@/utils/utils'
import qs from 'qs'
import { makeOrderProductOptionDeliveryPrice } from '@/utils/orderUtils'

const apiStore = createNcpApiStore([
  {
    action: '_getCart',
    property: 'cart',
    path: 'cart'
  },
  {
    action: '_getGuestCart',
    property: 'cart',
    path: 'guest/cart',
    method: 'post'
  },
  {
    action: '_calculate',
    property: 'calculate',
    path: 'cart/calculate',
    method: 'get',
    requestConfig: {
      paramsSerializer: params => qs.stringify(params, { arrayFormat: 'repeat' })
    }
  },
  {
    action: '_calcGuestCart',
    property: 'calculate',
    path: 'guest/cart',
    method: 'post'
  },
  {
    action: '_addCart',
    property: 'addcount',
    path: 'cart',
    method: 'post'
  },
  {
    action: '_countCart',
    property: 'count',
    path: 'cart/count',
    onSuccess (state, payload) {
      state.count = payload.data.count
    }
  },
  {
    action: '_deleteCart',
    property: 'delcount',
    path: 'cart',
    method: 'delete',
    requestConfig: {
      paramsSerializer: params => qs.stringify(params, { arrayFormat: 'repeat' })
    }
  },
  {
    action: '_updateCart',
    property: 'result',
    path: 'cart',
    method: 'put'
  }
])

export default {
  namespaced: true,
  mixins: [apiStore],
  state: {
    checkAll: false,
    checkedOptions: [],
    cartItems: null,
    invalidCartItems: null,
    cartPrice: {
      totalItemPrice: 0,
      totalDiscountAmt: 0,
      totalShippingCost: 0,
      paymentAmount: 0,
      accumulationAmtWhenBuyConfirm: 0
    }
  },
  actions: {
    async fetchCart ({ state, commit, dispatch, rootState, rootGetters }) {
      if (isLogin()) {
        await dispatch('_getCart')
      } else {
        const items = JSON.parse(window.localStorage.cartInfo || '[]')
        if (items.length > 0) {
          await dispatch('_getGuestCart', { data: items })
        } else {
          state.cart = {}
        }
      }
      commit('INIT_CART_ITEM_DATA', commit)
      await dispatch('calculate')
    },
    async addToCart ({ dispatch }, carts) {
      if (isLogin()) {
        await dispatch('_addCart', { data: carts })
      } else {
        const preItems = JSON.parse(window.localStorage.cartInfo || '[]')
        preItems.push(...carts)
        window.localStorage.cartInfo = JSON.stringify(preItems)
      }
      return dispatch('fetchCartCount')
    },
    fetchCartCount ({ state, dispatch }) {
      if (isLogin()) {
        dispatch('_countCart')
      } else {
        const items = JSON.parse(window.localStorage.cartInfo || '[]')
        if (items.length > 0) {
          state.count = items.length
        } else {
          state.count = 0
        }
      }
    },
    async deleteCartByCartNos ({ state, dispatch }, cartNo) {
      if (isLogin()) {
        await dispatch('_deleteCart', { params: { cartNo } })
      } else {
        const items = JSON.parse(window.localStorage.cartInfo || '[]')
        window.localStorage.cartInfo = JSON.stringify(
          items.filter(item => {
            return !cartNo.some(cartNo => cartNo === item.cartNo)
          })
        )
      }
      state.checkAll = false
      dispatch('fetchCart')
      dispatch('fetchCartCount')
    },
    async putCarts ({ dispatch }, carts) {
      if (isLogin()) {
        await dispatch('_updateCart', { data: carts })
      } else {
        const items = JSON.parse(window.localStorage.cartInfo || '[]')
        items.forEach(item => {
          carts.forEach(option => {
            if (item.cartNo === option.cartNo) {
              item.orderCnt = option.orderCnt
            }
          })
        })
        window.localStorage.cartInfo = JSON.stringify(items)
      }
      await dispatch('calculate')
    },
    async calculate ({ state, commit, dispatch }) {
      const checkedCartItems = state.checkedOptions.filter(item => !item.isInvalid)
      if (checkedCartItems && checkedCartItems.length > 0) {
        if (isLogin()) {
          commit('CHECK_CART_ITEM')
          const nos = checkedCartItems.map(item => item.cartNo)
          await dispatch('_calculate', { params: { cartNo: nos } })
          if (state.calculate) {
            state.cartPrice.totalItemPrice = state.calculate.standardAmt
            state.cartPrice.accumulationAmtWhenBuyConfirm = state.calculate.accumulationAmtWhenBuyConfirm
            state.cartPrice.totalDiscountAmt = state.calculate.discountAmt
            state.cartPrice.totalShippingCost = state.calculate.totalPrePaidDeliveryAmt
            state.cartPrice.paymentAmount = state.calculate.totalAmt
          }
        } else {
          await dispatch('_calcGuestCart', { data: checkedCartItems })
          if (state.calculate) {
            state.cartPrice.totalItemPrice = state.calculate.price.standardAmt
            state.cartPrice.totalDiscountAmt = state.calculate.discountAmt
            state.cartPrice.accumulationAmtWhenBuyConfirm = state.calculate.price.accumulationAmtWhenBuyConfirm
            state.cartPrice.totalShippingCost = state.calculate.price.totalPrePaidDeliveryAmt
            state.cartPrice.paymentAmount = state.calculate.price.totalAmt
          }
        }
      } else {
        state.cartPrice.totalItemPrice = 0
        state.cartPrice.totalDiscountAmt = 0
        state.cartPrice.accumulationAmtWhenBuyConfirm = 0
        state.cartPrice.totalShippingCost = 0
        state.cartPrice.paymentAmount = 0
      }
    }
  },
  getters: {
  },
  mutations: {
    INIT_CART_ITEM_DATA (state, commit) {
      state.cartItems = []
      state.invalidCartItems = []
      if (state.cart) {
        if (state.cart.deliveryGroups && state.cart.deliveryGroups.length) {
          state.cart.deliveryGroups.forEach((deliveryGroup) => {
            const item = {
              deliveryAmt: deliveryGroup.deliveryAmt,
              deliveryPayType: 'PAY_ON_DELIVERY',
              products: []
            }
            deliveryGroup.orderProducts.forEach((product, productIdx) => {
              product.orderProductOptions.forEach((option, optionIdx) => {
                makeOrderProductOptionDeliveryPrice(product, option, productIdx, optionIdx, deliveryGroup)

                item.products.push({
                  checked: true,
                  cartNo: option.cartNo,
                  imageUrl: product.imageUrl,
                  brandNameEn: product.brandNameEn,
                  productNo: option.productNo,
                  productName: product.productName,
                  optionNo: option.optionNo,
                  optionTitle: option.optionTitle,
                  addPrice: option.price.addPrice,
                  orderCnt: option.orderCnt,
                  // accumulationAmt: option.accumulationAmtWhenBuyConfirm + option.accumulationAmtWhenWriteReview,
                  accumulationAmt: option.accumulationAmtWhenBuyConfirm,
                  immediateDiscountAmt: option.price.immediateDiscountAmt,
                  additionalDiscountAmt: option.price.additionalDiscountAmt,
                  discountAmt: option.price.immediateDiscountAmt + option.price.additionalDiscountAmt,
                  buyAmt: (option.price.salePrice + option.price.addPrice) - (option.price.immediateDiscountAmt + option.price.additionalDiscountAmt),
                  standardAmt: option.price.standardAmt,
                  salePrice: option.price.salePrice,
                  optionManagementCd: option.optionManagementCd,
                  bundledFlg: option.bundledFlg,
                  bundledFirst: option.bundledFirst,
                  bundledSize: option.bundledSize,
                  deliverable: option.deliverable,
                  free: option.free,
                  showShippingFee: option.showShippingFee,
                  deliveryPayType: option.deliveryPayType,
                  refundable: product.refundable
                })
              })
            })
            state.cartItems.push(item)
          })
        }

        if (state.cart.invalidProducts && state.cart.invalidProducts.length) {
          state.cart.invalidProducts.forEach((product, productIdx) => {
            product.orderProductOptions.forEach((option, optionIdx) => {
              makeOrderProductOptionDeliveryPrice(product, product, productIdx, optionIdx)

              state.invalidCartItems.push({
                checked: false,
                cartNo: option.cartNo,
                imageUrl: product.imageUrl,
                brandNameEn: product.brandNameEn,
                productNo: option.productNo,
                productName: product.productName,
                optionNo: option.optionNo,
                optionTitle: option.optionTitle,
                addPrice: option.price.addPrice,
                orderCnt: option.orderCnt,
                // accumulationAmt: option.accumulationAmtWhenBuyConfirm + option.accumulationAmtWhenWriteReview,
                accumulationAmt: option.accumulationAmtWhenBuyConfirm,
                immediateDiscountAmt: option.price.immediateDiscountAmt,
                additionalDiscountAmt: option.price.additionalDiscountAmt,
                discountAmt: option.price.immediateDiscountAmt + option.price.additionalDiscountAmt,
                buyAmt: (option.price.salePrice + option.price.addPrice) - (option.price.immediateDiscountAmt + option.price.additionalDiscountAmt),
                standardAmt: option.price.standardAmt,
                salePrice: option.price.salePrice,
                optionManagementCd: option.optionManagementCd,
                bundledFlg: option.bundledFlg,
                bundledFirst: option.bundledFirst,
                bundledSize: option.bundledSize,
                deliverable: option.deliverable,
                free: option.free,
                showShippingFee: option.showShippingFee,
                deliveryPayType: option.deliveryPayType,
                errMessage: option.validInfo.errorCode === 'THIS_PRODUCT_CAN_NOT_USE_CART' ? '이 상품은 장바구니에 담을 수 없습니다. 상품상세에서 바로 구매해 주세요.' : '이 상품은 상품정보 변경 또는 재고 소진으로 주문이 불가합니다.'
              })
            })
          })
        }
        state.checkAll = state.cart.invalidProducts && state.cart.invalidProducts.length === 0 && state.cartItems && state.cartItems.length > 0
        commit('CHECK_CART_ITEM')
      }
    },
    CHECK_CART_ITEM (state) {
      state.checkedOptions = []
      state.cartItems.forEach((item) => {
        item.products.forEach((option) => {
          if (option.checked) {
            state.checkedOptions.push({
              cartNo: option.cartNo,
              productNo: option.productNo,
              optionNo: option.optionNo,
              orderCnt: option.orderCnt,
              isInvalid: false
            })
          }
        })
      })
      state.invalidCartItems.forEach((option) => {
        if (option.checked) {
          state.checkedOptions.push({
            cartNo: option.cartNo,
            productNo: option.productNo,
            optionNo: option.optionNo,
            orderCnt: option.orderCnt,
            isInvalid: true,
            errMessage: option.errMessage
          })
        }
      })
    },
    CHANGE_CART_ITEM_SET (state, { cartNo, optionNo, checked, orderCnt, isInvalid }) {
      if (isInvalid) {
        const invalidItem = state.invalidCartItems.find(sitem => sitem.optionNo === optionNo && sitem.cartNo === cartNo)
        if (invalidItem) {
          invalidItem.checked = checked
          invalidItem.orderCnt = orderCnt
        }
      } else {
        state.cartItems.forEach((item) => {
          const product = item.products.find(sitem => sitem.optionNo === optionNo && sitem.cartNo === cartNo)
          if (product) {
            product.checked = checked
            product.orderCnt = orderCnt
          }
        })
      }
      const cartItemChecked = !state.cartItems.some((citem) => {
        return citem.products.some(sitem => !sitem.checked)
      })
      const invalidItemChecked = !state.invalidCartItems.some((citem) => !citem.checked)
      state.checkAll = cartItemChecked && invalidItemChecked
      if (!isLogin()) {
        const checkedCartItems = state.checkedOptions.filter(item => !item.isInvalid)
        const tempOption = checkedCartItems.find(item => item.cartNo === cartNo)
        if (tempOption) {
          tempOption.orderCnt = orderCnt
        }
      }
    },
    CHANGE_CART_ITEM_CHECKOUT_ALL (state, checked) {
      state.checkAll = checked
      state.cartItems.forEach((item) => {
        item.products.forEach(sitem => {
          sitem.checked = checked
        })
      })
      state.invalidCartItems.forEach(sitem => {
        sitem.checked = checked
      })
    },
    CLEAR_CART_ITEM (state) {
      state.cartItems = []
      state.invalidCartItems = []
    }
  }
}
