import { createNcpApiStore } from '@/api'
import cookies from 'js-cookie'

const defaultParams = {
  'pageNumber': 1,
  'pageSize': 10,
  'hasTotalCount': true
}

const apiStore = createNcpApiStore([
  {
    action: '_memberInformation',
    property: 'member',
    path: 'profile',
    pathParams: ['get']
  },
  {
    action: '_mySummary',
    property: 'mySummary',
    path: 'profile/summary',
    pathParams: ['get']
  },
  {
    action: '_mileage',
    property: 'mMileages',
    path: 'profile/accumulations/summary',
    method: 'get'
  },
  {
    action: '_mileageItem',
    property: 'mileageItmes',
    path: 'profile/accumulations',
    method: 'get',
    queryParams: true,
    onSuccess (state, payload) {
      state.mileageItmes = [...state.mileageItmes || [], ...payload.data.items]
      state.totalMileageCount = payload.data.totalCount
    }
  },
  {
    action: '_checkMemberId',
    property: 'idCheckRes',
    path: 'profile/id/exist',
    method: 'get'
  },
  {
    action: '_passwordByEmail',
    property: 'certificateSms',
    path: 'profile/password/no-authentication/certificated-by-email',
    method: 'put'
  },
  {
    action: '_passwordBySms',
    property: 'certificateSms',
    path: 'profile/password/no-authentication/certificated-by-sms',
    method: 'put'
  },
  {
    action: '_searchAccount',
    property: 'account',
    path: 'profile/password/search-account',
    method: 'get'
  }
])

export default {
  namespaced: true,
  state: {
    fetchMileageListParams: {},
    totalMileageCount: null,
    loading: true,
    certType: '',
    certificationNumber: '',
    searchMemberId: ''
  },
  mixins: [apiStore],
  actions: {
    async memberInformation ({ state, commit, dispatch }) {
      if (cookies.get('1ST_APPERAL_TOKEN') && cookies.get('1ST_APPERAL_TOKEN').length > 0) {
        await dispatch('_memberInformation')
        cookies.set('ncpMemberId', state.member.memberId)
        cookies.set('ncpOauthIdNo', state.member.oauthIdNo)
        cookies.set('memberStatus', state.member.memberStatus)
        cookies.set('ncpCertificated', state.member.principalCertificated)
        cookies.set('memberName', state.member.memberName)
      }
    },
    mySummary ({ state, commit, dispatch }) {
      return dispatch('_mySummary')
    },

    mileAge ({ state, commit, dispatch }) {
      return dispatch('_mileage')
    },
    mileAgeItems ({ state, commit, dispatch }) {
      commit('RESET_LIST')
      commit('SET_PARAMS')
      return dispatch('_mileageItem', { params: state.fetchMileageListParams })
    },
    async fetchMileageMore ({ state, dispatch, commit, rootState }, payload) {
      commit('SET_PARAMS', {
        pageNumber: state.fetchMileageListParams.pageNumber + 1
      })
      await dispatch('_mileageItem', { params: state.fetchMileageListParams })
      if (state.mileageItmes.length >= state.totalCount) {
        state.loading = false
      }
    },
    async checkIdExist ({ commit, dispatch, state }, memberId) {
      let params = {}
      params.memberId = memberId
      await dispatch('_checkMemberId', { params: params })
    },
    searchAccount ({ dispatch }, memberId) {
      return dispatch('_searchAccount', { params: { memberId } })
    },
    passwordReset ({ dispatch }, { type, certificationNumber, memberId, newPassword }) {
      if (type === 'email') {
        return dispatch('_passwordByEmail', { data: { certificationNumber, memberId, newPassword } })
      } else if (type === 'sms') {
        return dispatch('_passwordBySms', { data: { certificationNumber, memberId, newPassword } })
      }
    }
  },
  getters: {

  },
  mutations: {
    RESET_LIST (state) {
      state.mileageItmes = null
      state.totalMileageCount = null
      state.loading = true
      state.fetchMileageListParams = defaultParams
    },
    SET_PARAMS (state, params) {
      state.fetchMileageListParams = {
        ...state.fetchMileageListParams,
        ...params
      }
    },
    SET_CERTTYPE (state, type) {
      state.certType = type
    },
    SET_NUMBER (state, certificationNumber) {
      state.certificationNumber = certificationNumber
    },
    SET_MEMBERID (state, searchMemberId) {
      state.searchMemberId = searchMemberId
    }
  }
}
