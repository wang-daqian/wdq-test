import { createNcpApiStore } from '@/api'
import { isLogin } from '@/utils/utils'

const apiStore = createNcpApiStore([
  {
    action: '_getRecent',
    property: 'reProducts',
    path: 'profile/recent-products',
    method: 'get'
  },
  {
    action: '_addRecent',
    property: 'recent',
    path: 'profile/recent-products',
    method: 'post'
  }
])

export default {
  namespaced: true,
  mixins: [apiStore],
  actions: {
    async fetchRecent ({ dispatch }) {
      if (!isLogin()) {
        return
      }
      await dispatch('_getRecent', { params: { hasMaxCouponAmt: true } })
    },
    async addRecent ({ dispatch }, { productNo }) {
      if (!isLogin()) {
        return
      }
      await dispatch('_addRecent', { data: { productNo } })
    }
  }
}
