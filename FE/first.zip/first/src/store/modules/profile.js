import { createNcpApiStore } from '@/api'
import cookies from 'js-cookie'
import ncpApi from '@/api/ncpApi'

const apiStore = createNcpApiStore([
  {
    action: '_signUp',
    property: 'profile',
    path: 'profile',
    method: 'post',
    onSuccess (state, payload) {
      state.profile = payload.data
      alert('회원가입이 완료되었습니다.')
      window.location.href = '/'
    }
  },
  {
    action: '_change',
    property: 'profile',
    path: 'profile',
    method: 'put',
    version: '1.1'
  },
  {
    action: '_fetch',
    property: 'profile',
    path: 'profile',
    method: 'get'
  },
  {
    action: '_signUpOpenid',
    property: 'profile',
    path: 'profile/openid',
    method: 'post'
  },
  {
    action: '_delProfile',
    property: 'delResult',
    path: 'profile',
    method: 'delete'
  },
  {
    action: '_syncProfile',
    property: 'sync',
    path: 'profile/payco/sync',
    method: 'put'
  },
  {
    action: '_updateProfile',
    property: 'profile',
    path: 'profile',
    method: 'put',
    version: '1.1'
  },
  {
    action: '_paycoSync',
    property: 'profile',
    path: 'profile/payco/sync',
    method: 'put'
  },
  {
    action: '_memberLogin',
    property: 'memberLogin',
    path: 'oauth/token',
    method: 'post',
    onSuccess (state, payload) {
      if (payload.data) {
        ncpApi.defaults.headers.accessToken = payload.data.accessToken
        if (payload.data.dormantMemberResponse) {
          cookies.set('1ST_APPERAL_dormantMember', payload.data.dormantMemberResponse)
        } else {
          cookies.set('1ST_APPERAL_TOKEN', payload.data.accessToken, payload.data.expireIn)
        }
      }
      // this.syncGuestDataToMember()
    },
    onError (state, payload) {
      state.memberLogin = {}
      state.memberLogin.code = payload.data.code
      state.memberLogin.error = true
      // alert(payload.data.message)
    }
  },
  {
    action: '_memberLoginWithoutSet',
    property: 'memberLoginWithoutSet',
    path: 'oauth/token',
    method: 'post'
  },
  {
    action: '_shippingAddress',
    property: 'profile',
    path: 'profile/shipping-addresses',
    method: 'post'
  },
  {
    action: '_fetchAllAddress',
    property: 'addresses',
    path: 'profile/shipping-addresses',
    method: 'get'
  },
  {
    action: '_shippingAddressModify',
    property: 'profile',
    path: 'profile/shipping-addresses/{addressNo}',
    pathParams: ['addressNo'],
    method: 'put'
  },
  {
    action: '_delShippingAddress',
    property: 'profile',
    path: 'profile/shipping-addresses/{addressNo}',
    pathParams: ['addressNo'],
    method: 'delete'
  },
  {
    action: '_findid',
    property: 'memberIdInfo',
    path: 'profile/id',
    method: 'get'
  },
  {
    action: '_memberFetchNonMasking',
    property: 'profileNonMasking',
    path: 'profile/non-masking',
    method: 'post'
  },
  {
    action: '_changeFreeze',
    path: 'profile/dormancy',
    method: 'put'
  }
])

export default {
  namespaced: true,
  mixins: [apiStore],
  state: {
    redirectUrl: ''
  },
  actions: {
    async signUp ({ commit, dispatch, rootState }, payload) {
      await dispatch('_signUp', { data: payload.registParams })
      const registerParams = {
        memberId: payload.registParams.memberId,
        password: payload.registParams.password
      }
      const loginParams = {
        redirect: payload.redirect,
        loginParams: registerParams
      }
      dispatch('memberLogin', loginParams)
    },
    change ({ dispatch }, payload) {
      return dispatch('_change', { data: payload.changeParams })
    },
    async memberLogin ({ state, commit, dispatch }, params) {
      await dispatch('_memberLogin', { data: params.loginParams })
      commit('REDIRECT_URL', params.redirect)
    },
    async memberLoginWithoutSet ({ dispatch }, loginParams) {
      await dispatch('_memberLoginWithoutSet', { data: loginParams })
    },
    async memberStatusChange ({ commit, dispatch, state, rootState }, shopAdChecked) {
      if (rootState.memberStatus !== 'ACTIVE') {
        const requestBody = shopAdChecked ? {
          directMailAgreed: true,
          smsAgreed: true
        } : { nodata: '' }
        await dispatch('_signUpOpenid', { data: requestBody })
      }
      await dispatch('_syncProfile')
      await dispatch('memberFetch')
    },
    async memberFetch ({ commit, dispatch, state, route, rootGetters }) {
      if (cookies.get('1ST_APPERAL_TOKEN') && cookies.get('1ST_APPERAL_TOKEN').length > 0) {
        await dispatch('_fetch')
        cookies.set('ncpMemberId', state.profile.memberId)
        cookies.set('ncpOauthIdNo', state.profile.oauthIdNo)
        cookies.set('memberStatus', state.profile.memberStatus)
        cookies.set('ncpCertificated', state.profile.principalCertificated)
        cookies.set('memberName', state.profile.memberName)
      }
    },
    async delProfile ({ commit, dispatch, state }, { reason }) {
      await dispatch('_delProfile', { params: { reason: reason || '회원 탈퇴' } })
    },
    async updateProfile ({ commit, dispatch, state }, { smsAgreed, directMailAgreed }) {
      await dispatch('_updateProfile', { data: { smsAgreed, directMailAgreed } })
    },
    async paycoSync ({ commit, dispatch, state }) {
      await dispatch('_paycoSync')
      return dispatch('memberFetch')
    },
    shippingAddress ({ dispatch }, addressParams) {
      return dispatch('_shippingAddress', { data: addressParams })
    },
    fetchAllAddress ({ dispatch }) {
      return dispatch('_fetchAllAddress')
    },
    shippingAddressModify ({ dispatch }, aParams) {
      return dispatch('_shippingAddressModify', { params: { addressNo: aParams.addressNo }, data: aParams.addressParams })
    },
    delShippingAddress ({ dispatch }, addressNo) {
      return dispatch('_delShippingAddress', { params: { addressNo: addressNo } })
    },
    findId ({ dispatch }, { memberName, mobileNo }) {
      return dispatch('_findid', { params: { memberName, mobileNo } })
    },
    memberFetchNonMasking ({ dispatch }, passwordData) {
      return dispatch('_memberFetchNonMasking', { data: { password: passwordData } })
    },
    async changeFreeze ({ dispatch }, params) {
      await dispatch('_changeFreeze', { data: params })
    }
  },
  mutations: {
    REDIRECT_URL (state, redirectUrl) {
      state.redirectUrl = redirectUrl
    }
  },
  getters: {
    boardInquireInfo (state) {
      if (state.profile) {
        const memberInfo = {}
        let memberId = state.profile.memberId
        let telephoneNo = state.profile.telephoneNo
        if (memberId) {
          memberInfo.memberId = memberId
        }
        if (telephoneNo) {
          if (telephoneNo.indexOf('-') > -1) {
            let telephoneArry = telephoneNo.split('-')
            memberInfo.telephoneNo1 = telephoneArry[0]
            memberInfo.telephoneNo2 = telephoneArry[1]
            memberInfo.telephoneNo3 = telephoneArry[2]
            memberInfo.telephoneNoflg = true
          }
        } else {
          memberInfo.telephoneNoflg = false
        }
        return memberInfo
      }
    }
  }
}
