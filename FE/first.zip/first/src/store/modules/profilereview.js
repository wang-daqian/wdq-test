import { createNcpApiStore } from '@/api'

const apiStore = createNcpApiStore([
  {
    action: '_fetchProduct',
    property: 'product',
    path: 'products/{productNo}',
    pathParams: ['productNo'],
    method: 'get'
  },
  {
    action: '_getReviewProducts',
    path: 'profile/order-options/product-reviewable',
    property: 'reviewProducts',
    method: 'get',
    onSuccess (state, payload) {
      state.reviewProducts = [...state.reviewProducts || [], ...payload.data.items]
      state.reviewProductstotalCount = payload.data.totalCount
    }
  },
  {
    action: '_postProductReview',
    path: 'products/{productNo}/product-reviews',
    pathParams: ['productNo'],
    method: 'post'
  },
  {
    action: '_getProductReviews',
    path: 'profile/product-reviews',
    property: 'reviews',
    method: 'get',
    onSuccess (state, payload) {
      state.reviews = [...state.reviews || [], ...payload.data.items]
      state.totalCount = payload.data.totalCount
    }
  },
  {
    action: '_getProductReview',
    path: 'products/{productNo}/product-reviews/{reviewNo}',
    property: 'review',
    pathParams: ['productNo', 'reviewNo'],
    method: 'get'
  },
  {
    action: '_delProductReview',
    path: 'products/{productNo}/product-reviews/{reviewNo}',
    property: 'review',
    pathParams: ['productNo', 'reviewNo'],
    method: 'delete'
  },
  {
    action: '_putProductReview',
    path: 'products/{productNo}/product-reviews/{reviewNo}',
    property: 'review',
    pathParams: ['productNo', 'reviewNo'],
    method: 'put'
  }
])

const defaultParams = {
  'pageNumber': 1,
  'pageSize': 5,
  'hasTotalCount': true
}

export default {
  namespaced: true,
  mixins: [apiStore],
  state: {
    fetchListParams: null,
    totalCount: null
  },
  actions: {
    fetchProduct ({ dispatch }, productNo) {
      return dispatch('_fetchProduct', { params: { productNo } })
    },
    async getReviewProducts ({ state, dispatch, commit }) {
      commit('RESET_LIST')
      await dispatch('_getReviewProducts', { params: state.fetchListParams })
    },
    async getReviewProductsMore ({ state, dispatch, commit }) {
      commit('SET_PARAMS', {
        'pageNumber': state.fetchListParams.pageNumber + 1
      })
      await dispatch('_getReviewProducts', { params: state.fetchListParams })
    },
    postProductReview ({ dispatch }, params) {
      return dispatch('_postProductReview', { data: params, params: { productNo: params.productNo } })
    },
    async getProductReviews ({ state, dispatch, commit }) {
      commit('RESET_LIST')
      await dispatch('_getProductReviews', { params: state.fetchListParams })
    },
    async getProductReviewsMore ({ state, dispatch, commit }) {
      commit('SET_PARAMS', {
        'pageNumber': state.fetchListParams.pageNumber + 1
      })
      await dispatch('_getProductReviews', { params: state.fetchListParams })
    },
    getProductReview ({ dispatch }, { to }) {
      dispatch('_getProductReview', { params: { productNo: to.params.productNo, reviewNo: to.params.reviewNo } })
    },
    delProductReview ({ dispatch }, params) {
      return dispatch('_delProductReview', { params: { productNo: params.productNo, reviewNo: params.reviewNo } })
    },
    putProductReview ({ dispatch }, params) {
      return dispatch('_putProductReview', { data: params, params: { productNo: params.productNo, reviewNo: params.reviewNo } })
    }
  },
  mutations: {
    SET_PARAMS (state, params) {
      state.fetchListParams = {
        ...state.fetchListParams,
        ...params
      }
    },
    RESET_LIST (state) {
      state.reviews = null
      state.totalCount = null
      state.fetchListParams = defaultParams
      state.reviewProducts = null
    }
  }
}
