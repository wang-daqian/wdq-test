import { createNcpApiStore } from '@/api'
import qs from 'qs'
import cookies from 'js-cookie'
import { isIE } from '@/utils/utils'

const defaultParams = {
  'order.by': 'POPULAR',
  'order.direction': 'DESC',
  'pageNumber': 1,
  'pageSize': 20,
  'hasTotalCount': true,
  'hasMaxCouponAmt': true
}

const apiStore = createNcpApiStore([
  {
    action: 'fetchList',
    property: 'list',
    path: 'products/search',
    method: 'get',
    queryParams: true,
    onSuccess (state, payload) {
      state.list = [...state.list || [], ...payload.data.items]
      state.totalCount = payload.data.totalCount

      state.categoryListBk = state.list
      state.totalCountBk = state.totalCount
    },
    requestConfig: {
      paramsSerializer: params => qs.stringify(params, { arrayFormat: 'repeat' })
    }
  },
  {
    action: 'fetchListBrand',
    property: 'listBrand',
    path: 'products/search',
    method: 'get',
    queryParams: true,
    onSuccess (state, payload) {
      state.listBrand = [...state.listBrand || [], ...payload.data.items]
      state.totalBrandCount = payload.data.totalCount
    },
    requestConfig: {
      paramsSerializer: params => qs.stringify(params, { arrayFormat: 'repeat' })
    }
  }
])

export default {
  namespaced: true,
  mixins: [apiStore],
  state: {
    fetchListParams: {},
    totalCount: null,
    noNeedRefresh: false,
    categoryListBk: [],
    totalCountBk: null,
    initSortType: null,
    initSortTypeStr: null,
    initPageSize: null,
    listBrand: [],
    totalBrandCount: null,
    fetchBrandListParams: {}
  },
  actions: {
    async fetchSearch ({ state, dispatch, commit }, { to }) {
      let keyword = to.query.q || ''
      let orderBy = 'POPULAR'
      let orderDirection = 'DESC'
      const sortTypes = state.initSortTypeStr ? state.initSortTypeStr.split(':') : null
      if (sortTypes && sortTypes[0] !== null) {
        orderBy = sortTypes[0]
        orderDirection = sortTypes[1]
      }
      commit('CLEAR_LIST')
      commit('RESET_PARAMS')
      commit('SET_PARAMS', {
        'order.by': orderBy,
        'order.direction': orderDirection,
        'filter.keywords': keyword
      })
      await dispatch('fetchList', { params: state.fetchListParams })
    },

    async fetchListByCategory ({ state, dispatch, commit }, { to }) {
      let categoryNo = to.params.depth3 || to.params.depth2 || to.params.depth1 || to.params.brandNo
      categoryNo = categoryNo || null
      let isShowBk = false
      if (isIE()) {
        let params = cookies.get('fetchListParams') ? JSON.parse(cookies.get('fetchListParams')) : null
        isShowBk = params && params.categoryNos && (params.categoryNos === categoryNo)
      } else {
        isShowBk = history.state && history.state.categoryNos && (history.state.categoryNos === state.fetchListParams.categoryNos)
      }

      if (isShowBk) {
        dispatch('showBKCategoryData', { categoryNo })
      } else {
        dispatch('showFetchListByCategory', { categoryNo })
      }
    },

    // It needs show original postion of category list when back form view detail, so show backup data.
    // But IE has some strange errors in different versions,so distinct from other explores
    // IE used cookies for special process and others used normal history
    async showBKCategoryData ({ state, dispatch, commit }, categoryNo) {
      let params = null
      if (isIE()) {
        params = cookies.get('fetchListParams') ? JSON.parse(cookies.get('fetchListParams')) : null
      } else {
        params = history.state
      }

      if (state.categoryListBk) {
        commit('BK_DATA_TO_DISP')
      } else {
        commit('RESET_PARAMS')
        commit('SET_PARAMS', {
          'order.by': params['order.by'],
          'order.direction': params['order.direction'],
          'categoryNos': categoryNo,
          'pageNumber': params.pageNumber
        })
        await dispatch('fetchList', { params: state.fetchListParams })

        cookies.remove('fetchListParams')
      }
    },
    async showFetchListByCategory ({ state, dispatch, commit }, { categoryNo }) {
      commit('CLEAR_BK_PARAMS')
      commit('CLEAR_LIST')
      commit('RESET_PARAMS')
      commit('SET_PARAMS', {
        'order.by': 'MD_RECOMMEND',
        'order.direction': 'ASC',
        'categoryNos': categoryNo
      })
      await dispatch('fetchList', { params: state.fetchListParams })
      if (isIE()) {
        cookies.set('fetchListParams', state.fetchListParams)
      } else {
        history.replaceState(state.fetchListParams, null, document.URL)
      }
    },

    async fetchListByCategoryKeyword ({ state, dispatch, commit }, params) {
      let categoryNo = params.categoryNo ? params.categoryNo : null
      let keyword = params.keyword ? params.keyword : null

      let orderBy = 'MD_RECOMMEND'
      let orderDirection = 'ASC'
      const sortTypes = state.initSortTypeStr ? state.initSortTypeStr.split(':') : null
      if (sortTypes && sortTypes[0] !== null) {
        orderBy = sortTypes[0]
        orderDirection = sortTypes[1]
      }
      commit('CLEAR_LIST')
      commit('RESET_PARAMS')
      commit('SET_PARAMS', {
        'order.by': orderBy,
        'order.direction': orderDirection,
        'filter.keywords': keyword,
        'categoryNos': categoryNo
      })

      await dispatch('fetchList', { params: state.fetchListParams })
    },

    async fetchMore ({ state, dispatch, commit }) {
      commit('SET_PARAMS', {
        'pageNumber': state.fetchListParams.pageNumber + 1
      })
      await dispatch('fetchList', { params: state.fetchListParams })
      if (isIE()) {
        cookies.set('fetchListParams', state.fetchListParams)
      } else {
        history.replaceState(state.fetchListParams, null, document.URL)
      }
    },

    async filterList ({ state, dispatch, commit }, { keyInReFlg, keywordInResult, pageSize, sortType, categoryNo, freeFlg, priceFlg, minPrice, maxPrice, isBkData }) {
      commit('CLEAR_LIST')
      let params = {
        'pageNumber': 1
      }
      if (freeFlg) {
        params = {
          ...params,
          'filter.deliveryConditionType': freeFlg
        }
      }

      if (keyInReFlg) {
        params = {
          ...params,
          'filter.keywordInResult': keywordInResult
        }
      }
      if (pageSize) {
        params.pageSize = pageSize
      }
      if (sortType) {
        const sortTypes = sortType.split(':')
        params = {
          ...params,
          'order.by': sortTypes[0],
          'order.direction': sortTypes[1]
        }
      }
      if (categoryNo === 0 || categoryNo === '0') {
        params.categoryNos = null
      } else if (categoryNo) {
        params.categoryNos = categoryNo
      }
      if (priceFlg) {
        if (minPrice && maxPrice) {
          params = {
            ...params,
            'filter.discountedPrices': [Number(minPrice), Number(maxPrice)],
            'filter.discountedComparison': 'BT'
          }
        } else if (minPrice) {
          params = {
            ...params,
            'filter.discountedPrices': Number(minPrice),
            'filter.discountedComparison': 'LTE'
          }
        } else if (maxPrice) {
          params = {
            ...params,
            'filter.discountedPrices': Number(maxPrice),
            'filter.discountedComparison': 'GTE'
          }
        } else {
          params = {
            ...params,
            'filter.discountedPrices': null,
            'filter.discountedComparison': null
          }
        }
      }
      commit('SET_PARAMS', params)
      await dispatch('fetchList', { params: state.fetchListParams })
      if (isBkData) {
        if (isIE()) {
          cookies.set('fetchListParams', state.fetchListParams)
        } else {
          history.replaceState(state.fetchListParams, null, document.URL)
        }
      }
    },
    async fetchProductDetailPopular ({ state, dispatch, commit }, brandNo) {
      commit('CLEAR_BRAND_LIST')
      commit('RESET_BRAND_LIST_PARAMS')
      commit('SET_BRAND_LIST_PARAMS', {
        'order.by': 'POPULAR',
        'order.direction': 'DESC',
        'categoryNos': [brandNo],
        'pageNumber': 1,
        'pageSize': 7,
        'hasMaxCouponAmt': true
      })
      await dispatch('fetchListBrand', { params: state.fetchBrandListParams })
    },
    ResetList ({ commit }) {
      commit('CLEAR_LIST')
    }
  },
  getters: {
  },
  mutations: {
    CLEAR_LIST (state) {
      state.list = null
      state.totalCount = null
    },
    RESET_PARAMS (state) {
      state.fetchListParams = defaultParams
    },
    SET_PARAMS (state, params) {
      state.fetchListParams = {
        ...state.fetchListParams,
        ...params
      }
    },
    CLEAR_BRAND_LIST (state) {
      state.listBrand = null
      state.totalBrandCount = null
    },
    RESET_BRAND_LIST_PARAMS (state) {
      state.fetchBrandListParams = defaultParams
    },
    SET_BRAND_LIST_PARAMS (state, params) {
      state.fetchBrandListParams = {
        ...state.fetchBrandListParams,
        ...params
      }
    },
    BK_DATA_TO_DISP (state) {
      state.list = state.categoryListBk
      state.totalCount = state.totalCountBk
      state.noNeedRefresh = false
    },
    SET_NONEEDREFRESH_FLG (state, flg) {
      if (state.totalCountBk && state.categoryListBk && state.categoryListBk.length > 0) {
        state.noNeedRefresh = flg
      } else {
        state.noNeedRefresh = false
      }
    },
    SET_INIT_SORTTYPE (state, data) {
      state.initSortType = data.index
      state.initSortTypeStr = data.sorts
    },
    SET_INIT_PAGESIZE (state, value) {
      state.initPageSize = value
    },
    CLEAR_BK_PARAMS (state) {
      state.noNeedRefresh = false
      state.initPageSize = null
      state.initSortType = null
      state.initSortTypeStr = null
      state.totalCountBk = null
    }
  }
}
