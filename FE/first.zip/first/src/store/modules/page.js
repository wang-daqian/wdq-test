import router from '@/router'
import store from '@/store'
import { getToday, addMonth } from '@/utils/dateUtils'

router.afterEach((to, from) => {
  if (to.name && to.name !== 'NotFound') {
    Promise.all([
      store.dispatch('display/fetchTopBand'),
      store.dispatch('cart/fetchCartCount'),
      store.dispatch('wishlist/fetchLikeProducts'),
      store.dispatch('recentproducts/fetchRecent')
    ])
    store.dispatch('category/fetchCategories').then(() => {
      if (to.name) {
        Promise.all([
          store.dispatch(`page/${to.name}`, { to, from })
        ])
      }
    })
  }
})

const pageStore = {
  namespaced: true,
  actions: {
    MainHome ({ dispatch }, { to, from }) {
      return Promise.all([
        dispatch('display/getPopups', { to, from }, { root: true }),
        dispatch('display/fetchMainAll', { to, from }, { root: true })
      ])
    },
    FrenchCat ({ dispatch }, { to, from }) {
      return Promise.all([
        dispatch('display/fetchFrenchCat', { to, from }, { root: true })
      ])
    },
    Tiffany ({ dispatch }, { to, from }) {
      return Promise.all([
        dispatch('display/fetchTiffany', { to, from }, { root: true })
      ])
    },
    Elecone ({ dispatch }, { to, from }) {
      return Promise.all([
        dispatch('display/fetchElecone', { to, from }, { root: true })
      ])
    },
    GuessKids ({ dispatch }, { to, from }) {
      return Promise.all([
        dispatch('display/fetchGuessKids', { to, from }, { root: true })
      ])
    },
    Nubaby ({ dispatch }, { to, from }) {
      return Promise.all([
        dispatch('display/fetchNubaby', { to, from }, { root: true })
      ])
    },
    JoinAgreement: ({ dispatch }, { to }) => {

    },
    Join: ({ dispatch }, { to }) => {

    },
    Login: ({ dispatch }, { to }) => {

    },
    CategoryList: ({ dispatch }, { to }) => {
      return Promise.all([
        dispatch('productList/fetchListByCategory', { to }, { root: true })
      ])
    },
    SearchList: ({ dispatch }, { to }) => {
      return Promise.all([
        dispatch('productList/fetchSearch', { to }, { root: true })
      ])
    },
    GoodsView: ({ dispatch }, { to, from }) => {
      return Promise.all([
        dispatch('product/fetchProduct', { to, from }, { root: true })
      ]).then(() => {
        dispatch('recentproducts/addRecent', { productNo: to.params.productNo }, { root: true })
        dispatch('coupon/fetchProductCoupons', to.params.productNo, { root: true })
      })
    },
    MyPage: ({ dispatch }, { to, from }) => {
    },
    OrderList: ({ dispatch }, { to }) => {
      Promise.all([
        dispatch('myorder/getOrderListPagin', { type: 'ORDER', to }, { root: true })
      ])
    },
    CancelList: ({ dispatch }, { to, from }) => {
      Promise.all([
        dispatch('myorder/getOrderListPagin', { type: 'CANCEL', to }, { root: true })
      ])
    },
    OrderDetail: ({ dispatch }, { to, from }) => {
      Promise.all([
        dispatch('myorder/getOrderDetail', to.params.orderNo, { root: true })
      ])
    },
    OrderClaimCancel: ({ dispatch }, { to, from }) => {
      Promise.all([
        dispatch('myorder/getClaimOrderOption', {
          claimParams: {
            claimType: 'CANCEL',
            orderOptionNo: to.params.orderOptionNo
          }
        }, { root: true })
      ])
    },
    OrderAllCancel: ({ dispatch }, { to, from }) => {
      Promise.all([
        dispatch('myorder/getOrderClaim', {
          claimParams: {
            claimType: 'CANCEL',
            orderNo: to.params.OrderClaimCancel
          }
        }, { root: true })
      ])
    },
    NonMemberOrderAllCancel: ({ dispatch }, { to, from }) => {
      Promise.all([
        dispatch('guestorder/getGuestOrderClaim', {
          claimParams: {
            claimType: 'CANCEL',
            orderNo: to.params.OrderClaimCancel
          }
        }, { root: true })
      ])
    },
    OrderClaimReturn: ({ dispatch }, { to, from }) => {
      Promise.all([
        dispatch('myorder/getClaimOrderOption', {
          claimParams: {
            claimType: 'RETURN',
            orderOptionNo: to.params.orderOptionNo
          }
        }, { root: true })
      ])
    },
    WishList: ({ dispatch }, { to, from }) => {
      Promise.all([
      ])
    },
    NonMemberOrderDetail: ({ dispatch }, { to, from }) => {
      Promise.all([
        dispatch('guestorder/getGuestOrderDetail', to.params.orderNo, { root: true })
      ])
    },
    NonMemberCancel: ({ dispatch }, { to, from }) => {
      Promise.all([
        dispatch('guestorder/getGuestClaim', {
          claimParams: {
            claimType: 'CANCEL',
            orderOptionNo: to.params.orderOptionNo
          }
        }, { root: true })
      ])
    },
    NonMemberReturn: ({ dispatch }, { to, from }) => {
      Promise.all([
        dispatch('guestorder/getGuestClaim', {
          claimParams: {
            claimType: 'RETURN',
            orderOptionNo: to.params.orderOptionNo
          }
        }, { root: true })
      ])
    },
    ValidCoupon: ({ dispatch }, { to, from }) => (
      Promise.all([
        dispatch('validCoupon/getValidCoupons', {}, { root: true }),
        dispatch('validCoupon/getNoValidCoupons', {}, { root: true })
      ])
    ),
    NoValidCoupon: ({ dispatch }, { to, from }) => (
      Promise.all([
        dispatch('validCoupon/getNoValidCoupons', {}, { root: true })
      ])
    ),
    MileageList: ({ dispatch }, { to, from }) => {
      Promise.all([
        dispatch('member/mileAgeItems', {}, { root: true })
      ])
    },
    Inquiries: ({ dispatch }) => {
      Promise.all([
        dispatch('profileinquiry/fetchInquiries', {}, { root: true })
      ])
    },
    SignInInquiry: ({ dispatch }) => {
      Promise.all([
        dispatch('profile/memberFetch', {}, { root: true }),
        dispatch('profileinquiry/resetInquiry', {}, { root: true })
      ])
    },
    InquiryDetail: ({ dispatch }, { to }) => {
      Promise.all([
        dispatch('profile/memberFetch', {}, { root: true }),
        dispatch('profileinquiry/fetchInquiry', to.params.inquiryNo, { root: true })
      ])
    },
    InquiryModify: ({ dispatch }, { to }) => {
      Promise.all([
        dispatch('profile/memberFetch', {}, { root: true }),
        dispatch('profileinquiry/fetchInquiry', to.params.inquiryNo, { root: true })
      ])
    },
    WithDrawal: ({ dispatch }, { to }) => {

    },
    MemberPwdCheck: ({ dispatch }) => {
      Promise.all([
        dispatch('profile/memberFetch', {}, { root: true })
      ])
    },
    MemberChange: ({ dispatch }, { to }) => {
      Promise.all([
      ])
    },
    MemberShipping: ({ dispatch }) => {
      Promise.all([
        dispatch('profile/fetchAllAddress', {}, { root: true })
      ])
    },
    ProductSignInInquiry: ({ dispatch }) => {
      Promise.all([
        dispatch('profile/memberFetch', {}, { root: true }),
        dispatch('productList/ResetList', {}, { root: true }),
        dispatch('profileinquiry/resetInquiry', {}, { root: true })
      ])
    },
    ProductInquiries: ({ dispatch }, { to }) => {
      Promise.all([
        dispatch('profileinquiry/fetchAllInquiries', { to }, { root: true })
      ])
    },
    ProductInquiryDetail: ({ dispatch }, { to }) => {
      Promise.all([
        dispatch('product/fetchProduct', { to }, { root: true }),
        dispatch('profile/memberFetch', {}, { root: true }),
        dispatch('profileinquiry/getProductInquiry', { to }, { root: true })
      ])
    },
    ProductInquiryModify: ({ dispatch }, { to }) => {
      Promise.all([
        dispatch('product/fetchProduct', { to }, { root: true }),
        dispatch('profile/memberFetch', {}, { root: true }),
        dispatch('profileinquiry/getProductInquiry', { to }, { root: true })
      ])
    },
    ProductReviews: ({ dispatch }) => {
      Promise.all([
        dispatch('profile/memberFetch', {}, { root: true }),
        dispatch('profilereview/getProductReviews', {}, { root: true })
      ])
    },
    ProductSignInReview: ({ dispatch }) => {
      Promise.all([
        dispatch('profile/memberFetch', {}, { root: true }),
        dispatch('profilereview/getReviewProducts', {}, { root: true })
      ])
    },
    ProductReviewDetail: ({ dispatch }, { to }) => {
      Promise.all([
        dispatch('profile/memberFetch', {}, { root: true }),
        dispatch('product/fetchProduct', { to }, { root: true }),
        dispatch('profilereview/getProductReview', { to }, { root: true })
      ])
    },
    ProductModifyReview: ({ dispatch }, { to }) => {
      Promise.all([
        dispatch('profile/memberFetch', {}, { root: true }),
        dispatch('product/fetchProduct', { to }, { root: true }),
        dispatch('profilereview/getReviewProducts', {}, { root: true }),
        dispatch('profilereview/getProductReview', { to }, { root: true })
      ])
    },
    Cart: ({ dispatch }, { to, from }) => {
      Promise.all([
        dispatch('cart/fetchCart', {}, { root: true })
      ])
    },
    BeforeOrder: ({ dispatch }, { to, from }) => {
      Promise.all([
        dispatch('ordersheet/getSheetNoInit', {}, { root: true })
      ])
    },
    OrderSheet: ({ dispatch }, { to, from }) => {
      Promise.all([
        dispatch('ordersheet/fetchOrder', to.params.orderSheetNo, { root: true }),
        dispatch('shippingaddresses/shippingAddresses', to.params.orderSheetNo, { root: true })
      ])
    },
    PaymentConfirm: ({ dispatch }, { to, from }) => {
      Promise.all([
        dispatch('myorder/getOrder', to.query.orderNo, { root: true })
      ])
    },
    PaymentConfirmNonMember: ({ dispatch }, { to }) => {

    },
    Dashboard: ({ dispatch }, { to }) => {
      const day = getToday()
      to.query.startYmd = addMonth(new Date(), -1)
      to.query.endYmd = day
      Promise.all([
        dispatch('myorder/getOrderListPagin', { type: 'ORDER', to }, { root: true })
      ])
    },
    Company: () => {

    },
    Guide: () => {

    },
    Agreement: () => {

    },
    Private: () => {

    },
    Online: () => {

    },
    FAQ: ({ dispatch }) => {
      Promise.all([
        dispatch('board/faqCategorys', { boardNo: process.env.VUE_APP_NCP_FAQ_BOARDNO }, { root: true })
      ])
    },
    Notice: ({ dispatch }) => {
      Promise.all([
        dispatch('board/featchBoard', { boardNo: process.env.VUE_APP_NCP_NOTICE_BOARDNO }, { root: true })
      ])
    },
    NoticeDetail: ({ dispatch }, { to }) => {
      Promise.all([
        dispatch('board/boardDetail', { boardNo: process.env.VUE_APP_NCP_NOTICE_BOARDNO, articleNo: to.params.articleNo }, { root: true })
      ])
    },
    Store: ({ dispatch }) => {
      Promise.all([
        dispatch('board/featchBoard', { boardNo: process.env.VUE_APP_NCP_STORE_BOARDNO }, { root: true })
      ])
    },
    StoreDetail: ({ dispatch }, { to }) => {
      Promise.all([
        dispatch('board/boardDetail', { boardNo: process.env.VUE_APP_NCP_STORE_BOARDNO, articleNo: to.params.articleNo }, { root: true })
      ])
    },
    Event: ({ dispatch }, { to }) => {
      Promise.all([
        dispatch('event/fetchEventDetail', to.params.eventNo, { root: true })
      ])
    }
  }
}

export default pageStore
