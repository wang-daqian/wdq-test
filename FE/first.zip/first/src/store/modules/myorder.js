import { createNcpApiStore } from '@/api'
import { formatCurrency, telnoFormat } from '@/utils/stringUtils'
import { addMonth, getToday, getStrDate, getSixMonths } from '@/utils/dateUtils'
import { makeOrderProductOptionName, getClaimStatusLabel, compareWithDrawBtnFunc, compareWithDrawBtnFunc2 } from '@/utils/orderUtils'
import qs from 'qs'
import Vue from 'vue'
import { isLogin } from '@/utils/utils'
import { gaEventPurchase } from '@/utils/gaEventUtils'

const defaultParams = {
  'orderRequestTypes': null,
  'pageNumber': 1,
  'pageSize': 10,
  'hasTotalCount': true,
  'startYmd': null,
  'endYmd': null
}
const defaultParamsPagin = {
  'orderRequestTypes': null,
  'pageNumber': 1,
  'pageSize': 25,
  'hasTotalCount': true,
  'startYmd': null,
  'endYmd': null
}

const apiStore = createNcpApiStore([
  {
    action: '_getOrder',
    property: 'order',
    path: 'profile/orders/{orderNo}',
    pathParams: ['orderNo']
  },
  {
    action: '_getOrderList',
    property: 'orders',
    path: 'profile/orders',
    method: 'get',
    queryParams: true,
    onSuccess (state, payload) {
      state.orders = [...state.orders || [], ...payload.data.items]
      state.totalCount = payload.data.totalCount
    },
    requestConfig: {
      paramsSerializer: params => qs.stringify(params, { arrayFormat: 'repeat' })
    },
    cacheable: false,
    cacheMaxAge: 1000 * 30
  },
  {
    action: '_getClaimOrderOption',
    property: 'claimOrderOption',
    path: 'profile/order-options/{orderOptionNo}/claim',
    pathParams: ['orderOptionNo'],
    onSuccess (state, payload) {
      state.claimOrderOption = payload.data
      if (state.claimOrderOption.claimableOptions) {
        state.claimOrderOption.claimableOptions.forEach(claimableOption => {
          if (claimableOption.claimStatusType) {
            getClaimStatusLabel(claimableOption, state.claimResult.claimedOption)
          } else {
            getClaimStatusLabel(claimableOption)
          }
        })
      }
      if (state.claimType === 'CANCEL') {
        state.cancelOptions = [state.claimOrderOption.originalOption, ...state.claimOrderOption.claimableOptions]
        state.cancelOptions.forEach(opiton => {
          opiton.productCnt = opiton.orderCnt
          if (state.claimOrderOption.originalOption.orderOptionNo === opiton.orderOptionNo) {
            Vue.set(opiton, 'checked', true)
          } else {
            Vue.set(opiton, 'checked', false)
          }
        })
      } else {
        state.returnOptions = [state.claimOrderOption.originalOption, ...state.claimOrderOption.claimableOptions]
        for (var i = state.returnOptions.length - 1; i >= 0; i--) {
          let option = state.returnOptions[i]

          if (option.claimStatusType) {
          } else {
            if (option.orderStatusType === 'BUY_CONFIRM' || option.orderStatusType === 'NOT_REFUNDABLE') {
              state.returnOptions.splice(i, 1)
            } else if (option.orderStatusType === 'PAY_DONE' || option.orderStatusType === 'PRODUCT_PREPARE' || option.orderStatusType === 'DELIVERY_PREPARE' || option.orderStatusType === 'DELIVERY_ING' || option.orderStatusType === 'DELIVERY_DONE') {
              if (option.deliverable && !option.refundable) {
                state.returnOptions.splice(i, 1)
              }
            }
          }
        }
        state.returnOptions.forEach(opiton => {
          opiton.productCnt = opiton.orderCnt
          if (state.claimOrderOption.originalOption.orderOptionNo === opiton.orderOptionNo) {
            Vue.set(opiton, 'checked', true)
          } else {
            Vue.set(opiton, 'checked', false)
          }
        })
      }
    }
  },
  {
    action: '_getClaimEstimate',
    property: 'claimEstimate',
    path: 'profile/order-options/{orderOptionNo}/claim/estimate',
    pathParams: ['orderOptionNo']
  },
  {
    action: '_postOrderOptionClaimReturn',
    path: 'profile/order-options/{orderOptionNo}/claim/return',
    pathParams: ['orderOptionNo'],
    method: 'post'
  },
  {
    action: '_postClaimReturn',
    path: 'profile/claim/return',
    method: 'post'
  },
  {
    action: '_postOrderOptionClaimCancel',
    path: 'profile/order-options/{orderOptionNo}/claim/cancel',
    pathParams: ['orderOptionNo'],
    method: 'post'
  },
  {
    action: '_postClaimCancel',
    path: 'profile/claim/cancel',
    method: 'post'
  },
  {
    action: '_putOrderOptionClaimWithdraw',
    path: 'profile/order-options/{orderOptionNo}/claim/withdraw',
    pathParams: ['orderOptionNo'],
    method: 'put'
  },
  {
    action: '_getClaimResult',
    property: 'claimResult',
    path: 'profile/order-options/{orderOptionNo}/claim/result',
    pathParams: ['orderOptionNo']
  },
  {
    action: '_editDeliveries',
    property: 'deliverie',
    path: 'profile/orders/{orderNo}/deliveries',
    pathParams: ['orderNo'],
    method: 'put'
  },
  {
    action: '_myOrderStatus',
    property: 'orderStatus',
    path: 'profile/orders/summary/status',
    method: 'get'
  },
  {
    action: '_postClaimEstimate',
    property: 'postClaimEstimate',
    path: 'profile/claim/estimate',
    method: 'post'
  },
  {
    action: '_putClaimsWithdraw',
    path: 'profile/claims/{claimNo}/withdraw',
    pathParams: ['claimNo'],
    method: 'put'
  },
  {
    action: '_getMutiReturnClaimResult',
    property: 'mutiReturnClaimResult',
    path: 'profile/claims/{claimNo}/result',
    pathParams: ['claimNo'],
    method: 'get'
  },
  {
    action: '_postOrderClaimCancel',
    path: 'profile/orders/{orderNo}/claim/cancel',
    pathParams: ['orderNo'],
    method: 'post'
  },
  {
    action: '_putOrderOptionConfirm',
    path: 'profile/order-options/{orderOptionNo}/confirm',
    pathParams: ['orderOptionNo'],
    method: 'put'
  },
  {
    action: '_getOrderClaim',
    property: 'orderClaimInfo',
    path: 'profile/orders/{orderNo}/claim',
    pathParams: ['orderNo'],
    method: 'get'
  }
])

export default {
  namespaced: true,
  state: {
    sixMonths: [],
    fetchListParams: {},
    totalCount: null,
    loading: true,
    selectTypeFlg: 'one_month',
    returnOptions: [],
    cancelOptions: [],
    checkAll: false,
    checkCancelAll: false,
    claimType: ''
  },
  mixins: [apiStore],
  actions: {
    getOrder ({ state, commit, dispatch, rootState, rootGetters }, orderNo) {
      if (!isLogin() || !orderNo) {
        return
      }
      dispatch('_getOrder', { params: { orderNo } }).then(() => {
        /** gtag.js */
        gaEventPurchase(state.order)
      })
    },
    async getOrderList ({ state, commit, dispatch }, { type, to }) {
      type = to.query.type || type
      const month = to.query.month
      const period = to.query.period
      const startYmd = to.query.startYmd
      const endYmd = to.query.endYmd
      state.selectTypeFlg = 'one_month'
      if (month || month === 0) {
        state.selectTypeFlg = month
      }
      if (period) {
        state.selectTypeFlg = period
      }
      commit('RESET_LIST')
      if (month === undefined || month === '' || month === null) {
        if (typeof startYmd === 'undefined') {
          const today = getToday()
          commit('SET_PARAMS', {
            startYmd: addMonth(new Date(), -1),
            endYmd: today
          })
        } else {
          commit('SET_PARAMS', {
            startYmd: startYmd,
            endYmd: endYmd
          })
        }
      }

      if (type === 'ORDER') {
        commit('SET_PARAMS', {
          orderRequestTypes: [
            'DEPOSIT_WAIT',
            'PAY_DONE',
            'PRODUCT_PREPARE',
            'DELIVERY_PREPARE',
            'DELIVERY_ING',
            'DELIVERY_DONE',
            'BUY_CONFIRM'
          ]
        })
      } else {
        commit('SET_PARAMS', {
          orderRequestTypes: [
            'CANCEL_DONE',
            'RETURN_DONE',
            'EXCHANGE_DONE',
            'CANCEL_PROCESSING',
            'RETURN_PROCESSING',
            'EXCHANGE_PROCESSING'
          ]
        })
      }

      await dispatch('_getOrderList', { params: state.fetchListParams })
      commit('FORMAT_ORDERLIST', commit)
      if (type !== 'ORDER') {
        // commit('DEL_CANCEL_NO_REFUND_ITEMS', commit)
        commit('RESORT_ORDERS_FOR_WITHDRAW_ROWS', commit)
      }
    },

    async getOrderListPagin ({ state, commit, dispatch }, { type, to }) {
      type = to.query.type || type
      const month = to.query.month
      const period = to.query.period
      const startYmd = to.query.startYmd
      const endYmd = to.query.endYmd
      state.selectTypeFlg = 'one_month'
      if (month || month === 0) {
        state.selectTypeFlg = month
      }
      if (period) {
        state.selectTypeFlg = period
      }
      commit('RESET_LIST_PAGIN')
      if (month === undefined || month === '' || month === null) {
        if (typeof startYmd === 'undefined') {
          const today = getToday()
          commit('SET_PARAMS', {
            startYmd: addMonth(new Date(), -1),
            endYmd: today
          })
        } else {
          commit('SET_PARAMS', {
            startYmd: startYmd,
            endYmd: endYmd
          })
        }
      }

      if (type === 'ORDER') {
        commit('SET_PARAMS', {
          orderRequestTypes: [
            'DEPOSIT_WAIT',
            'PAY_DONE',
            'PRODUCT_PREPARE',
            'DELIVERY_PREPARE',
            'DELIVERY_ING',
            'DELIVERY_DONE',
            'BUY_CONFIRM'
          ]
        })
      } else {
        commit('SET_PARAMS', {
          orderRequestTypes: [
            'CANCEL_DONE',
            'RETURN_DONE',
            'EXCHANGE_DONE',
            'CANCEL_PROCESSING',
            'RETURN_PROCESSING',
            'EXCHANGE_PROCESSING'
          ]
        })
      }

      await dispatch('_getOrderList', { params: state.fetchListParams })
      commit('FORMAT_ORDERLIST', commit)
      if (type !== 'ORDER') {
        //  commit('DEL_CANCEL_NO_REFUND_ITEMS', commit)
        commit('RESORT_ORDERS_FOR_WITHDRAW_ROWS', commit)
      }
    },
    async fetchMore ({ state, dispatch, commit, rootState }, payload) {
      commit('SET_PARAMS', {
        pageNumber: state.fetchListParams.pageNumber + 1
      })
      await dispatch('_getOrderList', { params: state.fetchListParams })
      if (state.orders.length >= state.totalCount) {
        state.loading = false
      }
      commit('FORMAT_ORDERLIST', commit)
    },
    async getClaimOrderOption ({ state, commit, dispatch }, { claimParams }) {
      state.claimType = claimParams.claimType
      await dispatch('_getClaimOrderOption', { params: { orderOptionNo: claimParams.orderOptionNo, claimType: claimParams.claimType } })
      commit('CALCULATE_ORDER_OPTION')
    },
    getCancelEstimate ({ state, commit, dispatch }, claimParams) {
      return dispatch('_getClaimEstimate', { params: { orderOptionNo: claimParams.orderOptionNo, claimType: claimParams.claimType, productCnt: claimParams.productCnt, claimReasonType: claimParams.claimReasonType } })
    },
    getReturnEstimate ({ state, commit, dispatch }, claimParams) {
      return dispatch('_getClaimEstimate', { params: { orderOptionNo: claimParams.orderOptionNo, claimType: claimParams.claimType, productCnt: claimParams.productCnt, claimReasonType: claimParams.claimReasonType, returnWayType: 'SELLER_COLLECT' } })
    },
    postClaimEstimate ({ state, dispatch, commit, rootState }, claimRequest) {
      return dispatch('_postClaimEstimate', { data: claimRequest })
    },
    postOrderOptionClaimReturn ({ state, dispatch, commit, rootState }, returntparam) {
      return dispatch('_postOrderOptionClaimReturn', { data: returntparam, params: { orderOptionNo: returntparam.orderOptionNo } })
    },
    postClaimReturn ({ state, dispatch, commit, rootState }, returntparam) {
      return dispatch('_postClaimReturn', { data: returntparam })
    },
    postOrderOptionClaimCancel ({ state, dispatch, commit, rootState }, cancelparam) {
      return dispatch('_postOrderOptionClaimCancel', { data: cancelparam, params: { orderOptionNo: cancelparam.orderOptionNo } })
    },
    postOrderClaimCancel ({ state, dispatch, commit, rootState }, claimParams) {
      return dispatch('_postOrderClaimCancel', { data: claimParams.claimRequest, params: { orderNo: claimParams.orderNo } })
    },
    async getOrderClaim ({ state, dispatch, commit }, { claimParams }) {
      state.claimType = claimParams.claimType
      await dispatch('_getOrderClaim', { params: { orderNo: claimParams.orderNo, claimType: claimParams.claimType } })
      commit('FORMAT_CLAIM_ORDER', commit)
    },
    postClaimCancel ({ state, dispatch, commit, rootState }, cancelparams) {
      return dispatch('_postClaimCancel', { data: cancelparams })
    },
    async getOrderDetail ({ state, commit, dispatch }, orderNo) {
      await dispatch('_getOrder', { params: { orderNo } })
      commit('FORMAT_ORDER', commit)
      commit('RESORT_ORDER_FOR_WITHDRAW_ROWS', commit)
    },
    async putOrderOptionClaimWithdraw ({ state, dispatch, commit, rootState }, withdrawparam) {
      await dispatch('_putOrderOptionClaimWithdraw', { data: withdrawparam, params: { orderOptionNo: withdrawparam.orderOptionNo } })
    },
    async getClaimResult ({ state, dispatch, commit, rootState }, { claimParams }) {
      const retClaimResult = await dispatch('_getClaimResult', { params: { orderOptionNo: claimParams.orderOptionNo } })
      await commit('FORMAT_CLAIM_RESULT')
      return retClaimResult
    },
    async editDeliveries ({ state, dispatch, commit, rootState }, deliveriesParam) {
      await dispatch('_editDeliveries', { data: deliveriesParam.addressRequest, params: { add: false, orderNo: deliveriesParam.orderNo } })
    },
    myOrderStatus ({ state, dispatch, commit, rootState }) {
      return dispatch('_myOrderStatus')
    },
    async putClaimsWithdraw ({ state, dispatch, commit, rootState }, withDrawClaimNo) {
      await dispatch('_putClaimsWithdraw', { params: { claimNo: withDrawClaimNo } })
    },
    async getMutiReturnClaimResult ({ state, dispatch, commit, rootState }, withDrawClaimNo) {
      await dispatch('_getMutiReturnClaimResult', { params: { claimNo: withDrawClaimNo } })
    },
    async putOrderOptionConfirm ({ state, dispatch, commit, rootState }, orderOptionNo) {
      await dispatch('_putOrderOptionConfirm', { params: { orderOptionNo: orderOptionNo } })
    }
  },
  mutations: {
    RESET_LIST (state) {
      state.orders = null
      state.totalCount = null
      state.loading = true
      state.fetchListParams = defaultParams
    },
    RESET_LIST_PAGIN (state) {
      state.orders = null
      state.totalCount = null
      state.loading = true
      state.fetchListParams = defaultParamsPagin
    },
    SET_PARAMS (state, params) {
      state.fetchListParams = {
        ...state.fetchListParams,
        ...params
      }
    },
    CALCULATE_ORDER_OPTION (state) {
      if (state.claimOrderOption) {
        if (state.claimType === 'CANCEL') {
          state.cancelOptions.forEach(opiton => {
            makeOrderProductOptionName(opiton, opiton.optionUsed, opiton.brandName, opiton.brandNameEn, opiton.productName)
          })
        } else if (state.claimType === 'RETURN') {
          state.returnOptions.forEach(opiton => {
            makeOrderProductOptionName(opiton, opiton.optionUsed, opiton.brandName, opiton.brandNameEn, opiton.productName)
          })
        } else {
          makeOrderProductOptionName(state.claimOrderOption.originalOption, state.claimOrderOption.originalOption.optionUsed, state.claimOrderOption.originalOption.brandName, state.claimOrderOption.originalOption.brandNameEn, state.claimOrderOption.originalOption.productName)
        }

        if (state.claimOrderOption.returnAddress) {
          const showReturnAddress = state.claimOrderOption.returnAddress
          state.claimOrderOption.showReturnAddress = showReturnAddress
        }
        if (state.claimOrderOption.originalOption.claimStatusType) {
          getClaimStatusLabel(state.claimOrderOption.originalOption, state.claimResult.claimedOption)
        } else {
          getClaimStatusLabel(state.claimOrderOption.originalOption)
        }
      }
    },
    FORMAT_CLAIM_RESULT (state) {
      if (state.claimResult) {
        makeOrderProductOptionName(state.claimResult.claimedOption, state.claimResult.claimedOption.optionUsed, state.claimResult.claimedOption.brandName, state.claimResult.claimedOption.brandNameEn, state.claimResult.claimedOption.productName)
        if (state.claimResult.returnAddress) {
          const showReturnAddress = state.claimResult.returnAddress
          state.claimResult.showReturnAddress = showReturnAddress
        }

        if (state.claimResult.claimedOption.claimStatusType) {
          if (state.claimResult.claimedOption.claimStatusType === 'CANCEL_REQUEST' || state.claimResult.claimedOption.claimStatusType === 'CANCEL_PROC_REQUEST_REFUND' || state.claimResult.claimedOption.claimStatusType === 'CANCEL_PROC_WAITING_REFUND') {
            state.claimResult.claimedOption.statusLabel = '취소처리중'
          } else if (state.claimResult.claimedOption.claimStatusType === 'CANCEL_NO_REFUND' || state.claimResult.claimedOption.claimStatusType === 'CANCEL_DONE') {
            state.claimResult.claimedOption.statusLabel = '취소완료'
          } else if (state.claimResult.claimedOption.claimStatusType === 'RETURN_REQUEST' || state.claimResult.claimedOption.claimStatusType === 'RETURN_REJECT_REQUEST' || state.claimResult.claimedOption.claimStatusType === 'RETURN_PROC_BEFORE_RECEIVE' || state.claimResult.claimedOption.claimStatusType === 'RETURN_PROC_REQUEST_REFUND' || state.claimResult.claimedOption.claimStatusType === 'RETURN_PROC_WAITING_REFUND') {
            state.claimResult.claimedOption.statusLabel = '반품처리중'
          } else if (state.claimResult.claimedOption.claimStatusType === 'RETURN_DONE') {
            state.claimResult.claimedOption.statusLabel = '반품완료'
          }
        } else {
          if (state.claimResult.claimedOption.orderStatusType === 'PAY_DONE') {
            state.claimResult.claimedOption.statusLabel = '결제완료'
          } else if (state.claimResult.claimedOption.orderStatusType === 'PRODUCT_PREPARE') {
            state.claimResult.claimedOption.statusLabel = '상품준비중'
          } else if (state.claimResult.claimedOption.orderStatusType === 'DELIVERY_PREPARE') {
            state.claimResult.claimedOption.statusLabel = '배송준비중'
          } else if (state.claimResult.claimedOption.orderStatusType === 'DELIVERY_ING') {
            state.claimResult.claimedOption.statusLabel = '배송중'
          } else if (state.claimResult.claimedOption.orderStatusType === 'DELIVERY_DONE') {
            state.claimResult.claimedOption.statusLabel = '배송완료'
          } else if (state.claimResult.claimedOption.orderStatusType === 'BUY_CONFIRM') {
            state.claimResult.claimedOption.statusLabel = '구매확정'
          }
        }
      }
    },
    FORMAT_ORDER (state, commit) {
      if (state.order) {
        Vue.set(state.order, 'showYmd', getStrDate(state.order.orderYmdt, '.'))

        if (state.order.payInfo && state.order.payInfo.cardInfo) {
          const cardInfo = state.order.payInfo.cardInfo
          if (cardInfo.installmentPeriod > 0) {
            if (cardInfo.noInterest) {
              cardInfo.installmentLabel = cardInfo.installmentPeriod + '개월 무이자'
            } else {
              cardInfo.installmentLabel = cardInfo.installmentPeriod + '개월'
            }
          } else {
            cardInfo.installmentLabel = '일시불'
          }
        }

        let showLabelFlg = false
        let showButtonFlg = true

        state.order.orderOptions = []
        state.order.orderOptionsGroupByPartner.forEach(partner => {
          partner.orderOptionsGroupByDelivery.forEach(delivery => {
            delivery.orderOptions.forEach(option => {
              commit('FORMAT_OPTION', option)
              state.order.orderOptions.push(option)

              if (!option.claimStatusType && (option.orderStatusType === 'PRODUCT_PREPARE' || option.orderStatusType === 'DELIVERY_PREPARE')) {
                showLabelFlg = true
              }
              if (option.claimStatusType || option.orderStatusType !== 'PAY_DONE') {
                showButtonFlg = false
              }
            })
          })
        })
        state.order.orderOptions.sort(compareWithDrawBtnFunc('buttons'))
        state.order.orderOptions.sort(compareWithDrawBtnFunc2('buttons'))
        const firstamt = state.order.firstOrderAmount
        const showPriceInfo = {}
        showPriceInfo.showStandardAmt = formatCurrency(firstamt.standardAmt)
        showPriceInfo.totalDisAmt = formatCurrency(firstamt.additionalDiscountAmt + firstamt.immediateDiscountAmt + firstamt.cartCouponDiscountAmt + firstamt.productCouponDiscountAmt)
        showPriceInfo.immDisAmt = formatCurrency(firstamt.immediateDiscountAmt)
        showPriceInfo.addDisAmt = formatCurrency(firstamt.additionalDiscountAmt)
        showPriceInfo.proCouDisAmt = formatCurrency(firstamt.productCouponDiscountAmt)
        showPriceInfo.cartCouDisAmt = formatCurrency(firstamt.cartCouponDiscountAmt)
        showPriceInfo.totalDeliveryAmt = formatCurrency((firstamt.deliveryAmt - firstamt.deliveryCouponDiscountAmt) + firstamt.remoteDeliveryAmt)
        showPriceInfo.deliveryAmt = formatCurrency(firstamt.deliveryAmt)
        showPriceInfo.delCouDisAmt = formatCurrency(firstamt.deliveryCouponDiscountAmt)
        showPriceInfo.remDelAmt = formatCurrency(firstamt.remoteDeliveryAmt)
        showPriceInfo.payAmt = formatCurrency(firstamt.payAmt)

        if (state.order.refundInfos) {
          const refundInfos = state.order.refundInfos
          let claimProductAmt = 0
          let claimSubtractionAmt = 0
          let claimDeliveryAmt = 0
          let refundPayAmt = 0
          refundInfos.forEach(refundInfo => {
            claimProductAmt += refundInfo.productAmtInfo.totalAmt
            claimSubtractionAmt += refundInfo.subtractionAmtInfo.totalAmt
            claimDeliveryAmt += refundInfo.deliveryAmtInfo.totalAmt
            refundPayAmt += refundInfo.refundPayAmt
          })
          showPriceInfo.claimProductAmt = formatCurrency(claimProductAmt)
          showPriceInfo.claimSubtractionAmt = formatCurrency(claimSubtractionAmt)
          showPriceInfo.claimDeliveryAmt = formatCurrency(claimDeliveryAmt)
          showPriceInfo.refundPayAmt = formatCurrency(refundPayAmt)
        }

        state.order.showPriceInfo = showPriceInfo
        const orderAddress = state.order.shippingAddress
        let contacts = telnoFormat(orderAddress.receiverContact1)
        Vue.set(orderAddress, 'receiverContact1One', contacts[0])
        Vue.set(orderAddress, 'receiverContact1Two', contacts[1])
        Vue.set(orderAddress, 'receiverContact1Three', contacts[2])
        contacts = telnoFormat(orderAddress.receiverContact2)
        Vue.set(orderAddress, 'receiverContact2One', contacts[0])
        Vue.set(orderAddress, 'receiverContact2Two', contacts[1])
        Vue.set(orderAddress, 'receiverContact2Three', contacts[2])
        orderAddress.deliveryMemo = state.order.deliveryMemo
        orderAddress.orderNo = state.order.orderNo
        orderAddress.showLabelFlg = showLabelFlg
        orderAddress.showButtonFlg = showButtonFlg

        state.order.orderAddress = orderAddress
      }
    },
    FORMAT_ORDERLIST (state, commit) {
      state.sixMonths = getSixMonths()

      if (state.orders && state.orders.length > 0) {
        state.orders.forEach(order => {
          Vue.set(order, 'showYmd', getStrDate(order.orderYmdt, '.'))

          order.orderOptions.forEach(option => {
            commit('FORMAT_OPTION', option)
          })
        })
      }
    },
    DEL_CANCEL_NO_REFUND_ITEMS (state, commit) {
      if (state.orders && state.orders.length > 0) {
        for (let i = state.orders.length - 1; i >= 0; i--) {
          let item = state.orders[i]
          for (let j = item.orderOptions.length - 1; j >= 0; j--) {
            if (item.orderOptions[j].claimStatusType === 'CANCEL_NO_REFUND') {
              item.orderOptions.splice(j, 1)
            }
          }
          if (!item.orderOptions || item.orderOptions.length <= 0) {
            state.orders.splice(i, 1)
            state.totalCount--
          }
        }
      }
    },
    RESORT_ORDERS_FOR_WITHDRAW_ROWS (state, commit) {
      if (state.orders && state.orders.length > 0) {
        // WITHDRAW_RETURN
        state.orders.forEach((order) => {
          if (order.orderOptions.length > 2) {
            order.orderOptions.sort(compareWithDrawBtnFunc('buttons'))
          }
        })
        state.orders.forEach((order) => {
          if (order.orderOptions.length > 2) {
            order.orderOptions.sort(function (element1, element2) {
              if (element1.buttons.some((btn) => btn === 'WITHDRAW_RETURN') && element2.buttons.some((btn) => btn === 'WITHDRAW_RETURN')) {
                return element1.claimNo - element2.claimNo
              } else {
                return 0
              }
            }
            )
          }
        })
        // WITHDRAW_CANCEL
        state.orders.forEach((order) => {
          if (order.orderOptions.length > 2) {
            order.orderOptions.sort(compareWithDrawBtnFunc2('buttons'))
          }
        })
        state.orders.forEach((order) => {
          if (order.orderOptions.length > 2) {
            order.orderOptions.sort(function (element1, element2) {
              if (element1.buttons.some((btn) => btn === 'WITHDRAW_CANCEL') && element2.buttons.some((btn) => btn === 'WITHDRAW_CANCEL')) {
                return element1.claimNo - element2.claimNo
              } else {
                return 0
              }
            }
            )
          }
        })
      }
    },
    RESORT_ORDER_FOR_WITHDRAW_ROWS (state, commit) {
      if (state.order) {
        if (state.order.orderOptions.length > 2) {
          state.order.orderOptions.sort(compareWithDrawBtnFunc('buttons'))
        }

        if (state.order.orderOptions.length > 2) {
          state.order.orderOptions.sort(function (element1, element2) {
            if (element1.buttons.some((btn) => btn === 'WITHDRAW_RETURN') && element2.buttons.some((btn) => btn === 'WITHDRAW_RETURN')) {
              return element1.claimNo - element2.claimNo
            } else {
              return 0
            }
          }
          )
          state.order.orderOptions.sort(compareWithDrawBtnFunc2('buttons'))
          state.order.orderOptions.sort(function (element1, element2) {
            if (element1.buttons.some((btn) => btn === 'WITHDRAW_CANCEL') && element2.buttons.some((btn) => btn === 'WITHDRAW_CANCEL')) {
              return element1.claimNo - element2.claimNo
            } else {
              return 0
            }
          }
          )
        }
      }
    },
    FORMAT_OPTION (state, option) {
      option.showOptions = []
      makeOrderProductOptionName(option, option.optionUsed, option.brandName, option.brandNameEn, option.productName)
      let price = option.price
      option.buttons = []
      if (option.claimStatusType) {
        if (option.claimStatusType === 'CANCEL_REQUEST' || option.claimStatusType === 'CANCEL_PROC_REQUEST_REFUND' || option.claimStatusType === 'CANCEL_PROC_WAITING_REFUND') {
          option.statusLabel = '취소처리중'
          option.buttonCount = 0
          option.nextActions.forEach(nextAction => {
            if (nextAction.nextActionType === 'VIEW_CLAIM') {
              option.buttonCount += 1
              option.buttons.push('CANCEL_VIEW_CLAIM_ING')
            } else if (nextAction.nextActionType === 'WITHDRAW_CANCEL') {
              option.buttonCount += 1
              option.buttons.push('WITHDRAW_CANCEL')
            }
          })
        } else if (option.claimStatusType === 'CANCEL_NO_REFUND' || option.claimStatusType === 'CANCEL_DONE') {
          option.statusLabel = '취소완료'
          option.buttonCount = 1
          option.buttons.push('CANCEL_VIEW_CLAIM')
        } else if (option.claimStatusType === 'RETURN_REQUEST' || option.claimStatusType === 'RETURN_REJECT_REQUEST' || option.claimStatusType === 'RETURN_PROC_BEFORE_RECEIVE' || option.claimStatusType === 'RETURN_PROC_REQUEST_REFUND' || option.claimStatusType === 'RETURN_PROC_WAITING_REFUND') {
          option.statusLabel = '반품처리중'
          option.buttonCount = 0
          option.nextActions.forEach(nextAction => {
            if (nextAction.nextActionType === 'VIEW_CLAIM') {
              option.buttonCount += 1
              option.buttons.push('RETURN_VIEW_CLAIM_ING')
            } else if (nextAction.nextActionType === 'WITHDRAW_RETURN') {
              option.buttonCount += 1
              option.buttons.push('WITHDRAW_RETURN')
            }
          })
        } else if (option.claimStatusType === 'RETURN_DONE') {
          option.statusLabel = '반품완료'
          option.buttonCount = 1
          option.buttons.push('RETURN_VIEW_CLAIM')
        }
      } else {
        if (option.orderStatusType === 'PAY_DONE') {
          option.statusLabel = '결제완료'
          if (option.deliverable) {
            option.buttonCount = 1
            if (option.refundable) {
              option.buttons.push('CANCEL')
            } else {
              option.buttons.push('NOT_REFUNDABLE')
            }
          }
        } else if (option.orderStatusType === 'PRODUCT_PREPARE') {
          option.statusLabel = '상품준비중'
          if (option.deliverable) {
            option.buttonCount = 1
            if (option.refundable) {
              option.buttons.push('CANCEL')
            } else {
              option.buttons.push('NOT_REFUNDABLE')
            }
          }
        } else if (option.orderStatusType === 'DELIVERY_PREPARE') {
          option.statusLabel = '배송준비중'
          if (option.deliverable) {
            option.buttonCount = 1
            if (option.refundable) {
              option.buttons.push('FORBID_ACTION')
            } else {
              option.buttons.push('NOT_REFUNDABLE')
            }
          }
        } else if (option.orderStatusType === 'DELIVERY_ING') {
          option.statusLabel = '배송중'
          option.buttonCount = 0
          option.nextActions.forEach(nextAction => {
            if (nextAction.nextActionType === 'VIEW_DELIVERY') {
              option.buttonCount += 1
              option.buttons.push('VIEW_DELIVERY')
            } else if (nextAction.nextActionType === 'WRITE_REVIEW') {
              option.buttonCount += 1
              option.buttons.push('WRITE_REVIEW')
            } else if (nextAction.nextActionType === 'RETURN') {
              if (option.deliverable && option.refundable) {
                option.buttonCount += 1
                option.buttons.push('RETURN')
              }
            } else if (nextAction.nextActionType === 'CONFIRM_ORDER') {
              option.buttonCount += 1
              option.buttons.push('CONFIRM_ORDER')
            }
          })
          if (option.deliverable && !option.refundable) {
            option.buttonCount += 1
            option.buttons.push('NOT_REFUNDABLE')
          }
        } else if (option.orderStatusType === 'DELIVERY_DONE') {
          option.statusLabel = '배송완료'
          option.buttonCount = 0
          option.nextActions.forEach(nextAction => {
            if (nextAction.nextActionType === 'VIEW_DELIVERY') {
              option.buttonCount += 1
              option.buttons.push('VIEW_DELIVERY')
            } else if (nextAction.nextActionType === 'WRITE_REVIEW') {
              option.buttonCount += 1
              option.buttons.push('WRITE_REVIEW')
            } else if (nextAction.nextActionType === 'RETURN') {
              if (option.deliverable && option.refundable) {
                option.buttonCount += 1
                option.buttons.push('RETURN')
              }
            } else if (nextAction.nextActionType === 'CONFIRM_ORDER') {
              option.buttonCount += 1
              option.buttons.push('CONFIRM_ORDER')
            }
          })

          if (option.deliverable && !option.refundable) {
            option.buttonCount += 1
            option.buttons.push('NOT_REFUNDABLE')
          }
        } else if (option.orderStatusType === 'BUY_CONFIRM') {
          option.statusLabel = '구매확정'
          option.buttonCount = 0

          option.nextActions.forEach(nextAction => {
            if (nextAction.nextActionType === 'WRITE_REVIEW') {
              option.buttonCount += 1
              option.buttons.push('WRITE_REVIEW')
            } else if (nextAction.nextActionType === 'VIEW_DELIVERY') {
              option.buttonCount += 1
              option.buttons.push('VIEW_DELIVERY')
            }
          })
        } else if (option.orderStatusType === 'DEPOSIT_WAIT') {
          option.statusLabel = '입금대기'
          option.buttonCount = 1
          option.buttons.push('DEPOSIT_WAIT')
        }
      }

      const orderBy = ['CANCEL', 'VIEW_DELIVERY', 'WRITE_REVIEW', 'CANCEL_VIEW_CLAIM_ING', 'CANCEL_VIEW_CLAIM', 'RETURN_VIEW_CLAIM_ING', 'RETURN_VIEW_CLAIM', 'RETURN', 'WITHDRAW_CANCEL', 'WITHDRAW_RETURN', 'NOT_REFUNDABLE', 'DEPOSIT_WAIT', 'CONFIRM_ORDER', 'FORBID_ACTION']
      const sortArray = []
      option.buttons.forEach((button, index) => {
        sortArray.push(orderBy.indexOf(button))
      })
      option.buttons = []
      sortArray.sort((i, j) => { return i > j ? 1 : -1 })
      sortArray.forEach((value) => {
        option.buttons.push(orderBy[value])
      })
      Vue.set(option, 'showPrice', formatCurrency(price.buyAmt))
    },
    RESET_CLAIM_ESTIMATE (state) {
      state.claimEstimate = null
    },
    RESET_CLAIM_ORDER_OPTION (state) {
      state.claimOrderOption = null
      state.returnOptions = null
      state.checkAll = false
      state.cancelOptions = null
      state.checkCancelAll = false
    },
    CHANGE_RETURN_OPTIONS (state, productData) {
      state.returnOptions.every(opiton => {
        if (productData.orderOptionNo === opiton.orderOptionNo) {
          opiton.productCnt = productData.quantity
          return false
        }
        return true
      })
    },
    CHANGE_RETURN_ITEMS_CHECKOUT_ALL (state, checked) {
      state.checkAll = checked
      if (state.returnOptions) {
        state.returnOptions.forEach((item) => {
          item.checked = checked
        })
      }
    },
    CHANGE_RETURN_ITEMS_SET (state, { orderOptionNo, checked }) {
      const option = state.returnOptions.find(item => item.orderOptionNo === orderOptionNo)
      if (option) {
        option.checked = checked
        state.checkAll = !state.returnOptions.some((citem) => {
          return !citem.checked
        })
      }
    },
    CHANGE_CANCEL_OPTIONS (state, productData) {
      state.cancelOptions.every(opiton => {
        if (productData.orderOptionNo === opiton.orderOptionNo) {
          opiton.productCnt = productData.quantity
          return false
        }
        return true
      })
    },
    CHANGE_CANCEL_ITEMS_CHECKOUT_ALL (state, checked) {
      state.checkCancelAll = checked
      if (state.cancelOptions) {
        state.cancelOptions.forEach((item) => {
          item.checked = checked
        })
      }
    },
    CHANGE_CANCEL_ITEMS_SET (state, { orderOptionNo, checked }) {
      const option = state.cancelOptions.find(item => item.orderOptionNo === orderOptionNo)
      if (option) {
        option.checked = checked
        state.checkCancelAll = !state.cancelOptions.some((citem) => {
          return !citem.checked
        })
      }
    },
    FORMAT_CLAIM_ORDER (state, commit) {
      if (state.orderClaimInfo) {
        Vue.set(state.orderClaimInfo, 'showYmd', getStrDate(state.orderClaimInfo.orderYmdt, '.'))

        if (state.orderClaimInfo.payInfo && state.orderClaimInfo.payInfo.cardInfo) {
          const cardInfo = state.orderClaimInfo.payInfo.cardInfo
          if (cardInfo.installmentPeriod > 0) {
            if (cardInfo.noInterest) {
              cardInfo.installmentLabel = cardInfo.installmentPeriod + '개월 무이자'
            } else {
              cardInfo.installmentLabel = cardInfo.installmentPeriod + '개월'
            }
          } else {
            cardInfo.installmentLabel = '일시불'
          }
        }

        state.orderClaimInfo.orderOptions = []
        state.orderClaimInfo.orderOptionsGroupByPartner.forEach(partner => {
          partner.orderOptionsGroupByDelivery.forEach(delivery => {
            delivery.orderOptions.forEach(option => {
              commit('FORMAT_OPTION', option)
              state.orderClaimInfo.orderOptions.push(option)
            })
          })
        })

        const firstamt = state.orderClaimInfo.firstOrderAmount
        const showPriceInfo = {}
        showPriceInfo.showStandardAmt = formatCurrency(firstamt.standardAmt)
        showPriceInfo.totalDisAmt = formatCurrency(firstamt.additionalDiscountAmt + firstamt.immediateDiscountAmt + firstamt.cartCouponDiscountAmt + firstamt.productCouponDiscountAmt)
        showPriceInfo.immDisAmt = formatCurrency(firstamt.immediateDiscountAmt)
        showPriceInfo.addDisAmt = formatCurrency(firstamt.additionalDiscountAmt)
        showPriceInfo.proCouDisAmt = formatCurrency(firstamt.productCouponDiscountAmt)
        showPriceInfo.cartCouDisAmt = formatCurrency(firstamt.cartCouponDiscountAmt)
        showPriceInfo.totalDeliveryAmt = formatCurrency((firstamt.deliveryAmt - firstamt.deliveryCouponDiscountAmt) + firstamt.remoteDeliveryAmt)
        showPriceInfo.deliveryAmt = formatCurrency(firstamt.deliveryAmt)
        showPriceInfo.delCouDisAmt = formatCurrency(firstamt.deliveryCouponDiscountAmt)
        showPriceInfo.remDelAmt = formatCurrency(firstamt.remoteDeliveryAmt)
        showPriceInfo.payAmt = formatCurrency(firstamt.payAmt)

        state.orderClaimInfo.showPriceInfo = showPriceInfo
      }
    }
  },
  getters: {
    orderOptions (state, getters, rootState) {
      if (state.order) {
        let orderOptions = []
        state.order.orderOptionsGroupByPartner.forEach(partner => {
          partner.orderOptionsGroupByDelivery.forEach(delivery => {
            orderOptions.push(...delivery.orderOptions)
          })
        })
        return orderOptions
      }
    },
    claimOrderOptionGetter (state) {
      return state.claimOrderOption
    }
  }
}
