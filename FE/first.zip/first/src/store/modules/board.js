import { createNcpApiStore } from '@/api'

const defaultParams = {
  'pageNumber': 1,
  'pageSize': 10,
  'hasTotalCount': true,
  'startYmd': null,
  'endYmd': null
}

const apiStore = createNcpApiStore([
  {
    action: '_faqCategory',
    property: 'faqCategorys',
    path: 'boards/{boardNo}/categories',
    pathParams: ['boardNo'],
    method: 'get'
  },
  {
    action: '_boardDetail',
    property: 'boardDetail',
    path: 'boards/{boardNo}/articles/{articleNo}',
    pathParams: ['boardNo', 'articleNo'],
    method: 'get'
  },
  {
    action: '_featchBoards',
    property: 'boardList',
    path: 'boards/{boardNo}/articles',
    pathParams: ['boardNo'],
    method: 'get',
    onSuccess (state, payload) {
      state.boardList = [...state.boardList || [], ...payload.data.items]
      state.totalCount = payload.data.totalCount
    }
  },
  {
    action: '_featchAllBoards',
    property: 'allBoardList',
    path: 'boards/{boardNo}/articles',
    pathParams: ['boardNo'],
    method: 'get',
    onSuccess (state, payload) {
      state.allBoardList = [...state.allBoardList || [], ...payload.data.items]
    }
  }
])

export default {
  namespaced: true,
  state: {
    fetchListParams: {},
    totalCount: null
  },
  mixins: [apiStore],
  actions: {
    async faqCategorys ({ state, dispatch }, params) {
      if (state.faqCategorys) {
        return
      }
      return dispatch('_faqCategory', { params: { boardNo: params.boardNo } })
    },
    async boardDetail ({ dispatch }, params) {
      return dispatch('_boardDetail', { params: { boardNo: params.boardNo, articleNo: params.articleNo } })
    },
    async featchBoard ({ state, commit, dispatch }, params) {
      commit('RESET_LIST')
      commit('SET_PARAMS', {
        'boardNo': params.boardNo
      })
      if (params && params.keyword) {
        commit('SET_PARAMS', {
          'keyword': params.keyword
        })
      }
      if (params && params.categoryNo) {
        commit('SET_PARAMS', {
          'categoryNo': params.categoryNo
        })
      }

      await dispatch('_featchBoards', { params: state.fetchListParams })
    },
    async featchAllBoard ({ state, commit, dispatch }, params) {
      commit('RESET_ALL_LIST')
      const fetchAllListParams = {
        'boardNo': params.boardNo,
        'pageSize': 100
      }

      await dispatch('_featchAllBoards', { params: fetchAllListParams })
    },
    async featchBoardMore ({ state, dispatch, commit }) {
      commit('SET_PARAMS', {
        pageNumber: state.fetchListParams.pageNumber + 1
      })
      await dispatch('_featchBoards', { params: state.fetchListParams })
    }
  },
  mutations: {
    RESET_LIST (state) {
      state.boardList = null
      state.totalCount = null
      state.fetchListParams = defaultParams
    },
    SET_PARAMS (state, params) {
      state.fetchListParams = {
        ...state.fetchListParams,
        ...params
      }
    },
    RESET_ALL_LIST (state) {
      state.allBoardList = null
    }
  },
  getters: {
  }
}
