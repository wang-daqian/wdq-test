import { createNcpApiStore } from '@/api'
import { getToday } from '@/utils/dateUtils'

const defaultParams = {
  'pageNumber': 1,
  'pageSize': 10,
  'hasTotalCount': true
}

const apiStore = createNcpApiStore([
  {
    action: '_uploadImages',
    property: 'uploadImagesData',
    path: 'files/images',
    method: 'post'
  },
  {
    action: '_getFile',
    property: 'file',
    path: 'files/{uploadedFileName}',
    pathParams: ['uploadedFileName'],
    method: 'get'
  },
  {
    action: '_uploadFiles',
    property: 'uploadFilesData',
    path: 'files',
    method: 'post'
  },
  {
    action: '_deleteFiles',
    property: 'deleteFilesData',
    path: 'files',
    method: 'delete'
  },
  {
    action: '_malls',
    property: 'malls',
    path: 'malls'
  },
  {
    action: '_partners',
    property: 'partners',
    path: 'malls/partners'
  },
  {
    action: '_fetchAddresses',
    property: 'addresses',
    path: 'addresses/search',
    method: 'get',
    queryParams: true,
    onSuccess (state, payload) {
      state.addresses = {
        items: payload.data.items,
        totalCount: payload.data.totalCount
      }
    },
    cacheable: false,
    cacheMaxAge: 1000 * 30
  }
])

export default {
  namespaced: true,
  state: {
    fetchListParams: {},
    totalCount: null,
    loading: true
  },
  mixins: [apiStore],
  actions: {
    uploadImages ({ state, dispatch, commit }, data) {
      return dispatch('_uploadImages', { data })
    },
    uploadFiles ({ state, dispatch, commit }, data) {
      return dispatch('_uploadFiles', { data })
    },
    deleteFiles ({ state, dispatch, commit }, filename) {
      return dispatch('_deleteFiles', { params: { fileName: filename } })
    },
    async fetchMalls ({ state, dispatch }) {
      let mallInfo = JSON.parse(window.localStorage.mallInfo || null)
      let expiredTime = JSON.parse(window.localStorage.expiredTime || null)
      if (mallInfo && expiredTime && expiredTime === getToday()) {
        state.malls = mallInfo
      } else {
        await dispatch('_malls')
        window.localStorage.mallInfo = JSON.stringify(state.malls)
        window.localStorage.expiredTime = JSON.stringify(getToday())
      }
      return state.malls
    },
    fetchPartners ({ state, commit, dispatch }) {
      if (state.malls) {
        return
      }
      return dispatch('_partners')
    },
    fetchAddresses ({ state, dispatch, commit }, params) {
      commit('SET_PARAMS', {
        'keyword': params.keyword,
        'pageNumber': params.pageNumber,
        'pageSize': 5,
        'hasTotalCount': true
      })
      return dispatch('_fetchAddresses', { params: state.fetchListParams })
    },
    getFile ({ dispatch }, uploadedFileName) {
      return dispatch('_getFile', { uploadedFileName: uploadedFileName })
    }
  },
  getters: {
    productInquiryTypes (state) {
      if (state.malls) {
        return state.malls.productInquiryType
      }
      return null
    },
    productReviewReportType (state) {
      if (state.malls) {
        return state.malls.productReviewReportType
      }
      return null
    },
    inquiryType (state) {
      if (state.malls) {
        return state.malls.inquiryType
      }
      return null
    },
    claimReasonTypes (state) {
      if (state.malls) {
        return state.malls.claimReasonType
      }
      return null
    },
    orderStatusTypes (state) {
      if (state.malls) {
        return state.malls.orderStatusType
      }
      return null
    },
    companyCenter (state) {
      if (state.malls) {
        return {
          serviceBasicInfo: state.malls.serviceBasicInfo,
          cscenter: state.malls.mall.serviceCenter,
          bank: state.malls.bankAccountInfo
        }
      }
    },
    isUseMallAccumulation (state) {
      return true
      // if (state.malls && state.malls.accumulationConfig !== null && state.malls.accumulationConfig.excludingReservePayAccumulation === false) {
      //   return true
      // } else {
      //   return false
      // }
    },
    showAccumulationName (state) {
      if (state.malls && state.malls.accumulationConfig) {
        return state.malls.accumulationConfig.accumulationName
      }
    },
    showAccumulationUnit (state) {
      if (state.malls && state.malls.accumulationConfig) {
        return state.malls.accumulationConfig.accumulationUnit
      }
    },
    accumulationDisplayFormatType (state) {
      if (state.malls && state.malls.accumulationConfig) {
        return state.malls.accumulationConfig.accumulationDisplayFormatType
      }
    },
    accumulationRate (state) {
      if (state.malls && state.malls.accumulationConfig) {
        return state.malls.accumulationConfig.accumulationRate
      }
    }
  },
  mutations: {
    SET_PARAMS (state, params) {
      state.fetchListParams = {
        ...state.fetchListParams,
        ...params
      }
    },
    RESET_LIST (state) {
      state.addresses = null
      state.totalCount = 0
      state.loading = true
      state.fetchListParams = defaultParams
    }
  }
}
