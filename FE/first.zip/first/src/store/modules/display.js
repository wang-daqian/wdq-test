import { createNcpApiStore } from '@/api'
import { includeNow } from '@/utils/dateUtils'
import { haveProductList } from '@/utils/utils'
import $ from 'jquery'

const apiStore = createNcpApiStore([
  {
    action: '_fetchTopBand',
    property: 'topBand',
    path: 'display/banners/{bannerSectionCodes}',
    pathParams: ['bannerSectionCodes']
  },
  {
    action: '_fetchMainBanners',
    property: 'banners',
    path: 'display/banners/{bannerSectionCodes}',
    pathParams: ['bannerSectionCodes'],
    method: 'get',
    onSuccess (state, payload) {
      if (payload.data && payload.data.length) {
        const topNos = [
          process.env.VUE_APP_NCP_FIRST_APPAREL_MAIN_TOP,
          process.env.VUE_APP_NCP_FRENCH_CAT_MAIN_TOP,
          process.env.VUE_APP_NCP_TIFFANY_MAIN_TOP,
          process.env.VUE_APP_NCP_ELECONE_MAIN_TOP,
          process.env.VUE_APP_NCP_GUESS_KIDS_MAIN_TOP,
          process.env.VUE_APP_NCP_NUBABY_MAIN_TOP
        ]
        const middle1Nos = [
          process.env.VUE_APP_NCP_FIRST_APPAREL_MAIN_MIDDLE1,
          process.env.VUE_APP_NCP_FRENCH_CAT_MAIN_MIDDLE1,
          process.env.VUE_APP_NCP_TIFFANY_MAIN_MIDDLE1,
          process.env.VUE_APP_NCP_ELECONE_MAIN_MIDDLE1,
          process.env.VUE_APP_NCP_GUESS_KIDS_MAIN_MIDDLE1,
          process.env.VUE_APP_NCP_NUBABY_MAIN_MIDDLE1
        ]
        const middle2Nos = [
          process.env.VUE_APP_NCP_FIRST_APPAREL_MAIN_MIDDLE2,
          process.env.VUE_APP_NCP_FRENCH_CAT_MAIN_MIDDLE2,
          process.env.VUE_APP_NCP_TIFFANY_MAIN_MIDDLE2,
          process.env.VUE_APP_NCP_ELECONE_MAIN_MIDDLE2,
          process.env.VUE_APP_NCP_GUESS_KIDS_MAIN_MIDDLE2,
          process.env.VUE_APP_NCP_NUBABY_MAIN_MIDDLE2
        ]
        const middle3Nos = [
          process.env.VUE_APP_NCP_FIRST_APPAREL_MAIN_MIDDLE3,
          process.env.VUE_APP_NCP_FRENCH_CAT_MAIN_MIDDLE3,
          process.env.VUE_APP_NCP_TIFFANY_MAIN_MIDDLE3,
          process.env.VUE_APP_NCP_ELECONE_MAIN_MIDDLE3,
          process.env.VUE_APP_NCP_GUESS_KIDS_MAIN_MIDDLE3,
          process.env.VUE_APP_NCP_NUBABY_MAIN_MIDDLE3
        ]
        const bottomNos = [
          process.env.VUE_APP_NCP_FIRST_APPAREL_MAIN_BOTTOM,
          process.env.VUE_APP_NCP_FRENCH_CAT_MAIN_BOTTOM,
          process.env.VUE_APP_NCP_TIFFANY_MAIN_BOTTOM,
          process.env.VUE_APP_NCP_ELECONE_MAIN_BOTTOM,
          process.env.VUE_APP_NCP_GUESS_KIDS_MAIN_BOTTOM,
          process.env.VUE_APP_NCP_NUBABY_MAIN_BOTTOM
        ]
        payload.data.forEach(banner => {
          if (topNos.find(item => item === banner.code)) {
            state.mainTop = banner.accounts[0].banners
          } else if (middle1Nos.find(item => item === banner.code)) {
            state.mainMiddle1 = banner.accounts[0].banners
          } else if (middle2Nos.find(item => item === banner.code)) {
            state.mainMiddle2 = banner.accounts[0].banners
          } else if (middle3Nos.find(item => item === banner.code)) {
            state.mainMiddle3 = banner.accounts[0].banners
          } else if (bottomNos.find(item => item === banner.code)) {
            state.mainBottom = banner.accounts[0].banners
          }
        })
      }
    }
  },
  {
    action: '_fetchMainSections',
    property: 'sections',
    path: 'display/sections/{sectionNos}',
    pathParams: ['sectionNos'],
    onSuccess (state, payload) {
      if (payload.data && payload.data.length) {
        const newRecommendNos = [
          process.env.VUE_APP_NCP_FIRST_APPAREL_MAIN_RECOMMEND,
          process.env.VUE_APP_NCP_FRENCH_CAT_MAIN_RECOMMEND,
          process.env.VUE_APP_NCP_TIFFANY_MAIN_RECOMMEND,
          process.env.VUE_APP_NCP_ELECONE_MAIN_RECOMMEND,
          process.env.VUE_APP_NCP_GUESS_KIDS_MAIN_RECOMMEND,
          process.env.VUE_APP_NCP_NUBABY_MAIN_RECOMMEND
        ]
        payload.data.forEach(section => {
          if (section.sectionNo === Number(process.env.VUE_APP_NCP_FIRST_APPAREL_MAIN_NEW_ARRIVALS)) {
            state.newFirstApparel = section
          } else if (section.sectionNo === Number(process.env.VUE_APP_NCP_FRENCH_CAT_MAIN_NEW_ARRIVALS)) {
            state.newFrenchCat = section
          } else if (section.sectionNo === Number(process.env.VUE_APP_NCP_TIFFANY_MAIN_NEW_ARRIVALS)) {
            state.newTiffany = section
          } else if (section.sectionNo === Number(process.env.VUE_APP_NCP_ELECONE_MAIN_NEW_ARRIVALS)) {
            state.newElecone = section
          } else if (section.sectionNo === Number(process.env.VUE_APP_NCP_GUESS_KIDS_MAIN_NEW_ARRIVALS)) {
            state.newGuessKids = section
          } else if (section.sectionNo === Number(process.env.VUE_APP_NCP_NUBABY_MAIN_NEW_ARRIVALS)) {
            state.newNubaby = section
          } else if (section.sectionNo === Number(process.env.VUE_APP_NCP_BEST_FIRST_APPAREL)) {
            state.bestFirstApparel = section
          } else if (section.sectionNo === Number(process.env.VUE_APP_NCP_BEST_FRENCH_CAT)) {
            state.bestFrenchCat = section
          } else if (section.sectionNo === Number(process.env.VUE_APP_NCP_BEST_TIFFANY)) {
            state.bestTiffany = section
          } else if (section.sectionNo === Number(process.env.VUE_APP_NCP_BEST_ELECONE)) {
            state.bestElecone = section
          } else if (section.sectionNo === Number(process.env.VUE_APP_NCP_BEST_GUESS_KIDS)) {
            state.bestGuessKids = section
          } else if (section.sectionNo === Number(process.env.VUE_APP_NCP_BEST_NUBABY)) {
            state.bestNubaby = section
          } else if (newRecommendNos.find(item => Number(item) === section.sectionNo)) {
            state.mainRecommend = section
          }
        })
      }
    }
  },
  {
    action: 'getPopups',
    property: 'popupsInfo',
    path: `display/popups`,
    method: 'get'
  }
])

export default {
  namespaced: true,
  mixins: [apiStore],
  state: {
    mainTop: null,
    mainMiddle1: null,
    mainMiddle2: null,
    mainMiddle3: null,
    mainBottom: null,
    mainRecommend: null,
    bestFirstApparel: null,
    bestFrenchCat: null,
    bestTiffany: null,
    bestElecone: null,
    bestGuessKids: null,
    bestNubaby: null,
    newFirstApparel: null,
    newFrenchCat: null,
    newTiffany: null,
    newElecone: null,
    newGuessKids: null,
    newNubaby: null,
    warpDivHeight: 0
  },
  actions: {
    async fetchTopBand ({ state, dispatch }) {
      if (state.topBand) {
        return
      }
      const bannerSectionCodes = [
        process.env.VUE_APP_NCP_MAIN_TOP_BAND
      ]
      await dispatch('_fetchTopBand', { params: { bannerSectionCodes } })
    },
    async fetchMainAll ({ dispatch, commit }, { to, from }) {
      commit('CLEAR_MAIN_INFO')
      commit('MAIN_INIT_SCROLL', { from })

      let bannerSectionCodes = [
        process.env.VUE_APP_NCP_FIRST_APPAREL_MAIN_TOP,
        process.env.VUE_APP_NCP_FIRST_APPAREL_MAIN_MIDDLE1,
        process.env.VUE_APP_NCP_FIRST_APPAREL_MAIN_MIDDLE2,
        process.env.VUE_APP_NCP_FIRST_APPAREL_MAIN_MIDDLE3,
        process.env.VUE_APP_NCP_FIRST_APPAREL_MAIN_BOTTOM
      ]
      await dispatch('_fetchMainBanners', { params: { bannerSectionCodes } })
      let sectionNos = [
        process.env.VUE_APP_NCP_BEST_FIRST_APPAREL,
        process.env.VUE_APP_NCP_BEST_FRENCH_CAT,
        process.env.VUE_APP_NCP_BEST_TIFFANY,
        process.env.VUE_APP_NCP_BEST_ELECONE,
        process.env.VUE_APP_NCP_BEST_GUESS_KIDS,
        process.env.VUE_APP_NCP_BEST_NUBABY,
        process.env.VUE_APP_NCP_FIRST_APPAREL_MAIN_NEW_ARRIVALS,
        process.env.VUE_APP_NCP_FRENCH_CAT_MAIN_NEW_ARRIVALS,
        process.env.VUE_APP_NCP_TIFFANY_MAIN_NEW_ARRIVALS,
        process.env.VUE_APP_NCP_ELECONE_MAIN_NEW_ARRIVALS,
        process.env.VUE_APP_NCP_GUESS_KIDS_MAIN_NEW_ARRIVALS,
        process.env.VUE_APP_NCP_NUBABY_MAIN_NEW_ARRIVALS,
        process.env.VUE_APP_NCP_FIRST_APPAREL_MAIN_RECOMMEND
      ]

      await dispatch('_fetchMainSections', { params: { sectionNos: sectionNos, hasMaxCouponAmt: true } })
      commit('SET_SCROLLTOP', { to, from })
    },
    async fetchFrenchCat ({ dispatch, commit }, { to, from }) {
      commit('CLEAR_MAIN_INFO')
      commit('MAIN_INIT_SCROLL', { from })

      let bannerSectionCodes = [
        process.env.VUE_APP_NCP_FRENCH_CAT_MAIN_TOP,
        process.env.VUE_APP_NCP_FRENCH_CAT_MAIN_MIDDLE1,
        process.env.VUE_APP_NCP_FRENCH_CAT_MAIN_MIDDLE2,
        process.env.VUE_APP_NCP_FRENCH_CAT_MAIN_MIDDLE3,
        process.env.VUE_APP_NCP_FRENCH_CAT_MAIN_BOTTOM
      ]
      await dispatch('_fetchMainBanners', { params: { bannerSectionCodes } })
      let sectionNos = [
        process.env.VUE_APP_NCP_BEST_FRENCH_CAT,
        process.env.VUE_APP_NCP_FRENCH_CAT_MAIN_NEW_ARRIVALS,
        process.env.VUE_APP_NCP_FRENCH_CAT_MAIN_RECOMMEND
      ]

      await dispatch('_fetchMainSections', { params: { sectionNos, hasMaxCouponAmt: true } })
      commit('SET_SCROLLTOP', { to, from })
    },
    async fetchTiffany ({ dispatch, commit }, { to, from }) {
      commit('CLEAR_MAIN_INFO')
      commit('MAIN_INIT_SCROLL', { from })

      let bannerSectionCodes = [
        process.env.VUE_APP_NCP_TIFFANY_MAIN_TOP,
        process.env.VUE_APP_NCP_TIFFANY_MAIN_MIDDLE1,
        process.env.VUE_APP_NCP_TIFFANY_MAIN_MIDDLE2,
        process.env.VUE_APP_NCP_TIFFANY_MAIN_MIDDLE3,
        process.env.VUE_APP_NCP_TIFFANY_MAIN_BOTTOM
      ]
      await dispatch('_fetchMainBanners', { params: { bannerSectionCodes } })
      let sectionNos = [
        process.env.VUE_APP_NCP_BEST_TIFFANY,
        process.env.VUE_APP_NCP_TIFFANY_MAIN_NEW_ARRIVALS,
        process.env.VUE_APP_NCP_TIFFANY_MAIN_RECOMMEND
      ]

      await dispatch('_fetchMainSections', { params: { sectionNos, hasMaxCouponAmt: true } })
      commit('SET_SCROLLTOP', { to, from })
    },
    async fetchElecone ({ dispatch, commit }, { to, from }) {
      commit('CLEAR_MAIN_INFO')
      commit('MAIN_INIT_SCROLL', { from })

      let bannerSectionCodes = [
        process.env.VUE_APP_NCP_ELECONE_MAIN_TOP,
        process.env.VUE_APP_NCP_ELECONE_MAIN_MIDDLE1,
        process.env.VUE_APP_NCP_ELECONE_MAIN_MIDDLE2,
        process.env.VUE_APP_NCP_ELECONE_MAIN_MIDDLE3,
        process.env.VUE_APP_NCP_ELECONE_MAIN_BOTTOM
      ]
      await dispatch('_fetchMainBanners', { params: { bannerSectionCodes } })
      let sectionNos = [
        process.env.VUE_APP_NCP_BEST_ELECONE,
        process.env.VUE_APP_NCP_ELECONE_MAIN_NEW_ARRIVALS,
        process.env.VUE_APP_NCP_ELECONE_MAIN_RECOMMEND
      ]

      await dispatch('_fetchMainSections', { params: { sectionNos, hasMaxCouponAmt: true } })
      commit('SET_SCROLLTOP', { to, from })
    },
    async fetchGuessKids ({ dispatch, commit }, { to, from }) {
      commit('CLEAR_MAIN_INFO')
      commit('MAIN_INIT_SCROLL', { from })

      let bannerSectionCodes = [
        process.env.VUE_APP_NCP_GUESS_KIDS_MAIN_TOP,
        process.env.VUE_APP_NCP_GUESS_KIDS_MAIN_MIDDLE1,
        process.env.VUE_APP_NCP_GUESS_KIDS_MAIN_MIDDLE2,
        process.env.VUE_APP_NCP_GUESS_KIDS_MAIN_MIDDLE3,
        process.env.VUE_APP_NCP_GUESS_KIDS_MAIN_BOTTOM
      ]
      await dispatch('_fetchMainBanners', { params: { bannerSectionCodes } })
      let sectionNos = [
        process.env.VUE_APP_NCP_BEST_GUESS_KIDS,
        process.env.VUE_APP_NCP_GUESS_KIDS_MAIN_NEW_ARRIVALS,
        process.env.VUE_APP_NCP_GUESS_KIDS_MAIN_RECOMMEND
      ]

      await dispatch('_fetchMainSections', { params: { sectionNos, hasMaxCouponAmt: true } })
      commit('SET_SCROLLTOP', { to, from })
    },
    async fetchNubaby ({ dispatch, commit }, { to, from }) {
      commit('CLEAR_MAIN_INFO')
      commit('MAIN_INIT_SCROLL', { from })

      let bannerSectionCodes = [
        process.env.VUE_APP_NCP_NUBABY_MAIN_TOP,
        process.env.VUE_APP_NCP_NUBABY_MAIN_MIDDLE1,
        process.env.VUE_APP_NCP_NUBABY_MAIN_MIDDLE2,
        process.env.VUE_APP_NCP_NUBABY_MAIN_MIDDLE3,
        process.env.VUE_APP_NCP_NUBABY_MAIN_BOTTOM
      ]
      await dispatch('_fetchMainBanners', { params: { bannerSectionCodes } })
      let sectionNos = [
        process.env.VUE_APP_NCP_BEST_NUBABY,
        process.env.VUE_APP_NCP_NUBABY_MAIN_NEW_ARRIVALS,
        process.env.VUE_APP_NCP_NUBABY_MAIN_RECOMMEND
      ]

      await dispatch('_fetchMainSections', { params: { sectionNos, hasMaxCouponAmt: true } })
      commit('SET_SCROLLTOP', { to, from })
    }
  },
  getters: {
    mainTopBanners (state) {
      if (state.mainTop) {
        return state.mainTop.filter((item, index) => index < 5)
      }
    },
    recommendItems (state) {
      if (haveProductList(state.mainRecommend)) {
        return state.mainRecommend.products.filter((item, index) => index < 8)
      }
    },
    bestList (state, getters, rootState) {
      if (rootState.route.name === 'MainHome' && (state.bestFirstApparel || state.bestFrenchCat || state.bestTiffany || state.bestElecone || state.bestGuessKids || state.bestNubaby)) {
        const bestList = []
        if (haveProductList(state.bestFirstApparel)) {
          bestList.push({
            label: 'ALL',
            products: state.bestFirstApparel.products.filter((item, index) => index < 8)
          })
        }
        if (haveProductList(state.bestFrenchCat)) {
          bestList.push({
            label: 'FRENCH CAT',
            products: state.bestFrenchCat.products.filter((item, index) => index < 8)
          })
        }
        if (haveProductList(state.bestTiffany)) {
          bestList.push({
            label: 'TIFFANY',
            products: state.bestTiffany.products.filter((item, index) => index < 8)
          })
        }
        if (haveProductList(state.bestElecone)) {
          bestList.push({
            label: 'ELECONE',
            products: state.bestElecone.products.filter((item, index) => index < 8)
          })
        }
        if (haveProductList(state.bestGuessKids)) {
          bestList.push({
            label: 'GUESS KIDS',
            products: state.bestGuessKids.products.filter((item, index) => index < 8)
          })
        }
        if (haveProductList(state.bestNubaby)) {
          bestList.push({
            label: 'NUBABY',
            products: state.bestNubaby.products.filter((item, index) => index < 8)
          })
        }
        return bestList
      } else if (rootState.route.name === 'FrenchCat' && haveProductList(state.bestFrenchCat)) {
        return [{
          products: state.bestFrenchCat.products.filter((item, index) => index < 8)
        }]
      } else if (rootState.route.name === 'Tiffany' && haveProductList(state.bestTiffany)) {
        return [{
          products: state.bestTiffany.products.filter((item, index) => index < 8)
        }]
      } else if (rootState.route.name === 'Elecone' && haveProductList(state.bestElecone)) {
        return [{
          products: state.bestElecone.products.filter((item, index) => index < 8)
        }]
      } else if (rootState.route.name === 'GuessKids' && haveProductList(state.bestGuessKids)) {
        return [{
          products: state.bestGuessKids.products.filter((item, index) => index < 8)
        }]
      } else if (rootState.route.name === 'Nubaby' && haveProductList(state.bestNubaby)) {
        return [{
          products: state.bestNubaby.products.filter((item, index) => index < 8)
        }]
      }
    },
    newArrivalsList (state, getters, rootState) {
      if (rootState.route.name === 'MainHome' && (state.newFirstApparel || state.newFrenchCat || state.newTiffany || state.newElecone || state.newGuessKids || state.newNubaby)) {
        const newArrivalsList = []
        if (haveProductList(state.newFirstApparel)) {
          newArrivalsList.push({
            label: 'ALL',
            products: state.newFirstApparel.products
          })
        }
        if (haveProductList(state.newFrenchCat)) {
          newArrivalsList.push({
            label: 'FRENCH CAT',
            products: state.newFrenchCat.products
          })
        }
        if (haveProductList(state.newTiffany)) {
          newArrivalsList.push({
            label: 'TIFFANY',
            products: state.newTiffany.products
          })
        }
        if (haveProductList(state.newElecone)) {
          newArrivalsList.push({
            label: 'ELECONE',
            products: state.newElecone.products
          })
        }
        if (haveProductList(state.newGuessKids)) {
          newArrivalsList.push({
            label: 'GUESS KIDS',
            products: state.newGuessKids.products
          })
        }
        if (haveProductList(state.newNubaby)) {
          newArrivalsList.push({
            label: 'NUBABY',
            products: state.newNubaby.products
          })
        }
        return newArrivalsList
      } else if (rootState.route.name === 'FrenchCat' && haveProductList(state.newFrenchCat)) {
        return [{
          products: state.newFrenchCat.products
        }]
      } else if (rootState.route.name === 'Tiffany' && haveProductList(state.newTiffany)) {
        return [{
          products: state.newTiffany.products
        }]
      } else if (rootState.route.name === 'Elecone' && haveProductList(state.newElecone)) {
        return [{
          products: state.newElecone.products
        }]
      } else if (rootState.route.name === 'GuessKids' && haveProductList(state.newGuessKids)) {
        return [{
          products: state.newGuessKids.products
        }]
      } else if (rootState.route.name === 'Nubaby' && haveProductList(state.newNubaby)) {
        return [{
          products: state.newNubaby.products
        }]
      }
    },
    mainPopupInfo (state) {
      if (state.popupsInfo) {
        const retPopups = state.popupsInfo.filter(popup => includeNow(popup.startYmdt, popup.endYmdt))
        if (retPopups && retPopups.length > 0) {
          return retPopups[0]
        }
      }
    }
  },
  mutations: {
    CLEAR_MAIN_INFO (state) {
      state.mainTop = null
      state.mainMiddle1 = null
      state.mainMiddle2 = null
      state.mainMiddle3 = null
      state.mainBottom = null
      state.mainRecommend = null
      state.bestFirstApparel = null
      state.bestFrenchCat = null
      state.bestTiffany = null
      state.bestElecone = null
      state.bestGuessKids = null
      state.bestNubaby = null
      state.newFirstApparel = null
      state.newFrenchCat = null
      state.newTiffany = null
      state.newElecone = null
      state.newGuessKids = null
      state.newNubaby = null
    },
    MAIN_INIT_SCROLL (state, { from }) {
      if (from && from.name === 'GoodsView') {
        const warpDivHeight = state.warpDivHeight
        if (warpDivHeight > 0) {
          $('#container').height(warpDivHeight)
        } else {
          $('#container').css({ height: 'auto' })
        }
      } else {
        $('#container').css({ height: 'auto' })
      }
    },
    SET_SCROLLTOP (state, { to, from }) {
      state.warpDivHeight = $('#container').height()
      if (from && from.name === 'GoodsView') {
        if (to.meta.savedPosition) {
          $(window).scrollTop(to.meta.savedPosition.y)
          to.meta.savedPosition = null
        }
      }
    },
    SET_SCROLLKEEP (state, scrollKeep) {
      state.scrollKeep = scrollKeep
    },
    CLEAR_POPUPS_INFO (state) {
      state.popupsInfo = null
    }
  }
}
