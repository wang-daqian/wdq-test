import { createNcpApiStore } from '@/api'
import { isLogin } from '@/utils/utils'

const apiStore = createNcpApiStore([
  {
    action: '_shipping-addresses',
    property: 'shippingAddresses',
    path: 'profile/shipping-addresses',
    method: 'get'
  },
  {
    action: '_newAddress',
    path: 'profile/shipping-addresses',
    method: 'post'
  },
  {
    action: '_recent-addresses',
    property: 'recentAddresses',
    path: 'profile/shipping-addresses/recent'
  },
  {
    action: '_address-delete',
    property: 'deleteAddress',
    path: 'profile/shipping-addresses/{addressNo}',
    pathParams: ['addressNo'],
    method: 'delete'
  },
  {
    action: '_updateAddress',
    property: 'updateAddress',
    path: 'profile/shipping-addresses/{addressNo}',
    pathParams: ['addressNo'],
    method: 'put'
  }
])

export default {
  namespaced: true,
  mixins: [apiStore],
  actions: {
    shippingAddresses ({ state, commit, dispatch, rootState, rootGetters }, orderSheetNo) {
      if (!isLogin()) {
        return
      }
      dispatch('_shipping-addresses')
    },
    async newAddress ({ state, commit, dispatch }, data) {
      await dispatch('_newAddress', { data: data })
      await dispatch('_shipping-addresses')
    },
    async recentAddresses ({ commit, dispatch, rootState, rootGetters }) {
      if (!isLogin()) {
        return
      }
      await dispatch('_recent-addresses')
    },
    async deleteShippingAddresses ({ commit, dispatch, rootState, rootGetters }, addressNo) {
      if (!isLogin()) {
        return
      }
      await dispatch('_address-delete', { params: { addressNo } })
      return dispatch('_shipping-addresses')
    },
    async updateAddress ({ commit, dispatch, rootState, rootGetters }, payload) {
      if (!isLogin()) {
        return
      }
      await dispatch('_updateAddress', { data: payload.data, params: { addressNo: payload.addressNo } })
      return dispatch('_shipping-addresses')
    }
  },
  mutations: {
    RESET_SHIPPING_ADDRESSES (state) {
      state.shippingAddresses = null
    }
  }
}
