import { createNcpApiStore } from '@/api'
import { addMonth, getToday } from '@/utils/dateUtils'

const apiStore = createNcpApiStore([
  {
    action: '_signInInquiries',
    property: 'profile',
    path: 'inquiries',
    method: 'post'
  },
  {
    action: '_fetchInquiries',
    property: 'inquiries',
    path: 'inquiries',
    method: 'get',
    onSuccess (state, payload) {
      state.inquiries = [...state.inquiries || [], ...payload.data.items]
      state.totalCount = payload.data.totalCount
    },
    cacheable: false,
    cacheMaxAge: 1000 * 30
  },
  {
    action: '_fetchInquiry',
    property: 'inquiry',
    path: 'inquiries/{inquiryNo}',
    pathParams: ['inquiryNo'],
    method: 'get'
  },
  {
    action: '_modifyInquiry',
    property: 'inquiry',
    path: 'inquiries/{inquiryNo}',
    pathParams: ['inquiryNo'],
    method: 'put'
  },
  {
    action: '_delInquiry',
    property: 'inquiry',
    path: 'inquiries/{inquiryNo}',
    pathParams: ['inquiryNo'],
    method: 'delete'
  },
  {
    action: '_fetchAllInquiries',
    property: 'productInquiries',
    path: 'profile/product-inquiries',
    method: 'get',
    onSuccess (state, payload) {
      state.productInquiries = [...state.productInquiries || [], ...payload.data.items]
      state.productInquirytotalCount = payload.data.totalCount
    }
  },
  {
    action: '_getProductInquiry',
    path: 'products/{productNo}/inquiries/{inquiryNo}',
    property: 'inquiry',
    pathParams: ['productNo', 'inquiryNo'],
    method: 'get'
  }
])

const defaultMyInquiryParams = {
  'pageNumber': 1,
  'pageSize': 5,
  'hasTotalCount': true,
  'startYmd': null,
  'endYmd': null
}

const defaultParams = {
  'pageNumber': 1,
  'pageSize': 5,
  'hasTotalCount': true
}

export default {
  namespaced: true,
  mixins: [apiStore],
  state: {
    fetchListParams: null,
    totalCount: null,
    productInquirytotalCount: null,
    reviewProductstotalCount: null,
    loading: true
  },
  actions: {
    async signInInquiries ({ dispatch }, iparam) {
      await dispatch('_signInInquiries', { data: iparam })
    },
    async fetchInquiries ({ state, dispatch, commit }) {
      commit('RESET_LIST')
      await dispatch('_fetchInquiries', { params: state.fetchListParams })
      if (state.inquiries.length >= state.totalCount) {
        state.loading = false
      }
    },
    async fetchInquiriesMore ({ state, dispatch, commit }) {
      commit('SET_PARAMS', {
        pageNumber: state.fetchListParams.pageNumber + 1
      })
      await dispatch('_fetchInquiries', { params: state.fetchListParams })
      if (state.inquiries.length >= state.totalCount) {
        state.loading = false
      }
    },
    fetchInquiry ({ dispatch }, inquiryNo) {
      dispatch('_fetchInquiry', { params: { inquiryNo } })
    },
    modifyInquiry ({ dispatch }, iparam) {
      let params = {
        inquiryContent: iparam.inquiryContent,
        inquiryTitle: iparam.inquiryTitle
      }
      return dispatch('_modifyInquiry', { params: { inquiryNo: iparam.inquiryNo }, data: params })
    },
    delInquiry ({ dispatch }, inquiryNo) {
      return dispatch('_delInquiry', { params: { inquiryNo } })
    },
    resetInquiry ({ state }) {
      state.inquiry = null
    },
    async fetchAllInquiries ({ state, dispatch, commit }, { to }) {
      commit('MY_INQUIRY_RESET_LIST')
      const startYmd = to.query.startYmd
      const endYmd = to.query.endYmd
      if (typeof startYmd === 'undefined') {
        commit('SET_PARAMS', {
          startYmd: addMonth(new Date(), -1),
          endYmd: getToday()
        })
      } else {
        commit('SET_PARAMS', {
          startYmd: startYmd,
          endYmd: endYmd
        })
      }
      await dispatch('_fetchAllInquiries', { params: state.fetchListParams })
    },
    fetchAllInquiriesMore ({ state, dispatch, commit }) {
      commit('SET_PARAMS', {
        'pageNumber': state.fetchListParams.pageNumber + 1
      })
      return dispatch('_fetchAllInquiries', { params: state.fetchListParams })
    },
    async getProductInquiry ({ dispatch }, { to }) {
      await dispatch('_getProductInquiry', { params: { productNo: to.params.productNo, inquiryNo: to.params.inquiryNo } })
    }
  },
  mutations: {
    SET_PARAMS (state, params) {
      state.fetchListParams = {
        ...state.fetchListParams,
        ...params
      }
    },
    MY_INQUIRY_RESET_LIST (state) {
      state.productInquiries = null
      state.totalCount = null
      state.fetchListParams = defaultMyInquiryParams
    },
    RESET_LIST (state) {
      state.inquiries = null
      state.totalCount = null
      state.reviewProductstotalCount = null
      state.loading = true
      state.fetchListParams = defaultParams
    }
  }
}
