import { createNcpApiStore } from '@/api'
import { isLogin } from '@/utils/utils'
import { gaEventViewItem } from '@/utils/gaEventUtils'

const apiStore = createNcpApiStore([
  {
    action: '_fetchProduct',
    property: 'product',
    path: 'products/{productNo}',
    pathParams: ['productNo'],
    method: 'get'
  },
  {
    action: '_fetchProductOptions',
    property: 'options',
    path: 'products/{productNo}/options',
    pathParams: ['productNo'],
    method: 'get'
  },
  {
    action: '_fetchOptionImages',
    property: 'optionImages',
    path: 'products/{productNo}/options/images',
    pathParams: ['productNo'],
    method: 'get'
  },
  {
    action: '_fetchProductInquiries',
    property: 'inquiries',
    path: 'products/{productNo}/inquiries',
    pathParams: ['productNo'],
    method: 'get',
    onSuccess (state, payload) {
      state.inquiries = [...state.inquiries || [], ...payload.data.items]
      state.inquiriesTotalCount = payload.data.totalCount
    }
  },
  {
    action: '_deleteProductInquiries',
    path: '/products/inquiries/{inquiryNo}',
    pathParams: ['inquiryNo'],
    method: 'delete'
  },
  {
    action: '_fetchProductReview',
    property: 'review',
    path: 'products/{productNo}/product-reviews',
    pathParams: ['productNo'],
    method: 'get',
    onSuccess (state, payload) {
      let resItems = payload.data.items || []
      state.review = [...state.review || [], ...resItems]
      state.reviewTotalCount = payload.data.totalCount
      state.reviewRate = payload.data.rate
    }
  },
  {
    action: '_postProductInquiry',
    path: 'products/{productNo}/inquiries',
    pathParams: ['productNo'],
    method: 'post'
  },
  {
    action: '_putProductInquiry',
    path: 'products/inquiries/{inquiryNo}',
    pathParams: ['inquiryNo'],
    method: 'put'
  },
  {
    action: '_postRecommend',
    path: '/products/{productNo}/product-reviews/{reviewNo}/recommend',
    pathParams: ['reviewNo'],
    method: 'post'
  },
  {
    action: '_delRecommend',
    path: '/products/{productNo}/product-reviews/{reviewNo}/recommend',
    pathParams: ['reviewNo'],
    method: 'delete'
  },
  {
    action: '_postProductReviewsReport',
    path: 'products/{productNo}/product-reviews/{reviewNo}/report',
    pathParams: ['productNo', 'reviewNo'],
    method: 'post'
  },
  {
    action: '_reviewableOption',
    property: 'reviewable',
    path: 'products/{productNo}/reviewable-options',
    pathParams: ['productNo'],
    method: 'get'
  },
  {
    action: '_postProductReviews',
    path: 'products/{productNo}/product-reviews',
    pathParams: ['productNo'],
    method: 'post'
  }

])

const defaultParams = {
  'isMyInquiries': false,
  'pageNumber': 1,
  'pageSize': 10,
  'hasTotalCount': true
}

const defaultReviewParams = {
  'order.by': 'RECOMMEND',
  'order.direction': 'DESC',
  'pageNumber': 1,
  'pageSize': 10,
  'hasTotalCount': true
}

export default {
  namespaced: true,
  mixins: [apiStore],
  state: {
    fetchListParams: null,
    inquiriesTotalCount: null,
    fetchListReviewParams: null,
    reviewTotalCount: null,
    reviewRate: null,
    fromUrl: ''
  },
  actions: {
    async fetchProduct ({ state, dispatch, commit }, { to, from }) {
      commit('INIT_PRODUCT')
      // state.fromUrl = from
      const productNo = to.params.productNo
      await dispatch('_fetchProduct', { params: { productNo } }).then(() => {
        if (state.product.baseInfo.optionImageViewable) {
          dispatch('_fetchOptionImages', { params: { productNo } })
        }
        /** gtag.js */
        gaEventViewItem(state.product)
      })
      await dispatch('_fetchProductOptions', { params: { productNo } })
      await dispatch('fetchProductInquiries', productNo)
      await dispatch('fetchProductReview', productNo)
    },
    async fetchProductInquiries ({ state, dispatch, commit }, productNo) {
      state.inquiries = []
      commit('RESET_PARAMS')
      state.fetchListParams.productNo = productNo
      await dispatch('_fetchProductInquiries', { params: state.fetchListParams })
    },
    async fetchProductReview ({ state, dispatch, commit }, productNo) {
      state.review = []
      commit('RESET_PARAMS_REVIEW')
      commit('SET_PARAMS_REVIEW', {
        productNo
      })
      await dispatch('_fetchProductReview', { params: state.fetchListReviewParams })
    },
    async orderByReview ({ state, dispatch, commit }, orderBy) {
      state.review = []
      commit('SET_PARAMS_REVIEW', {
        'pageNumber': 1,
        'order.by': orderBy
      })
      await dispatch('_fetchProductReview', { params: state.fetchListReviewParams })
    },
    fetchProductInquiriesMore ({ state, dispatch, commit }) {
      commit('SET_PARAMS', {
        'pageNumber': state.fetchListParams.pageNumber + 1
      })
      return dispatch('_fetchProductInquiries', { params: state.fetchListParams })
    },
    async deleteProductInquiries ({ state, dispatch, commit }, inquiryNo) {
      await dispatch('_deleteProductInquiries', { params: { inquiryNo } })
      state.inquiries = []
      commit('RESET_PARAMS')
      await dispatch('_fetchProductInquiries', { params: state.fetchListParams })
    },
    fetchProductReviewMore ({ state, dispatch, commit }) {
      commit('SET_PARAMS_REVIEW', {
        'pageNumber': state.fetchListReviewParams.pageNumber + 1
      })
      return dispatch('_fetchProductReview', { params: state.fetchListReviewParams })
    },
    async postProductInquiry ({ state, dispatch, commit }, inquiry) {
      await dispatch('_postProductInquiry', { data: inquiry, params: { productNo: inquiry.productNo } })
      await dispatch('fetchProductInquiries', inquiry.productNo)
    },
    async putProductInquiry ({ state, dispatch, commit }, inquiry) {
      await dispatch('_putProductInquiry', { data: inquiry, params: { inquiryNo: inquiry.inquiryNo } })
      await dispatch('fetchProductInquiries', inquiry.productNo)
    },
    async productRecommend ({ state, dispatch, commit }, { reviewNo, productNo, recommendFlg }) {
      if (recommendFlg) {
        await dispatch('_postRecommend', { params: { productNo, reviewNo } })
      } else {
        await dispatch('_delRecommend', { params: { productNo, reviewNo } })
      }
      commit('SET_RECOMMEND', { reviewNo, recommendFlg })
    },
    postProductReviewsReport ({ dispatch }, reportparam) {
      return dispatch('_postProductReviewsReport', { data: reportparam, params: { productNo: reportparam.productNo, reviewNo: reportparam.reviewNo } })
    },
    reviewableOption ({ dispatch }, { productNo }) {
      if (!isLogin()) {
        return
      }
      return dispatch('_reviewableOption', { params: { productNo } })
    },
    postProductReviews ({ state, dispatch, commit }, paramsReview) {
      return dispatch('_postProductReviews', { data: paramsReview, params: { productNo: paramsReview.productNo } })
    }
  },
  getters: {
    viewBrandNo (state) {
      if (state.product && state.product.categories && state.product.categories.length) {
        return state.product.categories[0].categories[0].categoryNo
      }
    },
    dutyInfo (state) {
      if (state.product && state.product.baseInfo) {
        const tempinfo = JSON.parse(state.product.baseInfo.dutyInfo || {})
        if (tempinfo && tempinfo.contents) {
          const dutyInfo = []
          tempinfo.contents.forEach(item => {
            Object.keys(item).forEach(itemKey => {
              dutyInfo.push({
                key: itemKey,
                value: item[itemKey]
              })
            })
          })
          return dutyInfo
        }
      }
    }
  },
  mutations: {
    INIT_PRODUCT (state) {
      state.product = null
      state.options = null
    },
    RESET_PARAMS (state) {
      state.fetchListParams = defaultParams
    },
    SET_PARAMS (state, params) {
      state.fetchListParams = {
        ...state.fetchListParams,
        ...params
      }
    },
    RESET_PARAMS_REVIEW (state) {
      state.fetchListReviewParams = defaultReviewParams
    },
    SET_PARAMS_REVIEW (state, params) {
      state.fetchListReviewParams = {
        ...state.fetchListReviewParams,
        ...params
      }
    },
    SET_RECOMMEND (state, { reviewNo, recommendFlg }) {
      if (state.review) {
        const reviewItem = state.review.find(item => item.reviewNo === reviewNo)
        if (reviewItem) {
          if (recommendFlg) {
            reviewItem.recommendCnt = reviewItem.recommendCnt + 1
            reviewItem.recommendable = false
          } else {
            reviewItem.recommendCnt = reviewItem.recommendCnt - 1
            reviewItem.recommendable = true
          }
        }
      }
    }
  }
}
