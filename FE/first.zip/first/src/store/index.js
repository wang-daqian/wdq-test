import Vue from 'vue'
import Vuex from 'vuex'
import { applyMixin } from './storeMixin'
import $ from 'jquery'

Vue.use(Vuex)

const requireModules = require.context('./modules', false, /\.js$/)
const modules = requireModules.keys().reduce((modules, fileName) => {
  const name = fileName.match(/([^./]+)\.js$/)[1]
  modules[name] = requireModules(fileName).default
  return modules
}, {})

export default new Vuex.Store(applyMixin({
  state: {
    showLayerBg: false,
    bodyScrollTop: 0
  },
  mutations: {
    SHOW_LAYER_BG (state) {
      const currScroll = document.body.scrollTop | document.documentElement.scrollTop
      state.bodyScrollTop = currScroll * -1
      document.body.style.top = state.bodyScrollTop + 'px'
      $('body').addClass('overflow_hidden')
      state.showLayerBg = true
    },
    HIDDEN_LAYER_BG (state) {
      $('body').removeClass('overflow_hidden')
      document.body.style.top = '0px'
      window.scrollTo(0, state.bodyScrollTop * -1)
      state.showLayerBg = false
    }
  },
  actions: {

  },
  modules
}))
