<template>
  <div id="container">
    <div id="contents">
      <!-- 본문 시작 -->

      <div class="location_wrap">
        <div class="location_cont">
          <em>
            <a href="/" class="local_home">HOME</a> &gt; 주문서 작성 / 결제</em>
        </div>
      </div>
      <!-- //location_wrap -->

      <div class="sub_content">

        <!-- //side_cont -->
        <div class="content_box">
          <div class="order_wrap">
            <div class="order_tit">
              <h2>주문서작성/결제</h2>
              <ol>
                <li>
                  <span>01</span> 장바구니
                  <span>
                    <img src="../../../assets/img/member/icon_join_step_off.png" alt="">
                  </span>
                </li>
                <li class="page_on">
                  <span>02</span> 주문서작성/결제
                  <span>
                    <img src="../../../assets/img/member/icon_join_step_on.png" alt="">
                  </span>
                </li>
                <li>
                  <span>03</span> 주문완료</li>
              </ol>
            </div>
            <!-- //order_tit -->

            <div class="order_cont">
              <order-table-body :orderProductOptions="orderProductOptions" />
              <div class="btn_left_box">
                <a href="" @click.prevent="$router.go(-1)" class="shop_go_link">
                  <em>{{showBackUrlMsg}}</em>
                </a>
              </div>
              <order-payment-confirm ref="orderPaymentConfirm" :order="ordersheet" :orderProductOptions="orderProductOptions" :logined="logined" />
              <div class="order_view_info">
                <!-- <order-agree-non-member v-if="!logined" ref="orderAgreeNonMember"></order-agree-non-member> -->
                <order-orderer-info v-if="ordersheet!==null" ref="orderOrdererInfo" :logined="logined" :orderer="ordersheet.ordererContact" :ordererInfo="ordererInfo" />
                <order-delivery-address-info v-if="ordersheet" ref="orderDeliveryAddressInfo" :logined="logined" :address="shippingAddresses" :requireCustomsIdNumber="ordersheet.requireCustomsIdNumber" :shippingAddressInfo='shippingAddressInfo' @copyOrderer="copyOrderer" :deliveryMemo="origDeliveryMemo" @resetMileage="resetMileage" />
                <order-payment-info ref="orderPaymentInfo" :order="ordersheet" @usedMileage="usedMileage" :logined="logined" :subPayAmtInfo="subPayAmtInfo" @disableScrollBar="disableScrollBar" @ableScrollBar="ableScrollBar"></order-payment-info>
                <order-payment-progress ref="orderPaymentProgress" v-if="ordersheet!==null && defaultAvailablePayType()" :paymentInfo="ordersheet.paymentInfo" @payments="payments" :logined="logined" :availablePayTypes="ordersheet.availablePayTypes" :checkedPayTpye="defaultAvailablePayType()"></order-payment-progress>
              </div>
            </div>
          </div>
          <!-- //order_wrap -->
        </div>
        <!-- //content_box -->
      </div>
      <!-- //sub_content -->
    </div>
    <!-- //본문 끝 contents -->
  </div>
</template>

<script>
/* global NCPPay */
/* global fbq */

import { mapState, mapGetters, mapMutations } from 'vuex'
import cookies from 'js-cookie'
import Validator from '@/utils/validateUtils'
import OrderTableBody from '@/components/order/order/OrderTableBody'
import OrderOrdererInfo from '@/components/order/order/OrderOrdererInfo'
import OrderAgreeNonMember from '@/components/order/order/OrderAgreeNonMember'
import OrderDeliveryAddressInfo from '@/components/order/order/OrderDeliveryAddressInfo'
import OrderPaymentConfirm from '@/components/order/order/OrderPaymentConfirm'
import OrderPaymentInfo from '@/components/order/order/OrderPaymentInfo'
import OrderPaymentProgress from '@/components/order/order/OrderPaymentProgress'
import { getPrevOrderInfoInStoreage, deletePrevOrderInfoInStoreage, setKakaoQueryInStorage, setWpItemsInStorage } from '@/utils/orderUtils'
import { isLogin, isPC, loadAnalysisScript, scriptLoader } from '@/utils/utils'

export default {
  name: 'OrderSheet',
  metaInfo: {
    title: '주문결제'
  },
  beforeCreate () {
    scriptLoader(process.env.VUE_APP_NCP_API_BASE_URL + 'payments/' + process.env.VUE_APP_NCP_PAY_JS)
  },
  data () {
    return {
      orderSheetNo: this.$store.state.route.params.orderSheetNo,
      logined: isLogin(),
      orderData: {
        orderSheetNo: this.$store.state.route.params.orderSheetNo,
        shippingAddress: {},
        saveAddressBook: true,
        orderMemo: '',
        deliveryMemo: '',
        member: true,
        orderer: {
          ordererName: '',
          ordererContact1: '',
          ordererContact2: '',
          ordererEmail: ''
        },
        updateMember: true,
        coupons: null,
        subPayAmt: 0,
        orderTitle: '',
        payType: 'CREDIT_CARD',
        pgType: 'KCP'
        // insurance에 대해서 여쭤보기
        /*
        applyInsurance: false,
        agreementEmail: false,
        agreementSMS: false,
        sex: 'MALE',
        insuranceType: 'USAFE',
        birthYmd: ''
        */
      },
      active: {
        coupon: true
      },
      ordererInfo: null,
      shippingAddressInfo: null,
      subPayAmtInfo: 0,
      dispScroll: false
    }
  },
  components: {
    OrderTableBody,
    OrderOrdererInfo,
    OrderAgreeNonMember,
    OrderDeliveryAddressInfo,
    OrderPaymentConfirm,
    OrderPaymentInfo,
    OrderPaymentProgress
  },
  methods: {
    ...mapMutations('shippingaddresses', ['RESET_SHIPPING_ADDRESSES']),
    ...mapMutations('ordersheet', ['DISABLE_SCROLL_BAR', 'ABLE_SCROLL_BAR']),

    copyOrderer () {
      const ordererInput = this.$refs.orderOrdererInfo.ordererInput
      this.$refs.orderDeliveryAddressInfo.setOrdererInput(ordererInput)
    },
    usedMileage (mileage) {
      this.usedMileageInt = mileage
      this.$refs.orderPaymentProgress.setUsedMileageInt(mileage)
      this.$refs.orderDeliveryAddressInfo.setUsedMileageInt(mileage)
    },
    resetMileage () {
      this.$refs.orderPaymentInfo.resetMileage2()
      this.usedMileageInt = 0
      this.$refs.orderPaymentProgress.setUsedMileageInt(0)
    },
    payments (payType) {
      let ordererValidateRule = this.$refs.orderOrdererInfo.validateRule
      let deliveryAddressValidateRule = this.$refs.orderDeliveryAddressInfo.validateRule
      let validateRule = [
        ...ordererValidateRule,
        ...deliveryAddressValidateRule
      ]
      const validator = new Validator(validateRule)
      if (validator.validate()) {
        return false
      }
      let agreeCheck = this.$refs.orderPaymentProgress.agreeCheck
      if (!agreeCheck) {
        alert('동의 항목에 체크하여야 결제를 진행할 수 있습니다.')
        return
      }

      let shippingAddressInput = this.$refs.orderDeliveryAddressInfo.shippingAddressInput
      if (!shippingAddressInput.receiverDetailAddress) {
        if (!confirm('상세주소를 입력하지 않고 주문하시겠습니까?')) {
          if (!isLogin()) {
            this.$refs.orderDeliveryAddressInfo.$refs.nonMember.$refs.receiverDetailAddress.focus()
          } else {
            this.$refs.orderDeliveryAddressInfo.$refs.member.$refs.receiverDetailAddress.focus()
          }
          return false
        }
      }

      let ordererInput = this.$refs.orderOrdererInfo.ordererInput
      let deliveryMemoInput = this.$refs.orderDeliveryAddressInfo.deliveryMemoInput
      let paymentInfoUsedMileage = this.$refs.orderPaymentInfo.paymentInfoUsedMileage
      let saveAddressBook = this.$refs.orderDeliveryAddressInfo.isAddToShippingList
      let updateMember = this.$refs.orderDeliveryAddressInfo.isReflectToMembInfo
      this.orderData.orderer = { ...ordererInput }
      this.orderData.shippingAddress = { ...shippingAddressInput }
      this.orderData.deliveryMemo = deliveryMemoInput
      this.orderData.orderMemo = this.$refs.orderOrdererInfo.orderMemo

      if (payType === 'PAYCO') {
        this.orderData.pgType = 'PAYCO'
      } else {
        this.orderData.pgType = 'KCP'
      }
      this.orderData.payType = payType
      this.orderData.subPayAmt = paymentInfoUsedMileage
      this.orderData.updateMember = updateMember
      this.orderData.saveAddressBook = saveAddressBook

      let confirmUrl = `${location.protocol}//${location.host}/order/paymentconfirm`

      // 비회원
      if (!isLogin()) {
        confirmUrl = `${location.protocol}//${location.host}/order/paymentconfirm/guest`
        let tempPasswordInput = this.$refs.orderOrdererInfo.tempPasswordInput
        this.orderData.member = false
        this.orderData.updateMember = false
        this.orderData.tempPassword = tempPasswordInput
      }

      const searchProductID = this.$store.state.route.query.searchProductID
      const productNo = this.$store.state.route.query.productNo
      const cartNos = this.$store.state.route.query.cartNos
      let params = []
      if (searchProductID) {
        params.push('searchProductID=' + searchProductID)
      }
      if (productNo) {
        params.push('productNo=' + productNo)
      }
      if (cartNos) {
        params.push('cartNos=' + cartNos)
      }
      confirmUrl += params.length > 0 ? ('?' + params.join('&')) : ''

      // 쿠폰 setting
      const coupons = JSON.parse(JSON.stringify(this.couponRequest))
      if (coupons.productCoupons && coupons.productCoupons.length > 0) {
        coupons.productCoupons = coupons.productCoupons.filter(item => item.couponIssueNo !== 0 || item.plusCouponIssueNo !== 0)
      }
      this.orderData.coupons = coupons
      // this.orderData.paymentAmtForVerification = this.ordersheet.paymentInfo.paymentAmt - paymentInfoUsedMileage
      this.orderData.paymentAmtForVerification = this.ordersheet.paymentInfo.paymentAmt

      // if (!isLogin()) {
      //   if (this.$refs.orderAgreeNonMember.getAgreeCheckedStatus() !== 'AllAccepted') {
      //     alert('동의 항목에 체크하여야 결제를 진행할 수 있습니다.')
      //     return false
      //   }
      // }

      NCPPay.setConfiguration({
        clientId: process.env.VUE_APP_NCP_CLIENTID,
        accessToken: cookies.get('1ST_APPERAL_TOKEN') || '',
        confirmUrl: confirmUrl,
        platform: isPC() ? 'PC' : 'MOBILE_WEB'
      })

      let backupData = {
        addressType: this.$refs.orderDeliveryAddressInfo.getAddressType,
        orderData: this.orderData
      }
      window.localStorage.backupData = JSON.stringify(backupData)

      const _this = this
      fbq('track', 'InitiateCheckout')
      this.loadWpAstgScripts()

      let totalQuantity = 0
      let kakaoProducts = []
      this.orderProductOptions.forEach(option => {
        totalQuantity += option.orderCnt
        kakaoProducts.push({
          name: option.showProductName,
          quantity: option.orderCnt,
          price: option.price.salePrice
        })
      })
      let kakaoQuery = {
        total_quantity: totalQuantity, // 주문 내 상품 개수(optional)
        total_price: this.orderData.paymentAmtForVerification, // 주문 총 가격(optional)
        currency: 'KRW', // 주문 가격의 화폐 단위(optional, 기본 값은 KRW)
        products: kakaoProducts // 주문 내 상품 정보(optional)
      }
      setKakaoQueryInStorage(kakaoQuery)

      NCPPay.reservation(this.orderData, function (response) {
        _this.loggerPaymentCompleteScript()
        deletePrevOrderInfoInStoreage(_this.orderData.orderSheetNo)
        loadAnalysisScript('1', _this.orderData.paymentAmtForVerification + '')
        fbq('track', 'Purchase', {
          value: _this.orderData.paymentAmtForVerification,
          currency: 'KRW'
        })
      }, function (e) {
        const goPrePage = ['PPE0013', 'MPPE0013', 'PPE0010', 'MPPE0010', 'O3013']
        if (goPrePage.some((item) => item === e.responseJSON.code)) {
          _this.$router.go(-1)
        }
        if (e.responseJSON.code === 'PPE0002') {
          window.location.reload()
        } else {
          const codeparrten = /C2[0-9][0-9][0-9]/
          if (codeparrten.test(e.responseJSON.code) || e.responseJSON.code === 'C1020') {
            let requestUrl = '/order/getsheetno'
            requestUrl += params.length > 0 ? ('?' + params.join('&')) : ''
            const orderinfo = getPrevOrderInfoInStoreage(_this.orderData.orderSheetNo)
            if (!orderinfo) {
              return
            }
            window.localStorage.orderInfo = orderinfo
            window.location.replace(requestUrl)
          }
        }
      })
    },
    defaultAvailablePayType () {
      let payType = null

      if (this.isShowPayco()) {
        payType = 'PAYCO'
      } else if (this.isShowCreditCard()) {
        payType = 'CREDIT_CARD'
      } else if (this.isShowVirtualAccount()) {
        payType = 'VIRTUAL_ACCOUNT'
      } else if (this.isShowRealTimeAcocountTransfer()) {
        payType = 'REALTIME_ACCOUNT_TRANSFER'
      } else if (this.isShowEscowVirtualAccount()) {
        payType = 'ESCROW_VIRTUAL_ACCOUNT'
      } else if (this.isShowRealTransfer()) {
        payType = 'ESCROW_REALTIME_ACCOUNT_TRANSFER'
      } else {
        payType = null
      }

      return payType
    },
    isShowPayco () {
      // return this.ordersheet.availablePayTypes && this.ordersheet.availablePayTypes.some((type) => type.payType === 'PAYCO' && type.pgTypes.some((pg) => pg === 'PAYCO'))
      return false
    },
    isShowCreditCard () {
      return this.ordersheet.availablePayTypes && this.ordersheet.availablePayTypes.some((type) => type.payType === 'CREDIT_CARD' && type.pgTypes.some((pg) => pg === 'KCP'))
    },
    isShowVirtualAccount () {
      return this.ordersheet.availablePayTypes && this.ordersheet.availablePayTypes.some((type) => type.payType === 'VIRTUAL_ACCOUNT' && type.pgTypes.some((pg) => pg === 'KCP'))
    },
    isShowRealTimeAcocountTransfer () {
      return this.ordersheet.availablePayTypes && this.ordersheet.availablePayTypes.some((type) => type.payType === 'REALTIME_ACCOUNT_TRANSFER' && type.pgTypes.some((pg) => pg === 'KCP'))
    },
    isShowEscowVirtualAccount () {
      return this.ordersheet.availablePayTypes && this.ordersheet.availablePayTypes.some((type) => type.payType === 'ESCROW_VIRTUAL_ACCOUNT' && type.pgTypes.some((pg) => pg === 'KCP'))
    },
    isShowRealTransfer () {
      return this.ordersheet.availablePayTypes && this.ordersheet.availablePayTypes.some((type) => type.payType === 'ESCROW_REALTIME_ACCOUNT_TRANSFER' && type.pgTypes.some((pg) => pg === 'KCP'))
    },
    loadWpAstgScripts () {
      if (this.orderProductOptions) {
        const items = this.orderProductOptions.map((product) => {
          return {
            i: product.productNo,
            t: product.showProductName,
            p: product.showPrice,
            q: product.showOrderCnt
          }
        })
        setWpItemsInStorage(items)
      }
    },
    loggerPaymentCompleteScript () {
      if (this.orderProductOptions) {
        const items = this.orderProductOptions.map((product) => {
          return {
            i: product.productNo,
            t: product.showProductName,
            p: product.showPrice,
            q: product.showOrderCnt.slice(0, product.showOrderCnt.length - 1)
          }
        })

        const products = items.map((product) => {
          return product.i
        }).join(';')
        const cnts = items.map((product) => {
          return product.q
        }).join(';')
        const prices = items.map((product) => {
          return product.p
        }).join(';')
        return new Promise((resolve, reject) => {
          const script = document.createElement('script')
          script.type = 'text/javascript'
          script.async = true
          script._TRK_PI = 'ODR'
          script._TRK_OA = prices
          script._TRK_OE = cnts
          script._TRK_OP = products
          script.addEventListener('load', resolve)
          script.addEventListener('error', reject)
          document.body.appendChild(script)
        })
      }
    },
    disableScrollBar () {
      this.DISABLE_SCROLL_BAR()
    },
    ableScrollBar () {
      this.ABLE_SCROLL_BAR()
    }
  },
  computed: {
    ...mapGetters('ordersheet', ['orderProductOptions', 'orderProductOptionNos']),
    ...mapState('ordersheet', ['ordersheet', 'orderCoupons', 'couponAmt', 'couponRequest', 'newAddress', 'currRecent', 'origDeliveryMemo', 'payType', 'pgType']),
    ...mapState('shippingaddresses', ['shippingAddresses']),

    showBackUrlMsg () {
      if (this.$store.state.route.from.name === 'Cart') {
        return '< 장바구니 가기'
      }
      return '< 쇼핑 계속하기'
    }
  },
  created () {
    if (window.localStorage.backupData) {
      let backupData = JSON.parse(window.localStorage.backupData)
      if (backupData.orderData.orderSheetNo === this.$route.params.orderSheetNo) {
        this.ordererInfo = backupData.orderData.orderer
        this.shippingAddressInfo = backupData.orderData.shippingAddress
        this.shippingAddressInfo.addressType = backupData.addressType
        this.shippingAddressInfo.saveAddressBook = backupData.orderData.saveAddressBook
        this.shippingAddressInfo.updateMember = backupData.orderData.updateMember
        this.subPayAmtInfo = backupData.orderData.subPayAmt
        delete window.localStorage.backupData
      }
    }
  },
  destroyed () {
    this.RESET_SHIPPING_ADDRESSES()
  }
}
</script>
