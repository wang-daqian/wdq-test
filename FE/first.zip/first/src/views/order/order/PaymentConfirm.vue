<template>
  <div id="price_sum">
    <template v-if="result === 'SUCCESS'">
      <payment-confirm-member v-if="logined" />
      <payment-confirm-non-member v-else />
    </template>
    <template v-else>
      <payment-confirm-fail />
    </template>
  </div>
</template>

<script>
/* global fbq */
/* global kakaoPixel */

import PaymentConfirmMember from '@/components/order/order/PaymentConfirmMember'
import PaymentConfirmNonMember from '@/components/order/order/PaymentConfirmNonMember'
import PaymentConfirmFail from '@/components/order/order/PaymentConfirmFail'
import { isLogin, loadWpAstgScripts } from '@/utils/utils'

import { deleteKakaoQueryInStorage, deleteWpItemsInStorage, deleteOrderInfoInStorage } from '@/utils/orderUtils'

export default {
  components: {
    PaymentConfirmMember,
    PaymentConfirmNonMember,
    PaymentConfirmFail
  },
  name: 'PaymentConfirm',
  metaInfo: {
    title: '주문완료'
  },
  data () {
    return {
      logined: isLogin()
    }
  },
  methods: {
    doHistoryBack () {
      if (!window.location.hash) {
        let redirectUrl = '/'
        if (this.$route.query.result === 'FAIL') {
          redirectUrl = `/order/${this.orderSheetNo}`
        }
        this.$router.push(redirectUrl)
      }
    }
  },
  computed: {
    result: {
      get () {
        return this.$store.state.route.query.result
      }
    },
    orderSheetNo: {
      get () {
        return this.$store.state.route.query.orderSheetNo
      }
    }
  },
  beforeMount () {
    if (!window.location.hash) {
      this.$router.push(`${this.$route.fullPath}#complete`)
    }
  },
  mounted () {
    fbq('track', 'CompleteRegistration')
    if (opener) {
      opener.location.href = this.$route.fullPath.replace('#complete', '')
      self.close()
    } else {
      if (window.localStorage.kakaoQuery) {
        const kakaoQuery = JSON.parse(window.localStorage.kakaoQuery)
        kakaoPixel('1292090119990392533').purchase(kakaoQuery)
        deleteKakaoQueryInStorage()
      }

      if (window.localStorage.wpItems) {
        const wpItems = JSON.parse(window.localStorage.wpItems)
        loadWpAstgScripts('PurchaseComplete', wpItems)
        deleteWpItemsInStorage()
      }

      deleteOrderInfoInStorage()

      if (this.$store.state.route.query.cartNos && this.$store.state.route.query.cartNos.length > 0) {
        const cartNos = JSON.parse(this.$store.state.route.query.cartNos)
        if (cartNos && cartNos.length > 0 && this.result === 'SUCCESS' && !isLogin()) {
          this.$store.dispatch('cart/deleteCartByCartNos', cartNos)
        }
      }
    }
  },
  watch: {
    '$route': 'doHistoryBack'
  }
}
</script>
