<template>
  <div id="container">
    <div id="contents">
      <!-- 본문 시작 -->
      <div class="location_wrap">
        <div class="location_cont">
          <em>
            <a href="/" class="local_home">HOME</a> &gt; 장바구니</em>
        </div>
      </div>
      <!-- //location_wrap -->

      <div class="sub_content">

        <!-- //side_cont -->

        <div class="content_box">
          <div class="order_wrap">
            <div class="order_tit">
              <h2>장바구니</h2>
              <ol>
                <li class="page_on">
                  <span>01</span> 장바구니
                  <span><img src="../../../assets/img/member/icon_join_step_on.png" alt=""></span>
                </li>
                <li>
                  <span>02</span> 주문서작성/결제
                  <span><img src="../../../assets/img/member/icon_join_step_off.png" alt=""></span>
                </li>
                <li>
                  <span>03</span> 주문완료</li>
              </ol>
            </div>
            <!-- //order_tit -->

            <div class="cart_cont">

              <item-list :cartItems="cartItems" :invalidCartItems="invalidCartItems" :checkAll="checkAll" />
              <div class="btn_left_box">
                <router-link to="/" class="shop_go_link">
                  <em>&lt; 쇼핑 계속하기</em>
                </router-link>
              </div>

              <template v-if="canBuy">
                <price-area :checkedOptions="checkedOptions" :cartPrice="cartPrice" />
                <!-- //price_sum -->

                <check-out :displayMode="displayMode" :checkedOptions="checkedOptions" :cartItems="cartItems" :invalidCartItems="invalidCartItems" />
                <!-- //btn_order_box -->
                <em class="chk_none">주문서 작성단계에서 할인/{{showAccumulationName}} 적용을 하실 수 있습니다.</em>
              </template>
              <!-- //pay_box -->
            </div>
            <!-- //cart_cont -->
          </div>
          <!-- //order_wrap -->
        </div>
        <!-- //content_box -->
      </div>
      <!-- //sub_content -->
    </div>
    <!-- //본문 끝 contents -->
  </div>
</template>

<script>
/* global kakaoPixel */
import { mapState } from 'vuex'
import PriceArea from '@/components/order/cart/PriceArea.vue'
import ItemList from '@/components/order/cart/ItemList.vue'
import CheckOut from '@/components/order/cart/CheckOut.vue'
import { loadWpAstgScripts } from '@/utils/utils'

export default {
  props: ['displayMode'],
  computed: {
    ...mapState('cart', ['invalidCartItems', 'cartItems', 'checkAll', 'checkedOptions', 'cartPrice']),
    ...mapState('common', ['malls']),
    canBuy () {
      this.loadWpAstgScripts()
      // loadAnalysisScript('3', '3')
      return (this.cartItems && this.cartItems.length) || (this.invalidCartItems && this.invalidCartItems.length)
    },
    showAccumulationName () {
      return this.malls && this.malls.accumulationConfig.accumulationName
    }
  },
  methods: {
    loadWpAstgScripts () {
      if (this.cartItems && this.cartItems.length) {
        const items = []
        this.cartItems.forEach(item => {
          item.products.map((product) => {
            items.push({
              i: product.productNo,
              t: product.productName
            })
          })
        })
        loadWpAstgScripts('Cart', items)
      }
    }
  },
  components: {
    PriceArea,
    ItemList,
    CheckOut
  },
  mounted () {
    kakaoPixel('1292090119990392533').viewCart()
  }
}
</script>

<style scoped>
</style>
