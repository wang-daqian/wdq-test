<template>
  <div class="content">
    <div class="board_zone_sec">
      <div class="board_zone_cont">
        <div class="board_zone_list">
          <div class="date_check_box">
            <div class="date_faq_list">
              <h2>자주묻는 질문 검색</h2>
              <input type="text" id="time" name="searchWord" class="text" placeholder="검색어를 입력하세요" v-model="keyword">
              <button type="submit" class="btn_date_check" @click.prevent.enter="searchClick">
                <em>검색</em>
              </button>
            </div>
            <div class="date_faq_txt">
              <p>
                <strong>찾으시는 질문이 없다면?</strong>
                <span class="btn_gray_list">
                  <a href="#" @click="gotoQA">
                    <span>1:1 문의하기</span>
                  </a>
                </span>
              </p>
            </div>
          </div>
          <div class="board_zone_tit">
            <h3>FAQ</h3>
          </div>
          <div class="board_list_faq">
            <div class="board_hot_list">
              <ul>
                <li :class="{ 'on': categoryNo === 0 }">
                  <a href="#" @click.prevent="clickTab(0)">
                    <span>전체</span>
                  </a>
                </li>
                <li :class="{ 'on': category.categoryNo === categoryNo }" v-for="category in showFaqCategorys" :key="category.categoryNo">
                  <a href="#" @click.prevent="clickTab(category.categoryNo)">
                    <span>{{ category.label }}</span>
                  </a>
                </li>
              </ul>
            </div>
            <ul class="lst_description faq">
              <!-- [D] 활성화 된 li에 on 클래스 추가 -->
              <faq-item v-for="(faqItem, index) in showboardList" :key="index" :faq-item="faqItem" :index="index" :search="keywordQuery" :categoryNo="categoryNo"></faq-item>
            </ul>
          </div>
          <div v-if="boardList && boardList.length < totalCount" class="pagination">
            <p class="pagination-btn">
              <button type="button" class="btn_more" @click.prevent="fetchMore">더보기</button>
            </p>
          </div>
        </div>
      </div>
    </div>
    <div class="service_main_cont">
    </div>
  </div>
</template>

<script>
import { mapState } from 'vuex'
import FaqItem from '@/components/etc/FaqItem'

export default {
  name: 'FAQ',
  data () {
    return {
      sortAllBoardList: [],
      categoryNo: 0,
      keyword: ''
    }
  },
  metaInfo: {
    title: '자주하는질문'
  },
  computed: {
    ...mapState('board', ['faqCategorys', 'boardList', 'totalCount', 'allBoardList']),
    keywordQuery () {
      return (this.$route && this.$route.query && this.$route.query.keyword) || ''
    },
    showFaqCategorys () {
      if (this.faqCategorys && this.boardList && this.allBoardList) {
        if (this.keyword === '') {
          return this.faqCategorys.filter(c => {
            let boards = this.allBoardList.find(b => b.categoryNo === c.categoryNo)
            if (boards !== undefined && boards != null) {
              return true
            }
            return false
          })
        } else {
          return this.faqCategorys.filter(c => {
            let boards = this.boardList.find(b => b.categoryNo === c.categoryNo)
            if (boards !== undefined && boards != null) {
              return true
            }
            return false
          })
        }
      }
    },
    showboardList () {
      if (this.categoryNo === 0 && this.boardList && this.keyword === '') {
        var best = this.sortAllBoardList.slice(0, 5)
        let boards = this.boardList.filter(board => {
          let idx = best.find(b => b.articleNo === board.articleNo)
          return idx === undefined
        })
        return best.concat(boards)
      }
      return this.boardList
    }
  },
  watch: {
    '$route': 'changeRouter',
    categoryNo () {
      this.search()
    },
    allBoardList () {
      if (this.allBoardList) {
        this.sortAllBoardList = [].concat(this.allBoardList)
        this.sortAllBoardList.sort((a, b) => {
          let diff = b.viewCnt - a.viewCnt
          if (diff === 0) {
            var dateA = new Date(a.registerYmdt.replace(/-/g, '/'))
            var dateB = new Date(b.registerYmdt.replace(/-/g, '/'))
            if (dateA > dateB) {
              return -1
            } else {
              return 1
            }
          }
          return diff
        })
      }
    }

  },
  components: {
    FaqItem
  },
  created () {
    this.init()
  },
  methods: {
    clickTab (categoryNo) {
      this.categoryNo = categoryNo
    },
    fetchMore () {
      this.$store.dispatch('board/featchBoardMore')
    },
    searchClick () {
      if (!this.keyword) {
        alert('검색어를 입력하세요.')
        return
      }
      this.$router.push({
        path: `/etc/center/faq/search`,
        query: {
          keyword: this.keyword
        }
      })
    },
    search () {
      const boardParams = {
        boardNo: process.env.VUE_APP_NCP_FAQ_BOARDNO,
        keyword: this.keywordQuery,
        categoryNo: this.categoryNo || ''
      }
      this.$store.dispatch('board/featchBoard', boardParams)
      this.$store.dispatch('board/featchAllBoard', { boardNo: process.env.VUE_APP_NCP_FAQ_BOARDNO })
    },
    changeRouter () {
      this.init()
    },
    init () {
      this.keyword = this.keywordQuery
      this.search()
    },
    gotoQA () {
      this.$router.push('/mypage/profile/inquiries')
    }
  }
}
</script>
