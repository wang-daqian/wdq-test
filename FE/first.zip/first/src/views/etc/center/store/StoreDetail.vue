<template>
  <div class="content" v-if="boardDetail">
    <div class="board_zone_sec">
      <div class="board_zone_tit">
        <h2 class="notice">매장정보</h2>
      </div>
      <div class="board_zone_cont">
        <div class="board_zone_list" align="center">

          <div class="notice_title">{{boardDetail.title}}
            <p>{{disYmdt}}</p>
          </div>
          <div class="file_download" v-if="disAttachCnt > 0">
            <p>
              <a :class="{ is_open: isOpen }" href="#" @click.prevent="open">첨부파일 ({{disAttachCnt}})</a>
            </p>
          </div>
          <div class="file_area" v-if="isOpen">
            <ul>
              <li v-for="file in boardDetail.attachments" :key="file.uploadedFileName">
                <a href="#" @click.prevent="download(file)">{{file.fileName}}</a>
              </li>
            </ul>
          </div>
          <div class="notice_contents" v-html="boardDetail.content">
          </div>
          <div class="back_btn">
            <button type="submit" class="btn_back" @click="goList">
              <em>목록</em>
            </button>
          </div>

        </div>
        <!-- //board_zone_list -->

      </div>
      <!-- //board_zone_cont -->
    </div>
  </div>
</template>

<script>
import { getStrDate } from '@/utils/dateUtils'
import { mapState } from 'vuex'

export default {
  name: 'StoreDetail',
  data () {
    return {
      isOpen: false
    }
  },
  computed: {
    ...mapState('board', ['boardDetail']),
    disYmdt () {
      return this.boardDetail.modifyYmdt ? getStrDate(this.boardDetail.modifyYmdt, '.') : getStrDate(this.boardDetail.registerYmdt, '.')
    },
    disAttachCnt () {
      if (this.boardDetail.attachments) {
        return this.boardDetail.attachments.length
      }
      return 0
    }
  },
  methods: {
    open () {
      if (this.boardDetail.attachments && this.boardDetail.attachments.length > 0) {
        this.isOpen = !this.isOpen
      }
    },
    download (file) {
      window.location.assign(file.downloadFileUrl)
    },
    goList () {
      this.$router.push('/etc/center/store')
    }
  }
}
</script>
