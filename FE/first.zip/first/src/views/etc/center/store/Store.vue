<template>
  <div class="content">
    <div class="board_zone_sec">
      <div class="board_zone_tit">
        <h2 class="notice" style="display: block;">매장정보</h2>
      </div>
      <div class="board_zone_cont">
        <div class="board_zone_list" align="center">
          <table class="notice_table">
            <colgroup>
              <col style="width:15%">
              <col style="width:70%;">
              <col style="width:15%">
            </colgroup>
            <thead>
              <tr>
                <th>번호</th>
                <th>제목</th>
                <th>날짜</th>
              </tr>
            </thead>
            <tbody>
              <template v-if="boardList && boardList.length > 0">
                <store-item v-for="(board, index) in boardList" :key="board.articleNo" :notice="board" :idx="totalCount - index" />
              </template>
                <template v-else>
                  <tr>
                    <td colspan="3" align="center">게시글이 존재하지 않습니다.</td>
                  </tr>
                </template>
            </tbody>
          </table>

          <div v-if="boardList && boardList.length < totalCount" class="pagination">
            <p class="pagination-btn">
              <button type="button" class="btn_more" @click.prevent="fetchMore">더보기</button>
            </p>
          </div>

          <!-- //pagination -->

        </div>
        <!-- //board_zone_list -->

      </div>
      <!-- //board_zone_cont -->
    </div>
  </div>
</template>

<script>
import { mapState } from 'vuex'
import StoreItem from '@/components/etc/StoreItem'

export default {
  name: 'Notice',
  data () {
    return {}
  },
  computed: {
    ...mapState('board', ['boardList', 'totalCount'])
  },
  components: {
    StoreItem
  },
  methods: {
    fetchMore () {
      this.$store.dispatch('board/featchBoardMore')
    }
  }
}
</script>
