<template>
  <div id="container" class="body-service">
    <div id="contents">
      <!-- 본문 시작 -->
      <div class="location_wrap">
        <div class="location_cont">
          <em>
            <a href="/" class="local_home">HOME</a> > 고객센터</em>
        </div>
      </div>
      <!-- //location_wrap -->
      <div class="sub_content">
        <div class="side_cont">
          <span class="btn_side_mobile" @click="openMenu = !openMenu">고객센터 메뉴보기</span>
          <div class="sub_menu_box" :style="{display:openMenu?'block':'none'}">
            <h2>고객센터</h2>
            <ul class="sub_menu">
              <li>
                <router-link :class="{ active: startWith($route.path,'/etc/center/notice') }" to='/etc/center/notice'>NOTICE</router-link>
              </li>
              <li>
                <router-link :class="{ active: startWith($route.path,'/etc/center/faq') }" to='/etc/center/faq'>FAQ</router-link>
              </li>
              <li>
                <router-link :class="{ active: startWith($route.path,'/etc/center/store') }" to='/etc/center/store'>매장정보</router-link>
              </li>
            </ul>
          </div>
          <!-- //sub_menu_box -->
          <div class="info_box" v-if="displayMode === 'PC' && companyCenter">
            <dl>
              <dt>고객상담센터</dt>
              <dd>
                <strong class="info_num">{{companyCenter.cscenter.phoneNo}}</strong>
                <br />
                <a :href="`mailto:${companyCenter.cscenter.email}`" class="info_mail_link">{{companyCenter.cscenter.email}}</a>
                <p>운영시간 : AM09:00 ~ PM06:00
                  <br /> 점심시간 : AM12:30 ~ PM01:30
                  <br /> 토/일/공휴일 휴무</p>
              </dd>
            </dl>
          </div>
        </div>
        <!-- //side_cont -->
        <router-view></router-view>
      </div>
      <!-- //sub_content -->
    </div>
    <!-- //본문 끝 contents -->
  </div>
  <!-- //container -->
</template>

<script>
import { startWith } from '@/utils/utils'
import { mapGetters } from 'vuex'

export default {
  name: 'Center',
  props: ['displayMode'],
  data () {
    return {
      openMenu: this.displayMode === 'PC'
    }
  },
  computed: {
    ...mapGetters('common', ['companyCenter'])
  },
  methods: {
    startWith (src, str) {
      return startWith(src, str)
    }
  },
  watch: {
    displayMode () {
      this.openMenu = this.displayMode === 'PC'
    }
  }
}
</script>
