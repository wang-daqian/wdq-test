<template>
    <div id="container">
      <div id="contents">
        <div class="event">
          <div class="area_event_banner2">
            <!-- [D] 이벤트에 맞는 설명으로 alt값 변경 요청 -->
            <img src="../../assets/img/etc/company.jpg">
          </div>
        </div>
      </div>
      <!-- //본문 끝 contents -->
    </div>
    <!-- //container -->
</template>

<script>
export default {
  name: 'Company'
}
</script>

<style scoped>
.area_event_banner2 img {
    display: block;
    max-width: 100%;
    max-height: 100%;
    margin: 0 auto;
}
</style>
