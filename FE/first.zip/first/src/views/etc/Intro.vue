<template>
    <div class="site_ready">
    <strong>서비스 준비중입니다.</strong>
    <p>보다 좋은 서비스를 제공해 드리기 위해 서비스를 점검하고 있습니다.
      <br>
      <br>시스템 점검 시간: 2018년 10월 16일 오전 0시 ~ 2018년 10월 17일 오전 0시까지
      <br>
      <br>빠른 시간 내에 정상적인 이용이 가능하도록 최선을 다하겠습니다.
      <br>감사합니다.</p>
  </div>
</template>
<script>
import $ from 'jquery'

export default {
  metaInfo: {
    title: 'intro'
  },
  created () {
    $('body').addClass('error')
  },
  destroyed () {
    $('body').removeClass('error')
  }
}
</script>
