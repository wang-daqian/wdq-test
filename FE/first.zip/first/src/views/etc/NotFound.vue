<template>
    <div class="blackout">
      <strong>요청하신 페이지를 <em>찾을 수 없습니다.</em></strong>
      <p>
          오류 관련 문의는 <strong>02-446-0114</strong>로 연락하시기 바랍니다.<br>
          서비스 이용에 불편을 드려서 죄송합니다.
      </p>
      <div class="submitbtn">
          <button type="button" class="skinbtn default btn-m2" id="btnGoBack" @click.prevent="goBack"><b>뒤로가기</b></button>
          <router-link to="/"><button type="button" class="skinbtn default btn-m2" id="btnGoHome" style="margin-left: 5px"><b>홈 바로가기</b></button></router-link>
      </div>
    </div>
</template>
<script>
import $ from 'jquery'

export default {
  methods: {
    goBack () {
      this.$router.back()
    }
  },
  metaInfo: {
    title: 'NotFound'
  },
  created () {
    $('body').addClass('error')
  },
  destroyed () {
    $('body').removeClass('error')
  }
}
</script>
