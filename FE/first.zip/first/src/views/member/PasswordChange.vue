<template>
  <div id="container">
    <div id="contents">
      <!-- 본문 시작 -->

      <div class="location_wrap">
        <div class="location_cont">
          <em>
            <router-link class="local_home" to="/">HOME</router-link> &gt; 비밀번호 찾기</em>
        </div>
      </div>
      <!-- //location_wrap -->

      <div class="sub_content">

        <!-- //side_cont -->
        <div class="content_box">
          <div class="member_wrap">
            <div class="member_tit">
              <h2>비밀번호 찾기</h2>
            </div>
            <div class="member_cont">
              <div class="find_password_box">
                <h3>아이디 입력</h3>
                <p>비밀번호를 찾고자 하는 아이디를 입력해 주세요.</p>
                <div class="login_input">
                  <div class="member_warning">
                    <input type="text" maxlength="20" placeholder="아이디" v-model="memberId">
                    <div style="color:red;" v-if="msg != ''">{{msg}}</div>
                    <p class="info_again">아이디를 모르시나요?
                      <router-link to="/member/findid">아이디 찾기</router-link>
                    </p>
                    <p class="dn" id="errorMessage"></p>
                  </div>
                  <div class="btn_center_box">
                    <button class="btn_member_next" @click="searchAccount">다음</button>
                  </div>
                </div>
              </div>
              <!-- //find_password_box -->
            </div>
            <!-- //member_cont -->
          </div>
          <!-- //member_wrap -->
        </div>
        <!-- //content_box -->
      </div>
      <!-- //sub_content -->
    </div>
    <!-- //본문 끝 contents -->
  </div>
</template>

<script>
import { mapState } from 'vuex'
export default {
  data () {
    return {
      memberId: '',
      msg: ''
    }
  },
  computed: {
    ...mapState('member', ['account'])
  },
  methods: {
    searchAccount () {
      if (this.memberId.length) {
        const _this = this
        this.$store.dispatch('member/searchAccount', this.memberId).then(() => {
          this.$store.commit('member/SET_MEMBERID', _this.memberId)
          if (_this.account) {
            _this.$router.push({
              path: '/member/passwordciselect'
            })
          }
        }).catch(() => {
          this.msg = '일치하는 정보가 없습니다. 다시 확인해 주세요.'
        })
      } else {
        alert('아이디를 입력해주세요')
      }
    }
  },
  mounted () {
    if (this.$route.query) {
      this.memberId = this.$route.query.memberId
    }
  }
}
</script>

<style>
</style>
