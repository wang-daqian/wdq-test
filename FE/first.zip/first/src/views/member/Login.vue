<template>
  <div id="container">
    <div id="contents">
      <!-- 본문 시작 -->

      <div class="location_wrap">
        <div class="location_cont">
          <em>
            <a href="/" class="local_home">HOME</a> &gt; 로그인</em>
        </div>
      </div>
      <!-- //location_wrap -->

      <div class="sub_content">

        <!-- //side_cont -->
        <div class="content_box">
          <div class="member_wrap">
            <div class="member_tit">
              <h2>로그인</h2>
            </div>
            <!-- //member_tit -->
            <div class="member_cont">
              <div class="member_login_box">
                <h3>회원 로그인</h3>
                <div class="login_input_sec">
                  <div>
                    <input type="text" id="loginId" placeholder="아이디" v-model="mInputLogin.memberId" ref="loginMemberId">
                    <input type="password" id="loginPwd" value="" placeholder="비밀번호" @keypress.enter="onLogin" v-model="mInputLogin.password" ref="loginPassword">
                  </div>
                  <button type="submit" @click.prevent="onLogin">로그인</button>
                </div>
                <div class="id_chk">
                  <span class="form_element">
                    <!-- <input type="checkbox" id="saveId" name="saveId" checked="true" v-model="checkedSaveId" @click.prevent="onClickSaveId"> -->
                    <label :class="['check_s', {'on' : checkedSaveId}]" @click.prevent="onClickSaveId">아이디 저장</label>
                  </span>
                  <p class="dn js_caution_msg1">아이디, 비밀번호가 일치하지 않습니다. 다시 입력해 주세요.</p>
                </div>
              </div>
              <!-- //login_box -->
              <div class="member_sns_login">
              </div>
              <div class="btn_login_box">
                <ul>
                  <li>
                    <router-link tag="button" class="btn_member_join" to="/member/joinagreement">회원가입</router-link>
                  </li>
                  <li>
                    <router-link to="/member/findid" tag="button" class="btn_member_white">아이디 찾기</router-link>
                  </li>
                  <li>
                    <router-link to="/member/password" tag="button" class="btn_member_white">비밀번호 찾기</router-link>
                  </li>
                </ul>
              </div>
              <!-- //btn_login_box -->

              <div v-if="guest" class="nonmember_join_box">
                <h3>비회원 주문하기</h3>
                <div class="btn_center_box">
                  <button type="submit" class="btn_member_black" @click="geustOrder">비회원 주문하기</button>
                </div>
              </div>
              <!-- //nonmember_join_box -->
              <div v-else class="nonmember_order_box">
                <h3>비회원 주문조회 하기</h3>
                <div class="order_input_sec">
                  <div>
                    <input type="text" id="nonMemberName" ref="nonMemberName" name="orderNm" v-model="nonMemberName" placeholder="주문자명">
                    <input id="nonMemberOrderNo" ref="nonMemberOrderNo" name="orderNo" v-model="nonMemberOrderNo" placeholder="주문번호" type="text" @keydown="gdNum" @input="gdNum" @keypress.enter="searchNonMemberOrder">
                  </div>
                  <button type="submit" @click.prevent="searchNonMemberOrder">확인</button>
                </div>
                <p class="js_caution_msg2">비회원 주문번호를 잊으신 경우, 고객센터로 문의하여 주시기 바랍니다.</p>
              </div>
            </div>
            <!-- //member_cont -->
          </div>
          <!-- //member_wrap -->
        </div>
        <!-- //content_box -->
      </div>
      <!-- //sub_content -->
    </div>
    <!-- //본문 끝 contents -->

    <!-- 휴면회원 해제-->
    <login-pop @onLogin="onLogin" ref="loginFreezePopup" />
    <!-- //휴면회원 해제-->
  </div>
</template>

<script>
import { mapActions } from 'vuex'
import cookies from 'js-cookie'
import { replacePattern } from '@/utils/validateUtils'
import LoginPop from './LoginPop'
// import { loadWpAstgScripts } from '@/utils/utils'

export default {
  props: { loginStatus: { error: false, code: '' } },
  components: {
    LoginPop
  },
  data () {
    return {
      guest: this.$route.query.guest,
      saveIdChecked: false,
      activeLogin: {
        memberIdStatus: 0,
        passwordStatus: 0
      },
      mInputLogin: {
        memberId: cookies.get('FstAppMemberID') || '',
        password: ''
      },
      nonMemberOrderNo: '',
      nonMemberName: ''
    }
  },
  computed: {
    checkedSaveId: {
      // getter
      get () {
        return this.saveIdChecked
      },
      // setter
      set (newValue) {
        this.saveIdChecked = newValue
      }
    },

    memberIdClassStatus () {
      return this.activeLogin.memberIdStatus === 0 && (!this.loginStatus || (this.loginStatus && !this.loginStatus.error))
    },
    passwordClassStatus () {
      return this.activeLogin.passwordStatus === 0 && (!this.loginStatus || (this.loginStatus && !this.loginStatus.error))
    }
  },

  methods: {
    ...mapActions('guestorder', ['getGuestOrder']),
    ...mapActions('profile', ['memberLogin']),
    ...mapActions('cart', ['addToCart']),

    onClickSaveId () {
      this.saveIdChecked = !this.saveIdChecked
    },

    onLogin () {
      if (this.checkedSaveId) {
        cookies.set('FstAppMemberID', this.mInputLogin.memberId)
      } else {
        cookies.remove('FstAppMemberID')
      }

      if (this.mInputLogin.memberId === '') {
        alert('아이디를 입력해주세요')
      } else if (this.mInputLogin.password === '') {
        alert('비밀번호를 입력해주세요')
      } else {
        const loginParams = {
          memberId: this.mInputLogin.memberId,
          password: this.mInputLogin.password
        }
        let redirect = this.$route.query.redirect
        const params = {
          redirect: redirect,
          loginParams: loginParams
        }
        const _this = this
        this.memberLogin(params).then(() => {
          const dormantMember = cookies.get('1ST_APPERAL_dormantMember')
          if (dormantMember) {
            this.$refs.loginFreezePopup.openLoginFreezePopup()
            return false
          }
          cookies.set('FstAppShowMemberID', this.mInputLogin.memberId)
          // const item = [{ i: this.mInputLogin.memberId, t: this.mInputLogin.memberId, p: '1', q: '1' }]
          // loadWpAstgScripts('Login', item)
          const carts = JSON.parse(window.localStorage.cartInfo || '[]')
          if (carts.length > 0) {
            _this.addToCart(carts).then(res => {
              delete window.localStorage.cartInfo
              _this.goRedirect(redirect)
            }).catch(() => {
              _this.goRedirect(redirect)
            })
          } else {
            _this.goRedirect(redirect)
          }
        }).catch((e) => {
          if (e.data.code === 'M0019') {
            alert('로그인 정보가 맞지 않습니다.')
          } else if (e.data.code === 'M0038') {
            if (confirm('기존 엘리콘 회원은 퍼스트어패럴 몰 최초 접속시 비밀번호 재설정이 필요합니다. 비밀번호 재설정 후 이용해 주세요.')) {
              this.$router.push({
                path: '/member/password',
                query: {
                  memberId: this.mInputLogin.memberId
                }
              })
            }
          }
          return false
        })
      }
    },
    goRedirect (redirect) {
      if (redirect !== '' && typeof redirect !== 'undefined') {
        window.location.replace(decodeURIComponent(redirect))
      } else {
        window.location.replace('/')
      }
    },
    searchNonMemberOrder () {
      const _this = this
      if (this.nonMemberName.length === 0) {
        alert('주문자명을 입력해주세요.')
        this.$refs.nonMemberName.focus()
      } else if (this.nonMemberOrderNo.length === 0) {
        alert('주문번호를 입력해주세요.')
        this.$refs.nonMemberOrderNo.focus()
      } else {
        if (!this.isNum(this.nonMemberOrderNo)) {
          alert('숫자만 입력가능.')
          this.$refs.nonMemberOrderNo.focus()
        } else {
          this.getGuestOrder({ name: this.nonMemberName, orderNo: this.nonMemberOrderNo }).then((res) => {
            _this.$router.push({
              path: `/nonmember/orderdetail/${res}`
            })
          }).catch((e) => {
            if (e.data.code === 'E0005' || e.data.code === 'O0009' || e.data.code === 'O0018') {
              alert('입력 정보와 일치하는 주문이 없습니다. 정보 재확인 후 조회해 주세요.')
            }
          })
        }
      }
    },
    isNum (val) {
      return val.match('^[0-9]*$')
    },
    geustOrder () {
      if (this.$route.query.redirect) {
        window.location.replace(decodeURIComponent(this.$route.query.redirect))
      }
    },
    gdNum: function () {
      if (this.nonMemberOrderNo !== '') {
        this.nonMemberOrderNo = replacePattern(this.nonMemberOrderNo, /[^\d]/g, '')
      }
    }
  }
}
</script>
