<template>
  <div id="container">
    <div id="contents">
      <!-- 본문 시작 -->
      <div class="location_wrap">
        <div class="location_cont">
          <em>
            <router-link to="/" class="local_home">HOME</router-link>&gt; 아이디 찾기</em>
        </div>
      </div>
      <!-- //location_wrap -->
      <div class="sub_content">
        <!-- //side_cont -->
        <div class="content_box">
          <div class="member_wrap">
            <div class="member_tit">
              <h2>아이디찾기</h2>
            </div>
            <!-- //member_tit -->
            <div class="member_cont" v-if="mode === 'find'">
              <div class="find_id_box">
                <div class="find_id_sec">
                  <h3>회원 아이디찾기</h3>
                  <div class="login_input">
                    <div>
                      <input type="text" ref="memberName" placeholder="이름" v-model="memberName">
                      <input type="text" ref="mobileNo" placeholder="휴대폰번호" v-model="mobileNo">
                    </div>
                    <button type="submit" class="btn_member_id" @click="findMyId">아이디 찾기</button>
                  </div>
                  <p v-if="error" style="color:red">일치하는 정보가 없습니다. 쇼핑몰 고객센터로 문의해 주세요.</p>
                </div>
                <!-- //find_id_sec -->
                <div class="btn_member_sec">
                  <ul>
                    <li>
                      <router-link to="/member/password" tag="button" class="btn_member_white">비밀번호 찾기</router-link>
                    </li>
                    <li>
                      <router-link to="/member/login" tag="button" class="btn_comfirm">로그인하기</router-link>
                    </li>
                  </ul>
                </div>
                <!-- //btn_member_sec -->
              </div>
              <!-- //find_id_box -->
            </div>
            <div class="member_cont" v-else>
              <form id="formFindId" method="post" action="../member/member_ps.php" novalidate="novalidate">
                <div class="find_id_box">
                  <div class="find_id_sec">
                    <p class="id_con">아이디 : {{memberIdInfo.id}}</p>
                  </div>
                  <!-- //find_id_sec -->
                  <div class="btn_member_sec">
                    <ul>
                      <li>
                         <router-link to="/member/password" tag="button" class="btn_member_white">비밀번호 찾기</router-link>
                      </li>
                      <li>
                        <router-link to="/member/login" tag="button" class="btn_comfirm">로그인하기</router-link>
                      </li>
                    </ul>
                  </div>
                  <!-- //btn_member_sec -->
                </div>
                <!-- //find_id_box -->
              </form>
            </div>
            <!-- //member_cont -->
          </div>
          <!-- //member_wrap -->
        </div>
        <!-- //content_box -->
      </div>
      <!-- //sub_content -->
    </div>
    <!-- //본문 끝 contents -->
  </div>
</template>

<script>
import { mapState } from 'vuex'
export default {
  data () {
    return {
      memberName: '',
      mobileNo: '',
      mode: 'find',
      error: false
    }
  },
  computed: {
    ...mapState('profile', ['memberIdInfo'])
  },
  methods: {
    findMyId () {
      this.error = false
      if (this.memberName === '') {
        alert('이름은 필수값 입니다.')
        this.$refs.memberName.focus()
        return
      }
      if (this.mobileNo === '') {
        alert('휴대폰번호 필수값 입니다.')
        this.$refs.mobileNo.focus()
        return
      }
      this.$store.dispatch('profile/findId', {
        memberName: this.memberName, mobileNo: this.mobileNo
      }).then(() => {
        this.mode = 'ret'
      }).catch((e) => {
        if (e.data.code === 'M0017') {
          this.error = true
        } else {
          alert(e.data.message)
        }
      })
    }
  }
}
</script>

<style>
</style>
