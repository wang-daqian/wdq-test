<template>
  <div id="container">
    <div id="contents">
      <!-- 본문 시작 -->

      <div class="location_wrap">
        <div class="location_cont">
          <em>
            <router-link class="local_home" to="/">HOME</router-link> &gt; 본인인증 인증번호 확인</em>
        </div>
      </div>
      <!-- //location_wrap -->

      <div class="sub_content">

        <!-- //side_cont -->
        <div class="content_box">
          <div class="member_wrap">
            <div class="member_tit">
              <h2>비밀번호 찾기</h2>
            </div>
            <div class="member_cont">
              <div class="find_password_box">
                <h3>인증번호 입력</h3>
                <p class="guide">수신된 인증번호를 입력해 주세요.</p>
                <div class="login_input">
                  <div class="member_warning">
                    <input type="text" v-model="code" class="text" placeholder="인증번호 입력">
                    <div id="errorMessage" v-if="error">
                      <p class="info_again">잘못된 인증번호 입니다. 다시 입력해 주세요.
                        <a href="#" @click.prevent="codeSend">인증번호 다시받기</a>
                      </p>
                    </div>
                    <div id="guideMsg" v-else>
                      <p class="info_again">
                        <a href="#" @click.prevent="codeSend">인증번호 다시받기</a>
                      </p>
                    </div>
                  </div>
                  <!-- //member_warning -->
                  <div class="btn_center_box">
                    <router-link to="/member/passwordciselect" class="btn_member_prev" tag="button">이전</router-link>
                    <button class="btn_member_next" @click="next">다음</button>
                  </div>
                </div>
              </div>
              <!-- //find_password_box -->
            </div>
            <!-- //member_cont -->

          </div>
          <!-- //member_wrap -->
        </div>
        <!-- //content_box -->
      </div>
      <!-- //sub_content -->
    </div>
    <!-- //본문 끝 contents -->
  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex'
export default {
  data () {
    return {
      code: '',
      error: false
    }
  },
  computed: {
    ...mapState('member', ['account', 'certType'])
  },
  methods: {
    ...mapActions('authentication', ['authentications']),
    codeSend () {
      const type = this.certType === 'email' ? 'EMAIL' : 'SMS'
      this.authentications({
        memberNo: this.account.memberNo,
        type: type,
        usage: 'FIND_PASSWORD'
      }).then(() => {
        alert('메일이 발송되었습니다.')
      })
    },
    next () {
      if (this.code === '') {
        alert('인증번호를 입력해주세요.')
        return
      }
      const type = this.certType === 'email' ? 'EMAIL' : 'SMS'
      this.$store.dispatch('authentication/certiAuthentications', {
        memberNo: this.account.memberNo,
        usage: 'FIND_PASSWORD',
        type: type,
        certificatedNumber: this.code
      }).then((r) => {
        alert('인증되었습니다.')
        this.$store.commit('member/SET_NUMBER', this.code)
        this.$router.push({
          path: '/member/passwordreset'
        })
      }).catch((e) => {
        this.error = true
      })
    }
  },
  created () {
    if (!this.account) {
      this.$router.push({
        path: '/member/password'
      })
    }
  }
}
</script>

<style>
</style>
