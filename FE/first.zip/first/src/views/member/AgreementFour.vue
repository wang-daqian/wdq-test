<template>
  <div id="container">
    <div id="contents">
      <!-- 본문 시작 -->

      <div class="location_wrap">
        <div class="location_cont">
          <em>
            <a href="/" class="local_home">HOME</a> &gt; 서비스 이용약관</em>
        </div>
      </div>
      <!-- //location_wrap -->

      <div class="sub_content" style="padding-top: 45px;">

        <!-- //side_cont -->
        <div class="content_box">
          <div class="join_agreement_wrap">
            <div class="member_tit">
              <h2>개인정보 처리업무 위탁에 대한 동의</h2>
            </div>
            <div class="service_cont">
              <br>
              <br>
              (주)퍼스트어패럴은 이용자에게 보다 원활한 서비스를 제공하기 위하여 다음과 같이 개인정보 처리 관련 업무를 외부 전문업체에 위탁하고 있습니다 <br>
              <br>
              <div class="board_list_qa">
                <table class="agreement_list_table" style="width:100%">
                  <colgroup>
                    <col style="width:10%">
                    <col style="width:30%">
                    <col style="width:30%">
                    <col style="width:30%">
                  </colgroup>
                  <thead>
                    <tr>
                      <th></th>
                      <th>수탁자</th>
                      <th>위탁업무내용</th>
                      <th>제공정보</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>1</td>
                      <td>NHN엔터테인먼트</td>
                      <td>시스템 운영및 유지보수</td>
                      <td> 회원정보, 구매정보, 배송정보</td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>CJ대한통운</td>
                      <td>제품 배송</td>
                      <td>주문정보, 배송정보</td>
                    </tr>
                    <tr>
                      <td>3</td>
                      <td>㈜한국사이버결제</td>
                      <td>결제대행업무</td>
                      <td>구매정보</td>
                    </tr>
                    <tr>
                      <td>4</td>
                      <td>NHN엔터테인먼트</td>
                      <td>SMS/LMS/MMS 발송</td>
                      <td>회원정보</td>
                    </tr>

                  </tbody>
                </table>

              </div>
              <br>
              위탁계약 체결 시 위탁업무 수행목적 외 개인정보 처리금지, 기술적 관리적 보호조치, 재 위탁 제한, 수탁자에 대한 관리 및 감독, 손해배상 등 책임에 관한 사항을 계약서 등 문서에 명시하고, 수탁자가 개인정보를 안전하게 처리하는지를 관리, 감독합니다. <br>
              위탁업무의 내용이나 수탁업체가 변경될 경우 본 개인정보 처리방침을 통해 변경내용을 이용자에게 알리고 동의 절차를 진행하겠습니다.
            </div>
          </div>
        </div>
        <!-- //content_box -->
      </div>
      <!-- //sub_content -->
    </div>
    <!-- //본문 끝 contents -->
  </div>
</template>
