<template>
  <div id="container">
    <div id="contents">
      <!-- 본문 시작 -->

      <div class="location_wrap">
        <div class="location_cont">
          <em>
            <router-link class="local_home" to="/">HOME</router-link> &gt; 비밀번호 찾기</em>
        </div>
      </div>
      <!-- //location_wrap -->

      <div class="sub_content">

        <!-- //side_cont -->
        <div class="content_box">
          <div class="member_wrap">
            <div class="member_tit">
              <h2>비밀번호 찾기</h2>
            </div>
            <div class="member_cont">
              <div class="find_mode_box">
                <h3>인증수단 선택</h3>
                <p>본인인증 방법을 선택해 주세요.</p>
                <div class="login_input">
                  <div class="form_element" v-if="accountReal">
                    <ul>
                      <!-- <li v-if="account.email && account.email.length">
                        <label for="rating1" :class="['choice_s', {'on':certType === 'email'}]" @click="certType='email'">
                          <p>
                            <span>이메일 인증</span>
                            <span class="contact">({{account.email}})</span>
                          </p>
                        </label>
                        <p class="txt_ex">
                          <span>가입시 등록한 이메일로 인증번호가 발송됩니다.</span>
                        </p>
                      </li> -->
                      <li v-if="account.mobileNo && account.mobileNo.length">
                        <label for="rating2" :class="['choice_s', {'on':certType === 'sms'}]" @click="certType='sms'">
                          <p>
                            <span>SMS인증</span>
                            <span class="contact">({{account.mobileNo}})</span>
                          </p>
                        </label>
                      </li>
                    </ul>
                  </div>
                  <p class="txt_war_1" v-else>인증 가능한 이메일/SMS 정보가 없습니다. 쇼핑몰 고객센터로 문의해주세요.</p>
                  <div class="btn_center_box">
                    <button @click="next" class="btn_member_next">다음</button>
                  </div>
                </div>
              </div>
              <!-- //find_password_box -->
            </div>
            <!-- //member_cont -->
          </div>
          <!-- //member_wrap -->
        </div>
        <!-- //content_box -->
      </div>
      <!-- //sub_content -->
    </div>
    <!-- //본문 끝 contents -->
  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex'
export default {
  data () {
    return {
      certType: 'sms'
    }
  },
  computed: {
    ...mapState('member', ['account']),
    accountReal () {
      return this.account && (this.account.email || this.account.mobileNo)
    }
  },
  methods: {
    ...mapActions('authentication', ['authentications']),
    next () {
      if (!this.accountReal) {
        this.$router.push({
          path: '/member/password'
        })
        return
      }
      if (this.certType === '') {
        alert('인증수단을 선택해 주세요.')
        return
      }
      this.$store.commit('member/SET_CERTTYPE', this.certType)
      if (this.certType === 'email') {
        this.authentications({
          memberNo: this.account.memberNo,
          type: 'EMAIL',
          usage: 'FIND_PASSWORD'
        }).then(() => {
          this.$router.push({
            path: '/member/passwordcerti'
          })
        })
      } else if (this.certType === 'sms') {
        this.authentications({
          memberNo: this.account.memberNo,
          type: 'SMS',
          usage: 'FIND_PASSWORD'
        }).then(() => {
          this.$router.push({
            path: '/member/passwordcerti'
          })
        })
      } else {
        alert('인증수단을 선택해 주세요.')
      }
    }
  }
}
</script>

<style>
</style>
