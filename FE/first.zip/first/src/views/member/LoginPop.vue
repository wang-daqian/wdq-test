<template>
  <!--휴면회원 해제-->
  <div class="popup_wrap" v-show="active">
    <div class="popup">
      <h1>휴면회원 해제</h1>
      <div class="txt_con">
        <h2>퍼스트어패럴몰을 다시 찾아주셔서 감사합니다!</h2>
        <dl>
          <dt>지난 1년 동안 퍼스트어패럴몰 이용이 없으셨기 때문에 현재 회원님 계정 정보는 휴면으로 전환되어 있습니다.</dt>
          <dd>퍼스트어패럴몰은 1년 이상 이용하지 않는 회원의 개인정보는 휴면으로 전환하여 개인정보 유출의 위험성을 최소화 하고 있습니다.<br>
            휴면처리 된 회원의 개인정보를 보호하기 위해 접근이 불가능한 별도 보관장치에 분리보관 됩니다.</dd>
        </dl>
      </div>
      <ul class="btn_list">
        <li>
          <button class="btn_white" @click="closeBtn">닫기</button>
        </li>
        <li>
          <button class="btn_gray" @click="submitBtn">휴면계정 활성화</button>
        </li>
      </ul>
    </div>
  </div>
  <!-- //휴면회원 해제-->
</template>

<script>
import { addClass, removeClass, logoutRemoveCookie } from '@/utils/utils'
import cookies from 'js-cookie'
export default {
  data () {
    return {
      active: false,
      bodyScrollTop: 0
    }
  },
  methods: {
    closeBtn () {
      if (confirm('휴면계정을 활성화하지 않으셨습니다. 팝업을 닫으시겠습니까?')) {
        this.closeFreezePopup()
      }
    },
    closeFreezePopup () {
      this.active = false
      removeClass(document.body, 'no_scroll')
      document.body.style.top = '0px'
      window.scrollTo(0, this.bodyScrollTop * -1)
      logoutRemoveCookie()
    },
    openLoginFreezePopup () {
      this.active = true
      const currScroll = document.body.scrollTop | document.documentElement.scrollTop
      this.bodyScrollTop = currScroll * -1
      document.body.style.top = this.bodyScrollTop + 'px'
      addClass(document.body, 'no_scroll')
    },
    submitBtn () {
      let param = cookies.get('1ST_APPERAL_dormantMember')
      let objectParam = JSON.parse(param)
      objectParam['authType'] = 'NONE'
      this.$store.dispatch('profile/changeFreeze', objectParam).then(() => {
        alert('휴면 해제 되었습니다. 행복한 쇼핑 되세요.')
        this.closeFreezePopup()
        this.$emit('onLogin')
      })
    }
  }
}
</script>
