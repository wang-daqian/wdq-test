<template>
  <div id="container">
    <div id="contents">
      <!-- 본문 시작 -->

      <div class="location_wrap">
        <div class="location_cont">
          <em>
            <a href="/" class="local_home">HOME</a> &gt; 서비스 이용약관</em>
        </div>
      </div>
      <!-- //location_wrap -->

      <div class="sub_content">

        <!-- //side_cont -->
        <div class="content_box">
          <div class="join_agreement_wrap">
            <div class="member_tit">
              <h2>마케팅정보 수신 동의</h2>
            </div>
            <div class="service_cont">
              <br>
              <br>
              <b>수집 목적</b><br>
              신규 서비스(제품) 개발 및 맞춤 서비스 제공, 이벤트 및 광고성 정보 제공 및 참여기회 제공, 인구통계학적 특성에 따른 서비스 제공 및 광고 게재, 서비스의 유효성 확인, 접속빈도 파악 또는 회원의 서비스 이용에 대한 통계, 이벤트 참여 기회 제공, app push 발송<br>
              <br>
              <b>수집 항목 </b><br>
              성명, 생년월일, 주소, 이메일, 휴대폰번호<br>
              <br>
              <b>보유 기간</b><br>
              회원 탈퇴 후 60일까지 또는 해당서비스 동의 철회 시 까지 <br>
              선택적 정보 수집에 대한 동의를 거부하실 수 있으며, 거부하시더라도 회원가입, 상품구매 등 기본 서비스 이용에는 제한을 받지 않습니다. 단, 부가서비스 이용은 제한됩니다.
            </div>
          </div>
        </div>
        <!-- //content_box -->
      </div>
      <!-- //sub_content -->
    </div>
    <!-- //본문 끝 contents -->
  </div>
</template>
