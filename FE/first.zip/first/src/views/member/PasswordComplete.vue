<template>
  <div id="container">
    <div id="contents">
      <!-- 본문 시작 -->

      <div class="location_wrap">
        <div class="location_cont">
          <em>
            <router-link class="local_home" to="/">HOME</router-link> &gt; 비밀번호 변경 완료</em>
        </div>
      </div>
      <!-- //location_wrap -->

      <div class="sub_content">

        <!-- //side_cont -->
        <div class="content_box">
          <div class="member_wrap">
            <div class="member_tit">
              <h2>비밀번호 찾기</h2>
            </div>
            <div class="member_cont">
              <div class="find_password_complete_box">
                <p>비밀번호가 정상적으로 변경되었습니다.</p>
                <div class="btn_center_box">
                  <router-link class="btn_comfirm" tag="button" to="/member/login" >로그인</router-link>
                </div>
              </div>
              <!-- //find_password_complete_box -->
            </div>
            <!-- //member_cont -->
          </div>
          <!-- //member_wrap -->
        </div>
        <!-- //content_box -->
      </div>
      <!-- //sub_content -->
    </div>
    <!-- //본문 끝 contents -->
  </div>
</template>

<script>
export default {

}
</script>

<style>
</style>
