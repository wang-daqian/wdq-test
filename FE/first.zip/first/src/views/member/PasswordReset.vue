<template>
  <div id="container">
    <div id="contents">
      <!-- 본문 시작 -->

      <div class="location_wrap">
        <div class="location_cont">
          <em>
            <router-link class="local_home" to="/">HOME</router-link> &gt; 비밀번호 새로 등록
          </em>
        </div>
      </div>
      <!-- //location_wrap -->

      <div class="sub_content">

        <!-- //side_cont -->
        <div class="content_box">
          <div class="member_wrap">
            <div class="member_tit">
              <h2>비밀번호 찾기</h2>
            </div>
            <div class="member_cont">
              <div class="find_password_reset_box">
                <h3>비밀번호 변경</h3>
                <p>새로운 비밀번호를 등록해 주세요.</p>
                <div class="login_input">
                  <div class="js_input_pw">
                    <div :class="{'member_warning prior_wrong':error}">
                      <input v-model="password1" @blur="validatePassword1" type="password" autocomplete="off" placeholder="영문+숫자+특수문자  포함해서 8~20자 까지 가능" minlength="8" maxlength="20">
                    </div>
                    <div class="msg text_warning" v-if="error">{{newPwdTxt}}</div>
                  </div>
                  <div class="js_input_pw">
                    <div :class="{'member_warning prior_wrong':confirmError}">
                      <input v-model="password2" @blur="validatePassword2" type="password" autocomplete="off" placeholder="새 비밀번호 확인" minlength="8" maxlength="20">
                    </div>
                    <div class="msg text_warning" v-if="confirmError">{{confirmTxt}}</div>
                  </div>
                  <div class="btn_center_box">
                    <button type="button" id="btnConfirm" class="btn_member_ok" @click="passwordChange">확인</button>
                  </div>
                </div>
              </div>
              <!-- //find_password_reset_box -->
            </div>

            <!-- //member_cont -->
          </div>
          <!-- //member_wrap -->
        </div>
        <!-- //content_box -->
      </div>
      <!-- //sub_content -->
    </div>
    <!-- //본문 끝 contents -->
  </div>
</template>

<script>
import { mapState } from 'vuex'
export default {
  data () {
    return {
      error: false,
      confirmError: false,
      password1: '',
      password2: '',
      confirmTxt: '',
      newPwdTxt: ''
    }
  },
  computed: {
    ...mapState('member', ['account', 'certType', 'certificationNumber', 'searchMemberId'])
  },
  methods: {
    validatePassword1 () {
      this.error = false
      let reg = /^(?=.*[0-9])(?=.*[a-zA-Z])(?=.*[!@#$%^&+=_.()-])[A-Za-z0-9!@#$%^&+=_.()-]{8,20}$/
      if (this.password1 === '') {
        this.error = true
        this.newPwdTxt = '비밀번호는 띄어쓰기 없이 8-20자 영문, 숫자, 특수문자 조합으로 입력하셔야 합니다.'
      } else if (!reg.test(this.password1)) {
        this.error = true
        if (this.password1.length < 8) {
          this.newPwdTxt = '비밀번호는  띄어쓰기 없이 8-20자  영문, 숫자, 특수문자 조합으로  입력하셔야 합니다.'
        } else {
          let specCharacters = this.password1.replace(/[A-Za-z0-9!@#$%^&+=_.()-]/g, '')
          if (specCharacters !== '') {
            this.newPwdTxt = '특수문자는 !@#$%^&+=-_.()만 입력 가능합니다.'
          } else {
            this.newPwdTxt = '비밀번호는 띄어쓰기 없이 8-20자 영문, 숫자, 특수문자 조합으로 입력하셔야 합니다.'
          }
        }
      }
      return this.error
    },
    validatePassword2 () {
      this.confirmError = false
      if (this.password1 === '') {
        this.confirmError = true
        this.confirmTxt = '비밀번호 확인 값을 입력해 주세요.'
      } else if (this.password1 !== this.password2) {
        this.confirmError = true
        this.confirmTxt = '비밀번호와 비밀번호 확인 값이 다릅니다.'
      }
      return this.confirmError
    },
    passwordChange () {
      if (this.validatePassword1()) {
        return
      }

      if (this.validatePassword2()) {
        return
      }
      const loginParams = {
        memberId: this.searchMemberId,
        password: this.password1
      }

      this.$store.dispatch('profile/memberLoginWithoutSet', loginParams).then(() => {
        this.error = true
        this.newPwdTxt = '기존 비밀번호와 동일한 비밀번호를 사용할 수 없습니다. 새 비밀번호를 입력해 주세요.'
      }).catch(() => {
        this.$store.dispatch('member/passwordReset', {
          type: this.certType,
          certificationNumber: this.certificationNumber,
          memberId: this.searchMemberId,
          newPassword: this.password1
        }).then(() => {
          this.$router.push({
            path: '/member/passwordcomplete'
          })
        })
      })
    }
  },
  created () {
    if (!this.account) {
      this.$router.push({
        path: '/member/password'
      })
    }
  }
}
</script>

<style>
</style>
