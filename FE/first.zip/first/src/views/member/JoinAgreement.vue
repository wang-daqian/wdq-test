<template>
  <div id="container">
    <div id="contents">
      <!-- 본문 시작 -->

      <div class="location_wrap">
        <div class="location_cont">
          <em>
            <a href="/" class="local_home">HOME</a> &gt; 회원가입 &gt; 약관동의</em>
        </div>
      </div>
      <!-- //location_wrap -->

      <div class="sub_content">

        <!-- //side_cont -->
        <div class="content_box">
          <div class="join_agreement_wrap">
            <div class="member_tit">
              <h2>회원가입</h2>
              <ol>
                <li class="page_on">
                  <span>01</span> 약관동의
                  <span>
                    <img src="../../assets/img/member/icon_join_step_on.png" alt="">
                  </span>
                </li>
                <li>
                  <span>02</span> 정보입력
                  <span>
                    <img src="../../assets/img/member/icon_join_step_off.png" alt="">
                  </span>
                </li>
                <li>
                  <span>03</span> 가입완료</li>
              </ol>
            </div>
            <!-- //member_tit -->
            <div class="member_cont">
              <form id="formTerms" name="formTerms" method="post" action="../member/join.php">
                <h3>약관동의</h3>
                <div class="join_agreement_cont">
                  <div class="join_agreement_box js_terms_view">
                    <div class="form_element width_360">
                      <input type="checkbox" id="termsAgree1" name="agreementInfoFl" class="require" :checked="selectedNos.indexOf('termsAgree1')>=0" @click="checkedOne('termsAgree1')">
                      <label class="check_s" for="termsAgree1" :class="{'on' : selectedNos.indexOf('termsAgree1')>=0}">
                        퍼스트어패럴몰 이용 약관<strong>(필수)</strong>
                      </label>
                      <span>
                        <a href="../member/agreement1" target="_blank">보기</a>
                      </span>
                    </div>
                  </div>
                  <!-- //join_agreement_box -->

                  <div class="join_agreement_box js_terms_view">
                    <div class="form_element width_360">
                      <input type="checkbox" id="termsAgree2" name="privateApprovalFl1" class="require" :checked="selectedNos.indexOf('termsAgree2')>=0" @click="checkedOne('termsAgree2')">
                      <label class="check_s" for="termsAgree2" :class="{'on' : selectedNos.indexOf('termsAgree2')>=0}">
                        전자금융 거래 이용 약관<strong>(필수)</strong>
                      </label>
                      <span>
                        <a href="../member/agreement2" target="_blank">보기</a>
                      </span>
                    </div>
                  </div>

                  <div class="join_agreement_box js_terms_view">
                    <div class="form_element width_360">
                      <input type="checkbox" id="termsAgree3" name="privateApprovalFl2" class="require" :checked="selectedNos.indexOf('termsAgree3')>=0" @click="checkedOne('termsAgree3')">
                      <label class="check_s" for="termsAgree3" :class="{'on' : selectedNos.indexOf('termsAgree3')>=0}">
                        개인정보 수집 및 이용 동의<strong>(필수)</strong>
                      </label>
                      <span>
                        <a href="../member/agreement3" target="_blank">보기</a>
                      </span>
                    </div>
                  </div>
                  <div class="join_agreement_box js_terms_view">
                    <div class="form_element width_360">
                      <input type="checkbox" id="termsAgree4" name="privateApprovalFl3" class="require" :checked="selectedNos.indexOf('termsAgree4')>=0" @click="checkedOne('termsAgree4')">
                      <label class="check_s" for="termsAgree4" :class="{'on' : selectedNos.indexOf('termsAgree4')>=0}">
                        개인정보 처리업무 위탁에 대한 동의<strong>(필수)</strong>
                      </label>
                      <span>
                        <a href="../member/agreement4" target="_blank">보기</a>
                      </span>
                    </div>

                  </div>
                  <div class="join_agreement_box js_terms_view">
                    <div class="form_element width_360">
                      <input type="checkbox" id="termsAgree5" name="privateApprovalFl4" class="require" :checked="selectedNos.indexOf('termsAgree5')>=0" @click="checkedOne('termsAgree5')">
                      <label class="check_s" for="termsAgree5" :class="{'on' : selectedNos.indexOf('termsAgree5')>=0}">
                        마케팅 정보 수신 동의<strong>(선택)</strong>
                      </label>
                      <span>
                        <a href="../member/agreement5" target="_blank">보기</a>
                      </span>
                    </div>
                  </div>
                </div>
                <div class="join_agreement_cont">
                  <div class="join_agreement_box js_terms_view">
                    <div class="form_element">
                      <label class="check" for="allAgree" :class="{'on' : allChecked}" @click="checkedAll">
                        퍼스트어패럴몰의 모든 약관을 확인하고 전체 동의합니다.
                      </label>
                    </div>
                    <div class="form_element">
                      퍼스트어패럴몰이 위와 같이 수집하는 개인정보에 대해, 동의하지 않거나 개인정보를 기재하지 않음으로써 거부할 수 있습니다. 다만, 이때 회원에게 제공되는 서비스가 제한될 수
                      있습니다.
                    </div>
                  </div>
                  <div class="important_check_box">
                    <strong class="important_check" v-show="tipsShow">필수 항목을 체크해주세요.</strong>
                  </div>
                </div>
                <!-- //join_agreement_cont -->
                <!--  -->
                <!-- //join_certify_box -->

                <div class="btn_center_box">
                  <button type="button" id="btnNextStep" class="btn_member_next" @click="nextStage">다음단계</button>
                </div>
                <!-- //btn_member_sec -->
              </form>
            </div>
            <!-- //member_cont -->
          </div>
          <!-- //join_agreement_wrap -->
        </div>
        <!-- //content_box -->
      </div>
      <!-- //sub_content -->
    </div>
    <!-- //본문 끝 contents -->
  </div>
</template>

<script>
export default {
  data () {
    return {
      agreenments: [{
        id: 'termsAgree1',
        value: 'agreementInfoFl'
      },
      {
        id: 'termsAgree2',
        value: 'privateApprovalFl1'
      },
      {
        id: 'termsAgree3',
        value: 'privateApprovalFl2'
      },
      {
        id: 'termsAgree4',
        value: 'privateApprovalFl3'
      },
      {
        id: 'termsAgree5',
        value: 'privateApprovalFl4'
      }],
      isCheckedAll: false,
      selectedNos: [],
      tipsShow: false
    }
  },
  computed: {
    allChecked () {
      return this.agreenments.length === this.selectedNos.length
    }
  },
  methods: {
    checkedOne (id) {
      let idIndex = this.selectedNos.indexOf(id)
      if (idIndex >= 0) {
        this.selectedNos.splice(idIndex, 1)
      } else {
        this.selectedNos.push(id)
      }
      if (this.agreenments.length === this.selectedNos.length) {
        this.isCheckedAll = true
      } else {
        this.isCheckedAll = false
      }
    },
    checkedAll () {
      this.isCheckedAll = !this.isCheckedAll
      if (this.isCheckedAll) {
        this.selectedNos = []
        this.agreenments.forEach(function (agreenment) {
          this.selectedNos.push(agreenment.id)
        }, this)
      } else {
        this.selectedNos = []
      }
    },
    nextStage () {
      if (this.selectedNos.indexOf('termsAgree1') < 0 || this.selectedNos.indexOf('termsAgree2') < 0 || this.selectedNos.indexOf('termsAgree3') < 0 || this.selectedNos.indexOf('termsAgree4') < 0) {
        this.tipsShow = true
      } else {
        this.tipsShow = false
        if (this.selectedNos.indexOf('termsAgree5') >= 0) {
          this.$router.push({
            path: '/member/join',
            query: {
              info: true
            }
          })
        } else {
          this.$router.push('../member/join')
        }
      }
    }
  }
}
</script>
