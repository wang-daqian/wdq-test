
<template>
  <div id="container">
    <div id="contents">
      <!-- 본문 시작 -->

      <div class="location_wrap">
        <div class="location_cont">
          <em>
            <a href="/" class="local_home">HOME</a> &gt; 서비스 이용약관</em>
        </div>
      </div>
      <!-- //location_wrap -->

      <div class="sub_content">

        <!-- //side_cont -->
        <div class="content_box">
          <div class="join_agreement_wrap">
            <div class="member_tit">
              <h2>개인정보 수집 및 이용 동의</h2>
            </div>
            <div class="service_cont">
              <br>
              <br>
              (주)퍼스트어패럴은 개인정보를 안전하게 취급하는데 최선을 다합니다. 아래에 동의하시면 서비스에서 편리하게 이용하실 수 있습니다.<br>
              <br>
              <div class="board_list_qa">
                <table class="agreement_list_table" style="width:100%">
                  <colgroup>
                    <col style="width:10%">
                    <col style="width:30%">
                    <col style="width:30%">
                    <col style="width:30%">
                  </colgroup>
                  <thead>
                    <tr>
                      <th></th>
                      <th>수집목적</th>
                      <th>수집항목</th>
                      <th> 보유및 이용기간</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>1</td>
                      <td>이용자식별및 본인여부</td>
                      <td>
                        성명, 생년월일(14세 미만 가입 확인),<br>
                        성별, 아이디, 비밀번호, e-mail,<br>
                        전화번호(휴대폰포함), 주소,<br>
                        e-mail/SMS 수신동의 여부
                      </td>
                      <td>회원탈퇴 시까지</td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>
                        고객서비스 이용에 관한<br>
                        통지,CS대응을 위한<br>
                        이용자 식별
                      </td>
                      <td>이름, 주소, 전화번호</td>
                      <td>회원탈퇴 시까지</td>
                    </tr>
                    <tr>
                      <td>3</td>
                      <td>배송</td>
                      <td>수취인 정보(성명, 전화번호, 주소)</td>
                      <td>회원탈퇴 시까지</td>
                    </tr>
                    <tr>
                      <td>4</td>
                      <td>결제/취소/환불</td>
                      <td>
                        신용카드: 카드사명,카드번호,유효기간<br>
                        휴대전화: 휴대전화번호, 통신사<br>
                        계좌이체: 은행명,계좌번호<br>
                        무통장입금: 은행명,입금자명<br>
                        현금영수증정보
                      </td>
                      <td>회원탈퇴 시까지</td>
                    </tr>

                  </tbody>
                </table>

              </div>
              <br>
              서비스 제공을 위해 필요한 최소한의 개인정보이므로 동의를 해 주셔야 서비스 이용이 가능합니다.
              더 자세한 내용에 대해서는 <a href="../etc/private" class="to-personal-info-process">개인정보처리방침을</a> 참고하시기 바랍니다.

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
