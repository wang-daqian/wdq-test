<template>
  <div id="container">
    <div id="contents">
      <!-- 본문 시작 -->

      <div class="location_wrap">
        <div class="location_cont">
          <em>
            <a href="/" class="local_home">HOME</a> &gt; 회원가입 &gt; 정보입력</em>
        </div>
      </div>
      <!-- //location_wrap -->

      <div class="sub_content">
        <!-- //side_cont -->
        <div class="content_box">
          <div class="join_base_wrap">
            <div class="member_tit">
              <h2>회원가입</h2>
              <ol>
                <li>
                  <span>01</span> 약관동의
                  <span>
                    <img src="../../assets/img/member/icon_join_step_off.png" alt="">
                  </span>
                </li>
                <li class="page_on">
                  <span>02</span> 정보입력
                  <span>
                    <img src="../../assets/img/member/icon_join_step_on.png" alt="">
                  </span>
                </li>
                <li>
                  <span>03</span> 가입완료</li>
              </ol>
            </div>
            <!-- //member_tit -->
            <div class="member_cont">
              <form id="formJoin" name="formJoin" action="http://samplecodefix2.godomall.com/member/member_ps.php" method="post" novalidate="novalidate">

                <!-- 회원가입/정보 기본정보 -->
                <div class="base_info_box">
                  <h3>회원정보 입력</h3>
                  <span class="important">필수 입력 사항</span>
                  <div class="base_info_sec">
                    <table border="0" cellpadding="0" cellspacing="0">
                      <colgroup>
                        <col width="25%">
                        <col width="75%">
                      </colgroup>
                      <tbody>
                        <tr>
                          <th>
                            <span class="important">아이디</span>
                          </th>
                          <td>
                            <div :class="myInput.idPriorWrong?'member_warning prior_wrong':'member_warning'">
                              <input type="text" id="memId" v-model="myInput.memberId" ref="memberId" @keydown="gdMemberId" @input="gdMemberId" @blur="memberIdCheck(false)" placeholder="영문, 숫자로 8~20자까지 가능">
                              <button type="button" ref="memberIdBtn" @click.prevent="isMembIdExist" class="btn_sec">중복확인</button>
                              <p v-if="!myInput.memberIdPassed" class="warning_1">{{myInput.memberIdTxt}}</p>
                            </div>
                          </td>
                        </tr>
                        <tr class="">
                          <th>
                            <span class="important">비밀번호</span>
                          </th>
                          <td class="member_password">
                            <div :class="myInput.psdPriorWrong?'member_warning prior_wrong':'member_warning'">
                              <input type="password" id="newPassword" name="memPw" autocomplete="off" maxlength="20" v-model="myInput.tmpPsd" ref="tmpPsd" @keydown="gdPassword" @input="gdPassword" @blur="validateMemberPassword" placeholder="영문+숫자+특수문자 포함해서 8~20자까지 가능">
                            </div>
                            <div v-if="!myInput.tmpPsdPassed" id="memId-error" class="warning_1">{{myInput.tmpPsdTxt}}</div>
                          </td>
                        </tr>
                        <tr class="">
                          <th>
                            <span class="important">비밀번호 확인</span>
                          </th>
                          <td>
                            <div :class="myInput.psdConfPriorWrong?'member_warning prior_wrong':'member_warning'">
                              <input type="password" class="check-id" maxlength="20" autocomplete="off" placeholder="비밀번호를 한번 더 입력해 주세요." v-model="myInput.passwordConfirm " @blur="confirmPassword" ref="passwordConfirm">
                            </div>
                            <div v-if="myInput.psdConfPriorWrong" id="memId-error" class="warning_1">{{myInput.passwordConfirmTxt}}</div>
                          </td>
                        </tr>
                        <tr>
                          <th>
                            <span class="important">이름</span>
                          </th>
                          <td>
                            <div :class="myInput.memNameIllegal ?'member_warning prior_wrong':'member_warning'">
                              <input type="text" class="middle" v-model="myInput.memberName" maxlength="30" placeholder="한글+영문 만 입력 가능" @keydown="gdEngKor" @input="gdEngKor" @blur="memberNameCheck" ref="memberName">
                            </div>
                            <div v-if="myInput.memNameIllegal" class="warning_1">{{myInput.memberNameTxt}}</div>
                          </td>
                        </tr>
                        <email-authentications ref="emailAuthentications" @showEmailAuthenPop="showEmailAuthenPop"></email-authentications>
                        <sms-authentications ref="smsAuthentications" @showSmsAuthenPop="showSmsAuthenPop" from="JOIN"></sms-authentications>
                        <tr>
                          <th>
                            <span>연락처</span>
                          </th>
                          <td class="member_add_tel">
                            <vue-select-box :showValue="selectPhoneValue" :items="selectPhoneItems" @selected="setPhonePrefix" :width="seletBoxWidth" :noLeftMargin="true" />
                            <input class="cellphone" type="text" v-model="myInput.cellPhone" @keydown="gdNumPhone" @input="gdNumPhone" @blur="gdNumPhone" maxlength="9" placeholder="-  없이 숫자만 입력하세요." :style="{'margin-left':'5px'}">
                          </td>
                        </tr>
                        <tr>
                          <th>
                            <span>생년월일</span>
                          </th>
                          <td class="member_add_tel">
                            <input class="date_birth" type="text" maxlength="8" placeholder="예시 ) 19880807" v-model="myInput.birthday" @keydown="gdNumBirthday" @input="gdNumBirthday" @blur="gdNumBirthday">
                            <vue-select-box :showValue="selectSexValue" :items="selectSexItems" @selected="setSex" :width="seletBoxWidth" />
                          </td>
                        </tr>
                        <tr>
                          <th>
                            <span>수신 동의</span>
                          </th>
                          <td>
                            <div class="form_element">
                              <!-- <input type="checkbox" id="sms" name="sms" v-model="checkedSms"> -->
                              <label for="sms" :class="['check_s', {'on':smsChecked}]" @click="smsChecked=!smsChecked">SMS 수신 동의</label>
                              <!-- <label v-if="!mailAuthFlg" for="e-mail" class="check_s off" :style="{'margin-left':'10px'}">이메일 수신 동의</label> -->
                              <!-- <label v-else for="e-mail" :class="['check_s', {'on':mallChecked}]" @click="mallChecked=!mallChecked" :style="{'margin-left':'10px'}">이메일 수신 동의</label> -->
                              <label for="e-mail" :class="['check_s', {'on':mallChecked}]" @click="mallChecked=!mallChecked" :style="{'margin-left':'10px'}">이메일 수신 동의</label>
                            </div>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                  <!-- //base_info_sec -->
                </div>
                <!-- //base_info_box -->

                <div class="btn_center_box">
                  <button type="button" class="btn_comfirm js_btn_join" value="회원가입" @click.prevent="register">회원가입</button>
                </div>
                <!-- //btn_center_box -->
              </form>
            </div>
            <!-- //member_cont -->
          </div>
          <!-- //join_base_wrap -->
        </div>
        <!-- //content_box -->
      </div>
      <!-- //sub_content -->
    </div>
    <!-- //본문 끝 contents -->
    <authen-popup :textMsg="textMsgEmail" @confirmCallback="emailAuthen" v-if="emailPopFlg"></authen-popup>
    <authen-popup :textMsg="textMsgSms" @confirmCallback="smsAuthen" v-if="smsPopFlg"></authen-popup>
  </div>
</template>

<script>
/* global kakaoPixel */
import { replacePattern } from '@/utils/validateUtils'
import { mapState, mapActions } from 'vuex'
import VueSelectBox from '@/components/common/VueSelectBox'
import EmailAuthentications from '@/components/member/EmailAuthentications'
import SmsAuthentications from '@/components/member/SmsAuthentications'
import AuthenPopup from '@/components/member/AuthenPopup'
import { loadWpAstgScripts } from '@/utils/utils'
import { hasUpperCode } from '@/utils/stringUtils'

export default {
  props: { registerStatus: { registererror: false, msg: '' } },
  data () {
    return {
      myInput: {
        memberId: '',
        memberIdPassed: true,
        memberIdTxt: '',
        idPriorWrong: false,
        tmpPsd: '',
        tmpPsdPassed: true,
        tmpPsdTxt: '',
        psdPriorWrong: false,
        passwordConfirm: '',
        passwordConfirmTxt: '',
        psdConfPriorWrong: false,
        memberName: '',
        memberNameTxt: '',
        memNameIllegal: false,
        prefixPhone: '',
        cellPhone: '',
        sex: '',
        birthday: ''
      },

      mallChecked: false,
      smsChecked: false,
      seletBoxWidth: '120px',

      selectPhoneValue: '',
      selectPhoneItems: [
        {
          label: '선택',
          value: ''
        },
        {
          label: '02',
          value: '02'
        },
        {
          label: '031',
          value: '031'
        },
        {
          label: '032',
          value: '032'
        },
        {
          label: '033',
          value: '033'
        },
        {
          label: '041',
          value: '041'
        },
        {
          label: '042',
          value: '042'
        },
        {
          label: '043',
          value: '043'
        },
        {
          label: '051',
          value: '051'
        },
        {
          label: '052',
          value: '052'
        },
        {
          label: '053',
          value: '053'
        },
        {
          label: '054',
          value: '054'
        },
        {
          label: '055',
          value: '055'
        },
        {
          label: '061',
          value: '061'
        },
        {
          label: '062',
          value: '062'
        },
        {
          label: '063',
          value: '063'
        },
        {
          label: '064',
          value: '064'
        },
        {
          label: '070',
          value: '070'
        }
      ],
      selectSexValue: '',
      selectSexItems: [
        {
          label: '성별',
          value: ''
        },
        {
          label: '여자',
          value: 'F'
        },
        {
          label: '남자',
          value: 'M'
        }
      ],
      textMsgEmail: '\n인증 메일이 발송되었습니다.\n이메일에 발송된 인증번호를 입력하여\n이메일 인증을 완료해 주세요.',
      textMsgSms: '\n인증번호가 발송되었습니다.\n휴대폰으로 발송된 인증번호를 입력하여\n인증을 완료해 주세요.',
      emailPopFlg: false,
      smsPopFlg: false
    }
  },
  components: {
    VueSelectBox,
    EmailAuthentications,
    SmsAuthentications,
    AuthenPopup
  },
  computed: {
    ...mapState('member', ['idCheckRes']),

    checkedMaill: {
      // getter
      get () {
        return this.mallChecked
      },
      // setter
      set (newValue) {
        this.mallChecked = newValue
      }
    },
    checkedSms: {
      // getter
      get () {
        return this.smsChecked
      },
      // setter
      set (newValue) {
        this.smsChecked = newValue
      }
    },
    getEmail () {
      return this.$refs.emailAuthentications.getEmail
    },
    getMobileNum () {
      return this.$refs.smsAuthentications.getMobileNum
    }
  },
  methods: {
    ...mapActions('member', ['checkIdExist']),

    gdMemberId () {
      if (this.myInput.memberId !== '') {
        this.myInput.memberId = replacePattern(this.myInput.memberId, /[^\da-zA-Z]/g, '')
      }
    },
    isCharactersOnlyOrAlphaNumsOnly (input) {
      let reg = /^[A-Za-z0-9]{8,20}$/
      let pattern = new RegExp(reg)

      if (pattern.test(input)) {
        return true
      }
      return false
    },
    async isMembIdExist () {
      if (hasUpperCode(this.myInput.memberId)) {
        alert('아이디를 소문자로 입력해주세요.')
        this.myInput.memberIdTxt = '아이디를 소문자로 입력해주세요.'
        this.myInput.idPriorWrong = true
        return false
      }

      if (this.memberIdCheck(true)) {
        await this.checkIdExist(this.myInput.memberId).then((res) => {
          if (this.idCheckRes.exist) {
            this.myInput.memberIdPassed = false
            this.myInput.memberIdTxt = '이미 등록된 아이디입니다. 다른 아이디를 입력해 주세요.'
          } else {
            this.myInput.memberIdPassed = true
            // this.myInput.memberIdTxt = '사용가능한 아이디입니다.'
            this.myInput.memberIdTxt = ''
            this.myInput.idPriorWrong = false
          }
        })
      }
      if (this.myInput.memberIdPassed) {
        this.myInput.idPriorWrong = false
        return true
      } else {
        this.myInput.idPriorWrong = true
        return false
      }
    },
    memberIdCheck (isCheckBtnClicked) {
      let isValigate = false
      this.myInput.memberIdPassed = false

      if (this.myInput.memberId !== '') {
        if (this.myInput.memberId.length < 8 || this.myInput.memberId.length > 20) {
          this.myInput.memberIdTxt = '아이디는 띄어쓰기 없이 8-20자 영문, 숫자로 입력하셔야 합니다.'
          // this.$refs.memberId.focus()
        } else {
          // let reg = /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{8,20}$/
          if (this.isCharactersOnlyOrAlphaNumsOnly(this.myInput.memberId)) {
            if (isCheckBtnClicked) {
              this.myInput.memberIdPassed = true
            } else {
              this.myInput.memberIdTxt = '입력하신 아이디 중복 확인해 주세요.'
            }
            // this.$refs.memberIdBtn.focus()
            isValigate = true
          } else {
            this.myInput.memberIdTxt = '아이디는 띄어쓰기 없이 8-20자 영문, 숫자로 입력하셔야 합니다.'
            //  this.$refs.memberId.focus()
          }
        }
      } else {
        this.myInput.memberIdTxt = '아이디를 입력해 주세요.'
      }
      this.myInput.idPriorWrong = true
      return isValigate
    },
    gdPassword () {
      if (this.myInput.tmpPsd !== '') {
        this.myInput.tmpPsd = replacePattern(this.myInput.tmpPsd, /\s+/g, '')
      }
    },
    validateMemberPassword () {
      this.myInput.tmpPsdPassed = false

      if (this.myInput.tmpPsd === '') {
        this.myInput.tmpPsdTxt = '비밀번호를 입력해 주세요.'
      } else {
        // let reg = /^(?=.*[0-9])(?=.*[a-zA-Z])(?=.*[\\!@#$%^&+=\-_.()])[A-Za-z0-9\\!@#$%^&+=\-_.()]{8,20}$/
        let reg = /^(?=.*[0-9])(?=.*[a-zA-Z])(?=.*[!@#$%^&+=_.()-])[A-Za-z0-9!@#$%^&+=_.()-]{8,20}$/
        if (!reg.test(this.myInput.tmpPsd)) {
          if (this.myInput.tmpPsd.length < 8) {
            this.myInput.tmpPsdTxt = '비밀번호는  띄어쓰기 없이 8-20자  영문, 숫자, 특수문자 조합으로  입력하셔야 합니다.'
          } else {
            let specCharacters = this.myInput.tmpPsd.replace(/[A-Za-z0-9!@#$%^&+=_.()-]/g, '')
            if (specCharacters !== '') {
              this.myInput.tmpPsdTxt = '특수문자는 !@#$%^&+=-_.()만 입력 가능합니다.'
            } else {
              this.myInput.tmpPsdTxt = '비밀번호는  띄어쓰기 없이 8-20자  영문, 숫자, 특수문자 조합으로  입력하셔야 합니다.'
            }
            // this.$refs.tmpPsd.focus()
          }
        } else {
          this.myInput.tmpPsdPassed = true
          this.myInput.tmpPsdTxt = ''
        }
      }

      if (this.myInput.tmpPsdPassed) {
        this.myInput.psdPriorWrong = false
        return true
      } else {
        this.myInput.psdPriorWrong = true
        return false
      }
    },
    confirmPassword (isRegCheck) {
      this.myInput.cfmPasswordPassed = false

      if (this.myInput.passwordConfirm === '') {
        this.myInput.passwordConfirmTxt = '비밀번호 확인 값을 입력해 주세요.'
        this.myInput.psdConfPriorWrong = true
        return false
      } else if (this.myInput.tmpPsd !== this.myInput.passwordConfirm) {
        this.myInput.passwordConfirmTxt = '비밀번호와 비밀번호 확인 값이 다릅니다.'
        if (isRegCheck) {

        } else {
          // this.$refs.passwordConfirm.focus()
        }
        this.myInput.psdConfPriorWrong = true
        return false
      } else if (this.myInput.tmpPsd === this.myInput.passwordConfirm) {
        this.myInput.psdConfPriorWrong = false
        return true
      }
    },
    gdEngKor: function () {
      if (this.myInput.memberName !== '') {
        this.myInput.memberName = replacePattern(this.myInput.memberName, /\s+/g, '')
      }
    },
    memberNameCheck (isRegCheck) {
      if (this.myInput.memberName === '') {
        this.myInput.memberNameTxt = '이름을 입력해 주세요.'
        this.myInput.memNameIllegal = true
        if (isRegCheck === true) {

        } else {
          // this.$refs.memberName.focus()
        }
      } else {
        let regx = /^[a-zA-Zㄱ-ㅎㅏ-ㅣ가-힣]+$/

        if (!regx.test(this.myInput.memberName)) {
          this.myInput.memberNameTxt = '이름은 띄어쓰기 없이 한글,영문으로 입력하셔야 합니다.'
          this.myInput.memNameIllegal = true
          if (isRegCheck === true) {

          } else {
            //  this.$refs.memberName.focus()
          }
        } else {
          this.myInput.memNameIllegal = false
        }
      }
      return !this.myInput.memNameIllegal
    },
    gdNumPhone: function () {
      if (this.myInput.cellPhone !== '') {
        this.myInput.cellPhone = replacePattern(this.myInput.cellPhone, /[^\d]/g, '')
      }
    },
    gdNumBirthday () {
      if (this.myInput.birthday !== '') {
        this.myInput.birthday = replacePattern(this.myInput.birthday, /[^\d]/g, '')
      }
    },
    regCheckEmail () {
      return this.$refs.emailAuthentications ? this.$refs.emailAuthentications.regCheckEmail() : true
    },
    focusEmail () {
      this.$refs.emailAuthentications.focusEmailName()
    },
    mobileCheck (isCheckBtnClicked, isRegCheck) {
      return this.$refs.smsAuthentications ? this.$refs.smsAuthentications.mobileCheck(isCheckBtnClicked, isRegCheck) : false
    },
    focusMoblie () {
      this.$refs.smsAuthentications.focusMobile()
    },
    async register () {
      let checkPassed = true
      let focusID = false

      await this.isMembIdExist().then((ret) => {
        if (!ret) {
          checkPassed = false
          focusID = true
          this.$refs.memberId.focus()
        }
      })

      if (!this.validateMemberPassword()) {
        checkPassed = false
        if (!focusID) {
          this.$refs.tmpPsd.focus()
          focusID = true
        }
      }
      if (!this.confirmPassword(true)) {
        checkPassed = false
        if (!focusID) {
          this.$refs.passwordConfirm.focus()
          focusID = true
        }
      }
      if (!this.memberNameCheck(true)) {
        checkPassed = false
        if (!focusID) {
          this.$refs.memberName.focus()
          focusID = true
        }
      }
      if (!this.regCheckEmail()) {
        checkPassed = false
        if (!focusID) {
          this.focusEmail()
          focusID = true
        }
      }
      if (!this.mobileCheck(false, true)) {
        checkPassed = false
        if (!focusID) {
          this.focusMoblie()
          focusID = true
        }
      }

      if (!checkPassed) {
        return false
      }

      const registParams = {
        memberId: this.myInput.memberId,
        password: this.myInput.passwordConfirm,
        memberName: this.myInput.memberName,
        email: this.getEmail,
        mobileNo: this.getMobileNum,
        birthday: this.myInput.birthday,
        sex: this.myInput.sex,
        smsAgreed: this.smsChecked,
        directMailAgreed: this.checkedMaill,
        certificated: true
      }
      if (this.myInput.prefixPhone === '' || this.myInput.cellPhone === '') {
        registParams.telephoneNo = ''
      }
      if (this.myInput.prefixPhone !== '' && this.myInput.cellPhone !== '') {
        registParams.telephoneNo = this.myInput.prefixPhone + this.myInput.cellPhone
      }
      let redirect = this.$route.query.redirect
      const params = {
        redirect: redirect,
        registParams: registParams
      }
      this.$store.dispatch('profile/signUp', params).then(() => {
        const item = [{ i: this.myInput.memberId, t: this.myInput.memberName, p: '1', q: '1' }]
        loadWpAstgScripts('Join', item)
        this.loggerMemberJoinScript()
      })
    },
    loggerMemberJoinScript () {
      return new Promise((resolve, reject) => {
        const script = document.createElement('script')
        script.type = 'text/javascript'
        script.async = true
        script._TRK_PI = 'RGR'
        script._TRK_SX = ''
        script._TRK_AG = ''
        script.addEventListener('load', resolve)
        script.addEventListener('error', reject)
        document.body.appendChild(script)
        // loadAnalysisScript('2', '2')
      })
    },
    cancel () {
      window.location = '/'
    },
    setPhonePrefix (value) {
      this.selectPhoneValue = value
      this.myInput.prefixPhone = value
    },
    setSex (value) {
      this.selectSexValue = value
      this.myInput.sex = value
    },
    emailAuthen () {
      this.emailPopFlg = false
      this.$refs.emailAuthentications.reStartCountTime()
    },
    smsAuthen () {
      this.smsPopFlg = false
      this.$refs.smsAuthentications.reStartCountTime()
    },
    showEmailAuthenPop () {
      this.emailPopFlg = true
    },
    showSmsAuthenPop () {
      this.smsPopFlg = true
    }
  },
  mounted () {
    if (this.$route.query.info) {
      this.smsChecked = true
      this.mallChecked = true
    }
    kakaoPixel('1292090119990392533').completeRegistration()
  }
}
</script>
