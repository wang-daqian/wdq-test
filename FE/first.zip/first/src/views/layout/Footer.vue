<template>
  <div id="footer_wrap">
    <div id="footer">
      <div class="foot_list">
        <ul>
          <li>
            <router-link to="/etc/company">회사소개</router-link>
          </li>
          <li>
            <router-link to="/member/agreement1">이용약관</router-link>
          </li>
          <li>
            <router-link to="/etc/private">개인정보처리방침</router-link>
          </li>
          <li class="foot_top_arrow">
            <router-link to="/etc/online">온라인멤버십</router-link>
          </li>
          <li class="foot_top_arrow">
            <router-link to="/etc/center/store">매장정보</router-link>
          </li>
          <li class="foot_top_arrow">
            <router-link to="/etc/center/notice">고객센터</router-link>
          </li>
        </ul>
      </div>
      <div class="foot_cont">
        <div class="foot_info">
          <div class="foot_info_list" v-if="companyCenter">
            <p>상호명 : {{companyCenter.serviceBasicInfo.companyName}} / 전화 : {{companyCenter.serviceBasicInfo.representPhoneNo}} </p>
            <p>메일 :
              <a :href="`mailto:${companyCenter.serviceBasicInfo.representEmail}`" class="btn_email">{{companyCenter.serviceBasicInfo.representEmail}}</a>
            </p>
            <p>사업자등록번호 : {{companyCenter.serviceBasicInfo.businessRegistrationNo}} </p>
            <p>통신판매업신고번호 : {{companyCenter.serviceBasicInfo.onlineMarketingBusinessDeclarationNo}}</p>
            <p>대표 : {{companyCenter.serviceBasicInfo.representativeName}} / 개인정보관리자 : {{companyCenter.serviceBasicInfo.privacyManagerName}}</p>
            <p>{{companyCenter.serviceBasicInfo.address}}{{companyCenter.serviceBasicInfo.addressDetail}} </p>
          </div>
          <p class="copyright">copyright (c)
            <strong>First Apparel inc.</strong> all rights reserved.</p>
        </div>

        <div class="content_info_wrap" v-if="companyCenter">
          <div class="content_info">
            <div class="cs_center">
              <h3>CS CENTER</h3>
              <strong>{{companyCenter.cscenter.phoneNo}}</strong>
              <p>운영시간 : AM09:00 ~ PM06:00
                <br> 점심시간 : AM12:30 ~ PM01:30
                <br> 토/일/공휴일 휴무</p>
            </div>
            <div class="cs_bnr">
              <form name="shop_check" ref="shopForm" method="post" action="https://admin.kcp.co.kr/Modules/escrow/kcp_pop.jsp">
                <input type="hidden" name="site_cd" value="A846O">
                <div class="bnr-sp">
                  <img src="../../assets/img/banner/kcpescr_bn_01.gif" alt="" usemap="#MapMO">
                  <map name="MapMO" id="MapMO">
                    <area shape="rect" coords="5,62,74,83" @click.prevent="submitCD" />
                  </map>
                </div>
                <div class="bnr-pc">
                  <img src="../../assets/img/banner/kcpescr_bn_02.gif" alt="" usemap="#MapPC">
                  <map name="MapPC" id="MapPC">
                    <area shape="rect" coords="40,110,110,130" @click.prevent="submitCD" />
                  </map>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
    <p class="btn-top">
      <a href="javascript:" @click.prevent="toTop">
        <img src="../../assets/img/common/btn/btn_top.png" alt="">
      </a>
    </p>
  </div>
</template>

<script>
import $ from 'jquery'
import { mapGetters } from 'vuex'
export default {
  computed: {
    ...mapGetters('common', ['companyCenter']),
    host () {
      return window.location.host
    }
  },
  methods: {
    toTop () {
      $('body,html').animate({
        scrollTop: 0
      }, 800)
    },
    submitCD () {
      const status = 'width=500 height=450 menubar=no,scrollbars=no,resizable=no,status=no'
      window.open('', 'kcp_pop', status)

      this.$refs.shopForm.method = 'post'
      this.$refs.shopForm.target = 'kcp_pop'
      this.$refs.shopForm.action = 'https://admin.kcp.co.kr/Modules/escrow/kcp_pop.jsp'

      this.$refs.shopForm.submit()
    }
  }
}
</script>

<style>
</style>
