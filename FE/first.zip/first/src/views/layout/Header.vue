<template>
  <div :style="headerFix ? 'margin-bottom: 196px' : ''">
    <herder-banner :banner="topBand" />
    <div id="header_warp" :class="{'headerFix' : headerFix}">
      <div id="header">
        <herder-brand :brands="categories" :cartCnt="count" :wishCnt="totalCount" :products="reProducts" v-if="categories" />
        <herder-category :displayMode="displayMode" :brandInfo="brandInfo" :gnbMargin="gnbMargin" />
      </div>
    </div>
  </div>
</template>

<script>
import { mapState, mapGetters } from 'vuex'
import HerderBanner from '@/components/layout/HerderBanner'
import HerderBrand from '@/components/layout/HerderBrand'
import HerderCategory from '@/components/layout/HerderCategory'
import $ from 'jquery'
export default {
  props: ['displayMode'],
  components: {
    HerderBanner,
    HerderBrand,
    HerderCategory
  },
  computed: {
    brandInfo () {
      if (this.$route.name === 'GoodsView' && this.viewBrandNo) {
        return this.getBrandInfo({ brandNo: this.viewBrandNo })
      } else {
        const names = [
          'FrenchCat',
          'Tiffany',
          'Elecone',
          'GuessKids',
          'Nubaby'
        ]
        if (names.find(item => item === this.$route.name)) {
          return this.getBrandInfo({ brandName: this.$route.name })
        }
        return this.getBrandInfo({ brandNo: this.$route.params.brandNo })
      }
    },
    ...mapState('cart', ['count']),
    ...mapState('wishlist', ['totalCount']),
    ...mapState('recentproducts', ['reProducts']),
    ...mapState('display', ['topBand']),
    ...mapState('category', ['categories']),
    ...mapGetters('category', ['getBrandInfo']),
    ...mapGetters('product', ['viewBrandNo'])
  },
  data () {
    return {
      headerFix: false,
      gnbMargin: 0
    }
  },
  methods: {
    handleScroll () {
      if (this.displayMode === 'PC') {
        const scrollTop = $('.header_banner').height() ? $('.header_banner').height() - $(window).scrollTop() : 0 - $(window).scrollTop()

        if (scrollTop > 0) {
          this.headerFix = false
        } else {
          this.headerFix = true
        }

        if (scrollTop > 0) {
          this.gnbMargin = 0
        } else if (scrollTop < -90) {
          this.gnbMargin = -90
        } else {
          this.gnbMargin = scrollTop
        }
      }
    }
  },
  created () {
    window.addEventListener('scroll', this.handleScroll)
  }
}
</script>

<style>
</style>
