<template>
  <div>HeaderError</div>
</template>

<script>
export default {
}
</script>

<style>

</style>
