<template>
  <div id="container" class="body-goods">
    <div id="contents">
      <div class="sub_content">
        <div class="content">
          <location-wrap-menu :brandInfo="brandInfo" :listMenu="listMenu" v-if="brandInfo && listMenu" />
          <goods-list :displayMode="displayMode" :categoryName="categoryName" :list="list" :totalCount="totalCount" v-if="categoryName" />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapState, mapGetters } from 'vuex'
import LocationWrapMenu from '@/components/common/LocationWrapMenu'
import GoodsList from '@/components/goods/list/GoodsList'

export default {
  props: ['displayMode'],
  name: 'CategoryList',
  components: {
    LocationWrapMenu,
    GoodsList
  },
  computed: {
    categoryName () {
      return this.listMenu && this.listMenu.length && this.listMenu[this.listMenu.length - 1].selectItem
    },
    brandInfo () {
      return this.getBrandInfo({ brandNo: this.$route.params.brandNo })
    },
    listMenu () {
      const noList = [
        this.$route.params.brandNo,
        this.$route.params.depth1,
        this.$route.params.depth2,
        this.$route.params.depth3
      ]
      return this.getListMenu(noList)
    },
    ...mapGetters('category', ['getBrandInfo', 'getListMenu']),
    ...mapState('productList', ['list', 'totalCount'])
  }
}
</script>

<style>
</style>
