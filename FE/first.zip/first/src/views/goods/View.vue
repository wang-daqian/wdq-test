<template>
  <div id="container" class="body-goods">
    <div id="contents">
      <div class="sub_content">
        <div class="content_box">
          <location-wrap-menu :brandInfo="brandInfo" :listMenu="listMenu" v-if="brandInfo && listMenu" />
          <item-photo-info-sec :displayMode="displayMode" :product="product" :options="options" :couponCompare="couponCompare" />
          <item-popular v-if="listBrand && listBrand.length" :items="listBrand" />
          <item-goods-sec :product="product" :dutyInfo="dutyInfo" :optionImages="optionImages" :inquiries="inquiries" :inquiriesTotalCount="inquiriesTotalCount" :review="review" :reviewTotalCount="reviewTotalCount" :reviewRate="reviewRate" />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
/* global fbq */
/* global kakaoPixel */

import { mapState, mapGetters, mapMutations } from 'vuex'
import LocationWrapMenu from '@/components/common/LocationWrapMenu'
import ItemPhotoInfoSec from '@/components/goods/view/info/ItemPhotoInfoSec'
import ItemGoodsSec from '@/components/goods/view/tab/ItemGoodsSec'
import ItemPopular from '@/components/goods/view/info/ItemPopular'
import { loadWpAstgScripts, isIE } from '@/utils/utils'

export default {
  props: ['displayMode'],
  name: 'GoodsView',
  components: {
    LocationWrapMenu,
    ItemPhotoInfoSec,
    ItemGoodsSec,
    ItemPopular
  },
  computed: {
    brandInfo () {
      return this.getBrandInfo({ brandNo: this.viewBrandNo })
    },
    listMenu () {
      if (this.product && this.product.categories && this.product.categories.length) {
        const noList = [
          this.product.categories[0].categories[0].categoryNo,
          this.product.categories[0].categories[1] ? this.product.categories[0].categories[1].categoryNo : null,
          this.product.categories[0].categories[2] ? this.product.categories[0].categories[2].categoryNo : null,
          this.product.categories[0].categories[3] ? this.product.categories[0].categories[3].categoryNo : null
        ]
        const item = [{ i: this.product.baseInfo.productNo, t: this.product.baseInfo.productName }]
        loadWpAstgScripts('Item', item)
        this.loggerProductDetailScript()
        return this.getListMenu(noList)
      }
    },
    ...mapGetters('category', ['getBrandInfo', 'getListMenu']),
    ...mapState('product', ['product', 'options', 'optionImages', 'inquiries', 'inquiriesTotalCount', 'review', 'reviewTotalCount', 'reviewRate']),
    ...mapState('productList', ['listBrand']),
    ...mapGetters('product', ['viewBrandNo', 'dutyInfo']),
    ...mapGetters('coupon', ['couponCompare'])
  },
  methods: {
    ...mapMutations('productList', ['SET_NONEEDREFRESH_FLG']),

    loggerProductDetailScript () {
      return new Promise((resolve, reject) => {
        const script = document.createElement('script')
        script.type = 'text/javascript'
        script.async = true
        script._TRK_PI = 'DV'
        script._TRK_PN = this.product.baseInfo.productNo
        script._TRK_PND = this.product.baseInfo.productName
        script._TRK_MF = this.product.brand ? this.product.brand.name : ''
        script.addEventListener('load', resolve)
        script.addEventListener('error', reject)
        document.body.appendChild(script)
      })
    },

    goBack () {
      // replace替换原路由，作用是避免回退死循环
      if (!isIE()) {
        this.$router.back(-1)
      }
      this.SET_NONEEDREFRESH_FLG(true)
    }

  },
  watch: {
    viewBrandNo () {
      if (this.viewBrandNo) {
        this.$store.dispatch('productList/fetchProductDetailPopular', this.viewBrandNo)
      }
    }
  },
  mounted () {
    fbq('track', 'ViewContent')
    kakaoPixel('1292090119990392533').viewContent({ id: this.$route.params.productNo })
    // if (window.history && window.history.pushState) {
    //   if (isIE()) {
    //     window.addEventListener('popstate', this.goBack, false)
    //   } else {
    //     history.pushState(null, null, document.URL)
    //     window.addEventListener('popstate', this.goBack, false)
    //   }
    // }
  },
  destroyed () {
    // window.removeEventListener('popstate', this.goBack, false)
  }
}
</script>

<style>
</style>
