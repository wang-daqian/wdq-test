<template>
  <div id="container">
    <div id="contents">
      <div class="sub_content">
        <left-menu :categories="categories" />

        <search-content :list="list" :totalCount="totalCount" />
      </div>
    </div>
  </div>
</template>

<script>
/* global kakaoPixel */
import { mapState } from 'vuex'
import LeftMenu from '@/components/goods/search/LeftMenu'
import SearchContent from '@/components/goods/search/SearchContent'

export default {
  name: 'SearchList',
  components: {
    LeftMenu,
    SearchContent
  },
  computed: {
    ...mapState('category', ['categories']),
    ...mapState('productList', ['list', 'totalCount'])
  },
  mounted () {
    kakaoPixel('1292090119990392533').search({
      keyword: this.$route.query.q
    })
  }
}
</script>

<style>
</style>
