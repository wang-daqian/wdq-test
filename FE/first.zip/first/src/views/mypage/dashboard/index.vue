<template>
  <div class="content">
    <div class="mypage_main">

      <!-- 마이페이지 회원 요약정보 -->
      <top-info></top-info>
      <!-- //mypage_top_info -->

      <!--// 마이페이지 회원 요약정보 -->

      <order-info-status v-if="mySummary && mySummary.orderCountByStatus" :orderStatus="mySummary.orderCountByStatus" />

      <!-- //mypage_order_info -->

      <div class="mypage_lately_info">
        <div class="mypage_zone_tit">
          <h3>최근 주문 정보
            <span>최근 30일 내에 주문하신 내역입니다.</span>
          </h3>
        </div>

        <div class="mypage_lately_info_cont">
          <!-- 주문상품 리스트 -->
          <order-item-list :orders="orders" :totalCount="totalCount" />

          <!--// 주문상품 리스트 -->
        </div>
        <!-- <router-link to="/mypage/orderlist" class="btn_board_more">+ 더보기</router-link> -->
      </div>
      <!-- //mypage_lately_info -->

      <recent-product :reProducts="reProducts" :member="member" />
      <!-- //mypage_lately_goods -->

    </div>
    <!-- //mypage_main -->

  </div>
</template>

<script>
import { mapState } from 'vuex'
import TopInfo from '@/components/mypage/topinfo/TopInfo'
import OrderInfoStatus from '@/components/mypage/dashboard/OrderInfoStatus.vue'
import RecentProduct from '@/components/mypage/dashboard/RecentProduct.vue'
import OrderItemList from '@/components/mypage/order/OrderItemList.vue'
export default {
  computed: {
    ...mapState('recentproducts', ['reProducts']),
    ...mapState('myorder', ['orders', 'totalCount']),
    ...mapState('member', ['member', 'mySummary'])
  },
  components: {
    TopInfo,
    OrderInfoStatus,
    RecentProduct,
    OrderItemList
  }
}
</script>

<style>
</style>
