<template>
  <div class="content">
    <div class="mypage_cont">

      <!-- 마이페이지 회원 요약정보 -->
      <div class="mypage_lately_info">
        <div class="mypage_zone_tit">
          <h3>주문목록/배송조회</h3>
        </div>
        <date-picker :type="listType" ref="dataPicker" @initData="initDispData"></date-picker>
        <!-- //date_check_box -->

        <div class="mypage_lately_info_cont">
          <span class="pick_list_num">
            주문목록 / 배송조회 내역 총
            <strong>{{orders ? totalCount:0}}</strong> 건
          </span>
          <!-- 주문상품 리스트 -->
          <order-item-list :orders="orders" :totalCount="totalCount" ref="orderItemList" />
        </div>
        <!-- //mypage_lately_info_cont -->
      </div>
      <!-- //mypage_lately_info -->

      <!-- <div class="pagination" v-if="orders && orders.length<this.totalCount">
        <p class="pagination-btn">
          <button type="button" class="btn_more" @click.prevent="pageDown">더보기</button>
        </p>
      </div> -->
      <!-- //pagination -->

    </div>
    <!-- //mypage_cont -->

  </div>
</template>

<script >
import myDatepicker from '@/components/mypage/viewperiod/DatePicker.vue'
import { mapState } from 'vuex'
import Order from '@/components/mypage/order/Order.vue'
import TopInfo from '@/components/mypage/topinfo/TopInfo.vue'
import OrderItemList from '@/components/mypage/order/OrderItemList.vue'

export default {
  data () {
    return {
      listType: 'order',
      orderOption: {}
    }
  },
  metaInfo: {
    title: '주문내역·배송조회'
  },
  name: 'OrderList',

  components: {
    'date-picker': myDatepicker,
    'top-info': TopInfo,
    Order,
    OrderItemList
  },
  computed: {
    ...mapState('myorder', ['totalCount', 'orders'])
  },
  methods: {
    pageDown () {
      this.$store.dispatch('myorder/fetchMore')
    },
    initDispData () {
      this.$nextTick(() => {
        this.$refs.orderItemList.initData()
      })
    }
  },
  beforeRouteLeave (to, from, next) {
    this.$refs.dataPicker.initPeriodParam()
    next()
  }
}
</script>
