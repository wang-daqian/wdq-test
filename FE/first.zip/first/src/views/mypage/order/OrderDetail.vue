<template>
  <div class="content">
    <div class="mypage_main">

      <!-- 마이페이지 회원 요약정보 -->
      <top-info></top-info>
      <!-- 마이페이지 회원 요약정보 -->

      <div class="mypage_lately_info">
        <div class="mypage_zone_tit">
          <h3>주문/배송상세
            <strong class="order_num_view">(주문번호 : {{getOrderNo}} )</strong>
          </h3>
        </div>
        <order-detail-order-info :order="order" :type="'list'" :nonMember="false" :notShowOrderNo="true" />
      </div>
      <div v-if="order" class="order_view_info">
        <order-detail-buyer-info v-if="order.orderer" :orderer="order.orderer" :orderMemo="order.orderMemo" />
        <order-detail-delivery-info v-if="order.orderAddress" :orderNo="order.orderNo" :shippingAddress="order.orderAddress" :nonMember="false" />
        <order-detail-payment-info :order="order" v-if="order.showPriceInfo" />
        <!-- <order-detail-refund-info :order="order" v-if="order.showPriceInfo && order.refundInfos && order.refundInfos.length > 0" /> -->
        <template v-if="order.refundInfos && order.refundInfos.length > 0">
          <order-detail-refund-info v-for="(refundInfo, index) in order.refundInfos" :key="index" :refundInfo="refundInfo" :payInfo="order.payInfo" />
        </template>
      </div>
    </div>
    <!-- //order_view_info -->
  </div>
  <!-- //mypage_main -->
  <!-- //content -->

</template>

<script >
import { mapState } from 'vuex'
import OrderDetailOrderInfo from '@/components/mypage/order/detail/OrderDetailOrderInfo'
import OrderDetailBuyerInfo from '@/components/mypage/order/detail/OrderDetailBuyerInfo'
import OrderDetailPaymentInfo from '@/components/mypage/order/detail/OrderDetailPaymentInfo'
import OrderDetailRefundInfo from '@/components/mypage/order/detail/OrderDetailRefundInfo'
import OrderDetailDeliveryInfo from '@/components/mypage/order/detail/OrderDetailDeliveryInfo'
import myDatepicker from '@/components/mypage/viewperiod/DatePicker.vue'
import TopInfo from '@/components/mypage/topinfo/TopInfo'

export default {
  data () {
    return {
      cancelDetailOrderOptionNo: 0,
      returnDetailOrderOptionNo: 0,
      orderOption: {},
      orderNo: ''
    }
  },
  metaInfo: {
    title: '주문상세정보'
  },

  components: {
    OrderDetailOrderInfo,
    OrderDetailBuyerInfo,
    OrderDetailPaymentInfo,
    OrderDetailRefundInfo,
    OrderDetailDeliveryInfo,
    'top-info': TopInfo,
    'date-picker': myDatepicker
  },
  computed: {
    ...mapState('myorder', ['order']),

    getOrderNo () {
      if (this.order !== null && this.order.orderNo !== null) {
        return this.order.orderNo
      }
    }
  },
  methods: {
    enterBeforePage () {
      this.$router.back()
    }
  }
}
</script>
