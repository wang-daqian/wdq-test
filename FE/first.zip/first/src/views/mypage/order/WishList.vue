<template>
  <div class="content">
    <div class="mypage_cont">

      <!-- 마이페이지 회원 요약정보 -->
      <top-info></top-info>
      <!-- //mypage_top_info -->

      <!-- 마이페이지 회원 요약정보 -->

      <div class="mypage_wish_list" v-if="likeProducts">
        <div class="mypage_zone_tit">
          <h3>찜리스트</h3>
        </div>

        <div class="mypage_table_type">
          <table :class="likeProducts && likeProducts.length == 0 ? 'no_result' : 'scroll_table'">
            <colgroup>
              <col style="width:8%">
              <!-- 선택 -->
              <col>
              <col style="width:17%">
              <!-- 혜택 -->
              <col style="width:19%">
              <!-- 합계 -->
            </colgroup>
            <thead>
              <tr>
                <th>
                  <div>
                    <span v-if="likeProducts.length>0" class="form_element">
                      <label for="select_all" :class="['check',{'on':checkAll}]" @click.prevent="allSelect"></label>
                    </span>
                  </div>
                </th>
                <th>상품명</th>
                <th>상품금액</th>
                <th>삭제</th>
              </tr>
            </thead>
            <tbody v-if="likeProducts && likeProducts.length > 0">
              <template v-for="product in likeProducts">
                <wish-item-row :key="product.productNo" :product="product"></wish-item-row>
              </template>
            </tbody>
            <template v-else>
              <tr>
                <td colspan="5">
                  <p class="no_data">찜리스트에 상품이 없습니다.</p>
                </td>
              </tr>
            </template>
          </table>
          <div class="pagination" v-if="likeProducts.length < totalCount">
            <p class="pagination-btn">
              <button type="button" class="btn_more" @click="pageDown">더보기</button>
            </p>
          </div>
          <button v-if="likeProducts.length>0" class="btn_wish_choice_del" @click="likeDeleteProducts">
            <em>선택 상품 삭제</em>
          </button>
          <button class="btn_wish_choice_cart" style="display:none">
            <em>선택 상품 장바구니</em>
          </button>
        </div>
      </div>
      <!-- //mypage_wish_list -->

    </div>
    <!-- //mypage_cont -->

  </div>
</template>

<script >
import { mapState, mapActions, mapMutations } from 'vuex'
import TopInfo from '@/components/mypage/topinfo/TopInfo'
import WishItemRow from '@/components/mypage/order/WishItemRow'

export default {
  data () {
    return {
      listType: 'wishlist',
      selectedNos: this.getSelectedNos
    }
  },
  components: {
    WishItemRow,
    'top-info': TopInfo
  },
  computed: {
    ...mapState('wishlist', ['likeProducts', 'totalCount', 'checkAll']),

    getSelectedNos () {
      return this.likeProducts.filter(item => item.checked).map(sitem => sitem.productNo)
    }
  },

  methods: {
    ...mapActions('wishlist', ['getLikeProductsMore', 'pageLikeProducts']),
    ...mapActions('member', ['mySummary']),
    ...mapMutations('wishlist', ['CHANGE_WISH_ITEM_CHECKOUT_ALL']),

    likeDeleteProducts () {
      this.selectedNos = this.getSelectedNos

      if (this.selectedNos.length === 0) {
        alert('상품을 선택해주세요.')
      } else {
        if (confirm('상품을 삭제하시겠습니까?')) {
          this.pageLikeProducts(this.selectedNos).then(() => {
            this.selectedNos = []
            this.mySummary()
            this.CHANGE_WISH_ITEM_CHECKOUT_ALL(false)
          })
        }
      }
    },
    allSelect () {
      this.CHANGE_WISH_ITEM_CHECKOUT_ALL(!this.checkAll)
    },
    pageDown () {
      this.getLikeProductsMore()
    }
  }
}
</script>
