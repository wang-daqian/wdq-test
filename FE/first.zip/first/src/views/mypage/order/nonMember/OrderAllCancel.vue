<template>
  <div id="container">
    <div id="contents">
      <!-- 본문 시작 -->
      <div class="location_wrap">
        <div class="location_cont">
          <em>
            <a href="/" class="local_home">HOME</a> &gt; 마이페이지</em>
        </div>
      </div>
      <!-- //location_wrap -->

      <div class="sub_content">
        <div class="side_cont">
          <span class="btn_side_mobile" @click="openMenu = !openMenu">마이페이지 메뉴보기</span>
          <div class="sub_menu_box" :style="{display:openMenu?'block':'none'}">
            <h2>마이페이지</h2>
            <ul class="sub_menu_mypage">
              <li>쇼핑정보
                <ul class="sub_depth1">
                  <li>
                    <a class="active" @click.prevent="hideMenuOnlyMO()">- 주문목록/배송조회</a>
                  </li>
                </ul>
              </li>
            </ul>
          </div>
        </div>
        <div v-if="orderGuestClaimInfo" class="content">
          <div class="mypage_cont">
            <form name="frmClaimRegist" id="frmClaimRegist" method="post" novalidate="novalidate">
              <div class="mypage_zone_tit">
                <h3>취소신청
                  <strong class="order_num_view">(주문번호 : {{showOrderNo}} / 주문일시 {{showYmd}} )
                  </strong>
                </h3>
              </div>

              <div class="mypage_claim_cont">

                <!-- 주문상품 리스트 -->
                <div class="mypage_table_type">
                  <table class="scroll_table">
                    <colgroup>
                      <!-- 날짜/주문번호 -->
                      <col>
                      <!-- 상품명/옵션 -->
                      <col style="width:15%">
                      <!-- 상품금액/수량 -->
                      <col style="width:15%">
                      <!-- 주문상태 -->
                      <col style="width:15%">
                      <!-- 확인/리뷰 -->
                    </colgroup>
                    <thead>
                      <tr>
                        <th>상품명/옵션</th>
                        <th>상품금액/수량</th>
                        <th>주문상태</th>
                        <th>
                          취소수량
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      <template v-for="(option,index) in orderGuestClaimInfo.orderOptions">
                        <order-all-claim-option :option="option" :key="index" :orderNo="showOrderNo" :showYmd="showYmd" :type="type" :nonMember="true" />
                      </template>
                    </tbody>
                  </table>
                </div>

                <!--// 주문상품 리스트 -->
                <div class="mypage_claim_reason">
                  <div class="mypage_zone_tit">
                    <h4>취소 사유</h4>
                  </div>

                  <div class="mypage_table_type simple_table">
                    <table class="table_left">
                      <colgroup>
                        <col style="width:15%;">
                        <col style="width:85%;">
                      </colgroup>
                      <tbody>
                        <tr>
                          <th scope="row"> 사유 </th>
                          <td class="mypage_claim_select">
                            <vue-select-box :showValue="claimReasonType" :items="showClaimReasons" @selected="updateClaimReasonType" :width="seletBoxWidth" :noLeftMargin="true" />
                          </td>
                        </tr>
                        <tr>
                          <th scope="row">상세 사유</th>
                          <td>
                            <textarea title="메모입력" name="userHandleDetailReason" cols="15" rows="5" v-model="claimReasonDetail" maxlength="160"></textarea>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
                <order-claim-return-bank ref="bankAccountInfo" :payType="orderGuestClaimInfo.payType" :claimType="claimType"></order-claim-return-bank>
                <br>
                <br>
              </div>
              <!-- //mypage_claim_cont -->
              <div class="btn_center_box">
                <a href="javascript:" class="btn_claim_cancel" @click.prevent="enterBeforePage" :style="{'margin-right':'5px'}">
                  <em>취소</em>
                </a>
                <button type="submit" class="btn_claim_ok" @click.prevent="cancelOrderOption">
                  <em>신청</em>
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
    <!-- //mypage_cont -->
  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex'
import VueSelectBox from '@/components/common/VueSelectBox'
import OrderAllClaimOption from '@/components/mypage/order/claim/OrderAllClaimOption'
import OrderClaimReturnBank from '@/components/mypage/order/claim/OrderClaimReturnBank'

export default {
  props: ['displayMode'],
  data () {
    return {
      claimReasonType: 'default',
      claimReasonDetail: '',
      type: 'Cancel',
      seletBoxWidth: '290px',
      openMenu: this.displayMode === 'PC',
      claimType: 'cancel'
    }
  },
  metaInfo: {
    title: '취소신청'
  },
  components: {
    VueSelectBox,
    OrderAllClaimOption,
    OrderClaimReturnBank
  },
  computed: {
    ...mapState('guestorder', ['orderGuestClaimInfo']),

    showOrderNo () {
      if (this.orderGuestClaimInfo) {
        return this.orderGuestClaimInfo.orderNo
      }
    },
    showYmd () {
      if (this.orderGuestClaimInfo) {
        return this.orderGuestClaimInfo.showYmd
      }
    },
    showClaimReasons () {
      const claimReasons = [{
        label: '사유를 선택해 주세요',
        value: 'default'
      }]
      if (this.orderGuestClaimInfo.claimReasonTypes) {
        let arr = this.orderGuestClaimInfo.claimReasonTypes.map(item => {
          return {
            label: item.label,
            value: item.claimReasonType
          }
        })

        for (let i = 0; i < arr.length; i++) {
          const item = arr[i]
          claimReasons.push(item)
        }
      }
      return claimReasons
    },
    getBankAccountInfo () {
      return this.$refs.bankAccountInfo.getBankAccountInfo()
    }
  },
  methods: {
    ...mapActions('guestorder', ['postGuestOrderClaimCancel']),

    updateClaimReasonType (claimReasonType) {
      this.claimReasonType = claimReasonType
    },
    claimedProductOptions () {
      if (this.orderGuestClaimInfo && this.orderGuestClaimInfo.orderOptions.length > 0) {
        return this.orderGuestClaimInfo.orderOptions.filter(info => Number(info.orderCnt) > 0).map(option => {
          return {
            orderProductOptionNo: option.orderOptionNo,
            productCnt: option.orderCnt
          }
        })
      }
    },
    showBankErrorAlert () {
      return this.$refs.bankAccountInfo.showBankErrorAlert()
    },
    claimParamsCheck () {
      const claimedProductOptions = this.claimedProductOptions()
      if (claimedProductOptions === null || claimedProductOptions.length <= 0) {
        alert('취소상품을 하나 이상 선택해주세요.')
        return false
      }
      if (this.claimReasonType === 'default') {
        alert('취소사유 구분을 선택 해 주세요.')
        return false
      }
      if (this.getBankAccountInfo === 'Error') {
        this.showBankErrorAlert()
        return false
      }
      return true
    },
    cancelOrderOption () {
      const claimedProductOptions = this.claimedProductOptions()
      if (!this.claimParamsCheck()) {
        return
      }
      let cnt = claimedProductOptions.map((option) => { return option.productCnt }).reduce((accmulator, item) => {
        return accmulator + item
      })
      if (confirm('주문취소 처리를 하시겠습니까 ?')) {
        const claimRequest = {
          claimType: 'CANCEL',
          productCnt: cnt,
          claimReasonType: this.claimReasonType,
          claimReasonDetail: this.claimReasonDetail,
          saveBankAccountInfo: 'false',
          returnWayType: 'SELLER_COLLECT',
          bankAccountInfo: this.getBankAccountInfo,
          claimedProductOptions: claimedProductOptions
        }
        const claimParams = {
          orderNo: this.$store.state.route.params.OrderClaimCancel,
          claimRequest: claimRequest
        }
        this.postGuestOrderClaimCancel(claimParams).then(() => {
          alert('취소신청이 완료되었습니다. 환불관련 정보는 마이페이지의 취소반품조회에서 확인 가능합니다.')
          this.$router.push('/mypage/')
        })
      }
    },
    enterBeforePage () {
      this.$router.back()
    },

    beforeRouteLeave (to, from, next) {
      next()
    }
  }
}
</script>
