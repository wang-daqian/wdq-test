<template>
  <div id="container">
    <div id="contents">
      <!-- 본문 시작 -->
      <div class="location_wrap">
        <div class="location_cont">
          <em>
            <a href="/" class="local_home">HOME</a> &gt; 마이페이지</em>
        </div>
      </div>
      <!-- //location_wrap -->

      <div class="sub_content">
        <div class="side_cont">
          <span class="btn_side_mobile" @click="openMenu = !openMenu">마이페이지 메뉴보기</span>
          <div class="sub_menu_box" :style="{display:openMenu?'block':'none'}">
            <h2>마이페이지</h2>
            <ul class="sub_menu_mypage">
              <li>쇼핑정보
                <ul class="sub_depth1">
                  <li>
                    <a class="active" @click.prevent="hideMenuOnlyMO()">- 주문목록/배송조회</a>
                  </li>
                </ul>
              </li>
            </ul>
          </div>
        </div>
        <!-- //side_cont -->

        <div class="content">
          <div class="mypage_main">

            <div class="mypage_lately_info">
              <div class="mypage_zone_tit">
                <h3>주문/배송상세
                  <strong class="order_num_view">(주문번호 : {{getOrderNo}} )</strong>
                </h3>
              </div>
              <order-detail-order-info :order="guestOrder" :type="'list'" :nonMember="true" :notShowOrderNo="true" />
            </div>
            <div v-if="guestOrder" class="order_view_info">
              <order-detail-buyer-info v-if="guestOrder.orderer" :orderer="guestOrder.orderer" :orderMemo="guestOrder.orderMemo" />
              <order-detail-delivery-info v-if="guestOrder.orderAddress" :orderNo="guestOrder.orderNo" :shippingAddress="guestOrder.orderAddress" :nonMember="true" />
              <order-detail-payment-info v-if="guestOrder.showPriceInfo" :order="guestOrder" :nonMember="true" />
              <!-- <order-detail-refund-info :order="guestOrder" v-if="guestOrder.showPriceInfo && guestOrder.refundInfos && guestOrder.refundInfos.length > 0" /> -->
              <template v-if="guestOrder.refundInfos && guestOrder.refundInfos.length > 0">
                <order-detail-refund-info v-for="(refundInfo, index) in guestOrder.refundInfos" :key="index" :refundInfo="refundInfo" :payTypeLabel="guestOrder.payTypeLabel" :payInfo="guestOrder.payInfo" />
              </template>
            </div>
            <!-- //order_view_info -->
          </div>

        </div>
        <!-- //mypage_main -->

      </div>
      <!-- //content -->

    </div>
    <!-- //sub_content -->
  </div>
</template>

<script>
import { mapState, mapGetters } from 'vuex'
import OrderDetailOrderInfo from '@/components/mypage/order/detail/OrderDetailOrderInfo'
import OrderDetailBuyerInfo from '@/components/mypage/order/detail/OrderDetailBuyerInfo'
import OrderDetailPaymentInfo from '@/components/mypage/order/detail/OrderDetailPaymentInfo'
import OrderDetailRefundInfo from '@/components/mypage/order/detail/OrderDetailRefundInfo'
import OrderDetailDeliveryInfo from '@/components/mypage/order/detail/OrderDetailDeliveryInfo'

export default {
  metaInfo: {
    title: '주문상세정보'
  },
  props: ['displayMode'],
  data () {
    return {
      showPopFlg: false,
      inquiryProductNo: 0,
      cancelDetailOrderOptionNo: 0,
      returnDetailOrderOptionNo: 0,
      openMenu: this.displayMode === 'PC'
    }
  },
  components: {
    OrderDetailOrderInfo,
    OrderDetailBuyerInfo,
    OrderDetailPaymentInfo,
    OrderDetailRefundInfo,
    OrderDetailDeliveryInfo
  },
  computed: {
    ...mapState('guestorder', ['guestOrder']),
    ...mapGetters('common', ['productInquiryTypes']),

    getOrderNo () {
      if (this.guestOrder !== null && this.guestOrder.orderNo !== null) {
        return this.guestOrder.orderNo
      }
    }
  },
  methods: {
    enterBeforePage () {
      this.$router.back()
    },
    hideMenuOnlyMO () {
      if (this.displayMode === 'MO') {
        this.openMenu = false
      }
    }
  }
}
</script>
<style scoped>
@media all and (max-width: 1024px) {
  .content #contents .sub_content {
    margin-top: 88px;
  }
}
</style>
