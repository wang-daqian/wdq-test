<template>

  <div class="content">
    <div class="mypage_cont">
      <!-- 마이페이지 회원 요약정보 -->
      <div class="mypage_lately_info">
        <div class="mypage_zone_tit">
          <h3>주문취소/반품</h3>
        </div>

        <date-picker :type="listType" ref="dataPicker" @initData="initDispData"></date-picker>

        <div class="mypage_lately_info_cont">

          <span class="pick_list_num">
            취소/반품 내역 총
            <strong>{{orders ? totalCount:0}}</strong> 건
          </span>

          <!-- 주문상품 리스트 -->
          <div class="mypage_table_type">
            <table :class="(orders && orders.length == 0) ? 'no_result':'scroll_table'">
              <colgroup>
                <col style="width:15%">
                <!-- 날짜/주문번호 -->
                <col>
                <!-- 상품명/옵션 -->
                <col style="width:15%">
                <!-- 상품금액/수량 -->
                <col style="width:15%">
                <!-- 주문상태 -->
                <col style="width:15%">
                <!-- 확인/리뷰 -->
              </colgroup>
              <thead>
                <tr>
                  <th>날짜/주문번호</th>
                  <th>상품명/옵션</th>
                  <th>상품금액/수량</th>
                  <th>주문상태</th>
                  <th>상태</th>
                </tr>
              </thead>
              <template v-if="orders && orders.length > 0">
                <order v-for="order in getPageData" :key="order.orderNo" :type="'list'" :order="order" :showOrderType="'CANCEL'" />
              </template>
              <template v-if="orders && orders.length === 0">
                <tr>
                  <td colspan="5">
                    <p class="no_data">조회내역이 없습니다.</p>
                  </td>
                </tr>
              </template>
            </table>
            <pagination v-if="totalCount>=5" :page="1" :total_count="totalCount||0" :page_size="5" :page_term="5" @onPageChange="pageChange" ref="pagination" />
            <!-- <div v-if="orders && orders.length<this.totalCount" class="pagination">
              <p class="pagination-btn">
                <button type="button" class="btn_more" @click.prevent="pageDown">더보기</button>
              </p>
            </div> -->
          </div>

        </div>
        <!-- //mypage_lately_info_cont -->
      </div>
      <!-- //mypage_lately_info -->

    </div>
    <!-- //mypage_cont -->

  </div>
  <!-- //content -->
</template>
<script >
import { mapState } from 'vuex'

import Order from '@/components/mypage/order/Order'
import myDatepicker from '@/components/mypage/viewperiod/DatePicker.vue'
import TopInfo from '@/components/mypage/topinfo/TopInfo'
import Pagination from '@/components/common/Pagination'

export default {
  data () {
    return {
      listType: 'cancel',
      page: 1
    }
  },
  metaInfo: {
    title: '취소·반품 내역'
  },
  name: 'CancelList',

  components: {
    Order,
    'top-info': TopInfo,
    'date-picker': myDatepicker,
    Pagination
  },
  computed: {
    ...mapState('myorder', ['totalCount', 'orders']),
    getPageData () {
      return this.orders.slice((this.page - 1) * 5, 5 * this.page)
    }
  },
  methods: {
    pageChange (page) {
      this.page = page
      if ((this.page - 1) % 5 === 0) {
        this.$store.dispatch('myorder/fetchMore')
      }
    },
    initDispData () {
      this.page = 1
    }
  },
  beforeRouteLeave (to, from, next) {
    this.$refs.dataPicker.initPeriodParam()
    next()
  }
}
</script>
