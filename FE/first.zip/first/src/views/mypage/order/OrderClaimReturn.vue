<template>
  <div v-if="claimOrderOption && returnOptions" class="content">
    <div class="mypage_cont">
      <form name="frmClaimRegist" id="frmClaimRegist" method="post" novalidate="novalidate">
        <div class="mypage_zone_tit">
          <h3>반품 신청
            <strong class="order_num_view">주문번호 : {{showOrderNo}} / 주문일시 {{showYmd}}</strong>
          </h3>
        </div>

        <div class="mypage_claim_cont">

          <!-- 주문상품 리스트 -->
          <div class="mypage_table_type">
            <table class="scroll_table">
              <colgroup>
                <!-- <col style="width:15%"> -->
                <!-- 날짜/주문번호 -->
                <col v-if="getReturnOpitonsLen > 1" style="width:10%">
                <!-- 선택 -->
                <col>
                <!-- 상품명/옵션 -->
                <col style="width:15%">
                <!-- 상품금액/수량 -->
                <col style="width:15%">
                <!-- 주문상태 -->
                <col style="width:15%">
                <!-- 확인/리뷰 -->
              </colgroup>
              <thead>
                <tr>
                  <!-- <th>날짜</th> -->
                  <th v-if="getReturnOpitonsLen > 1" class="check_th_box">
                    <div class="form_element">
                      <label for="allCheck" :class="['check',{'on':checkAll}]" @click.prevent="allSelect"></label>
                    </div>
                  </th>
                  <th>상품명/옵션</th>
                  <th>상품금액/수량</th>
                  <th>주문상태</th>
                  <th>반품수량</th>
                </tr>
              </thead>
              <tbody v-if="getReturnOpitonsLen > 0">
                <template v-for="(option,index) in returnOptions">
                  <order-claim-return-option :option="option" :key="option.orderOptionNo" :orderNo="showOrderNo" :type="type" @updateCnt="updateProductCnt" :showFirst="index==0" :optinLen="returnOptions.length" :nonMember="false" />
                </template>
              </tbody>
            </table>
          </div>
          <div class="mypage_zone_tit">
            <span v-if="getReturnOpitonsLen> 1">※ 여러 개의 상품을 선택하여, 반품 신청할 수 있습니다.</span>
          </div>

          <!--// 주문상품 리스트 -->
          <div class="mypage_claim_reason">
            <div class="mypage_zone_tit">
              <h4>반품사유</h4>
            </div>

            <div class="mypage_table_type simple_table">
              <table class="table_left">
                <colgroup>
                  <col style="width:15%;">
                  <col style="width:85%;">
                </colgroup>
                <tbody>
                  <tr>
                    <th scope="row"> 사유 </th>
                    <td class="mypage_claim_select">
                      <vue-select-box :showValue="claimReasonType" :items="showClaimReasons" @selected="updateClaimReasonType" :width="seletBoxWidth" />
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">상세 사유</th>
                    <td>
                      <textarea title="메모입력" name="userHandleDetailReason" cols="15" rows="5" v-model="claimReasonDetail" maxlength="160"></textarea>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          <order-claim-return-bank ref="bankAccountInfo" :payType="claimOrderOption.payType" :claimType="claimType"></order-claim-return-bank>
          <order-return-collect-info ref="collectInfo" :address="claimOrderOption.returnAddress" :returnWarehouse="claimOrderOption.returnWarehouse"></order-return-collect-info>
          <!-- //mypage_claim_reason -->
          <br>
          <br>

        </div>
        <!-- //mypage_claim_cont -->
        <div class="btn_center_box">
          <a href="javascript:" class="btn_claim_cancel" @click.prevent="enterBeforePage" :style="{'margin-right':'5px'}">
            <em>취소</em>
          </a>
          <button type="submit" class="btn_claim_ok" @click.prevent="returnOrderOption">
            <em>신청</em>
          </button>
        </div>
      </form>

    </div>
    <!-- //mypage_cont -->
    <div class="layer_popup fixed" :style="showFlg?'display: block;':'display: none;'">
      <div class="layer_inner">
        <div class="layer_contents pop_size_mgs">
          <div class="pop_msg_conts">
            <dl class="txt_pop_msg">
              <dd>{{showTipsTxt}}</dd>
            </dl>
            <ul class="btn_pop_msg">
              <!-- <li>
                <a href="#" class="gray">취소</a>
              </li> -->
              <li>
                <a href="javascript:" class="blue" @click.prevent="returnComplete">OK</a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapState, mapActions, mapMutations } from 'vuex'
import VueSelectBox from '@/components/common/VueSelectBox'
import OrderClaimReturnOption from '@/components/mypage/order/claim/OrderClaimReturnOption'
import OrderClaimReturnBank from '@/components/mypage/order/claim/OrderClaimReturnBank'
import OrderReturnCollectInfo from '@/components/mypage/order/claim/OrderReturnCollectInfo'
import { getStrDate } from '@/utils/dateUtils'

export default {
  data () {
    return {
      claimReasonType: 'default',
      claimReasonDetail: '',
      productCnt: 0,
      type: 'Return',
      seletBoxWidth: '290px',
      claimType: 'return',
      showFlg: false,
      tipsTxt: '반품신청이 완료되었습니다. 환불관련 정보는 마이페이지의 취소반품조회에서 확인 가능합니다.',
      routerChange: true
    }
  },
  metaInfo: {
    title: '반품신청'
  },
  components: {
    VueSelectBox,
    OrderClaimReturnOption,
    OrderClaimReturnBank,
    OrderReturnCollectInfo
  },
  computed: {
    ...mapState('myorder', ['claimOrderOption', 'returnOptions', 'checkAll']),
    returnWayType () {
      return this.$refs.collectInfo ? this.$refs.collectInfo.getReturnWayType() : 'SELLER_COLLECT'
    },
    showTipsTxt () {
      return this.tipsTxt
    },
    showOrderNo () {
      if (this.claimOrderOption) {
        return this.claimOrderOption.originalOption.orderNo
      }
    },
    showYmd () {
      if (this.claimOrderOption) {
        return getStrDate(this.claimOrderOption.originalOption.orderStatusDate.registerYmdt, '.')
      }
    },
    showClaimReasons () {
      const claimReasons = [{
        label: '사유를 선택해 주세요',
        value: 'default'
      }]
      if (this.claimOrderOption.claimReasonTypes) {
        let arr = this.claimOrderOption.claimReasonTypes.map(item => {
          return {
            label: item.label,
            value: item.claimReasonType
          }
        })

        for (let i = 0; i < arr.length; i++) {
          const item = arr[i]
          claimReasons.push(item)
        }
      }
      return claimReasons
    },
    getBankAccountInfo () {
      return this.$refs.bankAccountInfo.getBankAccountInfo()
    },
    getReturnOpitonsLen () {
      return this.returnOptions ? this.returnOptions.length : 0
    },
    getCollectInfo () {
      return this.$refs.collectInfo.getCollectInfo()
    },
    checkCollectInfoDetailAddress () {
      return this.$refs.collectInfo ? this.$refs.collectInfo.checkCollectInfoDetailAddress() : true
    }
  },
  methods: {
    ...mapActions('myorder', ['postClaimEstimate', 'postClaimReturn']),
    ...mapMutations('myorder', ['CHANGE_RETURN_OPTIONS', 'RESET_CLAIM_ORDER_OPTION', 'CHANGE_RETURN_ITEMS_CHECKOUT_ALL']),

    claimedProductOptions () {
      if (this.getReturnOpitonsLen > 1) {
        return this.returnOptions.filter(info => Number(info.productCnt) > 0 && info.checked === true).map(option => {
          return {
            orderProductOptionNo: option.orderOptionNo,
            productCnt: option.productCnt
          }
        })
      } else if (this.getReturnOpitonsLen === 1) {
        return this.returnOptions.filter(info => Number(info.productCnt) > 0).map(option => {
          return {
            orderProductOptionNo: option.orderOptionNo,
            productCnt: option.productCnt
          }
        })
      }
    },
    updateClaimReasonType (claimReasonType) {
      this.claimReasonType = claimReasonType
      const claimedProductOptions = this.claimedProductOptions()

      if (this.claimReasonType !== 'default' && claimedProductOptions && claimedProductOptions.length > 0) {
        const claimParams = {
          orderOptionNo: this.$store.state.route.params.orderOptionNo,
          claimType: 'RETURN',
          productCnt: 0,
          claimReasonType: this.claimReasonType,
          returnWayType: this.returnWayType,
          claimedProductOptions: claimedProductOptions
        }
        this.postClaimEstimate(claimParams)
      }
    },
    updateProductCnt (productData) {
      this.CHANGE_RETURN_OPTIONS(productData)
    },
    showBankErrorAlert () {
      return this.$refs.bankAccountInfo.showBankErrorAlert()
    },
    showCollectErrorAlert () {
      return this.$refs.collectInfo.showCollectErrorAlert()
    },
    showCollectDetailAddressTips () {
      return this.$refs.collectInfo.showCollectDetailAddressTips()
    },
    claimParamsCheck () {
      const claimedProductOptions = this.claimedProductOptions()
      if (claimedProductOptions === null || claimedProductOptions.length <= 0) {
        alert('반품하실 상품을 하나 이상 선택해주세요.')
        return false
      }
      if (this.claimReasonType === 'default' || this.claimReasonType === '') {
        alert('반품사유 구분을 선택해 주세요')
        return false
      }
      if (this.getBankAccountInfo === 'Error') {
        this.showBankErrorAlert()
        return false
      }
      if (this.getCollectInfo === 'Error') {
        this.showCollectErrorAlert()
        return false
      }
      if (this.checkCollectInfoDetailAddress === false) {
        return this.showCollectDetailAddressTips()
      }
      return true
    },
    returnOrderOption () {
      const claimedProductOptions = this.claimedProductOptions()
      if (!this.claimParamsCheck()) {
        return
      }
      if (confirm('주문반품 처리를 하시겠습니까 ?')) {
        const returnParam = {
          orderOptionNo: this.$store.state.route.params.orderOptionNo,
          claimType: 'RETURN',
          productCnt: 0,
          claimReasonType: this.claimReasonType,
          claimReasonDetail: this.claimReasonDetail,
          saveBankAccountInfo: 'false',
          returnWayType: this.returnWayType,
          bankAccountInfo: this.getBankAccountInfo,
          claimedProductOptions: claimedProductOptions,
          returnAddress: this.getCollectInfo
        }
        this.postClaimReturn(returnParam).then(() => {
          this.tipsTxt = '반품신청이 완료되었습니다. 환불관련 정보는 마이페이지의 취소반품조회에서 확인 가능합니다.'
          this.showFlg = true
          this.routerChange = true
        }).catch((e) => {
          if (e.data.code === 'CL014') {
            this.tipsTxt = e.data.message
            this.showFlg = true
            this.routerChange = false
          }
        })
      }
    },
    enterBeforePage () {
      this.$router.back()
    },
    allSelect () {
      this.CHANGE_RETURN_ITEMS_CHECKOUT_ALL(!this.checkAll)
    },
    returnComplete () {
      if (this.routerChange) {
        this.$router.push('/mypage/')
      }
      this.showFlg = false
      this.tipsTxt = null
    }
  },
  beforeRouteLeave (to, from, next) {
    this.RESET_CLAIM_ORDER_OPTION()
    next()
  }
}
</script>
