<template>
  <div class="content">
    <div class="mypage_cont">

      <!-- 마이페이지 회원 요약정보 -->
      <top-info></top-info>
      <!-- //mypage_top_info -->

      <!-- 마이페이지 회원 요약정보 -->
      <div class="order_cancel_contents">
        <div class="mypage_breakdown_tab mb_25">
          <ul>
            <router-link to='/mypage/orderlist' tag="li" :class="{on:orderListTab}" @click.native="usableClick(true)">
              <a href="#">주문목록/배송조회</a>
            </router-link>
            <router-link to='/mypage/orderlist/cancellist' tag="li" :class="{on:!orderListTab}" @click.native="usableClick(false)">
              <a href="#">취소/반품 내역</a>
            </router-link>
          </ul>
        </div>
        <router-view></router-view>
      </div>
    </div>

  </div>
</template>
<script >
import TopInfo from '@/components/mypage/topinfo/TopInfo'

export default {
  data () {
    return {
      orderListTab: this.initTabData()
    }
  },
  components: {
    'top-info': TopInfo
  },
  methods: {
    usableClick (flag) {
      this.orderListTab = flag
    },
    initTab () {
      if (this.$route.query.orderListTab) {
        this.orderListTab = this.$route.query.orderListTab
      } else {
        this.orderListTab = !this.$route.path.includes('cancellist')
      }
    },
    initTabData () {
      if (this.$route.query.orderListTab) {
        return this.$route.query.orderListTab
      } else {
        return !this.$route.path.includes('cancellist')
      }
    }
  },
  watch: {
    '$route': 'initTab'
  }
}
</script>
