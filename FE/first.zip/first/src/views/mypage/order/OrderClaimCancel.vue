<template>
  <div v-if="claimOrderOption" class="content">
    <div class="mypage_cont">
      <form name="frmClaimRegist" id="frmClaimRegist" method="post" novalidate="novalidate">
        <div class="mypage_zone_tit">
          <h3>취소신청
            <strong class="order_num_view">(주문번호 : {{showOrderNo}} / 주문일시 {{showYmd}} )
            </strong>
          </h3>
        </div>

        <div class="mypage_claim_cont">

          <!-- 주문상품 리스트 -->
          <div class="mypage_table_type">
            <table class="scroll_table">
              <colgroup>
                <col v-if="getCancelOpitonsLen > 1" style="width:10%">
                <!-- 날짜/주문번호 -->
                <col>
                <!-- 상품명/옵션 -->
                <col style="width:15%">
                <!-- 상품금액/수량 -->
                <col style="width:15%">
                <!-- 주문상태 -->
                <col style="width:15%">
                <!-- 확인/리뷰 -->
              </colgroup>
              <thead>
                <tr>
                  <!-- <th>날짜</th> -->
                  <th v-if="getCancelOpitonsLen > 1" class="check_th_box">
                    <div class="form_element">
                      <label for="allCheck" :class="['check',{'on':checkCancelAll}]" @click.prevent="allSelect"></label>
                    </div>
                  </th>
                  <th>상품명/옵션</th>
                  <th>상품금액/수량</th>
                  <th>주문상태</th>
                  <th>
                    취소수량
                  </th>
                </tr>
              </thead>
              <tbody v-if="getCancelOpitonsLen > 0">
                <template v-for="(option,index) in cancelOptions">
                  <order-claim-option :option="option" :showFirst="index==0" :key="option.orderOptionNo" :orderNo="showOrderNo" :showYmd="showYmd" :type="type" :nonMember="false" @updateCnt="updateProductCnt" :optinLen="cancelOptions.length" />
                </template>
              </tbody>
            </table>
          </div>
          <div class="mypage_zone_tit">
            <span v-if="getCancelOpitonsLen> 1">※ 여러 개의 상품을 선택하여, 주문 취소할 수 있습니다.</span>
          </div>

          <!--// 주문상품 리스트 -->
          <div class="mypage_claim_reason">
            <div class="mypage_zone_tit">
              <h4>취소 사유</h4>
            </div>

            <div class="mypage_table_type simple_table">
              <table class="table_left">
                <colgroup>
                  <col style="width:15%;">
                  <col style="width:85%;">
                </colgroup>
                <tbody>
                  <tr>
                    <th scope="row"> 사유 </th>
                    <td class="mypage_claim_select">
                      <vue-select-box :showValue="claimReasonType" :items="showClaimReasons" @selected="updateClaimReasonType" :width="seletBoxWidth" :noLeftMargin="true" />
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">상세 사유</th>
                    <td>
                      <textarea title="메모입력" name="userHandleDetailReason" cols="15" rows="5" v-model="claimReasonDetail" maxlength="160"></textarea>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          <order-claim-return-bank ref="bankAccountInfo" :payType="claimOrderOption.payType" :claimType="claimType"></order-claim-return-bank>
          <br>
          <br>
        </div>
        <!-- //mypage_claim_cont -->
        <div class="btn_center_box">
          <a href="javascript:" class="btn_claim_cancel" @click.prevent="enterBeforePage" :style="{'margin-right':'5px'}">
            <em>취소</em>
          </a>
          <button type="submit" class="btn_claim_ok" @click.prevent="cancelOrderOption">
            <em>신청</em>
          </button>
        </div>
      </form>

    </div>
    <!-- //mypage_cont -->
  </div>
</template>

<script>
import { mapState, mapActions, mapMutations } from 'vuex'
import VueSelectBox from '@/components/common/VueSelectBox'
import OrderClaimOption from '@/components/mypage/order/claim/OrderClaimOption'
import { getStrDate } from '@/utils/dateUtils'
import OrderClaimReturnBank from '@/components/mypage/order/claim/OrderClaimReturnBank'

export default {
  data () {
    return {
      claimReasonType: 'default',
      claimReasonDetail: '',
      productCnt: 0,
      type: 'Cancel',
      seletBoxWidth: '290px',
      claimType: 'cancel'
    }
  },
  metaInfo: {
    title: '취소신청'
  },
  components: {
    VueSelectBox,
    OrderClaimOption,
    OrderClaimReturnBank
  },
  computed: {
    ...mapState('myorder', ['claimOrderOption', 'claimEstimate', 'cancelOptions', 'checkCancelAll']),
    maxProductCnt: {
      get () {
        if (this.claimOrderOption && this.productCnt === 0) {
          return this.claimOrderOption.originalOption.orderCnt
        } else {
          return this.productCnt
        }
      }
    },
    showOrderNo () {
      if (this.claimOrderOption) {
        return this.claimOrderOption.originalOption.orderNo
      }
    },
    showYmd () {
      if (this.claimOrderOption) {
        return getStrDate(this.claimOrderOption.originalOption.orderStatusDate.registerYmdt, '.')
      }
    },
    showClaimReasons () {
      const claimReasons = [{
        label: '사유를 선택해 주세요',
        value: 'default'
      }]
      if (this.claimOrderOption.claimReasonTypes) {
        let arr = this.claimOrderOption.claimReasonTypes.map(item => {
          return {
            label: item.label,
            value: item.claimReasonType
          }
        })

        for (let i = 0; i < arr.length; i++) {
          const item = arr[i]
          claimReasons.push(item)
        }
      }
      return claimReasons
    },
    getBankAccountInfo () {
      return this.$refs.bankAccountInfo.getBankAccountInfo()
    },
    getCancelOpitonsLen () {
      return this.cancelOptions ? this.cancelOptions.length : 0
    }
  },
  methods: {
    ...mapActions('myorder', ['getCancelEstimate', 'postClaimCancel']),
    ...mapMutations('myorder', ['RESET_CLAIM_ORDER_OPTION', 'CHANGE_CANCEL_ITEMS_CHECKOUT_ALL', 'CHANGE_CANCEL_OPTIONS']),

    claimedProductOptions () {
      if (this.getCancelOpitonsLen > 1) {
        return this.cancelOptions.filter(info => Number(info.productCnt) > 0 && info.checked === true).map(option => {
          return {
            orderProductOptionNo: option.orderOptionNo,
            productCnt: option.productCnt
          }
        })
      } else if (this.getCancelOpitonsLen === 1) {
        return this.cancelOptions.filter(info => Number(info.productCnt) > 0).map(option => {
          return {
            orderProductOptionNo: option.orderOptionNo,
            productCnt: option.productCnt
          }
        })
      }
    },
    updateClaimReasonType (claimReasonType) {
      this.claimReasonType = claimReasonType
      const claimedProductOptions = this.claimedProductOptions()

      if (this.claimReasonType !== 'default' && claimedProductOptions && claimedProductOptions.length > 0) {
        const claimParams = {
          orderOptionNo: this.$store.state.route.params.orderOptionNo,
          claimType: 'CANCEL',
          productCnt: 0,
          claimReasonType: this.claimReasonType,
          returnWayType: 'SELLER_COLLECT',
          claimedProductOptions: claimedProductOptions
        }

        this.getCancelEstimate(claimParams)
      }
    },
    updateProductCnt (productData) {
      this.CHANGE_CANCEL_OPTIONS(productData)
    },
    showBankErrorAlert () {
      return this.$refs.bankAccountInfo.showBankErrorAlert()
    },
    claimParamsCheck () {
      const claimedProductOptions = this.claimedProductOptions()
      if (claimedProductOptions === null || claimedProductOptions.length <= 0) {
        alert('취소상품을 하나 이상 선택해주세요.')
        return false
      }
      if (this.claimReasonType === 'default') {
        alert('취소사유 구분을 선택 해 주세요.')
        return false
      }
      if (this.getBankAccountInfo === 'Error') {
        this.showBankErrorAlert()
        return false
      }
      return true
    },
    cancelOrderOption () {
      const claimedProductOptions = this.claimedProductOptions()

      if (!this.claimParamsCheck()) {
        return
      }
      if (confirm('주문취소 처리를 하시겠습니까 ?')) {
        const cancelParam = {
          orderOptionNo: this.$store.state.route.params.orderOptionNo,
          claimType: 'CANCEL',
          productCnt: 0,
          claimReasonType: this.claimReasonType,
          claimReasonDetail: this.claimReasonDetail,
          saveBankAccountInfo: 'false',
          returnWayType: 'SELLER_COLLECT',
          bankAccountInfo: this.getBankAccountInfo,
          claimedProductOptions: claimedProductOptions
        }

        // if (this.claimOrderOption.originalOption.orderStatusType === 'PRODUCT_PREPARE' || this.claimOrderOption.originalOption.orderStatusType === 'DELIVERY_PREPARE') {
        //   alert('택배 포장중인 상품입니다.\n이미 출고된 상품인 경우 취소가 철회되고 문자를 발송해 드립니다.\n상품 수령후 반품신청 부탁드립니다.')
        // }
        this.postClaimCancel(cancelParam).then(() => {
          alert('취소신청이 완료되었습니다. 환불관련 정보는 마이페이지의 취소반품조회에서 확인 가능합니다.')
          this.$router.push('/mypage/')
        })
      }
    },
    enterBeforePage () {
      this.$router.back()
    },
    allSelect () {
      this.CHANGE_CANCEL_ITEMS_CHECKOUT_ALL(!this.checkCancelAll)
    }
  },
  beforeRouteLeave (to, from, next) {
    this.RESET_CLAIM_ORDER_OPTION()
    next()
  }
}
</script>
