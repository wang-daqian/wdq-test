<template>
  <div class="content">
    <div class="board_zone_sec">
      <div class="board_zone_tit">
        <h2>Q&amp;A</h2>
      </div>
      <div class="board_zone_cont">
        <form>
          <div class="board_zone_write">
            <div class="board_write_box">
              <table class="board_write_table">
                <colgroup>
                  <col style="width:15%">
                  <col style="width:85%">
                </colgroup>
                <tbody>
                  <tr v-if="inquiryTypeItems && pageType === 'REGISTE'">
                    <th scope="row">문의유형</th>
                    <td>
                      <div class="category_select">
                        <select class=" tune" id="category" name="category" style="width: 127px;" v-model="inquiryTypeNo">
                          <option value="-1" >선택해주세요</option>
                          <option v-for="typeItem in inquiryTypeItems" :key="typeItem.value" :value="typeItem.value">{{typeItem.label}} </option>
                        </select>
                      </div>
                    </td>
                  </tr>
                  <tr v-else-if="pageType === 'MODIFY'">
                    <th scope="row">문의유형</th>
                    <td>{{inquiry.inquiryType.inquiryTypeName}}</td>
                  </tr>
                  <tr v-if="profile">
                    <th scope="row">작성자</th>
                    <td>{{profile.memberName}}</td>
                  </tr>
                  <tr>
                    <th scope="row">제목</th>
                      <td>
                        <input type="text" name="subject" value="" maxlength="200" v-model="inquiryTitle">
                      </td>
                  </tr>
                  <tr>
                    <th scope="row">내용</th>
                    <td class="write_editor">
                      <div class="form_element">
                        <em>해당글은 비밀글로만 작성이 됩니다.</em>
                      </div>
                      <textarea id="editor" name="contents" cols="" rows="10" style="width: 100%; display: block;" maxlength="2000" v-model="inquiryContent"></textarea>
                    </td>
                  </tr>
                  <tr v-if="pageType === 'REGISTE'">
                    <th scope="row">첨부파일</th>
                    <td id="uploadBox">
                      <div class="file_upload_sec">
                        <label for="attach">
                          <input type="text" class="file_text" title="파일 첨부하기" readonly="readonly" v-model="originalFileName">
                        </label>
                        <div class="btn_upload_box">
                          <button type="button" class="btn_upload" title="찾아보기">
                            <em>찾아보기</em>
                          </button>
                          <input style="right: 80px;" type="file" id="attach" name="upfiles[]" class="file" title="찾아보기" @change="changeFile"/>
                          <span class="btn_gray_list">
                            <button type="button" id="addUploadBtn" class="btn_gray_big" v-if="originalFileName" @click.prevent="deleteFile">
                              <span>- 삭제</span>
                            </button>
                          </span>
                        </div>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
            <!-- //board_write_box -->
          </div>
          <!-- //board_zone_write -->
          <div class="btn_center_box">
            <button type="button" class="btn_before" @click.prevent="back">
              <strong>이전</strong>
            </button>
            <template v-if='!inquiry'>
            <button type="submit" class="btn_write_ok" @click.prevent="signInInquiry">
              <strong>저장</strong>
            </button>
            </template>
            <template v-else>
              <button type="submit" class="btn_write_ok" @click.prevent="modifyInquiry">
              <strong>저장</strong>
            </button>
            </template>
          </div>
        </form>
      </div>
      <!-- //board_zone_cont -->
    </div>
    <!-- //board_zone_sec -->
  </div>
</template>

<script>
import { mapState } from 'vuex'

export default {
  name: 'SignInInquiry',
  metaInfo: {
    title: 'Q&A'
  },
  data () {
    return {
      cancleConfirmMsg: 'Q&A 등록을 취소하시겠습니까?',
      inquiryTypeNo: '-1',
      inquiryTitle: '',
      inquiryContent: '',
      originalFileName: '',
      uploadFile: '',
      inquiryNo: -1,
      doubleClickFlag: false,
      pageType: 'REGISTE'
    }
  },
  watch: {
    inquiry: function () {
      this.pageType = 'MODIFY'
      this.inquiryNo = this.inquiry.inquiryNo
      this.inquiryTitle = this.inquiry.inquiryTitle
      this.inquiryContent = this.inquiry.inquiryContent
    }
  },
  computed: {
    ...mapState('profileinquiry', ['inquiry']),
    ...mapState('common', ['malls']),
    ...mapState('profile', ['profile']),
    ...mapState('common', ['uploadFilesData']),
    inquiryTypeItems () {
      if (this.malls && this.malls.inquiryType) {
        return this.malls.inquiryType.map(type => {
          return { label: type.inquiryTypeName, value: type.inquiryTypeNo }
        })
      }
    }
  },
  components: {
  },
  methods: {
    changeFile (event) {
      if (event.target.files[0].type.split('image').length === 1) {
        alert('이미지 파일만 등록가능합니다.')
        return false
      }
      if (event.target.files[0].size > 1048576) { // 1MB
        alert('각 사진은 최대 1MB까지 등록가능합니다.')
        return false
      }
      this.uploadFile = event.target.files[0]
      this.originalFileName = this.uploadFile.name
      event.target.value = ''
    },
    deleteFile (event) {
      this.uploadFile = ''
      this.originalFileName = ''
    },
    back () {
      if (confirm(this.cancleConfirmMsg)) {
        this.$router.push(`/mypage/profile/inquiries`)
      }
    },
    signInInquiry () {
      if (this.doubleClickFlag) {
        return false
      }
      if (!this.checkForm()) {
        return false
      }
      let iparam = {
        inquiryContent: this.inquiryContent,
        inquiryTitle: this.inquiryTitle,
        originalFileName: this.originalFileName,
        inquiryTypeNo: this.inquiryTypeNo
      }
      this.doubleClickFlag = true
      this.uploadFileAsync().then(res => {
        if (res) {
          iparam.uploadedFileName = res.data.imageUrl
        }
        return this.$store.dispatch('profileinquiry/signInInquiries', iparam)
      }).then(() => {
        this.doubleClickFlag = false
        alert('문의 등록이 완료되었습니다.')
        this.$router.push('/mypage/profile/inquiries')
      })
    },
    modifyInquiry () {
      if (!this.checkModifyForm()) {
        return false
      }
      let iparam = {
        inquiryNo: this.inquiryNo,
        inquiryContent: this.inquiryContent,
        inquiryTitle: this.inquiryTitle
      }
      this.$store.dispatch('profileinquiry/modifyInquiry', iparam).then(() => {
        this.$router.push('/mypage/profile/inquiries/')
      })
    },
    checkForm () {
      if (this.inquiryTypeItems.length !== 0 && this.inquiryTypeNo === '-1') {
        alert('문의유형을 선택하세요.')
        return false
      }
      return this.checkModifyForm()
    },
    checkModifyForm () {
      if (!this.inquiryTitle) {
        alert('제목을 입력해 주세요.')
        return false
      }
      if (!this.inquiryContent) {
        alert('내용을 입력해 주세요.')
        return false
      }
      return true
    },
    uploadFileAsync () {
      if (!this.uploadFile) {
        return Promise.resolve()
      }
      let data = new FormData()
      data.append('file', this.uploadFile)
      return this.$store.dispatch('common/uploadImages', data)
    }
  }
}
</script>
