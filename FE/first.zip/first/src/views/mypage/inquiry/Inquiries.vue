<template>
  <div class="content">
    <div class="board_zone_sec">
      <div class="board_zone_tit">
        <h3>Q&amp;A</h3>
      </div>
      <div class="board_zone_cont">
        <div class="board_zone_list">
          <div class="mypage_table_type q_a">
            <table :class="inquiries && inquiries.length == 0 ? 'no_result' : 'scroll_table'">
              <thead>
                <tr>
                  <th>문의일시</th>
                  <th>문의유형</th>
                  <th>제목</th>
                  <th>문의상태</th>
                </tr>
              </thead>
              <tbody>
                <template v-if="inquiries && inquiries.length > 0">
                  <inquiry-item v-for="inquiry in inquiries" :key="inquiry.inquiryNo" :inquiry="inquiry" />
                </template>
                <template v-else>
                  <tr>
                    <td colspan="5" align="center">게시글이 존재하지 않습니다.</td>
                  </tr>
                </template>
              </tbody>
            </table>
            <div v-if="inquiries && inquiries.length<this.totalCount" class="pagination">
              <p class="pagination-btn">
                <button type="button" class="btn_more" @click.prevent="pageDown">더보기</button>
              </p>
            </div>
          </div>
          <!-- //board_list_qa -->
          <div class="pagination">
            <ul></ul>
          </div>
          <!-- //pagination -->
        </div>
        <!-- //board_zone_list -->
        <div class="btn_right_box">
          <button type="button" class="btn_write" @click.prevent="goWrite">
            <strong>문의하기</strong>
          </button>
        </div>
      </div>
      <!-- //board_zone_cont -->
    </div>
    <!-- //board_zone_sec -->
  </div>
</template>

<script>
import InquiryItem from '@/components/mypage/inquiry/InquiryItem'
import { mapState } from 'vuex'

export default {
  name: 'Inquiries',
  metaInfo: {
    title: 'Q&A'
  },
  components: {
    'inquiry-item': InquiryItem
  },
  computed: {
    ...mapState('profileinquiry', ['inquiries', 'totalCount'])
  },
  methods: {
    goWrite () {
      this.$router.push('/mypage/profile/signininquiry')
    },
    pageDown () {
      this.$store.dispatch('profileinquiry/fetchInquiriesMore')
    }
  }
}
</script>
