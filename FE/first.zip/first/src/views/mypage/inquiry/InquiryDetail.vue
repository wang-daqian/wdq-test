<template>
  <div class="content" v-if="inquiry">
    <div class="board_zone_sec">
      <div class="board_zone_tit">
        <h2>Q&amp;A</h2>
      </div>
      <div class="board_zone_cont">
        <div class="board_zone_view">

          <div class="board_view_tit">
            <h3>
              [{{inquiry.inquiryType.inquiryTypeName}}] {{inquiry.inquiryTitle}}
            </h3>
          </div>
          <div class="board_view_info">
            <span class="view_info_idip" v-if="profile">
              <strong>{{profile.memberName}}</strong>
            </span>
            <span class="view_info_day">
              <em>{{inquiry.registerYmdt}}</em>
            </span>
          </div>
          <!-- //board_view_info -->
          <div class="board_view_content">
            <div class="view_goods_select">
            </div>
            <!-- //view_goods_select -->
            <div class="board_view_qa">
              <div class="view_question_box">
                <strong class="view_question_tit">Q.</strong>
                <div class="seem_cont">
                  <div style="margin:10px 0 10px 0">
                    <p class="content_pre">{{inquiry.inquiryContent}}</p>
                  </div>
                </div>
                <!-- //seem_cont -->
              </div>
              <div class="view_question_box" v-if="inquiry.answer">
                <strong class="view_question_tit">A.</strong>
                <div class="seem_cont">
                  <div style="margin:10px 0 10px 0">
                    <p class="content_pre" v-html="inquiry.answer.answerContent"></p>
                  </div>
                </div>
                <!-- //seem_cont -->
              </div>
            </div>
            <!-- //board_view_qa -->
            <div class="board_list_gallery">
              <ul class="ss_list">
                <li v-for="(url,index) in inquiry.imageUrls" :key="index"><a href="#" @click.prevent="showLayer(index)"><img :src="url" class="js_image_load"  /></a></li>
              </ul>
            </div>
          </div>
        </div>
        <!-- //board_zone_view -->
        <div class="btn_right_box">
          <button type="button" class="btn_board_del" @click.prevent="delInquiry">
            <strong>삭제</strong>
          </button>
          <button type="button" class="btn_board_edit" @click.prevent="goModify">
            <strong>수정</strong>
          </button>
          <button type="button" class="btn_board_list" @click.prevent="goList">
            <strong>목록</strong>
          </button>
        </div>
      </div>
      <!-- //board_zone_cont -->
      <template v-if="isPC">
        <item-photo-layer @close="closeLayer" :imageUrls="inquiry.imageUrls" :openLayer="openLayer" :imgStartIndex="imgStartIndex"/>
      </template>
      <template v-else>
        <ItemPhotoLayerSP @close="closeLayer" :imageUrls="inquiry.imageUrls" :openLayer="openLayer" :imgStartIndex="imgStartIndex" />
      </template>
    </div>
    <!-- //board_zone_sec -->
  </div>
  <!-- //content -->
</template>

<script>
import { mapState } from 'vuex'
import { isPC } from '@/utils/utils'
import ItemPhotoLayer from '@/components/mypage/product/ItemPhotoLayer'
import ItemPhotoLayerSP from '@/components/mypage/product/ItemPhotoLayerSP'

export default {
  name: 'inquirydetail',
  metaInfo: {
    title: 'Q&A'
  },
  data () {
    return {
      delMsg: '정말 삭제하시겠습니까?',
      openLayer: false,
      imgStartIndex: 0
    }
  },
  computed: {
    ...mapState('profileinquiry', ['inquiry']),
    ...mapState('profile', ['profile']),
    isPC () {
      return isPC()
    }
  },
  components: {
    ItemPhotoLayer,
    ItemPhotoLayerSP
  },
  methods: {
    showLayer (idx) {
      this.openLayer = true
      this.imgStartIndex = idx
      this.$store.commit('SHOW_LAYER_BG')
    },
    closeLayer () {
      this.openLayer = false
      this.$store.commit('HIDDEN_LAYER_BG')
    },
    delInquiry () {
      if (confirm(this.delMsg)) {
        this.$store.dispatch('profileinquiry/delInquiry', this.inquiry.inquiryNo).then(() => {
          this.$router.push('/mypage/profile/inquiries')
        })
      }
    },
    goModify () {
      this.$router.push('/mypage/profile/inquirymodify/' + this.inquiry.inquiryNo)
    },
    goList () {
      this.$router.push('/mypage/profile/inquiries')
    }
  }
}
</script>

<style scoped>
.btn_right_box {
  float: right;
  width: auto !important;
}
</style>
