<template>
  <div class="mypage_table_type" style="margin-top: 20px">
    <table :class="getNoValidCoupons && getNoValidCoupons.length == 0 ? 'no_result' : 'scroll_table'">
      <colgroup>
        <col style="width:18%">
        <!-- 쿠폰명 -->
        <col style="width:22%">
        <!-- 혜택 -->
        <col style="width:15%">
        <!-- 제한조건 -->
        <col style="width:30%">
        <!-- 유효기간 -->
        <col style="width:15%">
        <!-- 발급일 -->
      </colgroup>
      <thead>
        <tr>
          <th>쿠폰명</th>
          <th>혜택</th>
          <th>사용조건</th>
          <th>유효기간</th>
          <th>발급일</th>
        </tr>
      </thead>
      <tbody>
        <template v-if="getNoValidCoupons && getNoValidCoupons.length > 0">
          <tr v-for="(item, index) in getNoValidCoupons" :key="item.couponIssueNo">
            <td>
              <div class="mypage_coupon_name">
                <img src="../../../assets/img/mypage/coupon.png">
                <strong>{{item.couponName}}</strong>
              </div>
            </td>
            <td>
              <template v-if="item.discountAmt">{{MyMiliFormat(item.discountAmt)}}원 할인</template>
              <template v-if="item.discountRate">{{item.discountRate}}% 할인 (최대 {{MyMiliFormat(item.maxDiscountAmt)}}원)</template>
              <template v-if="item.couponType === 'CART_DELIVERY' && item.freeDelivery === true">
                <span class="txt">무료배송</span>
              </template>
            </td>
            <td>
              <div class="btn_layer">
                <span class="btn_gray_list" @click.prevent="setLearnMoreFlg(index)">
                  <a class="btn_gray_small">
                    <em>자세히보기</em>
                  </a>
                </span>

                <!-- N : 사용가능조건 레이어 시작 -->
                <div id="lyUseCase4" class="layer_area" :style="showLearnMorePop === index ? 'display:block':'display:none'">
                  <div class="ly_wrap use_case_layer">
                    <div class="ly_tit">
                      <strong>사용가능조건 보기</strong>
                    </div>
                    <div class="ly_cont">
                      <div class="use_case_list">
                        <dl>
                          <dt style="display:none">[사용범위]</dt>
                          <template v-if="(item.couponType === 'PRODUCT' || item.couponType === 'PRODUCT_PLUS')">
                            <template v-if="!item.maxSalePrice && !item.minSalePrice">
                              상품 기준금액 제한 없음
                            </template>
                            <template v-else="">

                              <template v-if="item.minSalePrice">
                                {{MyMiliFormat(item.minSalePrice)}}원 이상
                              </template>
                              <template v-if="item.minSalePrice && item.maxSalePrice">
                                ~
                              </template>
                              <template v-if="item.maxSalePrice">
                                {{MyMiliFormat(item.maxSalePrice)}}원 이하
                              </template>
                              사용가능
                            </template>
                          </template>
                          <!-- 장바구니 쿠폰 / 배송비 쿠폰 -->
                          <template v-if="(item.couponType === 'CART' || item.couponType === 'CART_DELIVERY')">
                            <template v-if="item.couponType === 'CART' && (!item.maxSalePrice && !item.minSalePrice)">
                              장바구니 기준금액 제한 없음
                            </template>
                            <!-- 최대 -->
                            <template v-else>
                              <template v-if="!item.freeDelivery"> 장바구니금액 </template>
                              <template v-if="item.minSalePrice">
                                {{MyMiliFormat(item.minSalePrice)}}원 이상
                              </template>
                              <template v-if="item.minSalePrice && item.maxSalePrice">
                                ~
                              </template>
                              <template v-if="item.maxSalePrice">
                                {{MyMiliFormat(item.maxSalePrice)}}원 이하
                              </template>
                              <template v-if="(item.minSalePrice && item.minDeliveryAmt) || (item.maxSalePrice && item.minDeliveryAmt)"> / </template>
                              <template v-if="item.minDeliveryAmt">
                                배송비 {{MyMiliFormat(item.minDeliveryAmt)}}원 이상
                              </template>
                              사용가능
                            </template>
                          </template>
                        </dl>
                        <dl v-if="(item.couponType === 'CART' && item.otherCouponUsable === false)">
                          <dt>상품할인쿠폰 중복 사용불가</dt>
                          <!-- <dd>배송비할인별 중복 사용가능</dd> -->
                        </dl>
                      </div>
                    </div>
                    <!-- //ly_cont -->
                    <a href="#lyUseCase4" class="ly_close" @click.prevent="setLearnMoreFlg(-1)">
                      <img src="../../../assets/img/common/layer/btn_layer_close.png" alt="닫기">
                    </a>
                  </div>
                  <!-- //ly_wrap -->
                </div>
                <!-- N : 사용가능조건 레이어 끝 -->
              </div>
            </td>
            <td>
              <em class="coupon_date_day">
                {{item.useYmdt}} ~{{item.useEndYmdt}}
              </em>
              <span class="coupon_before_use" style="display:none">사용가능</span>
            </td>
            <td>
              <template>{{item.issueYmdt}}</template>
            </td>
          </tr>
        </template>
        <template v-else>
          <tr>
            <td colspan="5">
              <p class="no_data">사용완료/사용불가 쿠폰이 없습니다.</p>
            </td>
          </tr>
        </template>
      </tbody>
    </table>
    <div class="pagination" v-if="getNoValidCoupons && getNoValidCoupons.length<this.getNoValidCoupons.totalCount">
      <p class="pagination-btn">
        <button type="button" class="btn_more" @click.prevent="moreNoCoupons">더보기</button>
      </p>
    </div>
  </div>
</template>

<script>
import { formatCurrency } from '@/utils/stringUtils'
import { mapState, mapActions } from 'vuex'

export default {
  data () {
    return {
      showLearnMorePop: -1
    }
  },
  metaInfo: {
    title: '사용완료/기간만료 쿠폰'
  },
  components: {
  },
  computed: {
    ...mapState('validCoupon', ['getNoValidCoupons'])
  },
  methods: {
    ...mapActions('validCoupon', ['moreNoCoupons']),
    MyMiliFormat (val) {
      return formatCurrency(val)
    },
    manageDate (date) {
      if (date) {
        let splitedDate = date.split(' ')
        splitedDate[1] = splitedDate[1].substr(0, 5)
        return splitedDate
      }
    },
    setLearnMoreFlg (flag) {
      this.showLearnMorePop = flag
    },
    usablePlatforms (platforms) {
      let platform = ''
      platforms.forEach(element => {
        platform = platform + '+' + element
      })
      return platform.substring(1)
    }
  }
}
</script>
