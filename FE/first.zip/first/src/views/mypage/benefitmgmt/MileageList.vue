<template>
  <div class="content">
    <div class="mypage_cont">

      <!-- N : [위젯] 마이페이지 요약정보 -->
      <!-- 마이페이지 회원 요약정보 -->
      <top-info></top-info>
      <!-- //mypage_top_info -->

      <!-- 마이페이지 회원 요약정보 -->

      <div class="mypage_lately_info">
        <div class="mypage_zone_tit">
          <h3>{{showAccumulationName}}</h3>
        </div>
        <!-- <date-picker :type="listType" ref="dataPicker"></date-picker> -->

        <div class="mypage_lately_info_cont">

          <div class="mypage_table_type">
            <span class="pick_list_day">
              {{showAccumulationName}} 내역 총
              <strong>{{totalMileageCount}}</strong>건</span>
            <table :class="mileageItmes && mileageItmes.length == 0 ? 'no_result': 'scroll_table'">
              <colgroup>
                <col style="width:7%">
                <col style="width:14%">
                <!-- 날짜 -->
                <col style="width:20%">
                <!-- 유형 -->
                <col style="width:14%">
                <!-- 내용 -->
                <col style="width:25%">
                <!-- 유효기간 -->
                <col style="width:10%">
                <col style="width:10%">
              </colgroup>
              <thead>
                <tr>
                  <th>구분</th>
                  <th>날짜</th>
                  <th>유형</th>
                  <th>내용</th>
                  <th>유효기간</th>
                  <th class="td_cash">
                    <span>{{showAccumulationName}} 내역</span>
                  </th>
                  <th class="td_cash">
                    <span>잔여 {{showAccumulationName}}</span>
                  </th>
                </tr>
              </thead>
              <tbody>
                <template v-if="mileageItmes && totalMileageCount > 0">
                  <tr v-for="item in mileageItmes" :key="item.accumulationNo">
                    <td>{{showDivisionFormat(item)}}</td>
                    <td>{{dateFormat(item.registerYmdt)}}</td>
                    <td>{{item.accumulationReserveReasonDisplay}}</td>
                    <td class="td_left">{{item.reasonDetail}}</td>
                    <td v-if="item.startYmdt && item.expireYmdt">
                      <em>{{item.startYmdt| getStrDate('-')}}~{{item.expireYmdt| getStrDate('-')}}</em>
                    </td>
                    <td v-else>
                      <em>-</em>
                    </td>
                    <td class="td_cash">
                      <strong>{{showDivision(item)}}{{(item.accumulationAmt)|formatNumber}}{{showAccumulationUnit}}</strong>
                    </td>
                    <td class="td_cash">
                      <span>{{(item.totalAvailableAmt)|formatNumber}}{{showAccumulationUnit}}</span>
                    </td>
                  </tr>
                </template>
                <template v-else>
                  <tr>
                    <td colspan="5">
                      <p class="no_data">적립한 내역이 없습니다.</p>
                    </td>
                  </tr>
                </template>
              </tbody>
            </table>
            <div v-if="mileageItmes && mileageItmes.length<this.totalMileageCount" class="pagination">
              <p class="pagination-btn">
                <button type="button" class="btn_more" @click.prevent="pageDown">더보기</button>
              </p>
            </div>
          </div>
        </div>
        <!-- //mypage_lately_info_cont -->
      </div>
      <!-- //mypage_lately_info -->

      <div class="pagination">
        <div class="pagination">
          <ul></ul>
        </div>
      </div>
      <!-- //pagination -->

    </div>
    <!-- //mypage_cont -->
  </div>
  <!-- //content -->
</template>

<script>
import myDatepicker from '@/components/mypage/viewperiod/DatePicker.vue'
import { mapState, mapGetters } from 'vuex'
import TopInfo from '@/components/mypage/topinfo/TopInfo'
import { formatCurrency } from '@/utils/stringUtils'
import { getStrDate } from '@/utils/dateUtils'

export default {
  data () {
    return {
      listType: 'mileage',
      orderOption: {}
    }
  },
  metaInfo: {
    title: '혜택관리·마일리지'
  },
  name: 'MileageList',

  components: {
    'date-picker': myDatepicker,
    'top-info': TopInfo
  },
  computed: {
    ...mapState('member', ['totalMileageCount', 'mileageItmes']),
    ...mapGetters('common', ['showAccumulationName', 'isUseMallAccumulation', 'showAccumulationUnit'])
  },
  methods: {
    pageDown () {
      this.$store.dispatch('member/fetchMileageMore')
    },
    mMiliFormat (val) {
      return formatCurrency(val)
    },
    dateFormat (date) {
      if (date !== null) {
        return getStrDate(date, '-')
      } else {
        return ''
      }
    },
    showDivision (item) {
      if (item.accumulationStatus === 'GIVE_AVAILABLE' || item.accumulationStatus === 'SUBTRACTION_CANCELED') {
        return '+'
      } else if (item.accumulationStatus === 'GIVE_CANCELED' || item.accumulationStatus === 'SUBTRACTION_USED') {
        return '-'
      }
    },
    showDivisionFormat (item) {
      if (item.accumulationStatus === 'GIVE_AVAILABLE' || item.accumulationStatus === 'SUBTRACTION_CANCELED') {
        return '적립'
      } else if (item.accumulationStatus === 'GIVE_CANCELED' || item.accumulationStatus === 'SUBTRACTION_USED') {
        return '차감'
      }
    }

  }
}
</script>
