<template>
  <div class="content">
    <div class="mypage_cont">

      <!-- 마이페이지 회원 요약정보 -->
      <top-info></top-info>
      <!-- //mypage_top_info -->

      <!-- 마이페이지 회원 요약정보 -->

      <div class="mypage_lately_info">
        <div class="mypage_zone_tit">
          <h3>쿠폰</h3>
        </div>

        <div class="mypage_lately_info_cont">
          <div class="mypage_breakdown_tab">
            <ul>
              <router-link to='/mypage/coupon' tag="li" :class="{on:usableTab}" @click.native="usableClick(true)">
                <a href="#">사용가능</a>
              </router-link>
              <router-link to='/mypage/coupon/novalidcoupon' tag="li" :class="{on:!usableTab}" @click.native="usableClick(false)">
                <a href="#">사용완료/사용불가</a>
              </router-link>
            </ul>
          </div>
          <router-view></router-view>
        </div>
      </div>
    </div>

  </div>
</template>
<script >
import TopInfo from '@/components/mypage/topinfo/TopInfo'

export default {
  data () {
    return {
      usableTab: true
    }
  },
  components: {
    'top-info': TopInfo
  },
  methods: {
    usableClick (flag) {
      this.usableTab = flag
    }
  },
  created () {
    this.usableTab = !this.$route.path.includes('novalidcoupon')
  }
}
</script>
