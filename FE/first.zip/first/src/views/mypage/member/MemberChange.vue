<template>
  <div class="content">
    <div class="mypage_cont">
      <div class="my_page">
        <div class="mypage_zone_tit">
          <h3>회원정보 변경</h3>
        </div>
        <div class="join_base_wrap">
          <div class="member_cont">
            <form id="formJoin">
              <!-- 회원가입/정보 기본정보 -->
              <div class="base_info_box">
                <h3>기본정보</h3>
                <div class="base_info_sec">
                  <table border="0" cellpadding="0" cellspacing="0">
                    <colgroup>
                      <col width="25%">
                      <col width="75%">
                    </colgroup>
                    <tbody>
                      <tr>
                        <th>
                          <span class="important">아이디</span>
                        </th>
                        <td>{{memberId}}</td>
                      </tr>
                      <tr>
                        <th>
                          <span class="important">현재 비밀번호</span>
                        </th>
                        <td>
                          <div :class="input.currentPwd.errorFlg? 'member_warning prior_wrong':'member_warning'">
                            <input type="password" id="currentPassword" name="oldMemPw" v-model='input.currentPwd.value' ref='currentPwd' @blur="currentPwdCheck" maxlength="20" autocomplete="off" />
                          </div>
                          <div id="mempwd-error" class="warning_1" v-if="input.currentPwd.errorFlg">{{input.currentPwd.errorMsgTxt}}</div>
                        </td>
                      </tr>
                      <tr>
                        <th>
                          <span class="important">신규 비밀번호</span>
                        </th>
                        <td>
                          <div :class="input.newPwd.errorFlg? 'member_warning prior_wrong':'member_warning'">
                            <input type="password" id="newPassword" name="memPw" v-model='input.newPwd.value' ref="newPwd" @blur="newPwdCheck" placeholder="영문+숫자+특수문자 포함해서 8~20자까지 가능" maxlength="20" autocomplete="off" />
                          </div>
                          <div id="mempwd-error" class="warning_1" v-if="input.newPwd.errorFlg">{{input.newPwd.errorMsgTxt}}</div>
                        </td>
                      </tr>
                      <tr>
                        <th>
                          <span class="important">비밀번호 확인</span>
                        </th>
                        <td>
                          <div :class="input.confirmPwd.errorFlg? 'member_warning prior_wrong':'member_warning'">
                            <input type="password" id="newPasswordCheck" name="memPwRe" v-model='input.confirmPwd.value' ref="confirmPwd" @blur="confirmPwdCheck" placeholder="비밀번호를 한번 더 입력해 주세요." maxlength="20" autocomplete="off" />
                          </div>
                          <div id="mempwd-error" class="warning_1" v-if="input.confirmPwd.errorFlg">{{input.confirmPwd.errorMsgTxt}}</div>
                        </td>
                      </tr>
                      <tr>
                        <th>
                          <span class="important">이름</span>
                        </th>
                        <td>
                          <div :class="input.memNameIllegal ?'member_warning prior_wrong':'member_warning'">
                            <input type="text" class="middle" v-model="input.memberName" maxlength="30" placeholder="한글+영문 만 입력 가능" @keydown="gdEngKor" @input="gdEngKor" @blur="memberNameCheck" ref="memberName">
                          </div>
                          <div v-if="input.memNameIllegal" class="warning_1">{{input.memberNameTxt}}</div>
                        </td>
                        <!-- <td>{{memberName}}</td> -->
                      </tr>
                      <email-authentications ref="emailAuthentications" :prefixName="input.prefixEmailName" :domain="input.emailDomain" @showEmailAuthenPop="showEmailAuthenPop"></email-authentications>
                      <sms-authentications ref="smsAuthentications" :prefixMobileNo="input.prefixMobileNo" :mobileNo="input.mobileNo" @showSmsAuthenPop="showSmsAuthenPop" from="CHANGE_MOBILE_NO"></sms-authentications>
                      <tr>
                        <th>
                          <span>연락처</span>
                        </th>
                        <td class="member_add_tel">
                          <div style="margin-left: -5px">
                            <vue-select-box :showValue="input.prefixTelephoneNo" :items="selectTelNoItems" @selected="setPrefixTelNo" :width="seletBoxWidth" />
                            <input class="cellphone" type="text" id="cellPhone" name="cellPhone" maxlength="9" placeholder="-  없이 숫자만 입력하세요." data-pattern="gdNum" v-model="input.telephoneNo" @keydown="gdNumPhone" @input="gdNumPhone" @blur="gdNumPhone" :style="{'margin-left':'5px'}">
                            <div id="mempwd-error" class="warning_1" v-if="input.telError.errorFlg">{{input.telError.errorMsgTxt}}</div>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <th>
                          <span>생년월일</span>
                        </th>
                        <td class="member_add_tel">
                          <input class="date_birth" type="text" id="memId1" name="memId1" data-pattern="gdMemberId" placeholder="예시 ) 19880807" maxlength="8" v-model="input.birthday" @keydown="gdNumBirthday" @input="gdNumBirthday" @blur="gdNumBirthday">
                          <vue-select-box :showValue="input.sex" :items="selectSexItems" @selected="setSex" :width="seletBoxWidth" />
                        </td>
                      </tr>
                      <tr>
                        <th>
                          <span class="important">주소</span>
                        </th>
                        <td class="adress">
                          <div>
                            <input class="disabled" type="text" id="memId2" name="memId2" data-pattern="gdMemberId" placeholder="" v-model="input.zipCd" disabled>
                            <button type="button" id="btnPostcode" class="btn_sec" @click.prevent="searchAddress">우편번호찾기</button>
                          </div>
                          <div>
                            <input class="disabled" type="text" id="memId3" name="memId3" data-pattern="gdMemberId" placeholder="" v-model="input.address" disabled>
                          </div>
                          <div>
                            <input type="text" id="memId4" name="memId4" data-pattern="gdMemberId" placeholder="" v-model="input.addressSub">
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <th>
                          <span>수신 동의</span>
                        </th>
                        <td>
                          <div class="form_element">
                            <label for="sms" class="check_s" :class="['check_s', {'on':input.smsChecked}]" @click="input.smsChecked=!input.smsChecked" placeholder="예시 ) 19880807">SMS 수신 동의</label>
                            <!-- <label v-if="!mailAuthFlg" for="e-mail3" class="check_s off" :style="{'margin-left':'10px'}">이메일 수신 동의</label>
                            <label v-else for="e-mail3" :class="['check_s', {'on':input.mallChecked}]" @click="input.mallChecked=!input.mallChecked" :style="{'margin-left':'10px'}">이메일 수신 동의</label> -->
                            <label for="e-mail3" :class="['check_s', {'on':input.mallChecked}]" @click="input.mallChecked=!input.mallChecked" :style="{'margin-left':'10px'}">이메일 수신 동의</label>
                            <p>구매정보 및 서비스 주요 안내 사항은 수신 동의 여부와 관계없이 발송됩니다.</p>
                          </div>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <!-- //base_info_sec -->
                <h3>환불정보</h3>
                <div class="base_info_sec">
                  <table border="0" cellpadding="0" cellspacing="0">
                    <colgroup>
                      <col width="25%">
                      <col width="75%">
                    </colgroup>
                    <tbody>
                      <tr>
                        <th>
                          <span>환불 계좌</span>
                        </th>
                        <td class="refund">
                          <div>
                            <input type="text" name="" v-model="input.refundBankDepositorName" maxlength="10" placeholder="예금주명" />
                            <vue-select-box :showValue="input.refundBank" :items="showBankList" @selected="setBank" :width="seletBoxWidth" placeholder="은행 선택" />
                            <input type="text" name="" value="" v-model="input.refundBankAccount" maxlength="30" @keydown="gdBankAcount" @input="gdBankAcount" @blur="gdBankAcount" placeholder="계좌번호" />
                          </div>
                          <div class="form_element">
                            <label for="e-mail2" :class="['check_s', {'on':bankAgreeCheck}]" @click="bankAgreeCheck = !bankAgreeCheck">본 계좌를 환불 계좌로 설정하는데 동의합니다. <br>※환불 받는 계좌이므로 정확한 계좌정보를 입력해 주세요. </label>
                          </div>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <!-- //base_info_sec -->
              </div>
              <!-- //base_info_box -->
              <div class="btn_right_box">
                <button type="button" class="btn_logout" value="정보수정" @click="goWithDrawal">회원탈퇴</button>
              </div>
              <div class="btn_center_box">
                <button type="button" class="btn_comfirm js_btn_join" value="정보수정" @click="change">수정하기</button>
              </div>
              <!-- //btn_center_box -->
            </form>
          </div>
          <!-- //member_cont -->
        </div>
        <!-- //join_base_wrap -->
      </div>
      <!-- //my_page -->
    </div>
    <!-- //mypage_cont -->
    <authen-popup :textMsg="textMsgEmail" @confirmCallback="emailAuthen" v-if="emailPopFlg"></authen-popup>
    <authen-popup :textMsg="textMsgSms" @confirmCallback="smsAuthen" v-if="smsPopFlg"></authen-popup>
    <address-info @closePop="closeLayer" v-if="showAddLayer" />
  </div>
</template>

<script>
import { replacePattern } from '@/utils/validateUtils'
import { mapState } from 'vuex'
import { isPC } from '@/utils/utils'
import $ from 'jquery'

import VueSelectBox from '@/components/common/VueSelectBox'
import EmailAuthentications from '@/components/member/EmailAuthentications'
import SmsAuthentications from '@/components/member/SmsAuthentications'
import AuthenPopup from '@/components/member/AuthenPopup'
import AddressInfo from '@/components/common/address/AddressInfo'

export default {
  name: 'MemberChange',
  data () {
    return {
      input: {
        currentPwd: {
          value: '',
          errorMsgTxt: '',
          errorFlg: false
        },
        newPwd: {
          value: '',
          errorMsgTxt: '',
          errorFlg: false
        },
        confirmPwd: {
          value: '',
          errorMsgTxt: '',
          errorFlg: false
        },
        telError: {
          errorMsgTxt: '',
          errorFlg: false
        },

        memberName: '',
        memberNameTxt: '',
        memNameIllegal: false,

        prefixEmailName: '',
        emailDomain: '',
        prefixMobileNo: '',
        mobileNo: '',
        prefixTelephoneNo: '',
        telephoneNo: '',
        birthday: '',
        sex: '',
        zipCd: '',
        address: '',
        addressSub: '',
        refundBankDepositorName: '',
        refundBank: 'default',
        refundBankAccount: '',
        mallChecked: false,
        smsChecked: false
      },
      memberId: '',
      // memberName: '',
      selectValue: '@',
      pwdAuthCheck: false,
      bankAgreeCheck: false,
      seletBoxWidth: '120px',
      selectTelNoItems: [
        {
          label: '선택',
          value: ''
        },
        {
          label: '02',
          value: '02'
        },
        {
          label: '031',
          value: '031'
        },
        {
          label: '032',
          value: '032'
        },
        {
          label: '033',
          value: '033'
        },
        {
          label: '041',
          value: '041'
        },
        {
          label: '042',
          value: '042'
        },
        {
          label: '043',
          value: '043'
        },
        {
          label: '051',
          value: '051'
        },
        {
          label: '052',
          value: '052'
        },
        {
          label: '053',
          value: '053'
        },
        {
          label: '054',
          value: '054'
        },
        {
          label: '055',
          value: '055'
        },
        {
          label: '061',
          value: '061'
        },
        {
          label: '062',
          value: '062'
        },
        {
          label: '063',
          value: '063'
        },
        {
          label: '064',
          value: '064'
        },
        {
          label: '070',
          value: '070'
        }
      ],
      selectSexItems: [
        {
          label: '성별',
          value: ''
        },
        {
          label: '여자',
          value: 'F'
        },
        {
          label: '남자',
          value: 'M'
        }
      ],
      textMsgEmail: '\n인증 메일이 발송되었습니다.\n이메일에 발송된 인증번호를 입력하여\n이메일 인증을 완료해 주세요.',
      textMsgSms: '\n인증번호가 발송되었습니다.\n휴대폰으로 발송된 인증번호를 입력하여\n인증을 완료해 주세요.',
      emailPopFlg: false,
      smsPopFlg: false,
      showAddLayer: false
    }
  },
  components: {
    VueSelectBox,
    EmailAuthentications,
    SmsAuthentications,
    AuthenPopup,
    AddressInfo
  },
  watch: {
    profileNonMasking: function () {
      this.memberId = this.profileNonMasking.memberId
      this.input.memberName = this.profileNonMasking.memberName
      if (this.profileNonMasking.email && this.profileNonMasking.email !== '') {
        this.input.prefixEmailName = this.profileNonMasking.email.split('@')[0]
        this.input.emailDomain = this.profileNonMasking.email.split('@')[1]
      }
      if (this.profileNonMasking.mobileNo && this.profileNonMasking.mobileNo !== '') {
        this.input.prefixMobileNo = this.profileNonMasking.mobileNo.substring(0, 3)
        this.input.mobileNo = this.profileNonMasking.mobileNo.substring(3)
      }
      if (this.profileNonMasking.telephoneNo && this.profileNonMasking.telephoneNo !== '') {
        let tempPreNo = this.profileNonMasking.telephoneNo.substring(0, 2)
        let item = this.selectTelNoItems.find(item => { return item.value === tempPreNo })
        if (item) {
          this.input.prefixTelephoneNo = tempPreNo
          this.input.telephoneNo = this.profileNonMasking.telephoneNo.substring(2)
        } else {
          this.input.prefixTelephoneNo = this.profileNonMasking.telephoneNo.substring(0, 3)
          this.input.telephoneNo = this.profileNonMasking.telephoneNo.substring(3)
        }
      }
      this.input.birthday = this.profileNonMasking.birthday
      this.input.sex = this.profileNonMasking.sex === null ? '' : this.profileNonMasking.sex
      this.input.zipCd = this.profileNonMasking.zipCd
      this.input.address = this.profileNonMasking.address
      this.input.addressSub = this.profileNonMasking.detailAddress
      this.input.mallChecked = this.profileNonMasking.directMailAgreed
      this.input.smsChecked = this.profileNonMasking.smsAgreed
      this.input.refundBankDepositorName = this.profileNonMasking.refundBankDepositorName
      this.input.refundBank = this.profileNonMasking.refundBank ? this.profileNonMasking.refundBank : 'default'
      this.input.refundBankAccount = this.profileNonMasking.refundBankAccount
    }
  },
  computed: {
    ...mapState('profile', ['profileNonMasking']),
    ...mapState('common', ['malls']),
    showBankList () {
      let bankItems = [{
        label: '은행 선택',
        value: 'default'
      }]

      if (this.malls && this.malls.bankType) {
        let items = this.malls.bankType.map(type => {
          return { label: type.name, value: type.value }
        })
        bankItems = [...bankItems, ...items]
      }

      return bankItems
    },
    getEmail () {
      return this.$refs.emailAuthentications.getEmail
    },
    getMobileNum () {
      return this.$refs.smsAuthentications.getMobileNum
    },
    getSmsAuthKey () {
      return this.$refs.smsAuthentications.getSmsAuthKey
    }
  },
  methods: {
    currentPwdCheck: function () {
      if (this.input.currentPwd.value === '') {
        let errorMsg = '비밀 번호를 입력하세요.'
        this.setInputError(this.input.currentPwd, errorMsg)
      } else {
        if (this.input.newPwd.value !== '') {
          this.newPwdCheck()
        }
        this.resetInputError(this.input.currentPwd)
      }
    },
    newPwdCheck () {
      let newPwdErrorMsg = ''

      if (this.input.newPwd.value === '') {
        if (this.input.confirmPwd.value !== '') {
          this.currentPwdCheck()
          newPwdErrorMsg = '새 비밀 번호를 입력해 주세요.'
        }
      } else {
        if (this.input.confirmPwd.value !== '') {
          this.confirmPwdCheck()
        }
        if (this.input.currentPwd.value === '') {
          this.currentPwdCheck()
        }
        // let reg = /^(?=.*[0-9])(?=.*[a-zA-Z])(?=.*[\\!@#$%^&+=\-_.()])[A-Za-z0-9\\!@#$%^&+=\-_.()]{8,20}$/
        let reg = /^(?=.*[0-9])(?=.*[a-zA-Z])(?=.*[!@#$%^&+=_.()-])[A-Za-z0-9!@#$%^&+=_.()-]{8,20}$/
        if (!reg.test(this.input.newPwd.value)) {
          if (this.input.newPwd.value.length < 8) {
            newPwdErrorMsg = '비밀번호는  띄어쓰기 없이 8-20자  영문, 숫자, 특수문자 조합으로  입력하셔야 합니다.'
          } else {
            // let specCharacters = this.input.newPwd.value.replace(/[A-Za-z0-9\\!@#$%^&+=\-_.()]/g, '')
            let specCharacters = this.input.newPwd.value.replace(/[A-Za-z0-9!@#$%^&+=_.()-]/g, '')
            if (specCharacters !== '') {
              newPwdErrorMsg = '특수문자는 !@#$%^&+=-_.()만 입력 가능합니다.'
            } else {
              newPwdErrorMsg = '비밀번호는  띄어쓰기 없이 8-20자  영문, 숫자, 특수문자 조합으로  입력하셔야 합니다.'
            }
          }
        }
        if (this.input.newPwd.value === this.input.currentPwd.value) {
          newPwdErrorMsg = '현재 비밀번호와 같은 비밀번호를 사용할 수 없습니다.'
        }
      }

      if (newPwdErrorMsg !== '') {
        this.setInputError(this.input.newPwd, newPwdErrorMsg)
      } else {
        this.resetInputError(this.input.newPwd)
      }
    },
    confirmPwdCheck () {
      let errorMsg = ''

      if (this.input.confirmPwd.value === '') {
        if (this.input.newPwd.value !== '') {
          errorMsg = '필수항목 입니다.'
        } else {
          this.newPwdCheck()
        }
      } else {
        if (this.input.newPwd.value === '') {
          this.newPwdCheck()
        }
        if (this.input.confirmPwd.value !== this.input.newPwd.value) {
          errorMsg = '신규 비밀번호와 일치하지 않습니다. 다시 입력해 주세요.'
        }
      }
      if (errorMsg !== '') {
        this.setInputError(this.input.confirmPwd, errorMsg)
      } else {
        this.resetInputError(this.input.confirmPwd)
      }
    },
    gdNumPhone: function () {
      if (this.input.telephoneNo !== '') {
        this.input.telephoneNo = replacePattern(this.input.telephoneNo, /[^\d]/g, '')
      }
    },
    gdBankAcount: function () {
      if (this.input.refundBankAccount !== '') {
        this.input.refundBankAccount = replacePattern(this.input.refundBankAccount, /[^\d]/g, '')
      }
    },
    gdNumBirthday () {
      if (this.input.birthday !== '') {
        this.input.birthday = replacePattern(this.input.birthday, /[^\d]/g, '')
      }
    },
    mobileNoCheck () {
      if (this.input.cellPhone.value !== '' && !/^\d{10,11}$/.test(this.input.cellPhone.value)) {
        let errorMsg = '입력하신 통신사 번호는 없는 번호입니다.'
        this.setInputError(this.input.cellPhone, errorMsg, this.$refs.cellPhone)
      } else {
        this.resetInputError(this.input.cellPhone)
      }
    },
    regCheckEmail () {
      return this.$refs.emailAuthentications ? this.$refs.emailAuthentications.regCheckEmail() : true
    },
    focusEmail () {
      this.$refs.emailAuthentications.focusEmailName()
    },
    mobileCheck (isCheckBtnClicked, isRegCheck) {
      return this.$refs.smsAuthentications ? this.$refs.smsAuthentications.mobileCheck(isCheckBtnClicked, isRegCheck) : false
    },
    searchAddress () {
      this.showAddLayer = true
      this.$store.commit('SHOW_LAYER_BG')
    },
    closeLayer (selected, address) {
      this.showAddLayer = false
      this.$store.commit('HIDDEN_LAYER_BG')
      if (selected) {
        this.callbackAddr(address)
      }
    },
    callbackAddr ({ zipCd, address, addressSub }) {
      this.input.zipCd = zipCd
      this.input.address = address
      this.input.addressSub = addressSub
    },
    change () {
      let checkPassed = true

      this.currentPwdCheck()
      this.newPwdCheck()
      this.confirmPwdCheck()

      let focused = false
      if (this.input.currentPwd.errorFlg) {
        checkPassed = false
        this.$refs.currentPwd.focus()
        if (isPC()) {
          $('body,html').scrollTop(150)
        }
        focused = true
      }

      if (this.input.newPwd.errorFlg) {
        checkPassed = false
        if (!focused) {
          focused = true
          this.$refs.newPwd.focus()
          if (isPC()) {
            $('body,html').scrollTop(160)
          }
        }
      }

      if (this.input.confirmPwd.errorFlg) {
        checkPassed = false
        if (!focused) {
          focused = true
          this.$refs.confirmPwd.focus()
          if (isPC()) {
            $('body,html').scrollTop(170)
          }
        }
      }

      if (this.input.memNameIllegal) {
        checkPassed = false
        if (!focused) {
          focused = true
          this.$refs.memberName.focus()
          if (isPC()) {
            $('body,html').scrollTop(180)
          }
        }
      }

      if (!this.regCheckEmail()) {
        checkPassed = false
        if (!focused) {
          focused = true
          this.$refs.emailAuthentications.focusEmailName()
          if (isPC()) {
            $('body,html').scrollTop(400)
          }
        }
      }

      if (!this.mobileCheck(false, true)) {
        checkPassed = false
        if (!focused) {
          focused = true
          this.$refs.smsAuthentications.focusMobile()
          if (isPC()) {
            $('body,html').scrollTop(500)
          }
        }
      }

      if (!checkPassed) {
        return false
      }

      this.$store.dispatch('authentication/checkPassword', this.input.currentPwd.value).then(res => {
        if (res.status === 204) {
          let changeParams = {
            'address': this.input.address,
            'birthday': this.input.birthday,
            'detailAddress': this.input.addressSub,
            'directMailAgreed': this.input.mallChecked,
            'email': this.getEmail,
            'smsAgreed': this.input.smsChecked,
            'sex': this.input.sex,
            'mobileNo': this.getMobileNum,
            'smsAuthKey': this.getSmsAuthKey,
            'zipCd': this.input.zipCd,
            'certificated': true,
            'refundBank': this.profileNonMasking.refundBank,
            'refundBankAccount': this.profileNonMasking.refundBankAccount,
            'refundBankDepositorName': this.profileNonMasking.refundBankDepositorName,
            'memberName': this.input.memberName,
            'currentPassword': this.input.currentPwd.value
          }
          if (this.input.prefixTelephoneNo === '' || this.input.telephoneNo === '') {
            changeParams.telephoneNo = ''
          }
          if (this.input.prefixTelephoneNo !== '' && this.input.telephoneNo !== '') {
            changeParams.telephoneNo = this.input.prefixTelephoneNo + this.input.telephoneNo
          }
          if (this.input.newPwd.value !== '') {
            changeParams.password = this.input.newPwd.value
          }

          if (this.bankAgreeCheck) {
            if (this.input.refundBank === 'default' || this.input.refundBankAccount === '' || this.input.refundBankDepositorName === '') {
              changeParams.refundBank = null
              changeParams.refundBankAccount = ''
              changeParams.refundBankDepositorName = ''
            } else {
              changeParams.refundBank = this.input.refundBank
              changeParams.refundBankAccount = this.input.refundBankAccount
              changeParams.refundBankDepositorName = this.input.refundBankDepositorName
            }
          }

          const params = {
            changeParams: changeParams
          }
          this.$store.dispatch('profile/change', params).then(() => {
            alert('회원정보 수정이 성공하였습니다.')
            this.$router.go(0)
          })
        }
      }).catch((e) => {
        if (e.data.code === 'M0019') {
          alert('입력된 정보가 현재 비밀번호와 일치하지 않습니다')
        }
        return false
      })
    },
    cancel () {
      window.location = '/'
    },
    setInputError (item, errorMsg, ref) {
      item.errorMsgTxt = errorMsg
      item.errorFlg = true
    },
    resetInputError (item) {
      item.errorMsgTxt = ''
      item.errorFlg = false
    },
    setPrefixTelNo (value) {
      this.input.prefixTelephoneNo = value
      if (value !== '') {
        this.resetInputError(this.input.telError)
      }
    },
    setSex (value) {
      this.input.sex = value
    },
    setBank (value) {
      this.input.refundBank = value
    },
    goWithDrawal () {
      this.$router.push('/mypage/member/withdrawal')
    },
    emailAuthen () {
      this.emailPopFlg = false
      this.$refs.emailAuthentications.reStartCountTime()
    },
    smsAuthen () {
      this.smsPopFlg = false
      this.$refs.smsAuthentications.reStartCountTime()
    },
    showEmailAuthenPop () {
      this.emailPopFlg = true
    },
    showSmsAuthenPop () {
      this.smsPopFlg = true
    },
    gdEngKor: function () {
      if (this.input.memberName !== '') {
        this.input.memberName = replacePattern(this.input.memberName, /\s+/g, '')
      }
    },
    memberNameCheck () {
      if (this.input.memberName === '') {
        this.input.memberNameTxt = '이름을 입력해 주세요.'
        this.input.memNameIllegal = true
      } else {
        let regx = /^[a-zA-Zㄱ-ㅎㅏ-ㅣ가-힣]+$/

        if (!regx.test(this.input.memberName)) {
          this.input.memberNameTxt = '이름은 띄어쓰기 없이 한글,영문으로 입력하셔야 합니다.'
          this.input.memNameIllegal = true
        } else {
          this.input.memNameIllegal = false
        }
      }
      return !this.input.memNameIllegal
    }
  }
}
</script>
<style scoped>
.btn_right_box {
  float: none;
  width: auto;
}
</style>
