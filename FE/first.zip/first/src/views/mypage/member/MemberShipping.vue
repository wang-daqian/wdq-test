<template>
  <div class="content">
    <div class="mypage_main">

      <!-- 마이페이지 회원 요약정보 -->
      <top-info></top-info>
      <!-- //mypage_top_info -->

      <div class="mypage_shipping js_delivery_layer">
        <div class="mypage_zone_tit">
          <h3>배송지 관리</h3>
          <span class="pick_list_num">배송지 관리 내역 총
            <strong v-if="addresses">{{showAddressList.length}}</strong>건
          </span>
        </div>

        <div class="mypage_shipping_cont">
          <div class="mypage_table_type">
            <table :class="(addresses && showAddressList.length == 0) ? 'no_result':'scroll_table'">
              <colgroup>
                <col style="width:12%">
                <!-- 배송지이름 -->
                <col style="width:12%">
                <!-- 받으실 분 -->
                <col>
                <!-- 주소 -->
                <col style="width:20%">
                <!-- 연락처 -->
                <col style="width:12%">
              </colgroup>
              <thead>
                <tr>
                  <th>배송지이름</th>
                  <th>받으실 분</th>
                  <th>주소</th>
                  <th>연락처</th>
                  <th>수정/삭제</th>
                </tr>
              </thead>
              <tbody>
                <template v-if="addresses && showAddressList.length > 0">
                  <Address v-for="address in showAddressList" :key="address.addressNo" :address="address" @goModify="goModify(address)" />
                </template>
                <template v-else>
                  <tr>
                    <td colspan="5">
                      <p class="no_data">배송지 목록이 없습니다.</p>
                    </td>
                  </tr>
                </template>
              </tbody>
            </table>

          </div>

        </div>
        <!-- //mypage_shipping_cont  -->
        <div class="pagination">
          <ul></ul>
        </div>
      </div>
      <!-- //mypage_shipping-->

    </div>
    <!-- //mypage_main -->
    <div id="lyDeliveryAdd" class="layer_wrap delivery_add_layer" v-if="showPopupFlg">
      <div id="delivery_add_wrap" class="layer_wrap_cont" :style="ly_style">
        <div class="ly_tit">
          <h4>
            <font style="vertical-align: inherit;">
              <font style="vertical-align: inherit;">나의 배송지 관리</font>
            </font>
          </h4>
        </div>
        <div class="ly_cont">
          <div class="scroll_box">
            <h5>
              <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">배송지 등록</font>
              </font>
            </h5>
            <div class="left_table_type">
              <table>
                <colgroup>
                  <col style="width:20%;">
                  <col style="width:80%;">
                </colgroup>
                <tbody>
                  <tr>
                    <th scope="row">
                      <span class="important">
                        <font style="vertical-align: inherit;">
                          <font style="vertical-align: inherit;">배송지 이름</font>
                        </font>
                      </span>
                    </th>
                    <td><input type="text" name="shippingTitle" value="" v-model="addressName" ref="addressName"></td>
                  </tr>
                  <tr>
                    <th scope="row">
                      <span class="important">
                        <font style="vertical-align: inherit;">
                          <font style="vertical-align: inherit;">받으실 분</font>
                        </font>
                      </span>
                    </th>
                    <td><input type="text" name="shippingName" maxlength="20" value="" v-model="receiverName" ref="receiverName"></td>
                  </tr>
                  <tr>
                    <th scope="row">
                      <span class="important">
                        <font style="vertical-align: inherit;">
                          <font style="vertical-align: inherit;">받으실 곳</font>
                        </font>
                      </span>
                    </th>
                    <td class="member_address">
                      <div class="address_postcode">
                        <input type="text" name="shippingZonecode" value="" readonly="readonly" v-model="receiverZipCd" ref="receiverZipCd">
                        <button type="button" class="btn_post_search" @click.prevent='searchAddress'>
                          <font style="vertical-align: inherit;">
                            <font style="vertical-align: inherit;">우편번호검색</font>
                          </font>
                        </button>
                      </div>
                      <div class="address_input">
                        <input type="text" name="shippingAddress" value="" readonly="readonly" v-model="receiverAddress">
                        <input type="text" name="shippingAddressSub" value="" v-model="receiverDetailAddress" ref="receiverDetailAddress" :style="{'margin-left':'5px'}">
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">
                      <span class="important">
                        <font style="vertical-align: inherit;">
                          <font style="vertical-align: inherit;">휴대전화</font>
                        </font>
                      </span>
                    </th>
                    <td>
                      <input type="text" id="shippingMobile" name="shippingCellPhone" value="" v-model="telephoneNo" ref="telephoneNo" maxlength="11" @keydown="gdNum" @input="gdNum" @blur="gdNum">
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">
                      <font style="vertical-align: inherit;">
                        <font style="vertical-align: inherit;">연락처</font>
                      </font>
                    </th>
                    <td>
                      <input type="text" id="shippingPhone" ref="cellphoneNo" value="" v-model="cellphoneNo" maxlength="12" @keydown="gdNumPhone" @input="gdNumPhone" @blur="gdNumPhone">
                    </td>
                  </tr>

                </tbody>
              </table>
            </div>
          </div>
          <!-- //scroll_box -->
          <div class="btn_center_box">
            <button type="button" class="btn_ly_cancel layer_close" @click.prevent="showPopup">
              <strong>
                <font style="vertical-align: inherit;">
                  <font style="vertical-align: inherit;">취소</font>
                </font>
              </strong>
            </button>
            <button type="submit" class="btn_ly_save" @click.prevent="shippingAddress">
              <strong>
                <font style="vertical-align: inherit;">
                  <font style="vertical-align: inherit;">저장</font>
                </font>
              </strong>
            </button>
          </div>
        </div>
        <!-- //ly_cont -->
        <a href="" class="ly_close layer_close" @click.prevent="showPopup"><img src="../../../assets/img/common/layer/btn_layer_close.png" alt="취소"></a>
      </div>
    </div>
    <address-info @closePop="closeLayer" v-if="showAddLayer" />
  </div>
  <!-- //content -->
</template>

<script>
import $ from 'jquery'
import { mapState } from 'vuex'

import Address from '@/components/mypage/member/Address'
import TopInfo from '@/components/mypage/topinfo/TopInfo'
import { replacePattern } from '@/utils/validateUtils'
import AddressInfo from '@/components/common/address/AddressInfo'

export default {
  name: 'MemberShipping',
  data () {
    return {
      showPopupFlg: false,
      addressNo: 0,
      addressName: '',
      receiverAddress: '',
      receiverDetailAddress: '',
      telephoneNo: '',
      cellphoneNo: '',
      receiverName: '',
      receiverZipCd: '',
      address: null,
      doubleClickFlag: false,
      receiverJibunAddress: '',
      ly_style: '',
      showAddLayer: false
    }
  },
  components: {
    'top-info': TopInfo,
    Address,
    AddressInfo
  },
  computed: {
    ...mapState('profile', ['addresses']),
    showAddressList () {
      if (this.addresses.recentAddresses && this.addresses.recentAddresses.length > 5) {
        return this.addresses.recentAddresses.slice(0, 5)
      }
      return this.addresses.recentAddresses
    }
  },
  methods: {
    showPopup () {
      this.showPopupFlg = !this.showPopupFlg
      if (!this.showPopupFlg) {
        this.addressNo = 0
        this.addressName = ''
        this.receiverAddress = ''
        this.receiverDetailAddress = ''
        this.receiverJibunAddress = ''
        this.telephoneNo = ''
        this.cellphoneNo = ''
        this.receiverName = ''
        this.receiverZipCd = ''
        this.address = null
        this.doubleClickFlag = false
      }
    },
    searchAddress () {
      this.showAddLayer = true
    },
    closeLayer (selected, address) {
      this.showAddLayer = false
      if (selected) {
        this.callbackAddr(address)
      }
    },
    callbackAddr ({ zipCd, address, addressSub, receiverJibunAddress }) {
      this.receiverZipCd = zipCd
      this.receiverAddress = address
      this.receiverDetailAddress = addressSub
      this.receiverJibunAddress = receiverJibunAddress
    },
    shippingAddress () {
      if (this.doubleClickFlag) {
        return false
      }
      if (this.addressName === '') {
        alert('배송지 이름을 입력하세요.')
        this.$refs.addressName.focus()
        return false
      }

      if (this.receiverName === '') {
        alert('받으실 분 이름을 입력하세요.')
        this.$refs.receiverName.focus()
        return false
      }

      if (this.receiverZipCd === '') {
        alert('우편번호를 입력하세요')
        this.$refs.receiverZipCd.focus()
        return false
      }

      if (this.telephoneNo === '' || this.telephoneNo === null || this.telephoneNo.length <= 0) {
        alert('휴대전화를 입력해주세요.')
        this.$refs.telephoneNo.focus()
        return false
      } else if (this.telephoneNo !== '' && !/^\d{11}$/.test(this.telephoneNo)) {
        alert('정확한 휴대전화를 입력해 주세요.')
        this.$refs.telephoneNo.focus()
        return false
      }

      if (this.cellphoneNo) {
        if (!/^\d{10,12}$/.test(this.cellphoneNo)) {
          alert('휴대폰번호를 입력하세요.')
          this.$refs.cellphoneNo.focus()
          return false
        }
      }

      const addressParams = {
        'addressName': this.addressName,
        'addressType': 'BOOK',
        'countryCd': 'KR',
        'customsIdNumber': '',
        'defaultYn': '',
        'receiverAddress': this.receiverAddress,
        'receiverContact1': this.telephoneNo,
        'receiverContact2': this.cellphoneNo,
        'receiverDetailAddress': this.receiverDetailAddress,
        'receiverJibunAddress': this.receiverJibunAddress,
        'receiverName': this.receiverName,
        'receiverZipCd': this.receiverZipCd
      }

      this.doubleClickFlag = true
      if (this.address) {
        const aParams = {
          addressNo: this.addressNo,
          addressParams: addressParams
        }
        this.$store.dispatch('profile/shippingAddressModify', aParams).then(() => {
          this.doubleClickFlag = false
          alert('등록이 완료 되었습니다.')
          this.$router.go(0)
        })
      } else {
        this.$store.dispatch('profile/shippingAddress', addressParams).then(() => {
          this.doubleClickFlag = false
          alert('등록이 완료 되었습니다.')
          this.$router.go(0)
        })
      }
    },
    goModify (address) {
      this.showPopupFlg = true
      this.address = address
      this.addressNo = address.addressNo
      this.addressName = address.addressName
      this.receiverAddress = address.receiverAddress
      this.receiverDetailAddress = address.receiverDetailAddress
      this.receiverJibunAddress = address.receiverJibunAddress
      this.telephoneNo = replacePattern(address.receiverContact1, /[^\d]/g, '')
      this.cellphoneNo = replacePattern(address.receiverContact2, /[^\d]/g, '')
      this.receiverName = address.receiverName
      this.receiverZipCd = address.receiverZipCd
    },
    gdNumPhone: function () {
      if (this.cellphoneNo !== '') {
        this.cellphoneNo = replacePattern(this.cellphoneNo, /[^\d]/g, '')
      }
    },
    gdNum: function () {
      if (this.telephoneNo !== '') {
        this.telephoneNo = replacePattern(this.telephoneNo, /[^\d]/g, '')
      }
    },
    modifyPopFlg () {
      if (this.showPopupFlg) {
        this.$store.commit('SHOW_LAYER_BG')
        this.$nextTick(() => {
          const top = ($(window).height() - $('#delivery_add_wrap').outerHeight()) / 2
          const left = ($(window).width() - $('#delivery_add_wrap').outerWidth()) / 2
          this.ly_style = `position: absolute; margin: 0px; top: ${top > 0 ? top : 0}px; left: ${left > 0 ? left : 0}px;`
        })
      } else {
        this.$store.commit('HIDDEN_LAYER_BG')
      }
    }
  },
  watch: {
    'showPopupFlg': 'modifyPopFlg'
  }
}
</script>
