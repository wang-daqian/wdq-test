<template>
  <div class="content">
    <div class="mypage_cont">
      <div class="my_page_password">
        <div class="mypage_zone_tit">
          <h3>회원정보 변경</h3>
        </div>
        <p>
          <strong>회원님의 정보를 안전하게 보호하기 위해 비밀번호를 다시 한번 확인해 주세요.</strong>
        </p>
        <form id="formFind">
          <div class="id_pw_cont">
            <dl>
              <dt>아이디</dt>
              <dd>
                <strong>{{showMemberId()}}</strong>
              </dd>
            </dl>
            <dl>
              <dt>비밀번호</dt>
              <dd>
                <div class="member_warning">
                  <input type="password" name="findPassword" id="findPassword" v-model='password'>
                  <div class="text_warning">
                    비밀번호가 일치하지 않습니다.
                  </div>
                </div>
              </dd>
            </dl>
          </div>
          <div class="btn_center_box">
            <a class="btn_pw_cancel js_btn_back" :style="{'margin-right':'5px'}" @click.prevent='goback'>
              <em>취소</em>
            </a>
            <button type="submit" class="btn_pw_certify" @click.prevent='checkPwd'>
              <em>확인</em>
            </button>
          </div>
        </form>
      </div>
      <!-- //my_page_password -->
    </div>
    <!-- //mypage_cont -->
  </div>
</template>

<script>
import { mapState } from 'vuex'
import cookies from 'js-cookie'

export default {
  name: 'MemberPwdCheck',
  data () {
    return {
      password: ''
    }
  },
  computed: {
    ...mapState('profile', ['profile'])
  },
  methods: {
    showMemberId () {
      return cookies.get('FstAppShowMemberID')
    },
    checkPwd () {
      if (this.password === '') {
        alert('비밀번호를 입력해주세요.')
        return
      }
      this.$store.dispatch('authentication/checkPassword', this.password).then(res => {
        if (res.status === 204) {
          this.$store.dispatch('profile/memberFetchNonMasking', this.password)
          this.$router.push('/mypage/member/memberchange')
        }
      }).catch((e) => {
        if (e.data.code === 'M0019') {
          alert('입력된 정보가 현재 비밀번호와 일치하지 않습니다')
        }
        return false
      })
    },
    goback () {
      this.$router.back()
    }
  }
}
</script>
