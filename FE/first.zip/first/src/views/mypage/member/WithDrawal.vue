<template>
  <div class="content">
    <div class="mypage_cont">
      <form>
        <input type="hidden" name="mode" value="hackOut">
        <input type="hidden" name="snsType" value="">
        <div class="hack_out">
          <div class="mypage_zone_tit">
              <h3>회원탈퇴</h3>
            </div>

            <div class="mypage_unregister">
                <div class="unregister_info">
                    <br> ■ 회원 탈퇴 전, 아래 사항을 확인해 주시기 바랍니다.
                    <br> 1. 회원 탈퇴 시 회원전용 서비스 이용이 불가능합니다.
                    <br> 2. 구매정보가 있는 경우, 회원님의 정보는 상품 반품 및 A/S를 위해 전자상거래 등에서의 소비자 보호에 관한 법률에 따라 계약 또는 청약철회에 관한 기록, 대금 결제 및 재화 등의 공급에 관한 기록은 5년 동안 보존됩니다.
                    <br> 3. 보유한 쿠폰과 적립금은 소멸되며 복구할 수 없습니다.
                    <br>
                    <br>
                    <br>회원 탈퇴 후 당사 사이트 이용 권한이 삭제되며, 작성하였던 1:1문의, 상품 후기와 같은 게시물 및 댓글은 삭제되지 않습니다. 회원정보 삭제로 인해 작성자 본인을 확인할 수 없으므로 게시물 편집 및 삭제 처리가 원천적으로 불가능합니다. 게시물 삭제를 원하시는 경우에는 게시물을 삭제하신 후, 탈퇴를 신청하시기 바랍니다.
                </div>
                <div class="form_element" style="margin-top:10px">
                  <label for="e-mail2" :class="['check_s', {'on':agreeCheck}]" @click="agreeCheck = !agreeCheck">회원탈퇴 시 처리사항 안내를 확인하였음에 동의합니다.</label>
                </div>
                <!-- //unregister_info -->
            </div>
            <!-- //mypage_unregister -->

        </div>
        <!-- //hack_out -->

        <div class="btn_center_box">
            <a href="#;" class="btn_claim_cancel btn_prev" @click.prevent='back' :style="{'margin-right':'5px'}">
                <em>취소</em>
            </a>
            <button type="submit" class="btn_claim_ok" @click.prevent='withdrawal'>
                <em>탈퇴</em>
            </button>
        </div>
        </form>
    </div>
    <!-- //mypage_cont -->

  </div>
</template>

<script>
import { logoutRemoveCookie } from '@/utils/utils'

export default {
  name: 'WithDrawal',
  metaInfo: {
    title: '회원 탈퇴'
  },
  data () {
    return {
      agreeCheck: false
    }
  },
  methods: {
    back () {
      this.$router.go(-1)
    },
    withdrawal () {
      if (!this.agreeCheck) {
        alert('안내사항 동의 후 탈퇴 신청이 가능합니다.')
        return
      }

      this.$store.dispatch('authentication/delOnlyFirstApperal', '').then(() => {
        this.writeOff()
      })
    },
    writeOff () {
      alert('탈퇴처리가 완료되었습니다. 그동안 이용해 주셔서 감사합니다.')
      logoutRemoveCookie()
      window.location.href = '/'
    }
  }
}
</script>

<style scope>
.hack_out .mypage_unregister .unregister_info{margin:0 0 0 0; padding:15px 15px 15px 15px; color:#717171; border:1px solid #dadada;}
.hack_out .mypage_unregister .mypage_zone_tit{margin:40px 0 0 0; padding:0 0 10px 0; font-size:14px; border-bottom:none 0;}
</style>
