<template>
  <div id="container">
    <div id="contents">
      <!-- 본문 시작 -->

      <div class="location_wrap">
        <div class="location_cont">
          <em v-if="naviText !=''">
            <a href="/" class="local_home">HOME</a> &gt; 마이페이지 &gt; {{naviText}}</em>
          <em v-else>
            <a href="/" class="local_home">HOME</a> &gt; 마이페이지</em>
        </div>
      </div>
      <!-- //location_wrap -->

      <div class="sub_content">

        <div class="side_cont">
          <span class="btn_side_mobile" @click="openMenu = !openMenu">마이페이지 메뉴보기</span>
          <div class="sub_menu_box" :style="{display:openMenu?'block':'none'}">
            <h2>마이페이지</h2>
            <ul class="sub_menu_mypage">
              <li>쇼핑정보
                <ul class="sub_depth1">
                  <li>
                    <router-link :class="{ active: startWith($route.path,'/mypage/orderlist') }" to='/mypage/orderlist' @click.native="hideMenuOnlyMO('orderlist')">- 주문/취소/반품 내역</router-link>
                  </li>
                  <!-- <li>
                    <router-link :class="{ active: startWith($route.path,'/mypage/cancellist') }" @click.native="hideMenuOnlyMO('cancellist')" to='/mypage/cancellist'>- 취소/반품 내역</router-link>
                  </li> -->
                  <!-- <li>
                    <a href="#">- 환불/입금 내역</a>
                  </li> -->
                  <li>
                    <router-link :class="{ active: startWith($route.path,'/mypage/wishlist') }" @click.native="hideMenuOnlyMO('wishlist')" to='/mypage/wishlist'>- 찜리스트</router-link>
                  </li>
                </ul>
              </li>
              <li>혜택관리
                <ul class="sub_depth1">
                  <li>
                    <router-link :class="{ active: startWith($route.path,'/mypage/coupon') }" @click.native="hideMenuOnlyMO('coupon')" to='/mypage/coupon'>- 쿠폰</router-link>
                  </li>
                  <li>
                    <router-link :class="{ active: startWith($route.path,'/mypage/mileagelist') }" @click.native="hideMenuOnlyMO('mileagelist')" to='/mypage/mileagelist'>- {{showAccumulationName}}</router-link>
                  </li>
                </ul>
              </li>
              <li>Q&amp;A
                <ul class="sub_depth1">
                  <li>
                    <router-link :class="{ active: startWith($route.path,'/mypage/profile') }" @click.native="hideMenuOnlyMO('profile')" to='/mypage/profile/inquiries'>- Q&amp;A</router-link>
                  </li>
                </ul>
              </li>
              <li>회원정보
                <ul class="sub_depth1">
                  <li>
                    <router-link :class="{ active: startWith($route.path,'/mypage/member/memberpwdcheck') }" @click.native="hideMenuOnlyMO('memberpwdcheck')" to='/mypage/member/memberpwdcheck'>- 회원정보 변경</router-link>
                  </li>
                  <li>
                    <router-link :class="{ active: startWith($route.path,'/mypage/member/withdrawal') }" @click.native="hideMenuOnlyMO('withdrawal')" to='/mypage/member/withdrawal'>- 회원 탈퇴</router-link>
                  </li>
                  <li>
                    <router-link :class="{ active: startWith($route.path,'/mypage/member/membershipping') }" @click.native="hideMenuOnlyMO('membershipping')" to='/mypage/member/membershipping'>- 배송지 관리</router-link>
                  </li>
                </ul>
              </li>
              <li>나의 상품문의
                <ul class="sub_depth1">
                  <li>
                    <router-link :class="{ active: startWith($route.path,'/mypage/product/inquiries') }" @click.native="hideMenuOnlyMO('inquiries')" to='/mypage/product/inquiries'>- 나의 상품문의</router-link>
                  </li>
                </ul>
              </li>
              <li>나의 상품후기
                <ul class="sub_depth1">
                  <li>
                    <router-link :class="{ active: startWith($route.path,'/mypage/product/reviews') }" @click.native="hideMenuOnlyMO('reviews')" to='/mypage/product/reviews'>- 나의 상품후기</router-link>
                  </li>
                </ul>
              </li>
            </ul>
          </div>
          <!-- //sub_menu_box -->
        </div>
        <!-- //side_cont -->
        <router-view></router-view>

      </div>
      <!-- //sub_content -->
    </div>
    <!-- //본문 끝 contents -->
  </div>
</template>

<script>
import { mapState } from 'vuex'
import { startWith } from '@/utils/utils'

export default {
  props: ['displayMode'],
  name: 'MyPage',
  data () {
    return {
      openMenu: this.displayMode === 'PC',
      naviText: ''
    }
  },
  computed: {
    ...mapState('common', ['malls']),
    showAccumulationName () {
      return this.malls && this.malls.accumulationConfig.accumulationName
    }
  },
  metaInfo: {
    bodyAttrs: {
      class: 'mypage'
    }
  },
  methods: {
    hideMenuOnlyMO (menu) {
      if (this.displayMode === 'MO') {
        this.openMenu = false
      }
      switch (menu) {
        case 'orderlist':
          this.naviText = '주문/취소/반품 내역'
          break
        case 'cancellist':
          this.naviText = '취소/반품 내역'
          break
        case 'wishlist':
          this.naviText = '찜리스트'
          break
        case 'coupon':
          this.naviText = '쿠폰'
          break
        case 'mileagelist':
          this.naviText = this.showAccumulationName
          break
        case 'profile':
          this.naviText = 'Q&A'
          break
        case 'memberpwdcheck':
          this.naviText = '회원정보 변경'
          break
        case 'withdrawal':
          this.naviText = '회원 탈퇴'
          break
        case 'membershipping':
          this.naviText = '배송지 관리'
          break
        case 'inquiries':
          this.naviText = '나의 상품문의'
          break
        case 'reviews':
          this.naviText = '나의 상품후기'
          break
        default:
          break
      }
    },
    startWith (src, str) {
      return startWith(src, str)
    }
  },
  components: {

  },
  watch: {
    displayMode () {
      this.openMenu = this.displayMode === 'PC'
    }
  }
}
</script>
