<template>
  <div class="content">
    <div class="board_zone_sec">
      <div class="board_zone_tit">
        <h2>상품문의</h2>
      </div>
      <div class="board_zone_cont">
        <form name="frmWrite">
          <div class="board_zone_write">
            <div class="board_write_box">
              <table class="board_write_table">
                <colgroup>
                  <col style="width:15%">
                  <col style="width:85%">
                </colgroup>
                <tbody>
                  <tr>
                    <th scope="row">문의유형</th>
                    <td>
                      <div class="category_select">
                        <vue-select-box :showValue="inquiryInput.type" :items="productInquiryTypes" @selected="setType" :width="seletBoxWidth" />
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">상품 선택</th>
                    <td>
                      <div class="board_goods_select">
                        <span class="js_selected_info_text" v-if="!selectedProduct" style="margin-left: 5px">선택된 상품이 없습니다.</span>
                        <a href="" title="찾아보기" class="btn_goods_select btn_open_layer" v-if="!this.inquiry" @click.prevent="showSearchPopup"> 상품 선택 </a>
                        <div id="selectGoodsBox" v-if="selectedProduct">
                          <div class="goods_select_item js_select_item">
                            <span class="select_item_img" style="margin-left: 5px">
                              <goods-view-link :product="selectedProduct" target="_blank">
                                <img :src="selectedProduct.imageUrl" height="80" width="80" alt="">
                              </goods-view-link>
                            </span>
                            <span class="select_item_info">
                              <em>
                                {{selectedProduct.productName}} {{selectedProduct.productManagementCd | dispManageCode}}
                              </em>
                              <strong>
                                {{ selectedProduct.salePrice | formatNumber }}
                              </strong>
                              <button type="button" class="btn_goods_item_del js_select_remove" @click.prevent="resetProdcut" v-if="!inquiry">
                                <img src="../../../assets/img/common/btn/btn_goods_del.png" alt="선택 상품 삭제">
                              </button>
                            </span>
                          </div>
                        </div>
                        <!-- //goods_select_item -->
                      </div>
                      <!-- //board_goods_select -->
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">내용</th>
                    <td class="write_editor">
                      <div class="form_element">
                        <input type="checkbox" id="secret1" name="isSecret" value="y" checked="" v-model="inquiryInput.secreted">
                        <label class="check_s on" for="secret1" style="margin-left: 5px">비밀글</label>
                      </div>
                      <textarea id="editor" name="contents" cols="" rows="10" style="width: 100%; display: block; margin-left: 5px" v-model="inquiryInput.content"></textarea>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
            <!-- //board_write_box -->

          </div>
          <!-- //board_zone_write -->

          <div class="btn_center_box">
            <button type="button" class="btn_before" onclick="javascript:history.back()">
              <strong>이전</strong>
            </button>
            <template v-if="!inquiry">
              <button type="submit" class="btn_write_ok" @click.prevent="postProductInquiry">
                <strong>저장</strong>
              </button>
            </template>
            <template v-else>
              <button type="submit" class="btn_write_ok" @click.prevent="modifyProductInquiry">
                <strong>저장</strong>
              </button>
            </template>
          </div>

        </form>
      </div>
      <!-- //board_zone_cont -->

    </div>
    <!-- //board_zone_sec -->

    <product-search v-if="searchFlag" @showSearchPopup="showSearchPopup" @productChecked="productChecked" />

  </div>
</template>

<script>
import { mapState, mapGetters } from 'vuex'
import VueSelectBox from '@/components/common/VueSelectBox'
import GoodsViewLink from '@/components/common/GoodsViewLink'
import ProductSearch from '@/components/mypage/product/ProductSearch'

export default {
  name: 'SignInInquiry',
  data () {
    return {
      inquiryInput: {
        type: 'PRODUCT',
        title: '',
        secreted: false,
        content: ''
      },
      searchFlag: false,
      selectedProduct: null,
      seletBoxWidth: '120px'
    }
  },
  watch: {
    product () {
      this.selectedProduct = {}
      this.selectedProduct.productNo = this.product.baseInfo.productNo
      this.selectedProduct.imageUrl = this.product.baseInfo.imageUrls[0]
      this.selectedProduct.productName = this.product.baseInfo.productName
      this.selectedProduct.productManagementCd = this.product.baseInfo.productManagementCd
      this.selectedProduct.salePrice = this.product.price.salePrice
    },
    inquiry () {
      this.inquiryInput.type = this.inquiry.type
      this.inquiryInput.title = this.inquiry.title
      this.inquiryInput.secreted = this.inquiry.secreted
      this.inquiryInput.content = this.inquiry.content
    }
  },
  computed: {
    ...mapGetters('common', ['productInquiryTypes']),
    ...mapState('profile', ['profile']),
    ...mapState('profileinquiry', ['inquiry']),
    ...mapState('product', ['product'])
  },
  components: {
    VueSelectBox,
    ProductSearch,
    GoodsViewLink
  },
  methods: {
    showSearchPopup () {
      if (this.inquiry) {
        return false
      }
      this.searchFlag = !this.searchFlag
      if (this.searchFlag) {
        this.$store.commit('SHOW_LAYER_BG')
      } else {
        this.$store.commit('HIDDEN_LAYER_BG')
      }
    },
    productChecked (product) {
      this.selectedProduct = product
    },
    resetProdcut () {
      this.selectedProduct = null
    },
    postProductInquiry () {
      if (!this.selectedProduct) {
        alert('선택된 상품이 없습니다.')
        return false
      }
      if (!this.inquiryInput.content) {
        alert('내용을 입력해 주세요.')
        return false
      }

      this.$store.dispatch('product/postProductInquiry', {
        productNo: this.selectedProduct.productNo,
        title: this.inquiryInput.title,
        content: this.inquiryInput.content,
        secreted: this.inquiryInput.secreted,
        type: this.inquiryInput.type
      }).then(() => {
        this.$router.push('/mypage/product/inquiries')
      })
    },
    modifyProductInquiry () {
      if (!this.selectedProduct) {
        alert('선택된 상품이 없습니다.')
        return false
      }
      if (!this.inquiryInput.content) {
        alert('내용을 입력해 주세요.')
        return false
      }

      this.$store.dispatch('product/putProductInquiry', {
        productNo: this.selectedProduct.productNo,
        inquiryNo: this.inquiry.inquiryNo,
        title: this.inquiryInput.title,
        content: this.inquiryInput.content,
        secreted: this.inquiryInput.secreted,
        type: this.inquiryInput.type
      }).then(() => {
        this.$router.push('/mypage/product/inquiries')
      })
    },
    setType (value) {
      this.inquiryInput.type = value
    }
  }
}
</script>
