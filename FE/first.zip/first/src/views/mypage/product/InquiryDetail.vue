<template>
  <div class="content" v-if="inquiry && profile">
    <div class="board_zone_sec">
      <div class="board_zone_tit">
        <h2>상품문의</h2>
      </div>
      <div class="board_zone_cont">
        <div class="board_zone_view">
          <div class="qa_goods_info" v-if="product">
            <span>
              <goods-view-link :product="inquiry" target="_blank">
                <img :src="product.baseInfo.imageUrls[0]" width="100" :alt="product.baseInfo.productName" :title="product.baseInfo.productName" class="middle">
              </goods-view-link>
            </span>
            <span class="goods_info_txt" style="margin-left: 10px">
              <goods-view-link :product="inquiry" target="_blank">
                <em class="name" style="display: block;">{{product.baseInfo.productName}} {{product.baseInfo.productManagementCd | dispManageCode}}</em>
              </goods-view-link>
              <em class="name" style="display: block;">
              </em>
            </span>
          </div>
          <em class="name" style="display: block;"></em>

          <div class="board_view_comment">
            <div :class="[{'view_comment': inquiry.answers && inquiry.answers > 0}, 'js_comment_area']">
              <div class="q_area">
                <p class="q_title">Q.</p>
                <p class="q_sub_title">
                  <span>문의유형 : {{inquiryType.label}}</span>
                  <span style="margin-left: 5px;">문의일시 : {{inquiry.registerYmdt | getStrYMDHM('.')}}</span>
                </p>
                <p class="q_txt content_pre">{{inquiry.content}}</p>
              </div>
              <div class="a_area" v-for="answer in inquiry.answers" :key="answer.inquiryNo">
                <p class="q_title">A.</p>
                <p class="q_sub_title">
                  <span>답변일시 : {{answer.registerYmdt | getStrYMDHM('.')}}</span>
                </p>
                <p class="q_txt content_pre">{{answer.content}}</p>
              </div>
            </div>
          </div>
        </div>
        <!-- //board_zone_view -->
        <div class="btn_right_box">
          <button type="button" class="btn_board_del" @click.prevent="delInquiry">
            <strong>삭제</strong>
          </button>
          <button type="button" class="btn_board_edit" @click.prevent="modifyInquiry">
            <strong>수정</strong>
          </button>
          <button type="button" class="btn_board_list" @click.prevent="goList">
            <strong>목록</strong>
          </button>
        </div>
      </div>
      <!-- //board_zone_cont -->
    </div>
  </div>
</template>

<script>
import GoodsViewLink from '@/components/common/GoodsViewLink'

import { mapState, mapActions, mapGetters } from 'vuex'
export default {
  name: 'ProductInquiryDetail',
  components: {
    GoodsViewLink
  },
  data () {
    return {}
  },
  computed: {
    ...mapGetters('common', ['productInquiryTypes']),
    ...mapState('profileinquiry', ['inquiry']),
    ...mapState('profile', ['profile']),
    ...mapState('product', ['product']),
    inquiryType () {
      let inquiryType = ''
      if (this.inquiry) {
        inquiryType = this.productInquiryTypes.find(inquiry => inquiry.value === this.inquiry.type)
      }
      return inquiryType
    }
  },
  methods: {
    ...mapActions('product', ['deleteProductInquiries']),
    delInquiry () {
      if (confirm('정말 삭제하시겠습니까?')) {
        this.deleteProductInquiries(this.inquiry.inquiryNo).then(() => {
          this.$router.push('/mypage/product/inquiries')
        })
      }
    },
    modifyInquiry () {
      if (this.inquiry.answers && this.inquiry.answers.length) {
        alert('문의 답변이 등록되어 해당 문의는 수정할 수 없습니다.')
        return false
      }
      let productNo = this.inquiry.productNo
      let inquiryNo = this.inquiry.inquiryNo
      this.$router.push(`/mypage/productInquirymodify/${productNo}/inquiries/${inquiryNo}`)
    },
    goList () {
      this.$router.push('/mypage/product/inquiries')
    }
  }
}
</script>

<style scoped>
.btn_right_box {
  float: right;
  width: auto !important;
}
</style>
