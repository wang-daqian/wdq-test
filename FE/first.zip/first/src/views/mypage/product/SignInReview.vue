<template>
  <div class="content">
    <div class="board_zone_sec">
      <div class="board_zone_tit">
        <h2>상품후기</h2>
      </div>
      <div class="board_zone_cont">
        <form name="frmWrite">
          <div class="board_zone_write">
            <div class="board_write_box">
              <table class="board_write_table">
                <colgroup>
                  <col style="width:15%">
                  <col style="width:85%">
                </colgroup>
                <tbody>
                  <tr>
                    <th scope="row">상품 선택</th>
                    <td>
                      <div class="board_goods_select">
                        <span class="js_selected_info_text" v-if="!selectedProduct">선택된 상품이 없습니다.</span>
                        <a href="" title="찾아보기" class="btn_goods_select btn_open_layer" v-if="this.pageType !== 'MODIFY'" @click.prevent="showSearchPopup"> 상품 선택 </a>
                        <div id="selectGoodsBox" v-if="selectedProduct">
                          <div class="goods_select_item js_select_item">
                            <span class="select_item_img">
                              <input type="hidden" name="goodsNo[]" value="<%=goodsNo%>">
                              <goods-view-link :product="selectedProduct" target="_blank">
                                <img :src="selectedProduct.imageUrl" height="80" width="80" alt="">
                              </goods-view-link>
                            </span>
                            <span class="select_item_info">
                              <em>
                                {{selectedProduct.productName}} {{selectedProduct.productManagementCd | dispManageCode}}{{selectedProduct.optionManagementCd | dispManageCode}}
                              </em>
                              <strong>
                                {{ selectedProduct.price.salePrice | formatNumber }}원
                              </strong>
                              <button v-if="this.pageType !== 'MODIFY'" type="button" class="btn_goods_item_del js_select_remove" @click.prevent="resetProdcut">
                                <img src="../../../assets/img/common/btn/btn_goods_del.png" alt="선택 상품 삭제">
                              </button>
                            </span>
                          </div>
                        </div>
                        <!-- //goods_select_item -->
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">평점</th>
                    <td>
                      <div class="form_element">
                        <ul class="rating_star_list">
                          <li>
                            <label for="rating5" class="choice_s" v-bind:class="{ on: reviewInput.rate === '5' }">
                              <span class="rating_star">
                                <span style="width:100%;">별5</span>
                              </span>
                            </label>
                            <input type="radio" name="goodsPt" value="5" id="rating5" v-model="reviewInput.rate">
                          </li>
                          <li>
                            <label for="rating4" class="choice_s" v-bind:class="{ on: reviewInput.rate === '4' }">
                              <span class="rating_star">
                                <span style="width:80%;">별4</span>
                              </span>
                            </label>
                            <input type="radio" name="goodsPt" value="4" id="rating4" v-model="reviewInput.rate">
                          </li>
                          <li>
                            <label for="rating3" class="choice_s" v-bind:class="{ on: reviewInput.rate === '3' }">
                              <span class="rating_star">
                                <span style="width:60%;">별3</span>
                              </span>
                            </label>
                            <input type="radio" name="goodsPt" value="3" id="rating3" v-model="reviewInput.rate">
                          </li>
                          <li>
                            <label for="rating2" class="choice_s" v-bind:class="{ on: reviewInput.rate === '2' }">
                              <span class="rating_star">
                                <span style="width:40%;">별2</span>
                              </span>
                            </label>
                            <input type="radio" name="goodsPt" value="2" id="rating2" v-model="reviewInput.rate">
                          </li>
                          <li>
                            <label for="rating1" class="choice_s" v-bind:class="{ on: reviewInput.rate === '1' }">
                              <span class="rating_star">
                                <span style="width:20%;">별1</span>
                              </span>
                            </label>
                            <input type="radio" name="goodsPt" value="1" id="rating1" v-model="reviewInput.rate">
                          </li>
                        </ul>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">내용</th>
                    <td class="write_editor">
                      <textarea id="editor" name="contents" cols="" rows="10" style="width: 100%; display: block;" v-model="reviewInput.content"></textarea>
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">사진</th>
                    <td id="uploadBox">
                      <div class="file_upload_sec" v-for="(url, index) in modifyDisFileName" :key="url" v-if="pageType === 'MODIFY' && modifyDisFileName.length > 0">
                        <div class="form_element">
                          <a :href="url" class="link_file_down">{{getImageName(url)}}</a>
                          <input type="checkbox" :id="`delFile${index}`" :value="index" name="delFile" v-model="modifyDelImages">
                          <label :for="`delFile${index}`" class="check_s">삭제</label>
                        </div>
                        <label :for="`attach1${index}`">
                          <input type="text" class="file_text" title="파일 첨부하기" readonly="readonly" :value="modifyFilepath[index]">
                        </label>
                        <div class="btn_upload_box">
                          <button type="button" class="btn_upload" title="찾아보기">
                            <em>찾아보기</em>
                          </button>
                          <input type="file" :id="`attach1${index}`" style="right: 80px;" class="file" title="찾아보기" @change.prevent="onFileChange(index, $event, 'imgModify')" accept="image/*">
                        </div>
                      </div>
                      <div class="file_upload_sec" v-for="(file, index) in filepath" :key="index">
                        <label :for="`attach2${index}`">
                          <input type="text" class="file_text" title="파일 첨부하기" readonly="readonly" :value="filepath[index]">
                        </label>
                        <div class="btn_upload_box _btn">
                          <button type="button" class="btn_upload" title="찾아보기">
                            <em>찾아보기</em>
                          </button>
                          <input type="file" :id="`attach2${index}`" class="file1" title="찾아보기" @change.prevent="onFileChange(index, $event, 'imgAdd')" accept="image/*">
                          <span class="btn_gray_list" @click.prevent="minusFile(index)">
                            <button type="button" id="delUploadBtn" class="btn_gray_big">
                              <span>- 삭제</span>
                            </button>
                          </span>
                          <span class="btn_gray_list" v-if="index === 0" @click.prevent="plusFile()">
                            <button type="button" id="addUploadBtn" class="btn_gray_big">
                              <span>+ 추가</span>
                            </button>
                          </span>
                        </div>
                      </div>
                      <span>사진은 최대 10장까지 등록 가능합니다.</span>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
            <!-- //board_write_box -->

          </div>
          <!-- //board_zone_write -->

          <div class="btn_center_box">
            <button type="button" class="btn_before" @click="goBack">
              <strong>이전</strong>
            </button>
            <button type="submit" class="btn_write_ok" @click.prevent="postProductReview">
              <strong>저장</strong>
            </button>
          </div>

        </form>
      </div>
      <!-- //board_zone_cont -->

    </div>
    <!-- //board_zone_sec -->

    <review-products v-if="searchFlag" @showSearchPopup="showSearchPopup" @productChecked="productChecked" :reviewProducts="reviewProducts" :reviewProductstotalCount="reviewProductstotalCount" />

  </div>
</template>

<script>
import { mapState } from 'vuex'
import GoodsViewLink from '@/components/common/GoodsViewLink'
import ReviewProducts from '@/components/mypage/product/ReviewProducts'

export default {
  name: 'SignInReview',
  data () {
    return {
      reviewInput: {
        rate: '',
        content: ''
      },
      searchFlag: false,
      selectedProduct: null,
      filepath: [''],
      images: [],
      modifyDisFileName: [],
      modifyFilepath: [],
      modifyImages: [],
      modifyDelImages: [],
      pageType: 'REGISTE'
    }
  },
  watch: {
    review () {
      if (this.review) {
        this.pageType = 'MODIFY'
        this.reviewInput.rate = String(this.review.rate)
        this.reviewInput.content = this.review.content
        this.review.fileUrls.forEach(i => {
          let fileItem = {}
          fileItem.filedata = i
          this.modifyImages.push(fileItem)
          this.modifyDisFileName.push(fileItem.filedata)
          this.modifyFilepath.push('')
        })
        if (this.selectedProduct === null) {
          this.selectedProduct = {
            price: {
              salePrice: null
            }
          }
        }
        this.selectedProduct.productNo = this.review.productNo
        this.selectedProduct.orderOptionNo = this.review.orderedOption.orderOptionNo
        this.selectedProduct.optionNo = this.review.optionNo
        this.selectedProduct.imageUrl = this.review.imageUrl
        this.selectedProduct.productName = this.review.productName
      }
    },
    productInfo () {
      if (this.productInfo) {
        if (this.selectedProduct === null) {
          this.selectedProduct = {
            price: {
              salePrice: null
            }
          }
        }
        this.selectedProduct.price.salePrice = this.productInfo.price.salePrice
        this.selectedProduct.productManagementCd = this.productInfo.baseInfo.productManagementCd
      }
    }
  },
  computed: {
    ...mapState('profile', ['profile']),
    ...mapState('profilereview', ['reviewProducts', 'reviewProductstotalCount', 'review', 'product']),
    productInfo () {
      return this.$store.state.product.product
    }
  },
  components: {
    ReviewProducts,
    GoodsViewLink
  },
  mounted () {
    if (this.$route.query.productNo) {
      this.$store.dispatch('profilereview/fetchProduct', this.$route.query.productNo).then(() => {
        // let product = this.$store.state.profilereview.product
        this.selectedProduct = {}
        this.selectedProduct.orderOptionNo = this.$route.query.orderOptionNo
        if (this.product) {
          this.selectedProduct.productNo = this.product.baseInfo.productNo
          this.selectedProduct.optionNo = this.$route.query.optionNo
          this.selectedProduct.imageUrl = this.product.baseInfo.imageUrls[0]
          this.selectedProduct.productName = this.product.baseInfo.productName
          this.selectedProduct.optionManagementCd = this.product.baseInfo.productManagementCd
          this.selectedProduct.price = this.product.price
        }
        this.pageType = 'FROMURL'
      })
    }
  },
  methods: {
    goBack () {
      this.$router.push('/mypage/product/reviews')
    },
    showSearchPopup () {
      if (this.pageType === 'MODIFY') {
        return false
      }
      if (this.reviewProducts && this.reviewProducts.length > 0) {
        this.searchFlag = !this.searchFlag
        if (this.searchFlag) {
          this.$store.commit('SHOW_LAYER_BG')
        } else {
          this.$store.commit('HIDDEN_LAYER_BG')
        }
      } else {
        alert('상품후기를 작성할 수 있는 구매하신 상품이 없습니다.')
        return false
      }
    },
    productChecked (product) {
      this.selectedProduct = product
    },
    resetProdcut () {
      if (this.pageType === 'MODIFY') {
        return false
      }
      this.selectedProduct = null
    },
    onFileChange (index, e, type) {
      var files = e.target.files || e.dataTransfer.files
      if (!files.length) {
        return
      }
      if ((files.length + this.images.length) > 10) {
        alert('상품후기 첨부파일은 10개까지 등록 가능합니다.')
        return
      }
      this.createImage(files, index, type)
      e.target.value = ''
    },
    createImage (files, index, type) {
      if (typeof FileReader === 'undefined') {
        alert('브라우저가 이미지 업로드를 지원하지 않습니다. 브라우저를 업그레이드 해주세요.')
        return false
      }

      const leng = files.length
      for (let i = 0; i < leng; i++) {
        if (files[i].size > 1048576) { // 1MB
          alert('각 사진은 최대 1MB까지 등록가능합니다.')
          return false
        }

        if (files[i].type.split('image').length === 1) {
          alert('이미지파일(jpg, jpeg, gif, png, bmp)만 등록해주세요.')
          return false
        }
      }

      if (leng + this.images.length > 10) {
        alert('첨부파일은 10개까지만 등록 가능합니다.')
        return false
      }

      var pathStr = []
      const that = this
      for (let i = 0; i < leng; i++) {
        const fileitem = {}
        fileitem.file = files[i]
        pathStr.push(files[i].name)
        that.name = files[i].name
        const reader = new FileReader()
        reader.readAsDataURL(files[i])
        reader.onload = function (e) {
          var image = new Image()
          image.src = e.target.result
          image.onload = function () {
            fileitem.filedata = e.target.result
            if (this.width > 500 || this.height > 500) {
              var canvas = document.createElement('canvas')
              // canvas default
              canvas.width = 500
              canvas.height = 500
              // image
              let size = that.getSize(this.width, this.height)

              let ctx = canvas.getContext('2d')
              ctx.fillStyle = '#ffffff'
              ctx.fillRect(0, 0, 500, 500)
              ctx.drawImage(this, size.wd, size.hd, size.w, size.h)
              let base64 = canvas.toDataURL('image/jpeg')
              fileitem.file = that.dataURLtoFile(base64, that.name)
              fileitem.filedata = base64
            }
            if (type === 'imgAdd') {
              that.images.splice(index, 1, fileitem)
            } else if (type === 'imgModify') {
              that.modifyImages.splice(index, 1, fileitem)
            }
          }
        }
      }
      if (type === 'imgAdd') {
        this.filepath.splice(index, 1, pathStr.join(';'))
      } else if (type === 'imgModify') {
        this.modifyFilepath.splice(index, 1, pathStr.join(';'))
      }
    },
    getSize (width, height) {
      let size = {
        w: width,
        h: height,
        wd: 0,
        hd: 0
      }

      if (width > 500 && width === height) {
        size.w = 500
        size.h = 500
        return size
      }
      if (width > 500 && width > height) {
        let diff = width - 500
        size.w = 500
        size.h = height - height * (diff / width)
        size.hd = width === height ? 0 : (500 - size.h) / 2
        return size
      }
      if (height > 500 && width < height) {
        let diff = height - 500
        size.h = 500
        size.w = width - width * (diff / height)
        size.wd = (500 - size.w) / 2
        return size
      }
    },
    dataURLtoFile (dataurl, filename) {
      let arr = dataurl.split(',')
      let mime = arr[0].match(/:(.*?);/)[1]
      let bstr = atob(arr[1])
      let n = bstr.length
      let u8arr = new Uint8Array(n)
      while (n--) {
        u8arr[n] = bstr.charCodeAt(n)
      }
      return new File([u8arr], filename, { type: mime })
    },
    plusFile () {
      if (this.modifyFilepath.length + this.filepath.length < 10) {
        this.filepath.push('')
      } else {
        alert('상품후기 사진은 10개까지 등록 가능합니다.')
      }
    },
    minusFile (index) {
      if (index === 0) {
        this.filepath.splice(index, 1, '')
      } else {
        this.filepath.splice(index, 1)
      }
      this.images.splice(index, 1)
    },
    postProductReview () {
      if (!this.selectedProduct) {
        alert('상품을 선택해 주세요.')
        return false
      }

      if (this.reviewInput.rate === '') {
        alert('평점을 선택해 주세요.')
        return false
      }

      if (this.reviewInput.content.trim() === '') {
        alert('내용을 입력해 주세요.')
        return false
      }

      const paramsReview = {
        productNo: this.selectedProduct.productNo,
        optionNo: this.selectedProduct.optionNo,
        orderOptionNo: this.selectedProduct.orderOptionNo,
        rate: this.reviewInput.rate,
        content: this.reviewInput.content
      }
      if (this.pageType === 'MODIFY') {
        this.modifyDelImages.forEach(i => {
          if (this.modifyFilepath[i] === '') {
            this.modifyImages.splice(i, 1, null)
          }
        })
        this.modifyImages.forEach(file => {
          if (file !== null) {
            this.images.push(file)
          }
        })
      }

      const dispatch = this.$store.dispatch
      Promise.all(this.images.map(image => {
        if (image.file !== undefined) { // 이미 등록된 URL이 아니면
          const data = new FormData()
          data.append('file', image.file)
          return dispatch('common/uploadImages', data)
        }
      })).then(ret => {
        const urls = ret.filter(res => res !== undefined).map(res => res.data.imageUrl).concat(this.images.filter(i => i.file === undefined).map(i => i.filedata))
        paramsReview.urls = urls
        if (this.pageType === 'MODIFY') {
          paramsReview.reviewNo = this.review.reviewNo
          dispatch('profilereview/putProductReview', paramsReview).then(() => {
            alert('상품후기 작성이 완료되었습니다.')
            this.$router.push('/mypage/product/reviews')
          })
        } else if (this.pageType === 'REGISTE') {
          dispatch('profilereview/postProductReview', paramsReview).then(() => {
            alert('상품후기 작성이 완료되었습니다.')
            this.$router.push('/mypage/product/reviews')
          })
        } else if (this.pageType === 'FROMURL') {
          dispatch('profilereview/postProductReview', paramsReview).then(() => {
            alert('상품후기 작성이 완료되었습니다.')
            location.href = this.$route.query.nextUrl
          })
        }
      })
    },
    getImageName (url) {
      return url.substring(url.lastIndexOf('/') + 1, url.length)
    }
  }
}
</script>

<style scoped>
._btn {
  width: 200px;
}
.file_upload_sec .btn_upload_box .file1 {
  position: absolute;
  top: 0;
  right: 130px;
  height: 31px;
  cursor: pointer;
  opacity: 0;
  filter: alpha(opacity=0);
  -ms-filter: 'alpha(opacity=0)';
  -khtml-opacity: 0;
  -moz-opacity: 0;
}
</style>
