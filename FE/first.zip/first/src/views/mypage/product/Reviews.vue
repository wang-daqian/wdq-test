<template>
  <div class="content">
    <div class="board_zone_sec">
      <div class="board_zone_tit">
        <h3>상품후기</h3>
      </div>

      <div class="board_zone_cont">
        <div class="mypage_table_type">
          <table :class="reviews && reviews.length == 0 ? 'no_result' : 'scroll_table goods_table'">
            <colgroup>
              <col style="width:40%">
              <col style="width:10%">
              <col style="width:30%">
              <col style="width:20%">
            </colgroup>
            <thead>
              <tr>
                <th>상품</th>
                <th>평점</th>
                <th>후기내용</th>
                <th>작성일시</th>
              </tr>
            </thead>
            <tbody>
              <template v-if="reviews && reviews.length > 0">
                <review-item v-for="review in reviews" :key="review.reviewNo" :review="review" />
              </template>
              <template v-else>
              <tr>
                <td colspan="4" align="center">작성된 상품후기가 없습니다.</td>
              </tr>
              </template>
            </tbody>
          </table>
          <div class="pagination" v-if="reviews && reviews.length < totalCount">
            <p class="pagination-btn">
              <button type="button" class="btn_more" @click.prevent="fetchMore">더보기</button>
            </p>
          </div>
        </div>
        <!-- //board_zone_list -->
      </div>
      <!-- //board_zone_cont -->
      <div class="board_zone_cont">
        <!-- //board_zone_list -->
        <div class="btn_right_box">
          <button type="button" class="btn_write" @click.prevent="goPostReview">
            <strong>상품후기 쓰기</strong>
          </button>
        </div>
      </div>
      <!-- //board_zone_cont -->
    </div>
    <!-- //board_zone_sec -->
  </div>
</template>

<script>
import { mapState } from 'vuex'

import ReviewItem from '@/components/mypage/product/ReviewItem'

export default {
  name: 'ProductReviews',
  computed: {
    ...mapState('profilereview', [ 'reviews', 'totalCount' ]),
    ...mapState('profile', [ 'profile' ])
  },
  components: {
    'review-item': ReviewItem
  },
  methods: {
    goPostReview () {
      this.$router.push('/mypage/product/signinreview')
    },
    fetchMore () {
      this.$store.dispatch('profilereview/getProductReviewsMore')
    }
  }
}
</script>
