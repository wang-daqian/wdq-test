<template>
  <div class="content">
    <div class="board_zone_sec" v-if="review && product">
      <div class="board_zone_tit">
        <h2>상품후기</h2>
      </div>
      <div class="board_zone_cont">
        <div class="board_zone_list">
          <div class="board_list_gallery goods_qa_detail">
            <ul>
              <li>
                <div class="gallery_cont">
                  <div class="board_img goods_qa_img">
                    <goods-view-link :product="review">
                      <img :src="review.imageUrl" width="160" class="js_image_load" />
                    </goods-view-link>
                    <span>{{product.baseInfo.productName}} {{product.baseInfo.productManagementCd | dispManageCode}}</span>
                  </div>
                  <div class="gallery_info_cont">
                    <div class="rating_star_box detail">
                      <p>평점: </p>
                      <span class="rating_star">
                        <span :style="`width:${getDisRate}%;`">별 다섯개중 다섯개</span>
                      </span>
                      <p class="create_time">작성일시: </p>
                      <p class="">{{review.registerYmdt | getStrYMDHM('.')}}</p>
                    </div>
                    <ul class="ss_list">
                      <li v-for="(url,index) in review.fileUrls" :key="index"><a href="#" @click.prevent="showLayer(index)"><img :src="url" class="js_image_load"  /></a></li>
                    </ul>
                    <p class="content_pre">{{review.content}}</p>
                    <p class="recommend" v-if="review.recommendCnt > 0">{{review.recommendCnt}}명이 추천했습니다.</p>
                  </div>
                  <!-- //gallery_info_cont -->
                </div>
                <!-- //gallery_cont -->
              </li>
            </ul>
          </div>
          <!-- //board_list_gallery -->

          <div class="board_btn">
            <button class="btn_qa_detail" @click.prevent="goDel">
              <em>삭제</em>
            </button>
            <button class="btn_qa_detail" @click.prevent="goModify">
              <em>수정</em>
            </button>
            <button class="btn_qa_detail" @click.prevent="goList">
              <em>목록</em>
            </button>
          </div>
          <!-- //board_search_box -->

        </div>
        <!-- //board_zone_list -->
      </div>
      <template v-if="isPC">
        <item-photo-layer @close="closeLayer" :imageUrls="review.fileUrls" :openLayer="openLayer" :imgStartIndex="imgStartIndex" :product="product"/>
      </template>
      <template v-else>
        <ItemPhotoLayerSP @close="closeLayer" :imageUrls="review.fileUrls" :openLayer="openLayer" :imgStartIndex="imgStartIndex" />
      </template>
    </div>
    <!-- //board_zone_sec -->
  </div>
</template>

<script>
import { mapState } from 'vuex'
import { isPC } from '@/utils/utils'
import ItemPhotoLayer from '@/components/mypage/product/ItemPhotoLayer'
import ItemPhotoLayerSP from '@/components/mypage/product/ItemPhotoLayerSP'
import GoodsViewLink from '@/components/common/GoodsViewLink'

export default {
  name: 'ProductReviewDetail',
  data () {
    return {
      openLayer: false,
      imgStartIndex: 0
    }
  },
  computed: {
    ...mapState('profilereview', ['review']),
    ...mapState('profile', ['profile']),
    ...mapState('product', ['product']),
    getDisRate () {
      return 100 * (this.review.rate / 5)
    },
    isPC () {
      return isPC()
    }
  },
  components: {
    ItemPhotoLayer,
    ItemPhotoLayerSP,
    GoodsViewLink
  },
  methods: {
    showLayer (idx) {
      this.openLayer = true
      this.imgStartIndex = idx
      this.$store.commit('SHOW_LAYER_BG')
    },
    closeLayer () {
      this.openLayer = false
      this.$store.commit('HIDDEN_LAYER_BG')
    },
    goList () {
      this.$router.push('/mypage/product/reviews')
    },
    goDel () {
      if (confirm('정말 삭제하시겠습니까?')) {
        let params = {
          productNo: this.review.productNo,
          reviewNo: this.review.reviewNo
        }
        this.$store.dispatch('profilereview/delProductReview', params).then(() => {
          this.$router.push('/mypage/product/reviews')
        })
      }
    },
    goModify () {
      let productNo = this.review.productNo
      let reviewNo = this.review.reviewNo
      this.$router.push(`/mypage/productmodifyreview/${productNo}/product-reviews/${reviewNo}`)
    }
  }
}
</script>

<style scoped>
.btn_right_box {
  float: right;
  width: auto !important;
}
</style>
