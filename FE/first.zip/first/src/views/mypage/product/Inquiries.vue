<template>
  <!-- //side_cont -->
  <div class="content">
    <div class="board_zone_sec">
      <div class="board_zone_tit">
        <h3>상품문의</h3>
      </div>
      <div class="board_zone_cont">
        <div class="board_zone_list">
          <date-picker :type="listType" ref="dataPicker"></date-picker>
          <div class="mypage_table_type" align="center">
            <table :class="productInquiries && productInquiries.length == 0 ? 'no_result' : 'board_list_table scroll_table goods_table allShow'" style="width:100%">
              <colgroup>
                <col style="width:10%">
                <col style="width:35%">
                <col style="width:30%">
                <col style="width:15%">
                <col style="width:10%">
              </colgroup>
              <thead>
                <tr>
                  <th>문의유형</th>
                  <th>상품</th>
                  <th>문의내용</th>
                  <th>문의일시</th>
                  <th>문의상태</th>
                </tr>
              </thead>
              <tbody>
                <template v-if="productInquiries && productInquiries.length > 0">
                  <inquiry-item v-for="inquiry in productInquiries" :key="inquiry.inquiryNo" :inquiry="inquiry" :productInquiryTypes="productInquiryTypes" />
                </template>
                <template v-else>
                  <tr>
                    <td colspan="5" align="center">작성된 상품문의가 없습니다.</td>
                  </tr>
                </template>
              </tbody>
            </table>
          </div>
          <!-- //board_list_qa -->
          <div class="pagination" v-if="productInquiries && productInquiries.length < productInquirytotalCount">
            <p class="pagination-btn">
              <button type="button" class="btn_more" @click.prevent="fetchMore">더보기</button>
            </p>
          </div>
          <!-- //pagination -->
        </div>
        <!-- //board_zone_list -->
        <div class="btn_right_box ">
          <button type="button " class="btn_write" @click.prevent="goSigninInquiry">
            <strong>상품 문의하기</strong>
          </button>
        </div>
      </div>
      <!-- //board_zone_cont -->
    </div>
    <!-- //board_zone_sec -->
    <div id="layerDim " class="dn ">&nbsp;</div>
  </div>
</template>

<script>
import { mapState, mapActions, mapGetters } from 'vuex'
import myDatepicker from '@/components/mypage/viewperiod/DatePicker'
import InquiryItem from '@/components/mypage/product/InquiryItem'

export default {
  name: 'ProductInquiries',
  data () {
    return {
      listType: 'product'
    }
  },
  computed: {
    ...mapGetters('common', ['productInquiryTypes']),
    ...mapState('profileinquiry', ['productInquiries', 'productInquirytotalCount'])
  },
  components: {
    'inquiry-item': InquiryItem,
    'date-picker': myDatepicker
  },
  methods: {
    ...mapActions('profileinquiry', ['fetchAllInquiriesMore']),
    fetchMore () {
      this.fetchAllInquiriesMore()
    },
    goSigninInquiry () {
      this.$router.push('/mypage/product/signininquiry')
    }
  },
  beforeRouteLeave (to, from, next) {
    this.$refs.dataPicker.initPeriodParam()
    next()
  }
}
</script>
