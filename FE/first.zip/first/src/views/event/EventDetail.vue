<template>
  <div id="container">
    <div id="contents">
      <div class="event" v-if="event">
        <!--상단(기획전 명, 다른 기획전 셀렉터)-->
        <EventTopic></EventTopic>
        <template v-if="displayMode === 'PC' && event.top && event.top.pc.url">
          <div class="area_event_banner1" v-if="event.top.pc.type === 'HTML'" v-html="event.top.pc.url">
          </div>
          <div class="area_event_banner1" v-else>
            <img :src="event.top.pc.url" alt="">
          </div>
        </template>
        <template v-if="displayMode === 'MO' && event.top && event.top.mobile.url">
          <div class="area_event_banner1" v-if="event.top.mobile.type === 'HTML'" v-html="event.top.mobile.url">
          </div>
          <div class="area_event_banner1" v-else>
            <img :src="event.top.mobile.url" alt="">
          </div>
        </template>
        <EventSpMenu></EventSpMenu>
        <!--쿠폰-->
        <EventCoupon></EventCoupon>
        <!--상품섹션-->
        <EventProduct></EventProduct>
      </div>
    </div>
  </div>
</template>

<script>
import { mapState } from 'vuex'
import EventTopic from '@/components/event/EventTopic'
import EventCoupon from '@/components/event/EventCoupon'
import EventProduct from '@/components/event/EventProduct'
import EventSpMenu from '@/components/event/EventSpMenu'

export default {
  props: ['displayMode'],
  name: 'EventDetail',
  components: {
    EventTopic,
    EventCoupon,
    EventProduct,
    EventSpMenu
  },
  computed: {
    ...mapState('event', ['event'])
  }
}
</script>

<style scope>
.area_event_banner1 img {
  display: block;
  max-width: 100%;
  max-height: 100%;
  margin: 0 auto;
}
</style>
