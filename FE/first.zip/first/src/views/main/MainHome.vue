<template>
  <div id="container">
    <div id="contents">
      <div id="main_home" class="sub_content sub_content_bnr">
        <main-slider :banners="mainTopBanners" v-if="mainTopBanners" />
        <main-best :displayMode="displayMode" :bestList="bestList" v-if="bestList && bestList.length" />
        <main-new-arrivals :displayMode="displayMode" :newArrivalsList="newArrivalsList" v-if="newArrivalsList && newArrivalsList.length" />
        <main-goods-banner :banner1="mainMiddle1" :banner2="mainMiddle2[0]" :banner3="mainMiddle3[0]" v-if="mainMiddle1 && mainMiddle2[0] && mainMiddle3[0]" />
        <main-best-banner :banner="mainBottom && mainBottom[0]" v-if="mainBottom && mainBottom[0]" />
        <main-recommend :products="recommendItems" v-if="recommendItems" />
      </div>
    </div>
    <main-layer-popup :displayMode="displayMode" :popupInfo="mainPopupInfo" v-if="popShowFlg && popShow && mainPopupInfo" @closePop="popShow = false" />
  </div>
</template>

<script>
import { mapState, mapGetters } from 'vuex'
import MainSlider from '@/components/main/MainSlider'
import MainBest from '@/components/main/MainBest'
import MainNewArrivals from '@/components/main/MainNewArrivals'
import MainGoodsBanner from '@/components/main/MainGoodsBanner'
import MainBestBanner from '@/components/main/MainBestBanner'
import MainRecommend from '@/components/main/MainRecommend'
import MainLayerPopup from '@/components/main/MainLayerPopup'
import { getToday } from '@/utils/dateUtils'
import $ from 'jquery'
import cookies from 'js-cookie'
export default {
  name: 'mainHome',
  metaInfo: {
    title: 'Home'
  },
  props: ['displayMode'],
  data () {
    return {
      popShow: true
    }
  },
  components: {
    MainSlider,
    MainBest,
    MainNewArrivals,
    MainGoodsBanner,
    MainBestBanner,
    MainRecommend,
    MainLayerPopup
  },
  computed: {
    ...mapState('display', ['mainMiddle1', 'mainMiddle2', 'mainMiddle3', 'mainBottom']),
    ...mapGetters('display', ['mainTopBanners', 'recommendItems', 'bestList', 'newArrivalsList', 'mainPopupInfo']),
    ...mapGetters('category', ['mainBestCategory']),
    popShowFlg () {
      if (cookies.get('firstMallMainPop')) {
        return cookies.get('firstMallMainPop') !== getToday()
      }
      return true
    }
  },
  beforeDestroy () {
    $('#container').css({ height: 'auto' })
  }
}
</script>

<style lang="scss">
#contents #main_home {
  width: 100%;
  margin: 0;
  padding: 0;
}

@media all and (max-width: 1024px) {
  #contents #main_home {
    margin-top: 88px;
  }
}
</style>
