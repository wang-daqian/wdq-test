import Vue from 'vue'

const filters = {
  tagReplace (val, target, src) {
    const reg = new RegExp(src, 'ig')
    return val.replace(reg, target)
  },
  reviewrate (rate) {
    return (rate / 5 * 100) + '%'
  },
  maskId (str) {
    if (str.length > 3) {
      return str.substring(0, 3) + Array(str.length - 3).fill('*').join('')
    }
  },
  getStrYMDHM (date, separator) {
    date = new Date(date.replace(/-/g, '/'))
    if (date.constructor !== Date) {
      return ''
    }

    let month = date.getMonth() + 1
    let day = date.getDate()
    let hours = date.getHours()
    let minutes = date.getMinutes()

    if (month < 10) {
      month = '0' + month
    }
    if (day < 10) {
      day = '0' + day
    }
    if (hours < 10) {
      hours = '0' + hours
    }
    if (minutes < 10) {
      minutes = '0' + minutes
    }

    if (separator === null || separator === undefined) {
      separator = '-'
    }
    const reDate = date.getFullYear() + separator + month + separator + day + ' ' + hours + ':' + minutes

    return reDate
  },
  getStrDate (date, separator) {
    if (date) {
      if (date.constructor !== Date) {
        date = new Date(date.replace(/-/g, '/'))
      }
      if (date.constructor !== Date) {
        return ''
      }
      let month = date.getMonth() + 1
      let day = date.getDate()

      if (month < 10) {
        month = '0' + month
      }
      if (day < 10) {
        day = '0' + day
      }
      if (separator === null || separator === undefined) {
        separator = '-'
      }
      const reDate = date.getFullYear() + separator + month + separator + day
      return reDate
    } else {
      return ''
    }
  },
  formatNumber (num) {
    if (num) {
      let number = num.toString()

      if (number === '' || isNaN(number)) {
        return num
      }

      if (number.indexOf('-') > 0) {
        return num
      }

      let sign = number.indexOf('-') === 0 ? '-' : ''
      if (sign === '-') {
        number = number.substr(1)
      }

      let cents = number.indexOf('.') > 0 ? number.substr(number.indexOf('.')) : ''
      cents = cents.length > 1 ? cents : ''

      number = number.indexOf('.') > 0 ? number.substring(0, (number.indexOf('.'))) : number

      if (cents === '') {
        if (number.length > 1 && number.substr(0, 1) === '0') {
          return num
        }
      } else {
        if (number.length > 1 && number.substr(0, 1) === '0') {
          return num
        }
      }

      let tempNum = ''
      while (number.length > 3) {
        tempNum = ',' + number.slice(-3) + tempNum
        number = number.slice(0, number.length - 3)
      }
      if (number) {
        tempNum = number + tempNum
      }

      return (sign + tempNum + cents)
    } else {
      return 0
    }
  },
  pad (num, size) {
    const str = String(num)
    return new Array(size - str.length + 1).join('0') + str
  },
  optionName (label, value, addPrice) {
    const labels = label.split('|')
    const values = value.split('|')
    if (labels.length && values.length && labels.length === values.length) {
      let optionNm = ''
      labels.forEach((item, index) => {
        if (index > 0) {
          optionNm += ' / '
        }
        optionNm = optionNm + item + ':' + values[index]
      })
      if (addPrice) {
        let tempAddPrice = addPrice > 0 ? `+${this.formatNumber(addPrice)}` : `${this.formatNumber(addPrice)}`
        optionNm += ` (${tempAddPrice}원)`
      }
      return optionNm
    }
    return ''
  },
  dispManageCode (manageCode) {
    if (manageCode !== null && manageCode !== '' && manageCode !== undefined) {
      return `(${manageCode})`
    }
    return ''
  },
  subContent (str) {
    let titles = str.split('\n')
    let firstTitle = ''
    if (titles.length > 1) {
      firstTitle = titles.find(item => item !== '')
    } else {
      firstTitle = titles[0]
    }
    if (firstTitle.length > 20) {
      return firstTitle.substring(0, 19) + '...'
    }
    return firstTitle
  }
}

Object.keys(filters).forEach(name => Vue.filter(name, filters[name]))

export default filters
