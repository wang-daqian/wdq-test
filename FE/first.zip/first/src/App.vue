<template>
  <div id="wrap">
    <router-view name="header" :displayMode="displayMode" />
    <router-view :displayMode="displayMode" />
    <router-view name="footer" />
    <div id="layerDim" :class="showLayerBg ? '' : 'dn'">&nbsp;</div>
  </div>
</template>

<script>
import { mapState } from 'vuex'
import { isPC } from '@/utils/utils'

export default {
  name: 'app',
  data () {
    return {
      displayMode: isPC() ? 'PC' : 'MO'
    }
  },
  metaInfo: {
    titleTemplate: (titleChunk) => {
      return titleChunk ? `${titleChunk} : intro` : 'intro'
    }
  },
  computed: {
    ...mapState(['showLayerBg'])
  },
  methods: {
    hiddenLayer () {
      this.$store.commit('HIDDEN_LAYER_BG')
    }
  },
  watch: {
    '$route': 'hiddenLayer'
  }
}
</script>

<style lang="scss">
/*! 스타일 모듈 */
@import "./assets/css/reset.css";
@import "./assets/css/common/common.css";
@import "./assets/css/common/layer/layer.css";
@import "./assets/css/layout/layout.css";
@import "./assets/css/board/board.css";
@import "./assets/css/event/event.css";
@import "./assets/css/goods/list.css";
@import "./assets/css/goods/goods.css";
@import "./assets/css/main/main.css";
@import "./assets/css/member/member.css";
@import "./assets/css/member/responsive-style.css";
@import "./assets/css/mypage/mypage.css";
@import "./assets/css/order/order.css";
@import "./assets/css/plugins/bootstrap-datetimepicker-standalone.css";
@import "./assets/css/plugins/bootstrap-datetimepicker-standalone.min.css";
@import "./assets/css/plugins/bootstrap-datetimepicker.css";
@import "./assets/css/plugins/bootstrap-datetimepicker.min.css";
@import "./assets/css/service/service.css";
@import "./assets/css/button.css";
@import "./assets/css/codefix.css";
@import "./assets/css/error.css";
@import "./assets/css/custom.css";
@import "./assets/css/chosen.css";
@import "./assets/css/member/agreement.css";
@import "./assets/css/pop.css";
</style>
<style>
.overflow_hidden {
  position: fixed;
  left: 0;
  width: 100%;
  overflow-y: scroll;
}
</style>
