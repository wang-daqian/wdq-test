import Vue from 'vue'
const postClick = {
  bind (el, binding, vnode) {
    el.addEventListener(
      'click',
      function () {
        const ret = binding.value.args
          ? binding.value.fn(binding.value.args)
          : binding.value.fn()
        if (ret) {
          el.disabled = true
          if (!window.works) {
            window.works = {}
          }
          window.works[binding.value.actionid] = function () {
            el.disabled = false
          }
        }
      },
      false
    )
  }
}

export const directive = () => {
  Vue.directive('post-click', postClick)
}
