// import HeaderError from '../views/layout/HeaderError.vue'
import MainHeader from '../views/layout/Header.vue'
import SiteFooter from '../views/layout/Footer.vue'
import MainHome from '../views/main/MainHome.vue'
import NotFound from '../views/etc/NotFound.vue'
import Intro from '../views/etc/Intro.vue'
import JoinAgreement from '../views/member/JoinAgreement.vue'
import TermsUseDetail from '../views/member/TermsUseDetail.vue'
import TermsElecFinaTransac from '../views/member/TermsElecFinaTransac.vue'
import CollectInfoDetail from '../views/member/CollectInfoDetail.vue'
import AgreementFour from '../views/member/AgreementFour.vue'
import AgreementFive from '../views/member/AgreementFive.vue'
import Join from '../views/member/Join.vue'
import Login from '../views/member/Login.vue'
import FindID from '../views/member/FindID.vue'
import Password from '../views/member/PasswordChange.vue'
import PasswordCertiSelect from '../views/member/PasswordCertiSelect.vue'
import PasswordCerti from '../views/member/PasswordCerti.vue'
import PasswordReset from '../views/member/PasswordReset.vue'
import Passwordcomplete from '../views/member/PasswordComplete.vue'
import CategoryList from '../views/goods/CategoryList.vue'
import SearchList from '../views/goods/SearchList.vue'
import GoodsView from '../views/goods/View.vue'
import BeforeOrder from '../views/order/order/BeforeOrder.vue'
import MyPage from '../views/mypage/index.vue'
import MOrderItems from '../views/mypage/order/MOrderItems.vue'
import OrderList from '../views/mypage/order/OrderList.vue'
import CancelList from '../views/mypage/order/CancelList.vue'
import OrderDetail from '../views/mypage/order/OrderDetail.vue'
import NonMemberOrderDetail from '../views/mypage/order/nonMember/OrderDetail.vue'
import NonMemberCancel from '../views/mypage/order/nonMember/OrderClaimCancel.vue'
import NonMemberOrderAllCancel from '../views/mypage/order/nonMember/OrderAllCancel.vue'
import NonMemberReturn from '../views/mypage/order/nonMember/OrderClaimReturn.vue'
import WishList from '../views/mypage/order/WishList.vue'
import Coupon from '../views/mypage/benefitmgmt/Coupon.vue'
import ValidCoupon from '../views/mypage/benefitmgmt/ValidCoupon.vue'
import NoValidCoupon from '../views/mypage/benefitmgmt/NoValidCoupon.vue'
import MileageList from '../views/mypage/benefitmgmt/MileageList.vue'
import Inquiries from '../views/mypage/inquiry/Inquiries.vue'
import SignInInquiry from '../views/mypage/inquiry/SignInInquiry.vue'
import InquiryDetail from '../views/mypage/inquiry/InquiryDetail.vue'
import WithDrawal from '../views/mypage/member/WithDrawal.vue'
import MemberPwdCheck from '../views/mypage/member/MemberPwdCheck.vue'
import MemberChange from '../views/mypage/member/MemberChange.vue'
import MemberShipping from '../views/mypage/member/MemberShipping.vue'
import ProductSignInInquiry from '../views/mypage/product/SignInInquiry.vue'
import ProductInquiries from '../views/mypage/product/Inquiries.vue'
import ProductInquiryDetail from '../views/mypage/product/InquiryDetail.vue'
import ProductReviews from '../views/mypage/product/Reviews.vue'
import SignInReview from '../views/mypage/product/SignInReview.vue'
import ProductReviewDetail from '../views/mypage/product/ReviewDetail.vue'
import Cart from '../views/order/cart/CartIndex.vue'
import PaymentConfirm from '../views/order/order/PaymentConfirm.vue'
import OrderSheet from '../views/order/order/OrderSheet.vue'
import Dashboard from '../views/mypage/dashboard/index.vue'
import OrderClaimCancel from '../views/mypage/order/OrderClaimCancel.vue'
import OrderAllCancel from '../views/mypage/order/OrderAllCancel.vue'
import OrderClaimReturn from '../views/mypage/order/OrderClaimReturn.vue'
import Company from '../views/etc/Company.vue'
import Online from '../views/etc/Online.vue'
import Agreement from '../views/etc/Agreement.vue'
import Private from '../views/etc/Private.vue'
import Center from '../views/etc/center/Main.vue'
import FAQ from '../views/etc/center/faq/Faq.vue'
import Notice from '../views/etc/center/notice/Notice.vue'
import NoticeDetail from '../views/etc/center/notice/NoticeDetail.vue'
import Store from '../views/etc/center/store/Store.vue'
import StoreDetail from '../views/etc/center/store/StoreDetail.vue'
import EventDetail from '../views/event/EventDetail.vue'

export default [
  {
    path: '/',
    name: 'MainHome',
    components: {
      default: MainHome,
      header: MainHeader,
      footer: SiteFooter
    }
  },
  {
    path: '/frenchcat',
    name: 'FrenchCat',
    components: {
      default: MainHome,
      header: MainHeader,
      footer: SiteFooter
    }
  },
  {
    path: '/tiffany',
    name: 'Tiffany',
    components: {
      default: MainHome,
      header: MainHeader,
      footer: SiteFooter
    }
  },
  {
    path: '/elecone',
    name: 'Elecone',
    components: {
      default: MainHome,
      header: MainHeader,
      footer: SiteFooter
    }
  },
  {
    path: '/guesskids',
    name: 'GuessKids',
    components: {
      default: MainHome,
      header: MainHeader,
      footer: SiteFooter
    }
  },
  {
    path: '/nubaby',
    name: 'Nubaby',
    components: {
      default: MainHome,
      header: MainHeader,
      footer: SiteFooter
    }
  },
  {
    path: '/member/joinagreement',
    name: 'JoinAgreement',
    components: {
      default: JoinAgreement,
      header: MainHeader,
      footer: SiteFooter
    }
  },
  {
    path: '/member/agreement1',
    name: 'Agreement1',
    components: {
      default: TermsUseDetail,
      header: MainHeader,
      footer: SiteFooter
    }
  },
  {
    path: '/member/agreement2',
    name: 'Agreement2',
    components: {
      default: TermsElecFinaTransac,
      header: MainHeader,
      footer: SiteFooter
    }
  },
  {
    path: '/member/agreement3',
    name: 'Agreement3',
    components: {
      default: CollectInfoDetail,
      header: MainHeader,
      footer: SiteFooter
    }
  },
  {
    path: '/member/agreement4',
    name: 'Agreement4',
    components: {
      default: AgreementFour,
      header: MainHeader,
      footer: SiteFooter
    }
  },
  {
    path: '/member/agreement5',
    name: 'Agreement5',
    components: {
      default: AgreementFive,
      header: MainHeader,
      footer: SiteFooter
    }
  },
  {
    path: '/member/join',
    name: 'Join',
    components: {
      default: Join,
      header: MainHeader,
      footer: SiteFooter
    }
  },
  {
    path: '/member/login',
    name: 'Login',
    components: {
      default: Login,
      header: MainHeader,
      footer: SiteFooter
    }
  },
  {
    path: '/member/findid',
    // name: 'FindID',
    components: {
      default: FindID,
      header: MainHeader,
      footer: SiteFooter
    }
  },
  {
    path: '/member/password',
    // name: 'Password',
    components: {
      default: Password,
      header: MainHeader,
      footer: SiteFooter
    }
  },
  {
    path: '/member/passwordciselect',
    // name: 'PasswordCertiSelect',
    components: {
      default: PasswordCertiSelect,
      header: MainHeader,
      footer: SiteFooter
    }
  },
  {
    path: '/member/passwordcerti',
    // name: 'PasswordCerti',
    components: {
      default: PasswordCerti,
      header: MainHeader,
      footer: SiteFooter
    }
  },
  {
    path: '/member/passwordreset',
    // name: 'PasswordReset',
    components: {
      default: PasswordReset,
      header: MainHeader,
      footer: SiteFooter
    }
  },
  {
    path: '/member/passwordcomplete',
    // name: 'Passwordcomplete',
    components: {
      default: Passwordcomplete,
      header: MainHeader,
      footer: SiteFooter
    }
  },
  /** order */
  {
    path: '/order/getsheetno',
    name: 'BeforeOrder',
    components: {
      default: BeforeOrder
    }
  },
  {
    path: '/order/:orderSheetNo(\\d+)',
    name: 'OrderSheet',
    components: {
      default: OrderSheet,
      header: MainHeader,
      footer: SiteFooter
    }
  },
  {
    path: '/order/paymentconfirm',
    name: 'PaymentConfirm',
    components: {
      default: PaymentConfirm,
      header: MainHeader,
      footer: SiteFooter
    },
    meta: {
      action: true
    }
  },
  {
    path: '/order/paymentconfirm/guest',
    name: 'PaymentConfirmNonMember',
    components: {
      default: PaymentConfirm,
      header: MainHeader,
      footer: SiteFooter
    }
  },
  {
    path: '/:brandName/categorylist/:brandNo/:depth1/:depth2?/:depth3?',
    name: 'CategoryList',
    components: {
      default: CategoryList,
      header: MainHeader,
      footer: SiteFooter
    }
  },
  {
    path: '/:brandName?/goods/view/:productNo(\\d+)',
    name: 'GoodsView',
    components: {
      default: GoodsView,
      header: MainHeader,
      footer: SiteFooter
    }
  },
  {
    path: '/searchlist',
    name: 'SearchList',
    components: {
      default: SearchList,
      header: MainHeader,
      footer: SiteFooter
    }
  },
  {
    path: '/order/cart',
    name: 'Cart',
    components: {
      default: Cart,
      header: MainHeader,
      footer: SiteFooter
    }
  },
  {
    path: '/nonmember/orderdetail/:orderNo(\\d+)',
    name: 'NonMemberOrderDetail',
    components: {
      default: NonMemberOrderDetail,
      header: MainHeader,
      footer: SiteFooter
    }
  },
  {
    path: '/nonmember/cancel/:orderOptionNo(\\d+)',
    name: 'NonMemberCancel',
    components: {
      default: NonMemberCancel,
      header: MainHeader,
      footer: SiteFooter
    },
    meta: {
      action: true
    }
  },
  {
    path: '/nonmember/ordercancel/:OrderClaimCancel(\\d+)',
    name: 'NonMemberOrderAllCancel',
    components: {
      default: NonMemberOrderAllCancel,
      header: MainHeader,
      footer: SiteFooter
    },
    meta: {
      action: true
    }
  },
  {
    path: '/nonmember/return/:orderOptionNo(\\d+)',
    name: 'NonMemberReturn',
    components: {
      default: NonMemberReturn,
      header: MainHeader,
      footer: SiteFooter
    },
    meta: {
      action: true
    }
  },
  {
    path: '/mypage',
    name: 'Mypage',
    components: {
      default: MyPage,
      header: MainHeader,
      footer: SiteFooter
    },
    meta: {
      needAuth: true
    },
    children: [
      {
        path: '',
        name: 'Dashboard',
        component: Dashboard,
        meta: {
          needAuth: true
        }
      },
      {
        path: 'orderlist',
        components: {
          default: MOrderItems,
          header: MainHeader,
          footer: SiteFooter
        },
        meta: {
          needAuth: true
        },
        children: [
          {
            path: '/',
            name: 'OrderList',
            component: OrderList,
            meta: {
              needAuth: true
            }
          },
          {
            path: 'cancellist',
            name: 'CancelList',
            component: CancelList,
            meta: {
              needAuth: true
            }
          }
        ]
      },
      {
        path: 'orderdetail/:orderNo(\\d+)',
        name: 'OrderDetail',
        component: OrderDetail,
        meta: {
          needAuth: true
        }
      },
      {
        path: 'cancel/:orderOptionNo(\\d+)',
        name: 'OrderClaimCancel',
        components: {
          default: OrderClaimCancel,
          header: MainHeader,
          footer: SiteFooter
        },
        meta: {
          needAuth: true
        }
      },
      {
        path: 'ordercancel/:OrderClaimCancel(\\d+)',
        name: 'OrderAllCancel',
        components: {
          default: OrderAllCancel,
          header: MainHeader,
          footer: SiteFooter
        },
        meta: {
          needAuth: true
        }
      },
      {
        path: 'return/:orderOptionNo(\\d+)',
        name: 'OrderClaimReturn',
        components: {
          default: OrderClaimReturn,
          header: MainHeader,
          footer: SiteFooter
        },
        meta: {
          needAuth: true
        }
      },
      {
        path: 'wishlist',
        name: 'WishList',
        component: WishList,
        meta: {
          needAuth: true
        }
      },
      {
        path: 'coupon',
        components: {
          default: Coupon,
          header: MainHeader,
          footer: SiteFooter
        },
        meta: {
          needAuth: true
        },
        children: [
          {
            path: '/',
            name: 'ValidCoupon',
            component: ValidCoupon,
            meta: {
              needAuth: true
            }
          },
          {
            path: 'novalidcoupon',
            name: 'NoValidCoupon',
            component: NoValidCoupon,
            meta: {
              needAuth: true
            }
          }
        ]
      },
      {
        path: 'mileagelist',
        name: 'MileageList',
        component: MileageList,
        meta: {
          needAuth: true
        }
      },
      {
        path: 'profile/inquiries',
        name: 'Inquiries',
        component: Inquiries,
        meta: {
          needAuth: true
        }
      },
      {
        path: 'profile/signininquiry',
        name: 'SignInInquiry',
        component: SignInInquiry,
        meta: {
          needAuth: true
        }
      },
      {
        path: 'profile/inquiries/:inquiryNo(\\d+)',
        name: 'InquiryDetail',
        component: InquiryDetail,
        meta: {
          needAuth: true
        }
      },
      {
        path: 'profile/inquirymodify/:inquiryNo(\\d+)',
        name: 'InquiryModify',
        component: SignInInquiry,
        meta: {
          needAuth: true
        }
      },
      {
        path: 'member/withdrawal',
        name: 'WithDrawal',
        component: WithDrawal,
        meta: {
          needAuth: true
        }
      },
      {
        path: 'member/memberpwdcheck',
        name: 'MemberPwdCheck',
        component: MemberPwdCheck,
        meta: {
          needAuth: true
        }
      },
      {
        path: 'member/memberchange',
        name: 'MemberChange',
        component: MemberChange,
        meta: {
          needAuth: true,
          needPwdAuth: true
        }
      },
      {
        path: 'member/membershipping',
        name: 'MemberShipping',
        component: MemberShipping,
        meta: {
          needAuth: true
        }
      },
      {
        path: 'product/signininquiry',
        name: 'ProductSignInInquiry',
        component: ProductSignInInquiry,
        meta: {
          needAuth: true
        }
      },
      {
        path: 'product/inquiries',
        name: 'ProductInquiries',
        component: ProductInquiries,
        meta: {
          needAuth: true
        }
      },
      {
        path: 'product/:productNo(\\d+)/inquiries/:inquiryNo(\\d+)',
        name: 'ProductInquiryDetail',
        component: ProductInquiryDetail,
        meta: {
          needAuth: true
        }
      },
      {
        path: 'productInquirymodify/:productNo(\\d+)/inquiries/:inquiryNo(\\d+)',
        name: 'ProductInquiryModify',
        component: ProductSignInInquiry,
        meta: {
          needAuth: true
        }
      },
      {
        path: 'product/reviews',
        name: 'ProductReviews',
        component: ProductReviews,
        meta: {
          needAuth: true
        }
      },
      {
        path: 'product/signinreview',
        name: 'ProductSignInReview',
        component: SignInReview,
        meta: {
          needAuth: true
        }
      },
      {
        path: 'product/:productNo(\\d+)/product-reviews/:reviewNo(\\d+)',
        name: 'ProductReviewDetail',
        component: ProductReviewDetail,
        meta: {
          needAuth: true
        }
      },
      {
        path: 'productmodifyreview/:productNo(\\d+)/product-reviews/:reviewNo(\\d+)',
        name: 'ProductModifyReview',
        component: SignInReview,
        meta: {
          needAuth: true
        }
      }
    ]
  },
  {
    path: '/etc/company',
    name: 'Company',
    components: {
      default: Company,
      header: MainHeader,
      footer: SiteFooter
    }
  },
  {
    path: '/etc/online',
    name: 'Online',
    components: {
      default: Online,
      header: MainHeader,
      footer: SiteFooter
    }
  },
  {
    path: '/etc/agreement',
    name: 'Agreement',
    components: {
      default: Agreement,
      header: MainHeader,
      footer: SiteFooter
    }
  },
  {
    path: '/etc/private',
    name: 'Private',
    components: {
      default: Private,
      header: MainHeader,
      footer: SiteFooter
    }
  },
  {
    path: '/etc/center',
    redirect: '/etc/center/notice',
    components: {
      default: Center,
      header: MainHeader,
      footer: SiteFooter
    },
    children: [
      {
        path: 'faq',
        alias: 'faq/search',
        name: 'FAQ',
        component: FAQ
      },
      {
        path: 'notice',
        name: 'Notice',
        component: Notice
      },
      {
        path: 'notice/:articleNo(\\d+)',
        name: 'NoticeDetail',
        component: NoticeDetail
      },
      {
        path: 'store',
        name: 'Store',
        component: Store
      },
      {
        path: 'store/:articleNo(\\d+)',
        name: 'StoreDetail',
        component: StoreDetail
      }
    ]
  },
  {
    path: '/event/:eventNo',
    name: 'Event',
    components: {
      default: EventDetail,
      header: MainHeader,
      footer: SiteFooter
    }
  },
  {
    path: '/intro',
    components: {
      default: Intro
    }
  },
  {
    path: '/*',
    name: 'NotFound',
    components: {
      default: NotFound
    }
  }
]
