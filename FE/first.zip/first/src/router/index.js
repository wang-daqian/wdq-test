import Vue from 'vue'
import Router from 'vue-router'
import Meta from 'vue-meta'
import { scrollBehavior } from './utils'
import { beforeJob, needPwdAuth, loadAceCounter, loadTGScript } from './hooks'
import routes from './routes'

Vue.use(Router)
Vue.use(Meta)

const router = new Router({
  mode: 'history',
  scrollBehavior,
  routes
})

router.beforeEach(beforeJob)
router.beforeEach(needPwdAuth)
router.afterEach(loadAceCounter)
router.afterEach(loadTGScript)
// router.afterEach(resetSearchWordInfo)

export default router
