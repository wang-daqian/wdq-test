import { isLogin, scriptLoader } from '@/utils/utils'

export function beforeJob (to, from, next) {
  if (to.meta.needAuth && !isLogin()) {
    next({
      path: '/member/login',
      query: {
        redirect: to.fullPath
      }
    })
  } else {
    next()
  }
}

export function needPwdAuth (to, from, next) {
  if (to.meta.needPwdAuth && from.name !== 'MemberPwdCheck') {
    next({
      path: '/mypage/member/memberpwdcheck'
    })
  } else {
    next()
  }
}

/* Loading the script in every page */
export function loadAceCounter (to, from) {
  /* eslint-disable */

  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-152935519-1')
  /*
  var _AceTM = (_AceTM || {});
  if (cookies.get('ncpAccessToken') && cookies.get('ncpAccessToken').length > 0) {
    store.dispatch('profile/getProfileForAceTM').then(res => {
      _AceTM.Login = {
        uID: res.uID, 	// 로그인사용자 고유값
        uAge: res.uAge,   	// 로그인사용자 나이
        uGender: res.uGender, // 로그인사용자 성별(man | woman)
        uGroup1: '',	// 사용자 정의변수 1 ( 1 ~ 10 정수값)
        uGroup2: '',	// 사용자 정의변수 2 ( 1 ~ 10 정수값)
        uGroup3: ''	// 사용자 정의변수 3 ( 1 ~ 10 정수값)
      }
    })
  }
  */
  // <!--AceCounter Plus Login variable End -->
}

export function loadTGScript () {
  window.wptg_tagscript_vars = window.wptg_tagscript_vars || []
  if (window.wptg_tagscript_vars && window.wptg_tagscript_vars.length === 0) {
    window.wptg_tagscript_vars.push(function () {
      return {
        wp_hcuid: wpHcuid(), /* 고객넘버 등 Unique ID (ex. 로그인  ID, 고객넘버 등 )를 암호화하여 대입.  *주의 : 로그인 하지 않은 사용자는 어떠한 값도 대입하지 않습니다. */
        ti: '25725', /* 광고주 코드 */
        ty: 'Home', /* 트래킹태그 타입 */
        device: deviceType() /* 디바이스 종류  (web 또는  mobile) */
      }
    })
  }
  scriptLoader('//cdn-aitg.widerplanet.com/js/wp_astg_4.0.js').then(() => {
    if (window.wptg_tagscript_history) {
      window.wptg_tagscript_history.history_peak = {}
      window.wptg_tagscript_history.history_ty = {}
    }
    if (window.wptg_tagscript) {
      window.wptg_tagscript.exec()
    }
  })
}

export function wpHcuid() {
  var wp_hcuid = "";
  var arrstr = document.cookie.split("; ");
  for(var i = 0;i < arrstr.length;i ++){
    var temp = arrstr[i].split("=");
    if(temp[0] == "FstAppShowMemberID") {
      wp_hcuid = unescape(temp[1]);
    }
  }
  return wp_hcuid
}
export function deviceType() {
  if (/(iPhone|iPad|iPod|iOS|Android)/i.test(navigator.userAgent)) {
    return "mobile"
  } else {
    return "web"
  }
}
