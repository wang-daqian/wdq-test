export function scrollBehavior (to, from, savedPosition) {
  // if (to.meta.keepScroll && from.meta.keepScroll) {
  //   return null
  // }
  if (savedPosition) {
    to.meta.savedPosition = savedPosition
    return savedPosition
  }
  if (to.hash) {
    const position = {}
    position.selector = to.hash

    // const productHash = ['#item_detail', '#item_exchange', '#item_reviews', '#item_qna']
    // if (productHash.some(item => item === to.hash) || to.hash.indexOf('#category') === 0) {
    //   position.offset = {
    //     y: $('#header_warp').height()
    //   }
    // }
    return position
  }
  return { x: 0, y: 0 }
}
